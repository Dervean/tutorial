# Aram

## 本地环境配置

``` bash
# Zebra
# /data/webapps/appenv
env=test
deployenv=qa
zkserver=lion-zk.test.vip.sankuai.com:2181
# /data/appdatas/cat/client.xml
<config>
  <servers>
    <server ip="10.72.204.18" port="2280" />
    <server ip="10.72.204.19" port="2280" />
    <server ip="10.72.234.28" port="2280" />
  </servers>
</config>
```

## 本地启动

``` bash
# 安装依赖
npm install

# 本地开发启动
npm run serve

# 测试
npm run test

# 代码格式化
npm run prettier
```

## 发布

[Talos](https://talos.sankuai.com/#/project/9452/deploy)

## 日志查询

- [Nest 平台测试环境](https://nest.inf.test.sankuai.com/#/service/com.sankuai.aram/)

- [Nest 平台线上环境](https://nest.sankuai.com/#/service/com.sankuai.aram/)

- [美团日志中心测试环境](http://logcenter.test.data.sankuai.com/log)

- [美团日志中心线上环境](http://logcenter.data.sankuai.com/log)

- 跳板机

  - 启动日志：/data/applogs/hulk_start_log.*

  - 业务日志目录：/opt/logs/{appKey}/

    - `sudo -iu sankuai` 后查看业务日志 `aram.customize.log`

  - Nest Runtime 日志目录：/opt/logs/nest/runtime/​

## 目录结构

``` bash
├── jest                    jest 脚本
│   ├── setup.ts
│   └── teardown.ts
├── src                     
│   ├── aram-app            controller
│   ├── aram-base           dao
│   ├── aram-biz            service
│   ├── aram-lib            lib
│   └── aram-out            外接服务
├── README.md               🍺
├── index.ts                nest entry    
├── jest.config.ts          jest config
├── nest.yml                nest config
├── package.json            🍃
├── setup.ts                some stuff during bootstrap
└── tsconfig.json           typescript config
```

# Nest Koa TS 模板
**目录介绍**

*- deploy*  
&ensp;&ensp;&ensp;&ensp; deploy 目录为打包、部署脚本所在目录。  
*- server*  
&ensp;&ensp;&ensp;&ensp;*- controller*  
&ensp;&ensp;&ensp;&ensp;*- db*  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; Database 相关目录。  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; 1. zebra-sequelize-client 接入文档：https://km.sankuai.com/page/181228208  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; 2. zebra-typeorm-client 接入文档：https://km.sankuai.com/page/271208342  
&ensp;&ensp;&ensp;&ensp;*- service*  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; service 目录。包含 mafka、RPC、daxiang 的基本使用。  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; 1. mafka mafka：相关文档 https://km.sankuai.com/page/161213651 **注意：Node 14+ 版本 Mafka SDK 可能存在类型定义问题**    
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; 2. RPC RPC 采用公司内统一框架 Node Thrift。相关文档见下文 thrfit 目录说明。  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; 3. daxiang 相关文档：http://npm.sankuai.com/package/@mtfe/daxiang  
&ensp;&ensp;&ensp;&ensp;*- routes*  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; koa router 目录  
&ensp;&ensp;&ensp;&ensp;*- view*  
&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;view 目录为 ejs 文件所在目录。**注意：静态资源编译时不会放到build目录下，需注意引用路径问题**  
*- test*  
&ensp;&ensp;&ensp;&ensp;test 目录为单测目录，采用了 jest 和 supertest。包含了:  
&ensp;&ensp;&ensp;&ensp;1. 基础的 koa server 是否启动成功单测  
&ensp;&ensp;&ensp;&ensp;2. 基础的 koa server 请求单测  
&ensp;&ensp;&ensp;&ensp;service 相关单测需要业务方按需编写  
*- thrift*  
&ensp;&ensp;&ensp;&ensp; thrift 目录为 Node Thrift IDL 文件的定义目录。Node RPC 具体使用可以参考文档:  
&ensp;&ensp;&ensp;&ensp;1. 快速入门：https://km.sankuai.com/page/431205856  
&ensp;&ensp;&ensp;&ensp;2. 官方文档： https://docs.sankuai.com/mt/fe/ thrift/master/  
&ensp;&ensp;&ensp;&ensp;3. Demo 仓库：https://dev.sankuai.com/code/repo-detail/bfe/node-thrift-demo/file/list  
*- types*  
&ensp;&ensp;&ensp;&ensp; types 目录为 Typescript 类型定义目录。

*- package.json*  
&ensp;&ensp;&ensp;&ensp;使用 Nest 平台依赖：
```
  "ecfDependencies": {
    "@fdfe/ecf-platform-era-basic-deps": "^1.0.0"
  },
```
&ensp;&ensp;&ensp;&ensp;平台依赖文档：https://km.sankuai.com/page/1200793195  
**附录**  
nest.yml 结构说明：https://km.sankuai.com/page/198087574  
SSO 接入最佳实践：https://km.sankuai.com/page/1202110648  
