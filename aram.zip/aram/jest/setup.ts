import { addAlias } from 'module-alias'
import { posix } from 'path'

module.exports = async () => {
  process.env.ARAM_RUNTIME_ENV = 'jest'
  await addAlias('~', posix.join(__dirname, '..', 'src'))
}
