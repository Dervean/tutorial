import { addAlias } from 'module-alias'
import { posix } from 'path'
addAlias('~', posix.join(__dirname, 'src'))

import koaAdapter from '@fdfe/ecf-http-adapter'
import { app, setup } from '~/aram-app/app'

setup()

export const main = koaAdapter(app, {
  injectLogger: true,
})
