import Koa from 'koa'
import router from '~/aram-app/routes'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { AramConfiguration } from '~/aram-biz/context/aram-configuration'
import { FlowConfiguration } from '~/aram-flow/context/flow-configuration'
import { AramLogger } from '~/aram-lib/model/aram-logger'

const setup = async () => {
  await AbstractDAO.initConnection()
  await new AramConfiguration().buildAramEngine()
  await new FlowConfiguration().buildFlowEngine()
  AramLogger.logInfo(`system setup successfully`)
}

const app = new Koa()
app.use(router.routes())
app.use(router.allowedMethods())

export { app, setup }
