import { Context } from 'koa'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { ParamChecker } from '~/aram-biz/model/param-checker'

class SystemController extends AbstractController {
  /** @todo 存量 CDN 数据迁移接口 后续下线 */
  static async handlePostV1SystemBatchCDNMigration(ctx: Context) {
    try {
      await SystemController.setup(ctx)
      const payload: { projectIdList: AramIdType[] } = NestEventHelper.unifyPostRequestBody()
      const { projectIdList } = payload

      ParamChecker.checkAramIdList(projectIdList)

      await SystemController.engine.system().batchMigrateAramS3(projectIdList)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SystemController.errorHandler(ctx, error)
    }
  }
}

export const handlePostV1SystemBatchCDNMigration = SystemController.handlePostV1SystemBatchCDNMigration
