import { Context } from 'koa'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'

export abstract class AbstractController {
  static setup(ctx: Context) {
    NestEventHelper.setup(ctx)
  }

  static get engine() {
    return AramServiceContext.engine
  }

  static errorHandler(ctx: Context, error: Error) {
    const response = new AramHttpResponse(error)
    return response.build(ctx)
  }
}
