import { Context } from 'koa'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import * as HTTP from '~/aram-lib/constants/http'

class AdminController extends AbstractController {
  static async handleGetV1AdminLogin(ctx: Context) {
    try {
      AdminController.setup(ctx)
      const adminAuthRes = await AdminController.engine.admin().adminLoginAuthenticate()

      const response = new AramHttpResponse()
      if (adminAuthRes) {
        const { adminToken, expiresTime } = adminAuthRes
        response.setMessage('超级管理员登录成功')
        response.setHeader(HTTP.HeaderEnum.Set_Cookie, `admin_token=${adminToken}; path=/; Expires=${expiresTime}; HttpOnly; Secure; SameSite=none`)
      } else {
        response.setMessage('不是系统管理员，登录失败')
      }
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return AdminController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1AdminLogin = AdminController.handleGetV1AdminLogin
