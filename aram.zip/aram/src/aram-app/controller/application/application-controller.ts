import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramPageParams } from '~/aram-lib/model/aram-page'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramApplication } from '~/aram-base/entities/aram-application'

class ApplicationController extends AbstractController {
  /**
   * 获取应用详情
   */
  static async handleGetV1ApplicationGet(ctx: Context) {
    type PayloadType = Pick<AramApplication, 'appUid'>

    try {
      await ApplicationController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyGetRequestQuery()
      const { appUid } = payload

      ParamChecker.checkAramUid(appUid)

      const result = await ApplicationController.engine.application().getActiveApplication(appUid)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ApplicationController.errorHandler(ctx, error)
    }
  }

  /**
   * 获取应用列表
   */
  static async handleGetV1ApplicationList(ctx: Context) {
    try {
      await ApplicationController.setup(ctx)

      const payload: AramPageParams & Pick<AramApplication, 'status'> = NestEventHelper.unifyGetRequestQuery()
      const { pageNum = 1, pageSize = 10, status } = payload

      const result = await ApplicationController.engine.application().searchApplicationList({ pageNum: +pageNum, pageSize: +pageSize }, status)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ApplicationController.errorHandler(ctx, error)
    }
  }

  /**
   * 创建应用
   */
  static async handlePostV1ApplicationCreate(ctx: Context) {
    type PayloadType = Pick<AramApplication, 'appUid' | 'appName' | 'ext' | 'hooks' | 'description'>

    try {
      await ApplicationController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { appUid, appName, ext, hooks, description } = payload

      ParamChecker.checkAppName(appName)
      ParamChecker.checkAramUid(appUid)

      const result = await ApplicationController.engine.application().createApplication({
        appUid,
        appName,
        ext,
        hooks,
        description,
      })
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ApplicationController.errorHandler(ctx, error)
    }
  }

  /**
   * 编辑应用
   */
  static async handlePostV1ApplicationEdit(ctx: Context) {
    type PayloadType = Pick<AramApplication, 'appUid' | 'appName' | 'ext' | 'hooks' | 'description'>

    try {
      await ApplicationController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { appUid, appName, ext, hooks, description } = payload

      ParamChecker.checkAppName(appName)

      await ApplicationController.engine.application().updateApplicationInfo({
        appUid,
        appName,
        ext,
        hooks,
        description,
      })
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ApplicationController.errorHandler(ctx, error)
    }
  }

  /**
   * 下线应用
   */
  static async handlePostV1ApplicationOffline(ctx: Context) {
    type PayloadType = Pick<AramApplication, 'appUid'>

    try {
      await ApplicationController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { appUid } = payload

      ParamChecker.checkAramUid(appUid)

      await ApplicationController.engine.application().offlineApplication({ appUid })
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ApplicationController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1ApplicationGet = ApplicationController.handleGetV1ApplicationGet
export const handleGetV1ApplicationList = ApplicationController.handleGetV1ApplicationList
export const handlePostV1ApplicationCreate = ApplicationController.handlePostV1ApplicationCreate
export const handlePostV1ApplicationEdit = ApplicationController.handlePostV1ApplicationEdit
export const handlePostV1ApplicationOffline = ApplicationController.handlePostV1ApplicationOffline
