import { Context } from 'koa'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { OrgEmpInfo } from '~/aram-out/org/org-employee-service'

class CommonController extends AbstractController {
  /** generate s3 token for post uploading */
  static async handleGetV1CommonS3GenToken(ctx: Context) {
    try {
      await CommonController.setup(ctx)
      const token = await CommonController.engine.s3Token().genPostToken('')
      const response = new AramHttpResponse(token)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return CommonController.errorHandler(ctx, error)
    }
  }

  /** return user info (sso) */
  static async handleGetV1CommonUserInfo(ctx: Context) {
    try {
      await CommonController.setup(ctx)
      const { userName, displayName } = await NestEventHelper.user()
      const response = new AramHttpResponse({ userName, displayName })
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return CommonController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1CommonORGEmpSearch(ctx: Context) {
    try {
      await CommonController.setup(ctx)
      const payload: { keyword: string } = NestEventHelper.unifyGetRequestQuery()
      const { keyword } = payload
      let data: OrgEmpInfo[] = null
      if (escape(keyword).includes('%u')) {
        data = await CommonController.engine.org().searchByEmpName(keyword)
      } else {
        data = await CommonController.engine.org().searchByEmpMis(keyword)
      }
      const response = new AramHttpResponse(data)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return CommonController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1CommonS3GenToken = CommonController.handleGetV1CommonS3GenToken
export const handleGetV1CommonUserInfo = CommonController.handleGetV1CommonUserInfo
export const handleGetV1CommonORGEmpSearch = CommonController.handleGetV1CommonORGEmpSearch
