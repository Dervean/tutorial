import { Context } from 'koa'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { DynaAlert } from '~/aram-base/entities/dyna/dyna-alert'

class DynaAlertController extends AbstractController {
  static async handlePostV1DynaAlertCreate(ctx: Context) {
    type PayloadType = { alert: DynaAlert }

    try {
      await DynaAlertController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { alert } = payload

      ParamChecker.checkJson(alert, { required: true })
      ParamChecker.checkAramId(alert.schemaId)
      ParamChecker.checkUserNameList(alert.notifiers, { required: true })
      alert.remindTime = ParamChecker.checkDate(alert.remindTime, { required: true })

      await DynaAlertController.engine.dynaAlert().createCron(alert)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return DynaAlertController.errorHandler(ctx, error)
    }
  }

  static async handlePostV1DynaAlertUpdate(ctx: Context) {
    type PayloadType = { alert: DynaAlert }

    try {
      await DynaAlertController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { alert } = payload

      ParamChecker.checkJson(alert, { required: true })

      await DynaAlertController.engine.dynaAlert().updateCron(alert)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return DynaAlertController.errorHandler(ctx, error)
    }
  }

  static async handlePostV1DynaAlertCancel(ctx: Context) {
    type PayloadType = { craneTaskId: string }

    try {
      await DynaAlertController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()

      const { craneTaskId } = payload
      ParamChecker.checkString(craneTaskId, { required: true })

      await DynaAlertController.engine.dynaAlert().cancelCron(craneTaskId)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return DynaAlertController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1DynaAlertList(ctx: Context) {
    type PayloadType = { schemaId: AramIdType }

    try {
      await DynaAlertController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const result = await DynaAlertController.engine.dynaAlert().getActiveAlertList(schemaId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return DynaAlertController.errorHandler(ctx, error)
    }
  }
}

export const handlePostV1DynaAlertCreate = DynaAlertController.handlePostV1DynaAlertCreate
export const handlePostV1DynaAlertUpdate = DynaAlertController.handlePostV1DynaAlertUpdate
export const handlePostV1DynaAlertCancel = DynaAlertController.handlePostV1DynaAlertCancel
export const handleGetV1DynaAlertList = DynaAlertController.handleGetV1DynaAlertList
