import { Context } from 'koa'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'

class DynaFormSchemaController extends AbstractController {
  /**
   * 新增表单配置（建立关联）
   */
  static async handlePostV1DynaSchemaLink(ctx: Context) {
    type PayloadType = { schemaId: AramIdType; aramSchemaId: AramIdType }

    try {
      await DynaFormSchemaController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { schemaId, aramSchemaId } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkAramId(aramSchemaId)

      await DynaFormSchemaController.engine.dynaFormSchema().linkAramSchema(schemaId, aramSchemaId)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return DynaFormSchemaController.errorHandler(ctx, error)
    }
  }

  /**
   * 取消关联表单配置
   */
  static async handlePostV1DynaSchemaUnlink(ctx: Context) {
    type PayloadType = { schemaId: AramIdType; aramSchemaId: AramIdType }

    try {
      await DynaFormSchemaController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { schemaId, aramSchemaId } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkAramId(aramSchemaId)

      await DynaFormSchemaController.engine.dynaFormSchema().unlinkAramSchema(schemaId, aramSchemaId)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return DynaFormSchemaController.errorHandler(ctx, error)
    }
  }

  /**
   * 获取项目组件列表
   */
  static async handleGetV1DynaSchemaList(ctx: Context) {
    type PayloadType = { schemaId: AramIdType }

    try {
      await DynaFormSchemaController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const result = await DynaFormSchemaController.engine.dynaFormSchema().getAramSchemaList(schemaId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return DynaFormSchemaController.errorHandler(ctx, error)
    }
  }
}

export const handlePostV1DynaSchemaLink = DynaFormSchemaController.handlePostV1DynaSchemaLink
export const handlePostV1DynaSchemaUnlink = DynaFormSchemaController.handlePostV1DynaSchemaUnlink
export const handleGetV1DynaSchemaList = DynaFormSchemaController.handleGetV1DynaSchemaList
