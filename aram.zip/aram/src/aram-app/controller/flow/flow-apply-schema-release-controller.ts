import { Context } from 'koa'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'

class FlowApplySchemaReleaseController extends AbstractController {
  static async handlePostV1FlowApplySchemaReleaseCreate(ctx: Context) {
    type PayloadType = { schemaId: AramIdType; schema: AramJsonType; remark: string; approvers: AramUserNameType[] }

    try {
      await FlowApplySchemaReleaseController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { schemaId, schema, remark, approvers } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkAramJson(schema, { required: true })
      ParamChecker.checkString(remark, { required: false })
      ParamChecker.checkUserNameList(approvers, { required: true })

      const orderId = await FlowApplySchemaReleaseController.engine.flowApplySchemaRelease().createApplyOrder(schemaId, schema, remark, approvers)
      const response = new AramHttpResponse({ orderId })
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowApplySchemaReleaseController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1FlowApplySchemaReleaseActiveOrder(ctx: Context) {
    type PayloadType = { schemaId: AramIdType }

    try {
      await FlowApplySchemaReleaseController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const order = await FlowApplySchemaReleaseController.engine.flowHistoryOrder().getActiveApplySchemaReleaseOrder(schemaId)
      const response = new AramHttpResponse(order)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowApplySchemaReleaseController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1FlowApplySchemaReleaseApprovers(ctx: Context) {
    type PayloadType = { schemaId: AramIdType }

    try {
      FlowApplySchemaReleaseController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const result = await FlowApplySchemaReleaseController.engine.schemaMember().getAllAdminBySchemaId(schemaId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowApplySchemaReleaseController.errorHandler(ctx, error)
    }
  }

  static async handlePostV1FlowApplySchemaReleaseTerminate(ctx: Context) {
    type PayloadType = { orderId: AramUuidType }

    try {
      await FlowApplySchemaReleaseController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { orderId } = payload

      ParamChecker.checkAramUuid(orderId)

      await FlowApplySchemaReleaseController.engine.flowApplySchemaRelease().terminateOrder(orderId)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowApplySchemaReleaseController.errorHandler(ctx, error)
    }
  }

  static async handlePostV1FlowApplySchemaReleaseRemindApprovers(ctx: Context) {
    type PayloadType = { orderId: AramUuidType }

    try {
      await FlowApplySchemaReleaseController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { orderId } = payload

      ParamChecker.checkAramUuid(orderId)

      await FlowApplySchemaReleaseController.engine.flowApplySchemaRelease().remindApprovers(orderId)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowApplySchemaReleaseController.errorHandler(ctx, error)
    }
  }
}

export const handlePostV1FlowApplySchemaReleaseCreate = FlowApplySchemaReleaseController.handlePostV1FlowApplySchemaReleaseCreate
export const handleGetV1FlowApplySchemaReleaseApprovers = FlowApplySchemaReleaseController.handleGetV1FlowApplySchemaReleaseApprovers
export const handleGetV1FlowApplySchemaReleaseActiveOrder = FlowApplySchemaReleaseController.handleGetV1FlowApplySchemaReleaseActiveOrder
export const handlePostV1FlowApplySchemaReleaseTerminate = FlowApplySchemaReleaseController.handlePostV1FlowApplySchemaReleaseTerminate
export const handlePostV1FlowApplySchemaReleaseRemindApprovers = FlowApplySchemaReleaseController.handlePostV1FlowApplySchemaReleaseRemindApprovers
