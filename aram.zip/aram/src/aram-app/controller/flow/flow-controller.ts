import { Context } from 'koa'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { ApproverOpinionEnum } from '~/aram-base/entities/flow/aram-flow-approver'
import { FlowProcessEnum } from '~/aram-biz/context/enum'

class FlowController extends AbstractController {
  static async handlePostV1Flows(ctx: Context) {
    try {
      // @todo
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowController.errorHandler(ctx, error)
    }
  }

  static async handlePostFlowProcessDeploy(ctx: Context) {
    type PayloadType = { processName: FlowProcessEnum }

    try {
      await FlowController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { processName } = payload

      ParamChecker.checkProcessName(processName)

      await FlowController.engine.flow().deployProcess(processName)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1FlowDetail(ctx: Context) {
    type PayloadType = { orderId: AramUuidType }

    try {
      await FlowController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyGetRequestQuery()
      const { orderId } = payload

      ParamChecker.checkAramUuid(orderId)

      const result = await FlowController.engine.flow().getOrderdetail(orderId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowController.errorHandler(ctx, error)
    }
  }

  static async handlePostV1FlowAuditApprove(ctx: Context) {
    type PayloadType = { orderId: AramUuidType }

    try {
      await FlowController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { orderId } = payload

      ParamChecker.checkAramUuid(orderId)

      await FlowController.engine.flow().reviewOrder(orderId, ApproverOpinionEnum.pass, null)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowController.errorHandler(ctx, error)
    }
  }

  static async handlePostV1FlowAuditReject(ctx: Context) {
    type PayloadType = { orderId: AramUuidType; remark?: string }

    try {
      await FlowController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { orderId, remark } = payload

      ParamChecker.checkAramUuid(orderId)
      ParamChecker.checkString(remark, { required: false })

      await FlowController.engine.flow().reviewOrder(orderId, ApproverOpinionEnum.reject, remark)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return FlowController.errorHandler(ctx, error)
    }
  }
}

export const handlePostV1Flows = FlowController.handlePostV1Flows
export const handleGetV1FlowDetail = FlowController.handleGetV1FlowDetail
export const handlePostV1FlowAuditApprove = FlowController.handlePostV1FlowAuditApprove
export const handlePostV1FlowAuditReject = FlowController.handlePostV1FlowAuditReject
export const handlePostFlowProcessDeploy = FlowController.handlePostFlowProcessDeploy
