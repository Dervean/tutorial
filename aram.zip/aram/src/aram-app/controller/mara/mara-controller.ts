import { Context } from 'koa'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramMaraBuiltinComponent } from '~/aram-base/entities/aram-mara-builtin-component'

class MaraController extends AbstractController {
  /**
   * 上传内置组件配置
   */
  static async handlePostV1MaraBuiltinComponentCreate(ctx: Context) {
    try {
      await MaraController.setup(ctx)
      const payload: AramMaraBuiltinComponent = NestEventHelper.unifyPostRequestBody()
      const { componentType, schema, componentName } = payload

      ParamChecker.checkAramJson(schema, { required: true })
      ParamChecker.checkComponentType(componentType)
      ParamChecker.checkComponentName(componentName)

      const model = new AramMaraBuiltinComponent(payload)
      const { userName } = await NestEventHelper.user()
      model.createdBy = userName

      await MaraController.engine.mara().createBuiltinComponent(model)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return MaraController.errorHandler(ctx, error)
    }
  }

  /**
   * 修改内置组件配置
   */
  static async handlePostV1MaraBuiltinComponentEdit(ctx: Context) {
    try {
      await MaraController.setup(ctx)
      const payload: AramMaraBuiltinComponent = NestEventHelper.unifyPostRequestBody()

      const { componentName } = payload
      ParamChecker.checkComponentName(componentName)
      const model = new AramMaraBuiltinComponent(payload)
      const { userName } = await NestEventHelper.user()
      model.updatedBy = userName

      await MaraController.engine.mara().updateBuiltinComponent(componentName, model)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return MaraController.errorHandler(ctx, error)
    }
  }

  /**
   * 下线内置组件
   */
  static async handlePostV1MaraBuiltinComponentOffline(ctx: Context) {
    try {
      await MaraController.setup(ctx)
      const payload: { componentName: string } = NestEventHelper.unifyPostRequestBody()

      const { componentName } = payload
      ParamChecker.checkComponentName(componentName)

      await MaraController.engine.mara().offlineBuiltinComponent(componentName)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return MaraController.errorHandler(ctx, error)
    }
  }

  // /**
  //  * 创建自定义组件
  //  */
  // static async handlePostV1MaraCustomComponentCreate(ctx: Context) {

  //   try {
  //     await MaraController.setup(ctx)
  //     const payload: CreateCustomComponentParams = NestEventHelper.unifyPostRequestBody()

  //     const result = await MaraController.engine.mara().createCustomComponent(payload)
  //     const response = new AramHttpResponse(result)
  //     return response.build(ctx)
  //   } catch (error) {
  //     AramLogger.logError(error)
  //     return MaraController.errorHandler(ctx, error)
  //   }
  // }

  // /**
  //  * 发布自定义组件配置
  //  */
  // static async handlePostV1MaraCustomComponentVersionRelease(ctx: Context) {

  //   try {
  //     await MaraController.setup(ctx)
  //     const payload: CreateCustomComponentVersionParams = NestEventHelper.unifyPostRequestBody()
  //     const { componentId, projectId, schema, componentType } = payload

  //     ParamChecker.checkAramJson(schema, { required: true })
  //     ParamChecker.checkAramId(projectId)
  //     ParamChecker.checkAramId(componentId)
  //     ParamChecker.checkComponentType(componentType)

  //     const result = await MaraController.engine.mara().createCustomComponentVersion(payload)
  //     const response = new AramHttpResponse(result)
  //     return response.build(ctx)
  //   } catch (error) {
  //     AramLogger.logError(error)
  //     return MaraController.errorHandler(ctx, error)
  //   }
  // }

  /**
   * 获取项目组件列表
   */
  static async handleGetV1MaraComponentList(ctx: Context) {
    try {
      await MaraController.setup(ctx)
      const payload: { projectId: AramIdType } = NestEventHelper.unifyGetRequestQuery()
      const { projectId } = payload

      ParamChecker.checkAramId(projectId)

      const result = await MaraController.engine.mara().getActiveComponentList(projectId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return MaraController.errorHandler(ctx, error)
    }
  }
}

export const handlePostV1MaraBuiltinComponentCreate = MaraController.handlePostV1MaraBuiltinComponentCreate
export const handlePostV1MaraBuiltinComponentEdit = MaraController.handlePostV1MaraBuiltinComponentEdit
export const handlePostV1MaraBuiltinComponentOffline = MaraController.handlePostV1MaraBuiltinComponentOffline
// export const handlePostV1MaraCustomComponentCreate = MaraController.handlePostV1MaraCustomComponentCreate
// export const handlePostV1MaraCustomComponentVersionRelease = MaraController.handlePostV1MaraCustomComponentVersionRelease
export const handleGetV1MaraComponentList = MaraController.handleGetV1MaraComponentList
