import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { RoleTypeEnum } from '~/aram-base/model/permission/permission-builder'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AbstractController } from '~/aram-app/controller/abstract-controller'

class MemberController extends AbstractController {
  /** 获取项目权限列表 */
  static async handleGetV1MemberAuthorityProjectList(ctx: Context) {
    try {
      await MemberController.setup(ctx)
      const payload: { projectId: AramIdType } = NestEventHelper.unifyGetRequestQuery()
      const { projectId } = payload

      ParamChecker.checkAramId(projectId)

      const result = await MemberController.engine.member().searchRoleListByProjectId(projectId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return MemberController.errorHandler(ctx, error)
    }
  }

  /** 添加（编辑）项目个人权限 */
  static async handlePostV1MemberAuthorityProjectAddOrEdit(ctx: Context) {
    try {
      await MemberController.setup(ctx)
      const payload: { projectId: AramIdType; role: RoleTypeEnum; userName: string } = NestEventHelper.unifyPostRequestBody()
      const { projectId, role, userName } = payload

      ParamChecker.checkAramId(projectId)
      ParamChecker.checkRoleType(role)
      ParamChecker.checkUserName(userName)

      await MemberController.engine.member().insertOrUpdateMemberRole(projectId, userName, role)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return MemberController.errorHandler(ctx, error)
    }
  }

  /** 删除项目个人权限 */
  static async handlePostV1MemberAuthorityProjectDrop(ctx: Context) {
    try {
      await MemberController.setup(ctx)
      const payload: { projectId: AramIdType; userName: string } = NestEventHelper.unifyPostRequestBody()
      const { projectId, userName } = payload

      ParamChecker.checkAramId(projectId)
      ParamChecker.checkUserName(userName)

      await MemberController.engine.member().deleteMemberRole(projectId, userName)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return MemberController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1MemberAuthorityProjectList = MemberController.handleGetV1MemberAuthorityProjectList
export const handlePostV1MemberAuthorityProjectAddOrEdit = MemberController.handlePostV1MemberAuthorityProjectAddOrEdit
export const handlePostV1MemberAuthorityProjectDrop = MemberController.handlePostV1MemberAuthorityProjectDrop
