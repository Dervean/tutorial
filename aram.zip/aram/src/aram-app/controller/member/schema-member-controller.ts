import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { Context } from 'koa'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { RoleTypeEnum } from '~/aram-base/model/permission/permission-builder'

class SchemaMemberController extends AbstractController {
  /** 获取配置权限成员列表 */
  static async handleGetV1MemberAuthoritySchemaList(ctx: Context) {
    try {
      await SchemaMemberController.setup(ctx)
      const payload: { schemaId: AramIdType } = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const result = await SchemaMemberController.engine.schemaMember().searchRoleListBySchemaId(schemaId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaMemberController.errorHandler(ctx, error)
    }
  }

  // 添加编辑项目个人权限
  static async handlePostV1MemberAuthoritySchemaAddOrEdit(ctx: Context) {
    try {
      await SchemaMemberController.setup(ctx)
      const payload: { schemaId: AramIdType; role: RoleTypeEnum; userName: string } = NestEventHelper.unifyPostRequestBody()
      const { schemaId, role, userName } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkRoleType(role)
      ParamChecker.checkUserName(userName)

      await SchemaMemberController.engine.schemaMember().insertOrUpdateSchemaMemberRole(schemaId, userName, role)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaMemberController.errorHandler(ctx, error)
    }
  }

  // 删除配置个人权限
  static async handlePostV1MemberAuthoritySchemaDrop(ctx: Context) {
    try {
      await SchemaMemberController.setup(ctx)
      const payload: { schemaId: AramIdType; userName: string } = NestEventHelper.unifyPostRequestBody()
      const { schemaId, userName } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkUserName(userName)

      await SchemaMemberController.engine.schemaMember().deleteSchemaMemberRole(schemaId, userName)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaMemberController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1MemberAuthoritySchemaList = SchemaMemberController.handleGetV1MemberAuthoritySchemaList
export const handlePostV1MemberAuthoritySchemaAddOrEdit = SchemaMemberController.handlePostV1MemberAuthoritySchemaAddOrEdit
export const handlePostV1MemberAuthoritySchemaDrop = SchemaMemberController.handlePostV1MemberAuthoritySchemaDrop
