import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'

import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramPageParams } from '~/aram-lib/model/aram-page'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { AramMissingParamError } from '~/aram-lib/model/aram-error/bad-request/aram-missing-param-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'

class ModuleController extends AbstractController {
  /**
   * 获取模块列表
   */
  static async handleGetV1ModuleList(ctx: Context) {
    try {
      await ModuleController.setup(ctx)
      const payload: { projectId: AramIdType; keyword?: string } & AramPageParams = NestEventHelper.unifyGetRequestQuery()
      const { projectId, keyword, pageNum, pageSize } = payload

      let result

      ParamChecker.checkAramId(projectId)
      try {
        ParamChecker.checkPageNum(pageNum)
        ParamChecker.checkPageSize(pageSize)
        result = await ModuleController.engine.module().searchModuleList(projectId, keyword, { pageNum: +pageNum, pageSize: +pageSize })
      } catch (error) {
        /** 无分页参数则返回全部模块列表 */
        result = await ModuleController.engine.module().getModuleListByProjectId(projectId, keyword)
      }

      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ModuleController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1ModuleGet(ctx: Context) {
    try {
      await ModuleController.setup(ctx)
      const payload: { moduleId: AramIdType } = NestEventHelper.unifyGetRequestQuery()
      const { moduleId } = payload

      ParamChecker.checkAramId(moduleId)

      const module = await ModuleController.engine.module().getActiveModule(moduleId)
      const response = new AramHttpResponse(module)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ModuleController.errorHandler(ctx, error)
    }
  }

  /**
   * 创建模块
   */
  static async handlePostV1ModuleCreate(ctx: Context) {
    try {
      await ModuleController.setup(ctx)
      const payload: { projectId: AramIdType; moduleName: string; moduleDesc?: string } = NestEventHelper.unifyPostRequestBody()
      const { projectId, moduleName, moduleDesc } = payload

      ParamChecker.checkModuleName(moduleName)
      ParamChecker.checkAramId(projectId)

      const result = await ModuleController.engine.module().createModule({ projectId, moduleName, moduleDesc })
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ModuleController.errorHandler(ctx, error)
    }
  }

  /**
   * 编辑模块
   */
  static async handlePostV1ModuleEdit(ctx: Context) {
    try {
      await ModuleController.setup(ctx)
      const payload: { moduleId: AramIdType; moduleName?: string; moduleDesc?: string } = NestEventHelper.unifyPostRequestBody()
      const { moduleId, moduleName, moduleDesc } = payload

      ParamChecker.checkAramId(moduleId)
      if (!moduleName && !moduleDesc) throw new AramMissingParamError(`参数缺失: moduleDesc, moduleName`)
      if (moduleName) ParamChecker.checkModuleName(moduleName)

      await ModuleController.engine.module().updateModuleInfo({ moduleId, moduleName, moduleDesc })
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ModuleController.errorHandler(ctx, error)
    }
  }

  /**
   * 删除模块
   */
  static async handlePostV1ModuleDrop(ctx: Context) {
    try {
      await ModuleController.setup(ctx)
      const payload: { moduleId: AramIdType } = NestEventHelper.unifyPostRequestBody()
      const { moduleId } = payload

      ParamChecker.checkAramId(moduleId)

      await ModuleController.engine.module().dropModule({ moduleId })
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ModuleController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1ModuleList = ModuleController.handleGetV1ModuleList
export const handlePostV1ModuleCreate = ModuleController.handlePostV1ModuleCreate
export const handlePostV1ModuleEdit = ModuleController.handlePostV1ModuleEdit
export const handlePostV1ModuleDrop = ModuleController.handlePostV1ModuleDrop
export const handleGetV1ModuleGet = ModuleController.handleGetV1ModuleGet
