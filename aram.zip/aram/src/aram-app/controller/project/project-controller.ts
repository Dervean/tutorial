import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramPageParams } from '~/aram-lib/model/aram-page'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramProject } from '~/aram-base/entities/aram-project'
import { AramApplication } from '~/aram-base/entities/aram-application'

class ProjectController extends AbstractController {
  /**
   * 获取项目列表
   */
  static async handleGetV1ProjectList(ctx: Context) {
    type PayloadType = { keyword?: string; hidePublic: any } & AramPageParams & Pick<AramApplication, 'appUid'>

    try {
      await ProjectController.setup(ctx)
      /** Get 请求 hidePublic 默认字符串 */
      const payload: PayloadType = NestEventHelper.unifyGetRequestQuery()
      const { keyword, pageNum, pageSize, hidePublic, appUid } = payload

      ParamChecker.checkPageNum(pageNum)
      ParamChecker.checkPageSize(pageSize)
      appUid && ParamChecker.checkAramUid(appUid)
      /** hidePublic 未设置时默认 searchPublic 为 true */
      const searchPublic = !ParamChecker.checkBoolean(hidePublic)

      const result = await ProjectController.engine
        .project()
        .searchProjectList(keyword, { pageNum: +pageNum, pageSize: +pageSize }, searchPublic, appUid)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ProjectController.errorHandler(ctx, error)
    }
  }

  /**
   * 创建新项目
   */
  static async handlePostV1ProjectCreate(ctx: Context) {
    type PayloadType = Pick<AramProject, 'appUid' | 'projectName' | 'isPrivate' | 'description' | 'xattrs'>

    try {
      await ProjectController.setup(ctx)
      const { userName } = await NestEventHelper.user()
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { appUid, projectName, description, isPrivate = true, xattrs } = payload

      ParamChecker.checkAramUid(appUid)
      ParamChecker.checkProjectName(projectName)
      ParamChecker.checkAramJson(xattrs, { required: false })
      const bIsPrivate = ParamChecker.checkBoolean(isPrivate)

      const project = new AramProject()
      project.appUid = appUid
      /** 默认 false */
      project.isPrivate = Number(bIsPrivate)
      project.xattrs = xattrs || null
      project.description = description || null
      project.projectName = projectName

      // prettier-ignore
      const result = await ProjectController.engine.project().createProject(project, userName)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ProjectController.errorHandler(ctx, error)
    }
  }

  /**
   * 编辑项目
   */
  static async handlePostV1ProjectEdit(ctx: Context) {
    type PayloadType = Pick<AramProject, 'projectId' | 'projectName' | 'isPrivate' | 'description' | 'xattrs'>

    try {
      await ProjectController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { projectId, projectName, description, isPrivate, xattrs } = payload

      ParamChecker.checkAramId(projectId)

      const project = new AramProject()
      project.projectId = projectId
      if (projectName) {
        ParamChecker.checkProjectName(projectName)
        project.projectName = projectName
      }
      if (description) project.description = description
      if (xattrs) {
        ParamChecker.checkAramJson(xattrs, { required: false })
        project.xattrs = xattrs
      }
      if (isPrivate !== undefined) {
        const bIsPrivate = ParamChecker.checkBoolean(isPrivate)
        project.isPrivate = Number(bIsPrivate)
      }

      await ProjectController.engine.project().updateProjectInfo(projectId, project)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ProjectController.errorHandler(ctx, error)
    }
  }

  /**
   * 删除项目
   */
  static async handlePostV1ProjectDrop(ctx: Context) {
    try {
      await ProjectController.setup(ctx)
      const payload: { projectId: AramIdType } = NestEventHelper.unifyPostRequestBody()
      const { projectId } = payload

      ParamChecker.checkAramId(projectId)

      await ProjectController.engine.project().offlineProject(projectId)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ProjectController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1ProjectGet(ctx: Context) {
    try {
      await ProjectController.setup(ctx)
      const payload: { projectId: AramIdType } = NestEventHelper.unifyGetRequestQuery()
      const { projectId } = payload

      ParamChecker.checkAramId(projectId)

      const project = await ProjectController.engine.project().getActiveProject(projectId)
      const response = new AramHttpResponse(project)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ProjectController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1ProjectList = ProjectController.handleGetV1ProjectList
export const handleGetV1ProjectGet = ProjectController.handleGetV1ProjectGet
export const handlePostV1ProjectCreate = ProjectController.handlePostV1ProjectCreate
export const handlePostV1ProjectEdit = ProjectController.handlePostV1ProjectEdit
export const handlePostV1ProjectDrop = ProjectController.handlePostV1ProjectDrop
