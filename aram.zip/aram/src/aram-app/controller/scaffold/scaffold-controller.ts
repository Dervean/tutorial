import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AbstractController } from '~/aram-app/controller/abstract-controller'

class ScaffoldController extends AbstractController {
  /** 获取配置列表 */
  static async handleGetV1ScaffoldSchemaList(ctx: Context) {
    try {
      await ScaffoldController.setup(ctx)
      const payload: { projectId?: AramIdType } = NestEventHelper.unifyGetRequestQuery()
      const { projectId } = payload

      ParamChecker.checkAramId(projectId)

      const result = await ScaffoldController.engine.scaffold().getActiveSchemaList(projectId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return ScaffoldController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1ScaffoldSchemaList = ScaffoldController.handleGetV1ScaffoldSchemaList
