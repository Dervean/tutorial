import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramPageParams } from '~/aram-lib/model/aram-page'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { AramSchema } from '~/aram-base/entities/aram-schema'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'

class SchemaController extends AbstractController {
  /** 获取配置列表 */
  static async handleGetV1SchemaList(ctx: Context) {
    try {
      await SchemaController.setup(ctx)
      const payload: { moduleId?: AramIdType; projectId?: AramIdType; keyword?: string } & AramPageParams = NestEventHelper.unifyGetRequestQuery()
      const { moduleId, projectId, keyword, pageNum, pageSize } = payload

      ParamChecker.checkPageNum(pageNum)
      ParamChecker.checkPageSize(pageSize)
      try {
        ParamChecker.checkAramId(moduleId)
      } catch (error) {
        ParamChecker.checkAramId(projectId)
      }

      const result = await SchemaController.engine
        .schema()
        .searchSchemaList({ projectId, moduleId, keyword, pageParams: { pageNum: +pageNum, pageSize: +pageSize } })
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaController.errorHandler(ctx, error)
    }
  }

  /** 创建配置基础信息 */
  static async handlePostV1SchemaBaseCreate(ctx: Context) {
    try {
      await SchemaController.setup(ctx)
      const payload: Pick<AramSchema, 'moduleId' | 'schemaUid' | 'schemaName' | 'description' | 'ext'> = NestEventHelper.unifyPostRequestBody()
      const { moduleId, schemaName, schemaUid, description, ext } = payload

      ParamChecker.checkSchemaName(schemaName)
      ParamChecker.checkAramId(moduleId)
      ParamChecker.checkAramUid(schemaUid)

      const result = await SchemaController.engine.schema().createSchema({ moduleId, schemaUid, schemaName, description, ext })
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaController.errorHandler(ctx, error)
    }
  }

  static async handleGetV1SchemaBaseGet(ctx: Context) {
    try {
      await SchemaController.setup(ctx)
      const payload: Pick<AramSchema, 'schemaId'> = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)
      const schema = await SchemaController.engine.schema().getActiveSchema(schemaId)
      const response = new AramHttpResponse(schema)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaController.errorHandler(ctx, error)
    }
  }

  /** 删除配置基础信息 */
  static async handlePostV1SchemaBaseDrop(ctx: Context) {
    try {
      await SchemaController.setup(ctx)
      const payload: Pick<AramSchema, 'schemaId'> = NestEventHelper.unifyPostRequestBody()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      await SchemaController.engine.schema().dropSchema(schemaId)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaController.errorHandler(ctx, error)
    }
  }

  /** 编辑配置基本信息 */
  static async handlePostV1SchemaBaseEdit(ctx: Context) {
    try {
      await SchemaController.setup(ctx)
      const payload: Pick<AramSchema, 'schemaId' | 'schemaName' | 'schemaUid' | 'description'> = NestEventHelper.unifyPostRequestBody()
      const { schemaId, schemaName, description, schemaUid } = payload

      ParamChecker.checkAramId(schemaId)
      const { userName } = await NestEventHelper.user()

      const schema = new AramSchema()
      if (schemaName) {
        ParamChecker.checkSchemaName(schemaName)
        schema.schemaName = schemaName
      }
      if (description) schema.description = description
      if (schemaUid) {
        ParamChecker.checkAramUid(schemaUid)
        schema.schemaUid = schemaUid
      }
      schema.updatedBy = userName

      await SchemaController.engine.schema().updateSchemaBasicInfo(schemaId, schema)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1SchemaList = SchemaController.handleGetV1SchemaList
export const handlePostV1SchemaBaseCreate = SchemaController.handlePostV1SchemaBaseCreate
export const handleGetV1SchemaBaseGet = SchemaController.handleGetV1SchemaBaseGet
export const handlePostV1SchemaBaseEdit = SchemaController.handlePostV1SchemaBaseEdit
export const handlePostV1SchemaBaseDrop = SchemaController.handlePostV1SchemaBaseDrop
