import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { AramSchemaDraft } from '~/aram-base/entities/aram-schema-draft'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'

class SchemaDraftController extends AbstractController {
  /** 创建配置草稿 */
  static async handlePostV1SchemaDraftCreate(ctx: Context) {
    try {
      await SchemaDraftController.setup(ctx)
      const payload: Pick<AramSchemaDraft, 'schemaId'> = NestEventHelper.unifyPostRequestBody()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const result = await SchemaDraftController.engine.schemaDraft().createSchemaDraft(schemaId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaDraftController.errorHandler(ctx, error)
    }
  }

  /** 获取配置草稿 */
  static async handleGetV1SchemaDraftGet(ctx: Context) {
    try {
      await SchemaDraftController.setup(ctx)
      const payload: Pick<AramSchemaDraft, 'schemaId'> = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const { userName } = await NestEventHelper.user()
      const result = await SchemaDraftController.engine.schemaDraft().getSchemaDraft(schemaId, userName)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaDraftController.errorHandler(ctx, error)
    }
  }

  /** 获取配置草稿 */
  static async handleGetV1SchemaDraftCheckout(ctx: Context) {
    try {
      await SchemaDraftController.setup(ctx)
      const payload: Pick<AramSchemaDraft, 'schemaId'> = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const { userName } = await NestEventHelper.user()
      const result = await SchemaDraftController.engine.schemaDraft().checkoutSchemaDraft(schemaId, userName)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaDraftController.errorHandler(ctx, error)
    }
  }

  /** 保存配置草稿 */
  static async handlePostV1SchemaDraftSave(ctx: Context) {
    try {
      await SchemaDraftController.setup(ctx)
      const payload: Pick<AramSchemaDraft, 'schemaId' | 'schema'> & { sync: boolean } = NestEventHelper.unifyPostRequestBody()
      const { schemaId, schema, sync } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkAramJson(schema, { required: true })

      const draft = new AramSchemaDraft()
      draft.schema = schema
      await SchemaDraftController.engine.schemaDraft().updateSchemaDraft(schemaId, draft, !!sync)

      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaDraftController.errorHandler(ctx, error)
    }
  }
}

export const handlePostV1SchemaDraftCreate = SchemaDraftController.handlePostV1SchemaDraftCreate
export const handleGetV1SchemaDraftGet = SchemaDraftController.handleGetV1SchemaDraftGet
export const handlePostV1SchemaDraftSave = SchemaDraftController.handlePostV1SchemaDraftSave
export const handleGetV1SchemaDraftCheckout = SchemaDraftController.handleGetV1SchemaDraftCheckout
