import assert from 'assert'

import { Context } from 'koa'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramHttpResponse } from '~/aram-lib/model/aram-http-response'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramPageParams } from '~/aram-lib/model/aram-page'
import { AbstractController } from '~/aram-app/controller/abstract-controller'
import { AramInvalidFormatParamError } from '~/aram-lib/model/aram-error/bad-request/aram-invalid-param-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramSchemaBetaVersion } from '~/aram-base/entities/aram-schema-beta-version'
import { AramSchemaVersion } from '~/aram-base/entities/aram-schema-version'

class SchemaVersionController extends AbstractController {
  /** 获取 prod 配置版本列表 */
  static async handleGetV1SchemaVersionList(ctx: Context) {
    try {
      await SchemaVersionController.setup(ctx)
      const payload: { schemaId: AramIdType; createdBy?: AramUserNameType } & AramPageParams = NestEventHelper.unifyGetRequestQuery()
      const { schemaId, createdBy, pageNum, pageSize } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkPageNum(pageNum)
      ParamChecker.checkPageSize(pageSize)
      createdBy && ParamChecker.checkUserName(createdBy)

      const result = await SchemaVersionController.engine.schemaVersion().searchSchemaVersionList(schemaId, createdBy, {
        pageNum: +pageNum,
        pageSize: +pageSize,
      })
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }

  /** 获取 beta 配置版本列表 */
  static async handleGetV1SchemaBetaVersionList(ctx: Context) {
    try {
      await SchemaVersionController.setup(ctx)
      const payload: { schemaId: string; createdBy?: AramUserNameType } & AramPageParams = NestEventHelper.unifyGetRequestQuery()
      const { schemaId, createdBy, pageNum, pageSize } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkPageNum(pageNum)
      ParamChecker.checkPageSize(pageSize)
      createdBy && ParamChecker.checkUserName(createdBy)

      const result = await SchemaVersionController.engine.schemaVersion().searchSchemaBetaVersionList(+schemaId, createdBy, {
        pageNum: +pageNum,
        pageSize: +pageSize,
      })
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }

  /** 发布 prod 配置 前置检查 */
  static async handleGetV1SchemaVersionPrecheck(ctx: Context) {
    try {
      await SchemaVersionController.setup(ctx)
      const payload: { schemaId: AramIdType } = NestEventHelper.unifyGetRequestQuery()
      const { schemaId } = payload

      ParamChecker.checkAramId(schemaId)

      const result = await SchemaVersionController.engine.schemaVersion().releasePrecheck(schemaId)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }

  /** 发布 prod 配置 */
  static async handlePostV1SchemaVersionRelease(ctx: Context) {
    type PayloadType = { schemaId: AramIdType; schema: AramJsonType; description?: string }

    try {
      await SchemaVersionController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { schemaId, schema, description: remark } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkAramJson(schema, { required: true })
      ParamChecker.checkString(remark, { required: false })

      await SchemaVersionController.engine.flowApplySchemaRelease().createOrder(schemaId, schema, remark)
      const response = new AramHttpResponse()
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }

  /** 发布 beta 配置 */
  static async handlePostV1SchemaBetaVersionRelease(ctx: Context) {
    try {
      await SchemaVersionController.setup(ctx)
      const payload: { schemaId: AramIdType; schema: AramJsonType; description?: string } = NestEventHelper.unifyPostRequestBody()
      const { schemaId, schema, description } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkAramJson(schema, { required: true })

      const result = await SchemaVersionController.engine.schemaVersion().createSchemaBetaVersion(schemaId, schema, description)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }

  /** 根据 版本字符串 prod 配置回滚 */
  static async handlePostV1SchemaVersionRollback(ctx: Context) {
    try {
      await SchemaVersionController.setup(ctx)
      const payload: { schemaId: AramIdType; version: string; description?: string } = NestEventHelper.unifyPostRequestBody()
      const { schemaId, version, description } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkSchemaVersion(version)

      const versionNum = AramSchemaVersion.str2version(version)
      const result = await SchemaVersionController.engine.schemaVersion().rollbackSchemaVersion(schemaId, +versionNum, description)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }

  /** 根据 版本字符串 beta 配置回滚 */
  static async handlePostV1SchemaBetaVersionRollback(ctx: Context) {
    type BetaVersionType = Pick<AramSchemaBetaVersion, 'betaVersion' | 'version'>
    type PayloadType = Pick<AramSchemaBetaVersion, 'schemaId' | 'description'> & { version: string }

    try {
      await SchemaVersionController.setup(ctx)
      const payload: PayloadType = NestEventHelper.unifyPostRequestBody()
      const { schemaId, version: sVersion, description } = payload

      ParamChecker.checkAramId(schemaId)
      const { version, betaVersion } = ParamChecker.checkSchemaVersion(sVersion) as BetaVersionType
      assert.ok(Number.isInteger(version), `参数非法: version=${sVersion}`)
      assert.ok(Number.isInteger(betaVersion), `参数非法: version=${sVersion}`)

      const result = await SchemaVersionController.engine.schemaVersion().rollbackSchemaBetaVersion(schemaId, +version, +betaVersion, description)
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }

  /** 根据 版本字符串 获取某版本的配置 */
  static async handleGetV1SchemaVersionGet(ctx: Context) {
    type BetaVersionType = Pick<AramSchemaBetaVersion, 'betaVersion' | 'version'>

    try {
      await SchemaVersionController.setup(ctx)
      const payload: { schemaId: AramIdType; version: string } = NestEventHelper.unifyGetRequestQuery()
      const { schemaId, version: sVersion } = payload

      ParamChecker.checkAramId(schemaId)
      ParamChecker.checkSchemaVersion(sVersion)

      let result
      try {
        const ver = AramSchemaVersion.str2version(sVersion)
        result = await SchemaVersionController.engine.schemaVersion().getSchemaVersion(schemaId, ver)
      } catch (error) {
        /** 如果 version 参数校验失败则尝试获取 beta 版本 */
        if (error instanceof AramInvalidFormatParamError) {
          const { version, betaVersion } = ParamChecker.checkSchemaVersion(sVersion) as BetaVersionType
          result = await SchemaVersionController.engine.schemaVersion().getSchemaBetaVersion(schemaId, version, betaVersion)
        } else {
          throw error
        }
      }
      const response = new AramHttpResponse(result)
      return response.build(ctx)
    } catch (error) {
      AramLogger.logError(error)
      return SchemaVersionController.errorHandler(ctx, error)
    }
  }
}

export const handleGetV1SchemaVersionGet = SchemaVersionController.handleGetV1SchemaVersionGet

export const handleGetV1SchemaVersionList = SchemaVersionController.handleGetV1SchemaVersionList
export const handleGetV1SchemaVersionPrecheck = SchemaVersionController.handleGetV1SchemaVersionPrecheck
export const handlePostV1SchemaVersionRelease = SchemaVersionController.handlePostV1SchemaVersionRelease
export const handlePostV1SchemaVersionRollback = SchemaVersionController.handlePostV1SchemaVersionRollback

export const handleGetV1SchemaBetaVersionList = SchemaVersionController.handleGetV1SchemaBetaVersionList
export const handlePostV1SchemaBetaVersionRelease = SchemaVersionController.handlePostV1SchemaBetaVersionRelease
export const handlePostV1SchemaBetaVersionRollback = SchemaVersionController.handlePostV1SchemaBetaVersionRollback
