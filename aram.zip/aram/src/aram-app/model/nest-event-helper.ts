import { Context } from 'koa'
import { ParsedUrlQuery } from 'querystring'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { AramSSOUnauthorizedError } from '~/aram-lib/model/aram-error/server/aram-sso-unauthorized-error'

class AramLoginInfo {
  public userId: number = null
  public displayName: string = null
  public userName: AramUserNameType = null
  public isAdministrator: boolean = null
}

export class NestEventHelper {
  private static ctx: Context = null
  private static _info: AramLoginInfo = null

  public static setup(ctx: Context) {
    this.ctx = ctx
    this.setLoginInfo(ctx.query)
  }

  public static get info() {
    return NestEventHelper._info
  }

  private static set info(info: AramLoginInfo) {
    NestEventHelper._info = info
  }

  public static async setLoginInfo(userName: AramUserNameType): Promise<void>
  public static async setLoginInfo(info: AramLoginInfo): Promise<void>
  public static async setLoginInfo(query: ParsedUrlQuery): Promise<void>
  public static async setLoginInfo(param: AramUserNameType | AramLoginInfo | ParsedUrlQuery): Promise<void> {
    if (typeof param === 'string') {
      const { mis, name, empId } = await AramServiceContext.engine.org().queryByEmpMis(param)
      const info = new AramLoginInfo()
      info.userName = mis
      info.userId = +empId
      info.displayName = name
      this.setLoginInfo(info)
      return
    } else if (param instanceof AramLoginInfo) {
      this.info = param
      return
    } else {
      const info = new AramLoginInfo()
      info.userId = +param.ssoUserId
      info.displayName = param.ssoUserName as string
      info.userName = param.ssoUserLogin as string
      this.setLoginInfo(info)
      return
    }
  }

  /**
   * 返回 sso 登录信息
   * @returns
   */
  public static async user() {
    if (this.ctx === null || this.info === null) throw new Error('NestEventHelper not init')
    if (!this.info.userId) throw new AramSSOUnauthorizedError(`用户未登录`)
    const token = this.ctx.cookies.get('admin_token')
    this.info.isAdministrator = await AramServiceContext.engine.admin().adminIdentityVerify(token, this.info.userId, this.info.userName)
    return this.info
  }

  /**
   * http get 请求数据解构
   * @param event
   * @returns
   */
  public static unifyGetRequestQuery() {
    return this.ctx.query as any
  }

  /**
   * http post 请求数据解构
   * @param event
   * @returns
   */
  public static unifyPostRequestBody() {
    // @ts-ignore
    return this.ctx.request.body
  }

  /**
   * 定时触发器 请求数据解构
   * 数据格式 https://km.sankuai.com/page/284748459
   * @param event
   * @returns
   */
  public static unifyNestTimeTriggerRequestBody() {
    const payload = this.unifyPostRequestBody()
    const { body } = payload.data
    return typeof body === 'string' ? JSON.parse(body) : body
  }
}
