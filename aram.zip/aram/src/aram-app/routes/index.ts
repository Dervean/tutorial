import Router from 'koa-router'
import * as controller from '~/aram-app/controller'

const router = new Router()

router.post('/api/v1/aram/7acea773/system/batch-cdn-migration', controller.handlePostV1SystemBatchCDNMigration)
router.get('/api/v1/aram/c621106b/admin/login', controller.handleGetV1AdminLogin)
router
  .get('/api/v1/aram/37de913b/common/s3/token', controller.handleGetV1CommonS3GenToken)
  .get('/api/v1/aram/303c13b8/common/user/info', controller.handleGetV1CommonUserInfo)
  .get('/api/v1/aram/5a0c972d/common/org/emp/search', controller.handleGetV1CommonORGEmpSearch)
router
  .get('/api/v1/aram/6c748ee8/flow/detail', controller.handleGetV1FlowDetail)
  .post('/api/v1/aram/7b554e58/flow/process/deploy', controller.handlePostFlowProcessDeploy)
  .post('/api/v1/aram/204bc091/flow/audit/approve', controller.handlePostV1FlowAuditApprove)
  .post('/api/v1/aram/967c6919/flow/audit/reject', controller.handlePostV1FlowAuditReject)
  .post('/api/v1/aram/1280dd07/flow/apply-schema-release/terminate', controller.handlePostV1FlowApplySchemaReleaseTerminate)
  .post('/api/v1/aram/5bff2487/flow/apply-schema-release/create', controller.handlePostV1FlowApplySchemaReleaseCreate)
  .get('/api/v1/aram/d75c471a/flow/apply-schema-release/active-order', controller.handleGetV1FlowApplySchemaReleaseActiveOrder)
  .get('/api/v1/aram/5d722d12/flow/apply-schema-release/approvers', controller.handleGetV1FlowApplySchemaReleaseApprovers)
  .post('/api/v1/aram/2a99f6ba/flow/apply-schema-release/remind-approvers', controller.handlePostV1FlowApplySchemaReleaseRemindApprovers)
router
  .get('/api/v1/aram/df266fdb/application/list', controller.handleGetV1ApplicationList)
  .get('/api/v1/aram/256e89a9/application/get', controller.handleGetV1ApplicationGet)
  .post('/api/v1/aram/7bc6911f/application/create', controller.handlePostV1ApplicationCreate)
  .post('/api/v1/aram/39aa5fab/application/edit', controller.handlePostV1ApplicationEdit)
  .post('/api/v1/aram/9958f1fb/application/offline', controller.handlePostV1ApplicationOffline)
router
  .get('/api/v1/aram/e1de9652/project/list', controller.handleGetV1ProjectList)
  .post('/api/v1/aram/5dce947c/project/create', controller.handlePostV1ProjectCreate)
  .post('/api/v1/aram/7b5310fd/project/edit', controller.handlePostV1ProjectEdit)
  .post('/api/v1/aram/7bcce429/project/drop', controller.handlePostV1ProjectDrop)
  .get('/api/v1/aram/32fdae32/project/get', controller.handleGetV1ProjectGet)
router
  .get('/api/v1/aram/d8c546b1/authority/project/get', controller.handleGetV1MemberAuthorityProjectList)
  .post('/api/v1/aram/750076ed/authority/project/add', controller.handlePostV1MemberAuthorityProjectAddOrEdit)
  .post('/api/v1/aram/c457b161/authority/project/edit', controller.handlePostV1MemberAuthorityProjectAddOrEdit)
  .post('/api/v1/aram/337e6510/authority/project/drop', controller.handlePostV1MemberAuthorityProjectDrop)
router
  .get('/api/v1/aram/e4fg783e/authority/schema/get', controller.handleGetV1MemberAuthoritySchemaList)
  .post('/api/v1/aram/t57j82n9/authority/schema/add', controller.handlePostV1MemberAuthoritySchemaAddOrEdit)
  .post('/api/v1/aram/6hd9w45b/authority/schema/edit', controller.handlePostV1MemberAuthoritySchemaAddOrEdit)
  .post('/api/v1/aram/j78sn92z/authority/schema/drop', controller.handlePostV1MemberAuthoritySchemaDrop)
router
  .get('/api/v1/aram/1d864e12/module/list', controller.handleGetV1ModuleList)
  .post('/api/v1/aram/d414e17a/module/create', controller.handlePostV1ModuleCreate)
  .post('/api/v1/aram/a06072b0/module/edit', controller.handlePostV1ModuleEdit)
  .post('/api/v1/aram/e50621b8/module/drop', controller.handlePostV1ModuleDrop)
  .get('/api/v1/aram/21ddd0ac/module/get', controller.handleGetV1ModuleGet)
/** 脚手架 */
router.get('/api/v1/aram/scaffold/schema/list', controller.handleGetV1ScaffoldSchemaList)
router
  .get('/api/v1/aram/c7328483/schema/list', controller.handleGetV1SchemaList)
  .post('/api/v1/aram/55a1f2c2/schema/base/create', controller.handlePostV1SchemaBaseCreate)
  .post('/api/v1/aram/85118e6a/schema/base/edit', controller.handlePostV1SchemaBaseEdit)
  .post('/api/v1/aram/904f92e1/schema/base/drop', controller.handlePostV1SchemaBaseDrop)
  .get('/api/v1/aram/aa74ea5d/schema/base/get', controller.handleGetV1SchemaBaseGet)
router
  .get('/api/v1/aram/79e66224/schema/version/list', controller.handleGetV1SchemaVersionList)
  .get('/api/v1/aram/baf4b768/schema/version/get', controller.handleGetV1SchemaVersionGet)
  .get('/api/v1/aram/012b2de3/schema/version/precheck', controller.handleGetV1SchemaVersionPrecheck)
  .post('/api/v1/aram/2f7bea5b/schema/version/release', controller.handlePostV1SchemaVersionRelease)
  .post('/api/v1/aram/af9a1133/schema/version/rollback', controller.handlePostV1SchemaVersionRollback)
router
  .get('/api/v1/aram/b6a6d0cd/schema/beta/version/list', controller.handleGetV1SchemaBetaVersionList)
  .post('/api/v1/aram/36cbc0ef/schema/beta/version/release', controller.handlePostV1SchemaBetaVersionRelease)
  .post('/api/v1/aram/82b719d8/schema/beta/version/rollback', controller.handlePostV1SchemaBetaVersionRollback)
router
  .post('/api/v1/aram/b9da9e75/schema/draft/create', controller.handlePostV1SchemaDraftCreate)
  .get('/api/v1/aram/a323603f/schema/draft/get', controller.handleGetV1SchemaDraftGet)
  .get('/api/v1/aram/61f5e498/schema/draft/checkout', controller.handleGetV1SchemaDraftCheckout)
  .post('/api/v1/aram/551dc32a/schema/draft/save', controller.handlePostV1SchemaDraftSave)
router
  .get('/api/v1/aram/f0cbd2ec/mara/component/list', controller.handleGetV1MaraComponentList)
  .post('/api/v1/aram/f57cafb9/mara/builtin/component/create', controller.handlePostV1MaraBuiltinComponentCreate)
  .post('/api/v1/aram/fcb1358b/mara/builtin/component/edit', controller.handlePostV1MaraBuiltinComponentEdit)
  .post('/api/v1/aram/93d9df76/mara/builtin/component/offline', controller.handlePostV1MaraBuiltinComponentOffline)
// .post('/api/v1/aram/6464b629/mara/custom/component/create', controller.handlePostV1MaraCustomComponentCreate)
// .post('/api/v1/aram/588fa097/mara/custom/component/version/release', controller.handlePostV1MaraCustomComponentVersionRelease)
router
  .post('/api/v1/aram/ec882612/dyna/schema/link', controller.handlePostV1DynaSchemaLink)
  .get('/api/v1/aram/bf9214dc/dyna/schema/list', controller.handleGetV1DynaSchemaList)
  .post('/api/v1/aram/31203d19/dyna/schema/unlink', controller.handlePostV1DynaSchemaUnlink)
  .get('/api/v1/aram/c470fa45/dyna/alert/list', controller.handleGetV1DynaAlertList)
  .post('/api/v1/aram/0b46e07c/dyna/alert/create', controller.handlePostV1DynaAlertCreate)
  .post('/api/v1/aram/80b8ea86/dyna/alert/update', controller.handlePostV1DynaAlertUpdate)
  .post('/api/v1/aram/6cb2feac/dyna/alert/cancel', controller.handlePostV1DynaAlertCancel)

export default router
