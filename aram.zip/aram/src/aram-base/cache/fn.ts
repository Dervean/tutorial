import { v4 as uuid } from 'uuid'

class StringHelper {
  public static generatePrimaryKeyUUID() {
    return uuid().replace(/-/g, '')
  }
}

const fn = () => {
  return StringHelper.generatePrimaryKeyUUID().slice(0, 8).toLowerCase()
}

export const throwError = () => {
  throw new Error('我是谁哈哈哈哈')
}

console.log(fn())
