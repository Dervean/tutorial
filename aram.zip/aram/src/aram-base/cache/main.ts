import { throwError } from './fn'

const fn = () => {
  try {
    throwError()
  } catch (error) {
    console.log((error as Error).stack)
    console.log((error as Error).message)
    console.log((error as Error).name)
  }
}
