import { AramLogger } from '~/aram-lib/model/aram-logger'
import { createConnection, Connection } from '@gfe/zebra-typeorm-client'
import { APP_KEY as appName } from '~/aram-lib/config'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { KMSConfigKeyEnum, KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'
import { AramAdministrator } from '~/aram-base/entities/aram-administrator'
import { AramApplication } from '~/aram-base/entities/aram-application'
import { AramCustomComponent } from '~/aram-base/entities/aram-custom-component'
import { AramCustomComponentVersion } from '~/aram-base/entities/aram-custom-component-version'
import { AramMaraBuiltinComponent } from '~/aram-base/entities/aram-mara-builtin-component'
import { AramMember } from '~/aram-base/entities/aram-member'
import { AramModule } from '~/aram-base/entities/aram-module'
import { AramProject } from '~/aram-base/entities/aram-project'
import { AramSchema } from '~/aram-base/entities/aram-schema'
import { AramSchemaBetaVersion } from '~/aram-base/entities/aram-schema-beta-version'
import { AramSchemaDraft } from '~/aram-base/entities/aram-schema-draft'
import { AramSchemaVersion } from '~/aram-base/entities/aram-schema-version'
import { AramSchemaFlowHistoryOrder } from '~/aram-base/entities/flow-history-order/aram-schema-flow-history-order'
import { AramFlowApprover } from '~/aram-base/entities/flow/aram-flow-approver'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'
import { DynaFormSchema } from '~/aram-base/entities/dyna/dyna-form-schema'
import { AramSchemaMember } from '~/aram-base/entities/aram-schema-member'
import { DynaAlert } from '~/aram-base/entities/dyna/dyna-alert'
import { AramCraneTask } from '~/aram-base/entities/aram-crane-task'

type Columns<T> = {
  [key in keyof Omit<T, 'toJSON'>]: key
}

export abstract class AbstractDAO<T> {
  protected repository: Function
  protected primaryKey: string
  protected tableName: string
  protected columns: Columns<T>
  private static connection: Connection = null

  constructor() {}

  protected async getRepository() {
    if (AbstractDAO.connection === null) {
      await AbstractDAO.initConnection()
    }
    if (!AbstractDAO.connection.isConnected) {
      await AbstractDAO.connection.connect()
    }
    return AbstractDAO.connection.getRepository<T>(this.repository)
  }

  /**
   * 一般不使用
   * 通过事务执行多个 raw query
   * @param queryList
   * @returns
   */
  public static async runSQL(queryList: string[]) {
    try {
      if (AbstractDAO.connection === null) {
        await AbstractDAO.initConnection()
      }
      const queryRunner = AbstractDAO.connection.createQueryRunner()

      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        for (let i = 0; i < queryList.length; i++) {
          await queryRunner.manager.query(queryList[i])
        }
        await queryRunner.commitTransaction()
      } catch (e) {
        AramLogger.logError('transaction is failed', { queryList, message: e.message })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      AramLogger.logError(error, { queryList })
      throw error
    }
  }

  public static async initConnection() {
    try {
      const [jdbcRef, routeType, type] = await Promise.all([
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.RdsJdbcRef),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.RdsRouteType),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.RdsConnType),
      ])
      const entities = [
        AramSchemaFlowHistoryOrder,
        AramProject,
        AramModule,
        AramMember,
        AramSchema,
        AramSchemaDraft,
        AramSchemaVersion,
        AramSchemaBetaVersion,
        AramCustomComponent,
        AramCustomComponentVersion,
        AramMaraBuiltinComponent,
        AramAdministrator,
        AramApplication,
        AramFlowProcess,
        AramFlowTask,
        AramFlowOrder,
        AramFlowApprover,
        AramSchemaMember,
        AramCraneTask,
        DynaFormSchema,
        DynaAlert,
      ]
      AbstractDAO.connection = await createConnection({ appName, jdbcRef, routeType, type, entities })
    } catch (error) {
      AramLogger.logError(`Zebra 链接失败：${error.message}`)
      throw new AramZebraError('服务异常，请重试')
    }
  }

  public static async closeConnection() {
    try {
      if (AbstractDAO.connection && AbstractDAO.connection.isConnected) {
        await AbstractDAO.connection.close()
        AramLogger.logInfo(`zebra connection closed`)
      }
    } catch (error) {
      AramLogger.logError(`zebra connection close failed: ${error.message}`)
      throw error
    }
  }

  /** 改 */
  public async updateByPrimaryKey(key: AramPrimaryKeyType, data: Partial<T>) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({ ...data })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()
    } catch (error) {
      AramLogger.logError(error, { key, data })
      throw error
    }
  }

  /** 查 */
  public async getByPrimaryKey(key: AramPrimaryKeyType): Promise<T> {
    try {
      const repo = await this.getRepository()

      // prettier-ignore
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.primaryKey} = :key`, { key })
        .getOne()

      return (result || null) as T
    } catch (error) {
      AramLogger.logError(error, { key })
      throw error
    }
  }

  public async getByPrimaryKeyList(keys: AramPrimaryKeyType[]): Promise<T[]> {
    try {
      const repo = await this.getRepository()

      if (keys.length === 0) {
        return []
      }

      // prettier-ignore
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.primaryKey} IN (:keys)`, { keys })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { keys })
      throw error
    }
  }
}
