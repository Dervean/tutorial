import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { AramAdministrator } from '~/aram-base/entities/aram-administrator'
import { StringHelper } from '~/aram-lib/helper/string-helper'

export class AdministratorDAO extends AbstractDAO<AramAdministrator> {
  constructor() {
    super()
    this.repository = AramAdministrator
    this.primaryKey = 'userId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      userId: 'userId',
      userName: 'userName',
      /** 可选项 */
      createTime: 'createTime',
    }
  }
}
