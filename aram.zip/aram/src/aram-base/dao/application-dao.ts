import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { AramApplication } from '~/aram-base/entities/aram-application'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'

export class ApplicationDAO extends AbstractDAO<AramApplication> {
  constructor() {
    super()
    this.repository = AramApplication
    this.primaryKey = 'appUid'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = Object.freeze({
      appUid: 'appUid',
      /** 必填项 */
      appName: 'appName',
      createdBy: 'createdBy',
      /** 可选项 */
      ext: 'ext',
      hooks: 'hooks',
      status: 'status',
      description: 'description',
      /** 可选项 */
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    })
  }

  /** 增 */
  public async insert(row: AramApplication) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  /** 删 */
  async deleteByPrimaryKey(key: AramUidType, operator: AramUserNameType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({
          [`${this.columns.status}`]: AramStatusEnum.Inactive,
          [`${this.columns.updatedBy}`]: `${operator}`,
        })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { key })
      throw error
    }
  }

  /**
   * 查询全部结果并分页
   * @param offset
   * @param limit
   * @returns
   */
  public async search(offset: number, limit: number, status?: AramStatusEnum) {
    try {
      const repo = await this.getRepository()

      const hasStatus = status !== undefined
      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where(hasStatus ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as PagedResult<AramApplication>
    } catch (error) {
      AramLogger.logError(error, { offset, limit, status })
      throw error
    }
  }
}
