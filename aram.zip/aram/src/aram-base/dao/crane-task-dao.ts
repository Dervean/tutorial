import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { AramCraneTask } from '../entities/aram-crane-task'

export class CraneTaskDAO extends AbstractDAO<AramCraneTask> {
  constructor() {
    super()
    this.repository = AramCraneTask
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      craneTaskId: 'craneTaskId',
      craneTaskName: 'craneTaskName',
      version: 'version',
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
    this.primaryKey = this.columns.craneTaskId
  }

  async insert(row: AramCraneTask) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  async getLatestByCraneTaskName(craneTaskName: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.craneTaskName} = :craneTaskName`, { craneTaskName })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { craneTaskName })
      throw error
    }
  }
}
