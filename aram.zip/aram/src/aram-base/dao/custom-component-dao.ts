import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramCustomComponent } from '~/aram-base/entities/aram-custom-component'

export class CustomComponentDAO extends AbstractDAO<AramCustomComponent> {
  constructor() {
    super()
    this.repository = AramCustomComponent
    this.primaryKey = 'componentId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      componentId: 'componentId',
      /** 必填项 */
      projectId: 'projectId',
      /** 可选项 */
      isDeleted: 'isDeleted',
      description: 'description',
      /** 可选项 */
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: Partial<AramCustomComponent>) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }
}
