import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { AramCustomComponentVersion } from '~/aram-base/entities/aram-custom-component-version'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { StringHelper } from '~/aram-lib/helper/string-helper'

export class CustomComponentVersionDAO extends AbstractDAO<AramCustomComponentVersion> {
  constructor() {
    super()
    this.repository = AramCustomComponentVersion
    this.primaryKey = 'componentVersionId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      componentVersionId: 'componentVersionId',
      /** 必填项 */
      projectId: 'projectId',
      componentId: 'componentId',
      componentName: 'componentName',
      componentType: 'componentType',
      schema: 'schema',
      bundleMd5: 'bundleMd5',
      version: 'version',
      /** 可选项 */
      bundleLink: 'bundleLink',
      previews: 'previews',
      description: 'description',
      /** 可选项 */
      createdBy: 'createdBy',
      createTime: 'createTime',
    }
  }

  /** 增 */
  public async insert(row: Partial<AramCustomComponentVersion>) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  /**
   * 根据 componentId 查询最新版本的 component
   * @param componentId
   */
  async getLastestVersionByComponentId(componentId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.componentId} = :componentId`, { componentId })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .limit(1)
        .getOne()

      return result as AramCustomComponentVersion
    } catch (error) {
      AramLogger.logError(error, { componentId })
      throw error
    }
  }

  /**
   * 根据 projectId 查询所有最新版本的 component
   * @param projectId
   */
  async getAllLastestVersionByProjectId(projectId: AramIdType) {
    try {
      if (!projectId) return [] as AramCustomComponentVersion[]

      const repo = await this.getRepository()

      const joinTableName = `${this.tableName}_mirror`
      const result = await repo
        .createQueryBuilder(this.tableName)
        .leftJoinAndSelect(
          this.tableName,
          joinTableName,
          `
            ${this.tableName}.${this.columns.componentId} = ${joinTableName}.${this.columns.componentId}
            AND ${this.tableName}.${this.columns.version} < ${joinTableName}.${this.columns.version}
          `,
        )
        .where(`${joinTableName}.${this.columns.version} IS NULL`)
        .andWhere(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { projectId })
      throw error
    }
  }
}
