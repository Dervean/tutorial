import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { EnumHelper } from '~/aram-lib/helper/enum-helper'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { DynaAlert } from '~/aram-base/entities/dyna/dyna-alert'
import assert from 'assert'
import { StateEnum } from '~/aram-base/enum/flow'

export class DynaAlertDAO extends AbstractDAO<DynaAlert> {
  constructor() {
    super()
    this.repository = DynaAlert
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      craneTaskId: 'craneTaskId',
      craneTaskName: 'craneTaskName',
      schemaId: 'schemaId',
      notifiers: 'notifiers',
      remindTime: 'remindTime',
      remark: 'remark',
      status: 'status',
      state: 'state',
      stateDesc: 'stateDesc',
      createTime: 'createTime',
      createdBy: 'createdBy',
      updateTime: 'updateTime',
    }
    this.primaryKey = this.columns.craneTaskId
  }

  async insert(row: DynaAlert) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  async deleteByPrimaryKey(key: AramUuidType) {
    try {
      const repo = await this.getRepository()
      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({
          [`${this.columns.status}`]: AramStatusEnum.Inactive,
        })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { key })
      throw error
    }
  }

  async getAlertListBy(filter: DynaAlert) {
    try {
      const repo = await this.getRepository()

      const query = repo.createQueryBuilder(this.tableName)
      let queryNum = 0
      query.where(`1=1`)
      if (EnumHelper.isEnumMember(filter.status, AramStatusEnum)) {
        query.andWhere(`${this.tableName}.${this.columns.status} = :status`, { status: filter.status })
        queryNum++
      }
      if (EnumHelper.isEnumMember(filter.state, StateEnum)) {
        query.andWhere(`${this.tableName}.${this.columns.state} = :state`, { state: filter.state })
        queryNum++
      }
      if (filter.schemaId) {
        query.andWhere(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId: filter.schemaId })
        queryNum++
      }
      assert.ok(!!queryNum, `错误!!数据查询条件不能为空`)
      const result = await query.getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { filter })
      throw error
    }
  }

  async getMarkedAlertList() {
    try {
      const repo = await this.getRepository()

      return repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.status} = :status`, { status: AramStatusEnum.Active })
        .andWhere(`${this.tableName}.${this.columns.state} != :state`, { state: StateEnum.Active })
        .getMany()
    } catch (error) {
      AramLogger.logError(error)
      throw error
    }
  }
}
