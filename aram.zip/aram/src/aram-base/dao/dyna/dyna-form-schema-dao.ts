import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { EnumHelper } from '~/aram-lib/helper/enum-helper'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { DynaFormSchema } from '~/aram-base/entities/dyna/dyna-form-schema'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'

export class DynaFormSchemaDAO extends AbstractDAO<DynaFormSchema> {
  constructor() {
    super()
    this.repository = DynaFormSchema
    this.primaryKey = 'id'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      id: 'id',
      schemaId: 'schemaId',
      aramSchemaId: 'aramSchemaId',
      status: 'status',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  async insert(row: DynaFormSchema) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  async getAllBySchemaId(schemaId: AramIdType, filter?: DynaFormSchema) {
    try {
      const repo = await this.getRepository()

      const query = repo.createQueryBuilder(this.tableName)
      query.where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
      if (EnumHelper.isEnumMember(filter.status, AramStatusEnum)) {
        query.andWhere(`${this.tableName}.${this.columns.status} = :status`, { status: filter.status })
      }
      const result = await query.getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaId, filter })
      throw error
    }
  }

  async getBySchemaIdAndAramSchemaId(schemaId: AramIdType, aramSchemaId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.aramSchemaId} = :aramSchemaId`, { aramSchemaId })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }
}
