import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramSchemaFlowHistoryOrder } from '~/aram-base/entities/flow-history-order/aram-schema-flow-history-order'

export class SchemaFlowHistoryOrderDAO extends AbstractDAO<AramSchemaFlowHistoryOrder> {
  constructor() {
    super()
    this.repository = AramSchemaFlowHistoryOrder
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      orderId: 'orderId',
      processName: 'processName',
      state: 'state',
      stateDesc: 'stateDesc',
      creator: 'creator',
      creatorRemark: 'creatorRemark',
      auditState: 'auditState',
      auditStateDesc: 'auditStateDesc',
      schemaId: 'schemaId',
      appUid: 'appUid',
      projectId: 'projectId',
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
    this.primaryKey = this.columns.orderId
  }

  /** 增 */
  public async insert(row: AramSchemaFlowHistoryOrder) {
    try {
      const repo = await this.getRepository()
      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) {
        throw new AramZebraError()
      }
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  public async getFilteredOrderList(schemaId: AramIdType, filter: Partial<AramSchemaFlowHistoryOrder>) {
    try {
      const repo = await this.getRepository()

      const query = repo.createQueryBuilder(this.tableName)
      query.where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
      if (typeof filter.state === 'number') {
        query.andWhere(`${this.tableName}.${this.columns.state} = :state`, { state: filter.state })
      }
      if (filter.processName) {
        query.andWhere(`${this.tableName}.${this.columns.processName} = :processName`, { processName: filter.processName })
      }
      const result = await query.getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaId, filter })
      throw error
    }
  }
}
