import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramFlowApprover } from '~/aram-base/entities/flow/aram-flow-approver'

export class FlowApproverDAO extends AbstractDAO<AramFlowApprover> {
  constructor() {
    super()
    this.repository = AramFlowApprover
    this.primaryKey = 'approverId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      approverId: 'approverId',
      approverRemark: 'approverRemark',
      approver: 'approver',
      orderId: 'orderId',
      auditState: 'auditState',
      auditStateDesc: 'auditStateDesc',
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: AramFlowApprover) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  public async insertMany(rows: AramFlowApprover[]) {
    try {
      if (rows.length === 0) return
      const repo = await this.getRepository()

      const result = await repo.createQueryBuilder().insert().into(this.repository).values(rows).execute()

      if (result.identifiers.length !== rows.length) throw new AramZebraError()
    } catch (error) {
      AramLogger.logError(error, { rows })
      throw error
    }
  }

  public async bulkUpdate(rows: AramFlowApprover[]) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        const queryList = rows.map(e => queryRunner.manager.getRepository(AramFlowApprover).update(e.approverId, e))
        await Promise.all(queryList)
        await queryRunner.commitTransaction()
      } catch (e) {
        AramLogger.logError(e)
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      AramLogger.logError(error, { rows })
      throw error
    }
  }

  async getAllByOrderId(orderId: AramUuidType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .andWhere(`${this.tableName}.${this.columns.orderId} = :orderId`, { orderId })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { orderId })
      throw error
    }
  }
}
