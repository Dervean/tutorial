import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'

export class FlowOrderDAO extends AbstractDAO<AramFlowOrder> {
  constructor() {
    super()
    this.repository = AramFlowOrder
    this.primaryKey = 'orderId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      orderId: 'orderId',
      processId: 'processId',
      processName: 'processName',
      state: 'state',
      stateDesc: 'stateDesc',
      parentId: 'parentId',
      parentNodeName: 'parentNodeName',
      variable: 'variable',
      creator: 'creator',
      creatorRemark: 'creatorRemark',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
      auditState: 'auditState',
      auditStateDesc: 'auditStateDesc',
    }
  }

  /** 增 */
  public async insert(row: AramFlowOrder) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }
}
