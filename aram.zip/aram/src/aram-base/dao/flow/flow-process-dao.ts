import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'

export class FlowProcessDAO extends AbstractDAO<AramFlowProcess> {
  constructor() {
    super()
    this.repository = AramFlowProcess
    this.primaryKey = 'processId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      processId: 'processId',
      name: 'name',
      displayName: 'displayName',
      status: 'status',
      version: 'version',
      content: 'content',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: AramFlowProcess) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  public async getLatestVersionByProcessName(processName: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.name} = :processName`, { processName })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { processName })
      throw error
    }
  }
}
