import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'

export class FlowTaskDAO extends AbstractDAO<AramFlowTask> {
  constructor() {
    super()
    this.repository = AramFlowTask
    this.primaryKey = 'taskId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      taskId: 'taskId',
      name: 'name',
      displayName: 'displayName',
      state: 'state',
      stateDesc: 'stateDesc',
      orderId: 'orderId',
      performType: 'performType',
      parentTaskId: 'parentTaskId',
      operator: 'operator',
      actors: 'actors',
      variable: 'variable',
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: AramFlowTask) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  public async getAllTasksByStateAndOrderId(params: Partial<AramFlowTask>): Promise<AramFlowTask[]> {
    try {
      const { state, orderId } = params
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.state} = :state`, { state })
        .andWhere(`${this.tableName}.${this.columns.orderId} = :orderId`, { orderId })
        .getMany()

      return result as AramFlowTask[]
    } catch (error) {
      AramLogger.logError(error, { params })
      throw error
    }
  }

  async getAllByOrderId(orderId: AramUuidType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .andWhere(`${this.tableName}.${this.columns.orderId} = :orderId`, { orderId })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { orderId })
      throw error
    }
  }
}
