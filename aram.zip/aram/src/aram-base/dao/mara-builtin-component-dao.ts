import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { AramMaraBuiltinComponent } from '~/aram-base/entities/aram-mara-builtin-component'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramLogger } from '~/aram-lib/model/aram-logger'

export class MaraBuiltinComponentDAO extends AbstractDAO<AramMaraBuiltinComponent> {
  constructor() {
    super()
    this.repository = AramMaraBuiltinComponent
    this.primaryKey = 'componentId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      componentId: 'componentId',
      /** 必填项 */
      componentName: 'componentName',
      componentType: 'componentType',
      group: 'group',
      status: 'status',
      schema: 'schema',
      /** 可选项 */
      icon: 'icon',
      displayName: 'displayName',
      description: 'description',
      /** 必填项 */
      createdBy: 'createdBy',
      /** 可选项 */
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: AramMaraBuiltinComponent) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  async getByComponentName(componentName: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.componentName} = :componentName`, { componentName })
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { componentName })
      throw error
    }
  }

  async getAll() {
    const repo = await this.getRepository()
    return repo.createQueryBuilder(this.tableName).getMany()
  }
}
