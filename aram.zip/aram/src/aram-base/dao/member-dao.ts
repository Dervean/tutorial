import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramMember } from '~/aram-base/entities/aram-member'
import { DateHelper } from '~/aram-lib/helper/date-helper'

export class MemberDAO extends AbstractDAO<AramMember> {
  constructor() {
    super()
    this.repository = AramMember
    this.primaryKey = 'memberId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      memberId: 'memberId',
      /** 必填项 */
      projectId: 'projectId',
      userName: 'userName',
      permission: 'permission',
      /** 可选项 */
      isDeleted: 'isDeleted',
      joinTime: 'joinTime',
      dropTime: 'dropTime',
    }
  }

  /** 增 */
  public async insert(row: AramMember) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  /** 删 */
  async deleteByPrimaryKey(key: AramIdType) {
    /**
     * 删除操作为假删
     * 1. isDeleted 置为 1
     * 2. dropTime 置为 当前系统时间
     * */

    try {
      const repo = await this.getRepository()
      const current = DateHelper.getCurrentDatetime()

      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({
          [`${this.columns.isDeleted}`]: 1,
          [`${this.columns.dropTime}`]: `${current}`,
        })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { key })
      throw error
    }
  }

  /** 查 */
  async getAllByUserName(userName: AramUserNameType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.userName} = :userName`, { userName })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .getMany()

      return result as AramMember[]
    } catch (error) {
      AramLogger.logError(error, { userName })
      throw error
    }
  }

  async getAllByProjectId(projectId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .getMany()

      return result as AramMember[]
    } catch (error) {
      AramLogger.logError(error, { projectId })
      throw error
    }
  }

  async getAllByProjectIdAndPermission(projectId: AramIdType, permission: AramPermissionType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.permission} = :permission`, { permission })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .getMany()

      return result as AramMember[]
    } catch (error) {
      AramLogger.logError(error, { projectId, permission })
      throw error
    }
  }

  /**
   * 根据 projectId 和 userName 查找
   * 需要查找是否存在已被删除的条目，此时 isDeleted 不需要设置为 0
   * @param projectId
   * @param userName
   * @returns
   */
  async getByProjectIdAndUserName(projectId: AramIdType, userName: AramUserNameType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.userName} = :userName`, { userName })
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { projectId, userName })
      throw error
    }
  }
}
