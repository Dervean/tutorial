import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramModule } from '~/aram-base/entities/aram-module'

export class ModuleDAO extends AbstractDAO<AramModule> {
  constructor() {
    super()
    this.repository = AramModule
    this.primaryKey = 'moduleId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      moduleId: 'moduleId',
      /** 必填项 */
      projectId: 'projectId',
      appUid: 'appUid',
      moduleName: 'moduleName',
      createdBy: 'createdBy',
      /** 可选项 */
      isDeleted: 'isDeleted',
      description: 'description',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: AramModule) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  /** 删 */
  async deleteByPrimaryKey(key: AramIdType, operator: AramUserNameType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({
          [`${this.columns.isDeleted}`]: 1,
          [`${this.columns.updatedBy}`]: `${operator}`,
        })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { key })
      throw error
    }
  }

  async getAllByProjectId(projectId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .andWhere(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .getMany()

      return result as AramModule[]
    } catch (error) {
      AramLogger.logError(error, { projectId })
      throw error
    }
  }

  async searchByFuzzyModuleIdAndProjectId(fuzzyModuleId: AramIdType, projectId: AramIdType, offset: number, limit: number) {
    try {
      const repo = await this.getRepository()

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .andWhere(`${this.tableName}.${this.columns.moduleId} like :fuzzyModuleId`, { fuzzyModuleId: `%${fuzzyModuleId}%` })
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as PagedResult<AramModule>
    } catch (error) {
      AramLogger.logError(error, { projectId, fuzzyModuleId })
      throw error
    }
  }

  async searchByFuzzyModuleNameAndProjectId(fuzzyModuleName: string, projectId: AramIdType, offset: number, limit: number) {
    try {
      const repo = await this.getRepository()

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .andWhere(`${this.tableName}.${this.columns.moduleName} like :fuzzyModuleName`, { fuzzyModuleName: `%${fuzzyModuleName}%` })
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as PagedResult<AramModule>
    } catch (error) {
      AramLogger.logError(error, { projectId, fuzzyModuleName })
      throw error
    }
  }

  async searchByProjectId(projectId: AramIdType, offset: number, limit: number) {
    try {
      const repo = await this.getRepository()

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as PagedResult<AramModule>
    } catch (error) {
      AramLogger.logError(error, { projectId })
      throw error
    }
  }
}
