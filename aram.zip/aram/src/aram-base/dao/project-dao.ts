import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { Brackets } from '@gfe/zebra-typeorm-client'
import { AramProject } from '~/aram-base/entities/aram-project'
import { AramMember } from '~/aram-base/entities/aram-member'

export class ProjectDAO extends AbstractDAO<AramProject> {
  constructor() {
    super()
    this.repository = AramProject
    this.primaryKey = 'projectId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      projectId: 'projectId',
      /** 必填项 */
      appUid: 'appUid',
      projectName: 'projectName',
      createdBy: 'createdBy',
      /** 可选项 */
      isPrivate: 'isPrivate',
      isDeleted: 'isDeleted',
      description: 'description',
      /** 可选项 */
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(rowProject: AramProject, rowMember: AramMember) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        const { identifiers } = await queryRunner.manager.getRepository(this.repository).insert(rowProject)
        const { projectId } = identifiers[0] as { projectId: AramIdType }

        rowMember.projectId = projectId
        await queryRunner.manager.getRepository(AramMember).insert(rowMember)
        await queryRunner.commitTransaction()
        return projectId
      } catch (e) {
        AramLogger.logError('project creation is failed', { rowProject, rowMember, message: e.message })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      AramLogger.logError(error, { rowProject, rowMember })
      throw error
    }
  }

  /** 删 */
  async deleteByPrimaryKey(key: AramIdType, operator: AramUserNameType) {
    /**
     * 删除操作为假删
     * 1. isDeleted 置为 1
     * 2. updateTime 置为 当前系统时间
     * */
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({
          [`${this.columns.isDeleted}`]: 1,
          [`${this.columns.updatedBy}`]: operator,
        })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { key, operator })
      throw error
    }
  }

  /**
   * 查询全部结果并分页
   * @param offset
   * @param limit
   * @returns
   */
  public async search(
    offset: number,
    limit: number,
    filter: {
      appUid?: AramUidType
      fuzzyProjectId?: AramIdType
      fuzzyProjectName?: string
      projectIdList?: AramIdType[]
      searchPublicFlag?: boolean
    },
  ) {
    try {
      const repo = await this.getRepository()
      const { appUid, fuzzyProjectId, fuzzyProjectName, searchPublicFlag, projectIdList = [] } = filter

      const qb = repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .andWhere(appUid ? `${this.tableName}.${this.columns.appUid} = :appUid` : `1=1`, { appUid })
        .andWhere(fuzzyProjectId ? `${this.tableName}.${this.columns.projectId} like :fuzzyProjectId` : `1=1`, {
          fuzzyProjectId: `%${fuzzyProjectId}%`,
        })
        .andWhere(fuzzyProjectName ? `${this.tableName}.${this.columns.projectName} like :fuzzyProjectName` : `1=1`, {
          fuzzyProjectName: `%${fuzzyProjectName}%`,
        })

      if (searchPublicFlag || (projectIdList && projectIdList.length)) {
        qb.andWhere(
          new Brackets(qb => {
            // prettier-ignore
            qb.where(projectIdList && projectIdList.length ? `${this.tableName}.${this.primaryKey} IN (:projectIdList)` : '1!=1', { projectIdList })
              .orWhere(searchPublicFlag ? `${this.tableName}.${this.columns.isPrivate} = :isPrivate` : '1!=1', { isPrivate: Number(false) })
          }),
        )
      }

      const [data, totalCnt] = await qb.skip(offset).take(limit).getManyAndCount()
      return { rows: data, totalCnt } as PagedResult<AramProject>
    } catch (error) {
      AramLogger.logError(error, { offset, limit, filter })
      throw error
    }
  }
}
