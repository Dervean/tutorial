import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramInvalidFormatParamError } from '~/aram-lib/model/aram-error/bad-request/aram-invalid-param-error'
import { AramAesEncryption } from '~/aram-lib/model/aram-encryption/aram-aes-encryption'
import { AramSchemaBetaVersion } from '~/aram-base/entities/aram-schema-beta-version'

export class SchemaBetaVersionDAO extends AbstractDAO<AramSchemaBetaVersion> {
  constructor() {
    super()
    this.repository = AramSchemaBetaVersion
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      schemaBetaVersionId: 'schemaBetaVersionId',
      /** 必填项 */
      projectId: 'projectId',
      moduleId: 'moduleId',
      schemaId: 'schemaId',
      version: 'version',
      betaVersion: 'betaVersion',
      url: 'url',
      type: 'type',
      createdBy: 'createdBy',
      createTime: 'createTime',
      /** 可选项 */
      description: 'description',
      rollbackFrom: 'rollbackFrom',
    }
    this.primaryKey = this.columns.schemaBetaVersionId
  }

  /**
   * beta schema S3 发布地址
   * @param projectId
   * @param schemaUid
   * @param version 不填表示发布 latest
   * @param betaVersion 不填表示发布 latest
   * @returns
   * e.g.
   *  - 323/beta/aram-schema/v100-12.json
   *  - 323/beta/aram-schema/latest.json
   */
  public static toSchemaS3BetaURLV2(
    projectId: AramIdType,
    schemaUid: AramUidType,
    version?: AramSchemaVersionType,
    betaVersion?: AramSchemaVersionType,
  ) {
    if (!schemaUid) {
      throw new AramInvalidFormatParamError(`标识不能为空: schemaUid=${schemaUid}`)
    }
    const versionStr = AramSchemaBetaVersion.betaVersion2strV2(version, betaVersion)
    return `${projectId}/beta/${schemaUid}/${versionStr}.json`
  }

  /**
   * @todo 废弃发布地址生成器 后续删除
   * beta schema S3 发布地址
   * @param projectId
   * @param schemaId
   * @param version 不填表示发布 latest
   * @param betaVersion 不填表示发布 latest
   * @returns
   * e.g.
   *  - schema/323/dist/12/v1-beta@1.json
   *  - schema/323/dist/12/latest-beta.json
   */
  public static async toSchemaS3BetaURL(
    projectId: AramIdType,
    schemaId: AramIdType,
    version?: AramSchemaVersionType,
    betaVersion?: AramSchemaVersionType,
  ) {
    const versionStr = AramSchemaBetaVersion.betaVersion2str(version, betaVersion)
    const encryptedSchemaId = await AramAesEncryption.encrypt(`${schemaId}`)
    return `schema/${projectId}/dist/${encryptedSchemaId}/${versionStr}.json`
  }

  /** 增 */
  public async insert(row: AramSchemaBetaVersion) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  /**
   * 返回 beta 版本列表 并按照版本 由新至旧 排序
   * @param schemaId
   * @param createdBy 可能为空
   * @param offset
   * @param limit
   * @returns
   */
  async searchSchemaBetaVersionListBySchemaIdAndCreatedBy(schemaId: AramIdType, createdBy: AramUserNameType, offset: number, limit: number) {
    try {
      const repo = await this.getRepository()

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(!!createdBy ? `${this.tableName}.${this.columns.createdBy} = :createdBy` : `1=1`, { createdBy })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .addOrderBy(`${this.tableName}.${this.columns.betaVersion}`, `DESC`)
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as PagedResult<AramSchemaBetaVersion>
    } catch (error) {
      AramLogger.logError(error, { schemaId, createdBy })
      throw error
    }
  }

  /**
   * 根据 schemaId 查询最新 beta 版本 schema
   * @param schemaId
   */
  async getLastestBetaVersionBySchemaId(schemaId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .addOrderBy(`${this.tableName}.${this.columns.betaVersion}`, `DESC`)
        .limit(1)
        .getOne()

      return result as AramSchemaBetaVersion
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }

  /**
   * 根据 schemaId 查询 并按照版本 由新至旧 排序
   * @param schemaId
   */
  async getAllBySchemaId(schemaId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .addOrderBy(`${this.tableName}.${this.columns.betaVersion}`, `DESC`)
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }

  /**
   * 根据 schemaId 和 version 查询 并按照 betaVersion 由新至旧 排序
   * @param schemaId
   */
  async getAllByBySchemaIdAndVersion(schemaId: AramIdType, version: AramSchemaVersionType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.version} = :version`, { version })
        .addOrderBy(`${this.tableName}.${this.columns.betaVersion}`, `DESC`)
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }

  /**
   * 根据 schemaId 和 version 和 betaVersion 查询 唯一 记录
   * @param schemaId
   * @param version
   * @param betaVersion
   */
  async getBySchemaIdAndVersionAndBetaVersion(schemaId: AramIdType, version: AramSchemaVersionType, betaVersion: AramSchemaVersionType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.version} = :version`, { version })
        .andWhere(`${this.tableName}.${this.columns.betaVersion} = :betaVersion`, { betaVersion })
        .limit(1)
        .getOne()

      return result as AramSchemaBetaVersion
    } catch (error) {
      AramLogger.logError(error, { schemaId, version, betaVersion })
      throw error
    }
  }

  /**
   * 根据 schemaId[] 查询所有 schemaBetaVersion
   * @param schemaIdList
   * @returns
   */
  async getAllBySchemaIdList(schemaIdList: AramIdType[]) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} IN (:schemaIdList)`, { schemaIdList })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaIdList })
      throw error
    }
  }
}
