import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramSchema } from '~/aram-base/entities/aram-schema'

export class SchemaDAO extends AbstractDAO<AramSchema> {
  constructor() {
    super()
    this.repository = AramSchema
    this.primaryKey = 'schemaId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      schemaId: 'schemaId',
      /** 必填项 */
      schemaUid: 'schemaUid',
      projectId: 'projectId',
      appUid: 'appUid',
      moduleId: 'moduleId',
      schemaName: 'schemaName',
      createdBy: 'createdBy',
      /** 可选项 */
      isDeleted: 'isDeleted',
      description: 'description',
      /** 可选项 */
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: AramSchema) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  /** 删 */
  async deleteByPrimaryKey(key: AramIdType, operator: AramUserNameType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({
          [`${this.columns.isDeleted}`]: 1,
          [`${this.columns.updatedBy}`]: `${operator}`,
        })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { key })
      throw error
    }
  }

  async getByProjectIdAndSchemaUid(projectId: AramIdType, schemaUid: AramUidType) {
    try {
      const repo = await this.getRepository()

      /**
       * 这里不限制 isDeleted = 0
       * projectId & schemaUid 是联合索引
       * 新增 schema 也会受到被标记删除的 schema 的限制
       */
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.schemaUid} = :schemaUid`, { schemaUid })
        .limit(1)
        .getOne()

      return result
    } catch (error) {
      AramLogger.logError(error, { projectId })
      throw error
    }
  }

  /**
   * 根据 projectId[] 查询所有 schema (包括已删除的 schema)
   * @param projectIdList
   * @returns
   */
  async getAllByProjectIdList(projectIdList: AramIdType[]) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} IN (:projectIdList)`, { projectIdList })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { projectIdList })
      throw error
    }
  }

  /** 查 */
  async search(
    offset: number,
    limit: number,
    filter: {
      projectId?: AramIdType
      moduleId?: AramIdType
      fuzzySchemaId?: AramIdType
      fuzzySchemaName?: string
    },
  ) {
    try {
      const { projectId, fuzzySchemaName, moduleId, fuzzySchemaId } = filter

      const repo = await this.getRepository()
      const joinTableName = `aram_schema_version`
      //const [data, totalCnt] = await repo
      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .leftJoinAndSelect(
          joinTableName,
          joinTableName,
          `
            ${this.tableName}.${this.columns.schemaId} = ${joinTableName}.${this.columns.schemaId}
          `,
        )
        .where(`1=1`)
        .andWhere(qb => {
          const subQuery = qb
            .subQuery()
            .select(`max(create_time)`)
            .from(joinTableName, 'joinTable')
            .where(`joinTable.schema_id = ${this.tableName}.${this.columns.schemaId}`)
            .getQuery()
          return '(' + joinTableName + '.createTime = ' + subQuery
        })
        .orWhere(`aram_schema_version.${this.columns.createTime} IS NULL)`)
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .andWhere(projectId ? `${this.tableName}.${this.columns.projectId} = :projectId` : `1=1`, { projectId })
        .andWhere(fuzzySchemaName ? `${this.tableName}.${this.columns.schemaName} like :fuzzySchemaName` : `1=1`, {
          fuzzySchemaName: `%${fuzzySchemaName}%`,
        })
        .andWhere(fuzzySchemaId ? `${this.tableName}.${this.columns.schemaId} like :fuzzySchemaId` : `1=1`, {
          fuzzySchemaId: `%${fuzzySchemaId}%`,
        })
        .andWhere(moduleId ? `${this.tableName}.${this.columns.moduleId} = :moduleId` : `1=1`, { moduleId })
        .orderBy(`${joinTableName}.${this.columns.createTime}`, `DESC`)
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as PagedResult<AramSchema>
    } catch (error) {
      AramLogger.logError(error, { filter })
      throw error
    }
  }

  async countByModuleIdList(moduleIds: AramIdType[]) {
    try {
      const repo = await this.getRepository()

      if (moduleIds.length === 0) return []

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.moduleId} IN (:moduleIds)`, { moduleIds })
        .andWhere(`${this.tableName}.${this.columns.isDeleted} = :key`, { key: 0 })
        .select([
          `COUNT(${this.tableName}.${this.columns.moduleId}) as count`,
          `${this.tableName}.${this.columns.moduleId} as ${this.columns.moduleId}`,
        ])
        .groupBy(`${this.tableName}.${this.columns.moduleId}`)
        .getRawMany()

      return result as { moduleId: AramIdType; count: number }[]
    } catch (error) {
      AramLogger.logError(error, { moduleIds })
      throw error
    }
  }
}
