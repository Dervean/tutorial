import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramSchemaDraft } from '~/aram-base/entities/aram-schema-draft'

export class SchemaDraftDAO extends AbstractDAO<AramSchemaDraft> {
  constructor() {
    super()
    this.repository = AramSchemaDraft
    this.primaryKey = 'schemaDraftId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      schemaDraftId: 'schemaDraftId',
      /** 必填项 */
      schemaId: 'schemaId',
      projectId: 'projectId',
      moduleId: 'moduleId',
      userName: 'userName',
      schema: 'schema',
      /** 可选项 */
      syncVersion: 'syncVersion',
      schemaName: 'schemaName',
      description: 'description',
      /** 可选项 */
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
  }

  /** 增 */
  public async insert(row: AramSchemaDraft) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  async getBySchemaIdAndUserName(schemaId: AramIdType, userName: AramUserNameType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.userName} = :userName`, { userName })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { schemaId, userName })
      throw error
    }
  }
}
