import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramSchemaMember } from '~/aram-base/entities/aram-schema-member'
import { DateHelper } from '~/aram-lib/helper/date-helper'

export class SchemaMemberDao extends AbstractDAO<AramSchemaMember> {
  constructor() {
    super()
    this.repository = AramSchemaMember
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      memberId: 'memberId',
      schemaId: 'schemaId',
      projectId: 'projectId',
      userName: 'userName',
      permission: 'permission',
      status: 'status',
      joinTime: 'joinTime',
      dropTime: 'dropTime',
    }
    this.primaryKey = this.columns.memberId
  }

  // 增
  public async insert(row: AramSchemaMember) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([{ ...row }])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  // 删
  async deleteByPrimaryKey(key: AramIdType) {
    try {
      const repo = await this.getRepository()
      const current = DateHelper.getCurrentDatetime()

      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set({ [`${this.columns.status}`]: 1, [`${this.columns.dropTime}`]: `${current}` })
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { key })
      throw error
    }
  }

  // 查
  async getAllBySchemaId(schemaId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.status} = :key`, { key: 0 })
        .getMany()

      return result as AramSchemaMember[]
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }

  async getAllBySchemaIdAndPermission(schemaId: AramIdType, permission: AramPermissionType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.permission} = :permission`, { permission })
        .andWhere(`${this.tableName}.${this.columns.status} = :key`, { key: 0 })
        .getMany()

      return result as AramSchemaMember[]
    } catch (error) {
      AramLogger.logError(error, { schemaId, permission })
      throw error
    }
  }

  async getBySchemaIdAndUserName(schemaId: AramIdType, userName: AramUserNameType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.userName} = :userName`, { userName })
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { schemaId, userName })
      throw error
    }
  }
}
