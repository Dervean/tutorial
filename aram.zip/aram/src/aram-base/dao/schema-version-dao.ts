import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramInvalidFormatParamError } from '~/aram-lib/model/aram-error/bad-request/aram-invalid-param-error'
import { AramAesEncryption } from '~/aram-lib/model/aram-encryption/aram-aes-encryption'
import { AramSchemaVersion } from '~/aram-base/entities/aram-schema-version'
import { AramSchemaVersionTypeEnum } from '~/aram-base/enum/common'

export class SchemaVersionDAO extends AbstractDAO<AramSchemaVersion> {
  constructor() {
    super()
    this.repository = AramSchemaVersion
    this.primaryKey = 'schemaVersionId'
    this.tableName = StringHelper.transformFromCamelCase(this.repository.name, 'snake')
    this.columns = {
      schemaVersionId: 'schemaVersionId',
      /** 必填项 */
      projectId: 'projectId',
      moduleId: 'moduleId',
      schemaId: 'schemaId',
      version: 'version',
      url: 'url',
      type: 'type',
      createdBy: 'createdBy',
      createTime: 'createTime',

      /** 可选项 */
      description: 'description',
      rollbackFrom: 'rollbackFrom',
    }
  }

  /**
   * schema S3 线上发布地址
   * @param projectId
   * @param schemaUid
   * @param version
   * @returns
   * e.g.
   *  323/dist/aram-schema/v2.json
   *  323/dist/aram-schema/latest.json
   */
  public static toSchemaS3ProdURLV2(projectId: AramIdType, schemaUid: AramUidType, version: AramSchemaVersionType | AramSchemaVersionTypeEnum) {
    if (!schemaUid) {
      throw new AramInvalidFormatParamError(`标识不能为空: schemaUid=${schemaUid}`)
    }
    const versionStr = AramSchemaVersion.version2str(version)
    return `${projectId}/dist/${schemaUid}/${versionStr}.json`
  }

  /**
   * @todo 废弃发布地址生成器 后续删除
   * schema S3 线上发布地址
   * @param projectId
   * @param schemaId
   * @param version
   * @returns
   * e.g.
   *  schema/323/dist/12/v2.json
   *  schema/323/dist/12/latest.json
   */
  public static async toSchemaS3ProdURL(projectId: AramIdType, schemaId: AramIdType, version: AramSchemaVersionType | AramSchemaVersionTypeEnum) {
    const versionStr = AramSchemaVersion.version2str(version)
    const encryptedSchemaId = await AramAesEncryption.encrypt(`${schemaId}`)
    return `schema/${projectId}/dist/${encryptedSchemaId}/${versionStr}.json`
  }

  /** 增 */
  public async insert(row: AramSchemaVersion) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder()
        .insert()
        .into(this.repository)
        .values([
          {
            ...row,
          },
        ])
        .execute()

      if (result.identifiers.length !== 1) throw new AramZebraError()

      return result
    } catch (error) {
      AramLogger.logError(error, { row })
      throw error
    }
  }

  /**
   * 返回版本列表 并按照版本 由新至旧 排序
   * @param schemaId
   * @param createdBy 可能为空
   * @param offset
   * @param limit
   * @returns
   */
  async searchSchemaVersionListBySchemaIdAndCreatedBy(schemaId: AramIdType, createdBy: AramUserNameType, offset: number, limit: number) {
    try {
      const repo = await this.getRepository()

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(!!createdBy ? `${this.tableName}.${this.columns.createdBy} = :createdBy` : `1=1`, { createdBy })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as PagedResult<AramSchemaVersion>
    } catch (error) {
      AramLogger.logError(error, { schemaId, createdBy })
      throw error
    }
  }

  /**
   * 根据 schemaId 查询最新版本的 schema
   * @param schemaId
   */
  async getLastestVersionBySchemaId(schemaId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }

  /**
   * 根据 schemaId 查询 所有版本 schema 并按照版本 由新至旧 排序
   * @param schemaId
   */
  async getAllBySchemaId(schemaId: AramIdType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }

  /**
   * 根据 schemaId 和 版本 查询 唯一 schema
   * @param schemaId
   * @param version
   */
  async getBySchemaIdAndVersion(schemaId: AramIdType, version: AramSchemaVersionType) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} = :schemaId`, { schemaId })
        .andWhere(`${this.tableName}.${this.columns.version} = :version`, { version })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      AramLogger.logError(error, { schemaId })
      throw error
    }
  }

  /**
   * 根据 schema Id list 查询 所有 最新版本 的 schema
   * @param schemaIds
   */
  async getAllLatestVersionBySchemaIdList(schemaIds: AramIdType[]) {
    try {
      if (!schemaIds || !schemaIds.length) return [] as AramSchemaVersion[]

      const repo = await this.getRepository()

      const joinTableName = `${this.tableName}_mirror`
      const result = await repo
        .createQueryBuilder(this.tableName)
        .leftJoinAndSelect(
          this.tableName,
          joinTableName,
          `
            ${this.tableName}.${this.columns.schemaId} = ${joinTableName}.${this.columns.schemaId}
            AND ${this.tableName}.${this.columns.version} < ${joinTableName}.${this.columns.version}
          `,
        )
        .where(`${joinTableName}.${this.columns.version} IS NULL`)
        .andWhere(`${this.tableName}.${this.columns.schemaId} IN (:schemaIds)`, { schemaIds })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaIds })
      throw error
    }
  }

  /**
   * 根据 schemaId[] 查询所有 schemaVersion
   * @param schemaIdList
   * @returns
   */
  async getAllBySchemaIdList(schemaIdList: AramIdType[]) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.schemaId} IN (:schemaIdList)`, { schemaIdList })
        .getMany()

      return result
    } catch (error) {
      AramLogger.logError(error, { schemaIdList })
      throw error
    }
  }
}
