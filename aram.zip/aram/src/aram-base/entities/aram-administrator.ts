import { Entity, Column, PrimaryColumn, CreateDateColumn } from '@gfe/zebra-typeorm-client'

@Entity()
export class AramAdministrator {
  @PrimaryColumn({ name: 'user_id', type: 'int', unsigned: true, comment: 'SSO 环境下为用户 ID' })
  userId: AramIdType

  @Column({ name: 'user_name', type: 'varchar', length: 64, comment: 'SSO 环境下为 MIS 号' })
  userName: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
}
