import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { AramStatusEnum } from '~/aram-base/enum/common'

@Entity()
export class AramApplication {
  @PrimaryColumn({ name: 'app_uid', type: 'varchar', length: 64, comment: '应用场景标识, 应用场景表对应主键' })
  appUid: AramUidType
  @Column({ name: 'app_name', type: 'varchar', length: 64, comment: '应用场景名称' })
  appName: string

  @Column({ name: 'ext', type: 'simple-json', comment: '外部配置' })
  ext?: AramJsonType
  @Column({ name: 'hooks', type: 'simple-json', comment: '生命周期钩子配置' })
  hooks?: AramJsonType
  @Column({ name: 'status', type: 'tinyint', comment: '状态', default: 0 })
  status?: AramStatusEnum
  @Column({ name: 'description', type: 'varchar', length: 256, comment: '描述' })
  description?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}
