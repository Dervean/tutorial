import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { AramStatusEnum } from '~/aram-base/enum/common'

@Entity()
export class AramCraneTask {
  @PrimaryColumn({ name: 'crane_task_id', type: 'varchar', length: 128 })
  craneTaskId: string
  @Column({ name: 'crane_task_name', type: 'varchar', length: 128 })
  craneTaskName: string
  @Column({ type: 'bigint', comment: '版本号', unsigned: true })
  version: number

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}
