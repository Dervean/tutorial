import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from '@gfe/zebra-typeorm-client'

@Entity()
export class AramCustomComponentVersion {
  @PrimaryGeneratedColumn({ name: 'component_version_id', type: 'bigint', comment: '自定义组件版本 Id, 自定义组件版本表对应主键', unsigned: true })
  componentVersionId: AramIdType

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'component_id', type: 'bigint', comment: '自定义组件 Id' })
  componentId: AramIdType
  @Column({ name: 'component_name', type: 'varchar', length: 64, comment: '自定义组件名称' })
  componentName: string
  @Column({ name: 'component_type', type: 'tinyint', comment: '组件类型' })
  componentType: AramMaraComponentType
  @Column({ name: 'schema', type: 'simple-json', comment: '自定义组件 配置项 JSON' })
  schema: AramJsonType
  @Column({ name: 'bundle_md5', type: 'varchar', length: 256, comment: '打包代码 MD5' })
  bundleMd5: string
  @Column({ type: 'bigint', comment: '自定义组件版本号', unsigned: true })
  version: AramComponentVersionType

  @Column({ name: 'bundle_link', type: 'varchar', length: 256, comment: '打包代码 链接' })
  bundleLink?: string
  @Column({ name: 'previews', type: 'simple-json', comment: '预览信息' })
  previews?: { title: string; link: string }[]
  @Column({ type: 'varchar', length: 256, comment: '自定义组件描述' })
  description?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
}

export type CreateCustomComponentVersionParams = Pick<
  AramCustomComponentVersion,
  'projectId' | 'componentId' | 'componentName' | 'componentType' | 'bundleMd5' | 'schema' | 'bundleLink' | 'previews' | 'description'
>
