import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'

@Entity()
export class AramCustomComponent {
  @PrimaryGeneratedColumn({ name: 'component_id', type: 'bigint', comment: '自定义组件Id, 自定义组件表对应主键', unsigned: true })
  componentId: AramIdType

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType

  @Column({ name: 'is_deleted', type: 'tinyint', comment: '是否删除', default: 0 })
  isDeleted?: number
  @Column({ type: 'varchar', length: 256, comment: '项目描述' })
  description?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}

export type CreateCustomComponentParams = Pick<AramCustomComponent, 'projectId' | 'description'>
