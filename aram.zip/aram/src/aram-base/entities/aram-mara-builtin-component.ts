import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { AramMaraComponentGroupEnum, AramStatusEnum } from '~/aram-base/enum/common'

@Entity()
export class AramMaraBuiltinComponent {
  @PrimaryGeneratedColumn({ name: 'component_id', type: 'bigint', comment: 'Mara 内置组件 Id, Mara 内置组件表 对应主键', unsigned: true })
  componentId: AramIdType

  /** 必填项 */
  @Column({ name: 'component_name', type: 'varchar', length: 256, comment: '内置组件名称' })
  componentName: string
  @Column({ name: 'component_type', type: 'tinyint', comment: '组件类型' })
  componentType: AramMaraComponentType
  @Column({ type: 'tinyint', comment: '组件类型' })
  group: AramMaraComponentGroupEnum
  @Column({ type: 'tinyint', comment: '状态' })
  status: AramStatusEnum
  @Column({ name: 'schema', type: 'simple-json', comment: '内置组件 配置项 JSON' })
  schema: AramJsonType

  @Column({ name: 'icon', type: 'varchar', length: 512, comment: '组件图标资源' })
  icon?: string
  @Column({ name: 'display_name', type: 'varchar', length: 256, comment: '组件展示名称' })
  displayName?: string
  @Column({ name: 'description', type: 'varchar', length: 256, comment: '内置组件描述' })
  description?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  constructor(model?: AramMaraBuiltinComponent) {
    if (model) {
      if (model.componentName) this.componentName = model.componentName
      if (model.componentType !== undefined) this.componentType = +model.componentType
      if (model.group !== undefined) this.group = +model.group
      if (model.status !== undefined) this.status = +model.status
      if (model.schema) this.schema = model.schema
      if (model.icon) this.icon = model.icon
      if (model.displayName) this.displayName = model.displayName
      if (model.description) this.description = model.description
      if (model.createdBy) this.createdBy = model.createdBy
      if (model.updatedBy) this.updatedBy = model.updatedBy
    }
  }

  public toJSON() {
    return {
      // componentId: this.componentId,
      componentName: this.componentName,
      componentType: this.componentType,
      group: this.group,
      // status: this.status,
      schema: this.schema,
      icon: this.icon,
      displayName: this.displayName,
      createdBy: this.createdBy,
      createTime: this.createTime,
      updatedBy: this.updatedBy,
      updateTime: this.updateTime,
    }
  }
}
