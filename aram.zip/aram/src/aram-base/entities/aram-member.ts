import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from '@gfe/zebra-typeorm-client'

@Entity()
export class AramMember {
  @PrimaryGeneratedColumn({ name: 'member_id', type: 'bigint', comment: '成员 Id, 成员信息表对应主键', unsigned: true })
  memberId: AramIdType

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'user_name', type: 'varchar', length: 64, comment: 'SSO 环境下为 MIS 号' })
  userName: AramUserNameType
  @Column({ type: 'int', comment: '权限 32-bit integer', unsigned: true })
  permission: AramPermissionType

  @Column({ name: 'is_deleted', type: 'tinyint', comment: '是否删除', default: 0 })
  isDeleted?: number

  /** 可选项 */
  @CreateDateColumn({ name: 'join_time', type: 'datetime', comment: '加入时间' })
  joinTime?: string
  @CreateDateColumn({ name: 'drop_time', type: 'datetime', comment: '离开时间' })
  dropTime?: string
}
