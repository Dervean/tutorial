import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'

@Entity()
export class AramModule {
  @PrimaryGeneratedColumn({ name: 'module_id', type: 'bigint', comment: '模块 Id, 项目模块表对应主键', unsigned: true })
  moduleId: AramIdType

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'app_uid', type: 'varchar', length: 64, comment: '应用场景标识, 应用场景表对应主键' })
  appUid: AramUidType
  @Column({ name: 'module_name', type: 'varchar', length: 64, comment: '模块名称' })
  moduleName: string

  @Column({ name: 'is_deleted', type: 'tinyint', comment: '是否删除', default: 0 })
  isDeleted?: number
  @Column({ type: 'varchar', length: 256, comment: '模块描述' })
  description?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}
