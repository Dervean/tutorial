import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'

@Entity()
export class AramProject {
  @PrimaryGeneratedColumn({ name: 'project_id', type: 'bigint', unsigned: true, comment: '项目 ID, 项目表对应主键' })
  projectId: AramIdType

  @Column({ name: 'project_name', type: 'varchar', length: 64, comment: '项目名称' })
  projectName: string
  @Column({ name: 'app_uid', type: 'varchar', length: 64, comment: '应用场景标识, 应用场景表对应主键' })
  appUid: AramUidType

  @Column({ type: 'simple-json', comment: '应用扩展属性' })
  xattrs?: AramJsonType
  @Column({ name: 'is_private', type: 'tinyint', comment: '是否私有', default: 1 })
  isPrivate?: number
  @Column({ name: 'is_deleted', type: 'tinyint', comment: '是否删除', default: 0 })
  isDeleted?: number
  @Column({ type: 'varchar', length: 256, comment: '项目描述' })
  description?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}
