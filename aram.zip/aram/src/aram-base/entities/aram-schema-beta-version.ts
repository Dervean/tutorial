import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from '@gfe/zebra-typeorm-client'
import { AramInvalidFormatParamError } from '~/aram-lib/model/aram-error/bad-request/aram-invalid-param-error'
import { AramPublishTypeEnum, AramSchemaVersionTypeEnum } from '~/aram-base/enum/common'

@Entity()
export class AramSchemaBetaVersion {
  @PrimaryGeneratedColumn({ name: 'schema_beta_version_id', type: 'bigint', comment: '配置 beta 版本 ID, 配置 beta 版本表对应主键', unsigned: true })
  schemaBetaVersionId: AramIdType

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'module_id', type: 'bigint', comment: '模块 Id', unsigned: true })
  moduleId: AramIdType
  @Column({ name: 'schema_id', type: 'bigint', comment: '配置 Id', unsigned: true })
  schemaId: AramIdType
  @Column({ type: 'bigint', comment: '配置 prod 版本号', unsigned: true })
  version: AramSchemaVersionType
  @Column({ name: 'beta_version', type: 'bigint', comment: '配置 beta 版本号', unsigned: true })
  betaVersion: AramSchemaVersionType
  @Column({ type: 'varchar', length: 256, comment: 'S3 filename of schema JSON' })
  url: string
  @Column({ type: 'tinyint', default: AramPublishTypeEnum.publish, comment: '发布类型' })
  type: AramPublishTypeEnum

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ type: 'varchar', length: 256, default: null, comment: '配置描述' })
  description?: string
  @Column({ name: 'rollback_from', type: 'simple-json', default: null, comment: '回滚自' })
  rollbackFrom?: AramSchemaBetaVersion

  public static BETA_VERSION_LATEST = `${AramSchemaVersionTypeEnum.latest}-beta`

  public static BETA_VERSION_REGEX = /^v([1-9][\d]*)\-beta\.([1-9][\d]*)$/

  /**
   * 测试版本号 转 测试版本字符串
   * @param version
   * @param betaVersion
   * @returns
   */
  public static betaVersion2strV2(version?: AramSchemaVersionType, betaVersion?: AramSchemaVersionType) {
    if (!betaVersion || !version) return AramSchemaVersionTypeEnum.latest
    return `v${version}-beta.${betaVersion}`
  }

  /**
   * @todo 废弃转换器 后续删除
   * 测试版本号 转 测试版本字符串
   */
  public static betaVersion2str(version?: AramSchemaVersionType, betaVersion?: AramSchemaVersionType) {
    if (!betaVersion || !version) return AramSchemaBetaVersion.BETA_VERSION_LATEST
    return `v${version}-beta@${betaVersion}`
  }

  /**
   * 测试版本字符串 转 测试版本号
   * @param betaVersionStr
   * @returns
   */
  public static str2betaVersionV2(betaVersionStr: string) {
    if (betaVersionStr === AramSchemaVersionTypeEnum.latestBeta || betaVersionStr === AramSchemaVersionTypeEnum.latest) {
      return {
        version: AramSchemaVersionTypeEnum.latest,
      }
    }
    if (!AramSchemaBetaVersion.BETA_VERSION_REGEX.test(betaVersionStr)) {
      throw new AramInvalidFormatParamError(`参数格式不合法: version=${betaVersionStr}`)
    }
    const [_, version, betaVersion] = AramSchemaBetaVersion.BETA_VERSION_REGEX.exec(betaVersionStr)
    return {
      version: +version as AramSchemaVersionType,
      betaVersion: +betaVersion as AramSchemaVersionType,
    }
  }

  /**
   * @todo 废弃转换器 后续删除
   * 测试版本字符串 转 测试版本号
   */
  public static str2betaVersion(betaVersionStr: string) {
    const reg = /^v([1-9][\d]*)\-beta\@([1-9][\d]*)$/
    const isLatest = betaVersionStr === AramSchemaBetaVersion.BETA_VERSION_LATEST
    if (!reg.test(betaVersionStr) && !isLatest) {
      throw new AramInvalidFormatParamError(`参数格式不合法: version=${betaVersionStr}`)
    }
    if (isLatest) {
      return {
        version: AramSchemaVersionTypeEnum.latest,
      }
    } else {
      const [_, version, betaVersion] = reg.exec(betaVersionStr)
      return {
        version: +version as AramSchemaVersionType,
        betaVersion: +betaVersion as AramSchemaVersionType,
      }
    }
  }
}
