import { Entity, PrimaryGeneratedColumn, Column, UpdateDateColumn, CreateDateColumn } from '@gfe/zebra-typeorm-client'

@Entity()
export class AramSchemaDraft {
  @PrimaryGeneratedColumn({ name: 'schema_draft_id', type: 'bigint', comment: '配置草稿 Id, 配置草稿表对应主键', unsigned: true })
  schemaDraftId: AramIdType

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'module_id', type: 'bigint', comment: '模块 Id', unsigned: true })
  moduleId: AramIdType
  @Column({ name: 'schema_id', type: 'bigint', comment: '配置 Id', unsigned: true })
  schemaId: AramIdType
  @Column({ name: 'user_name', type: 'varchar', length: 64, comment: 'SSO 环境下为 MIS 号' })
  userName: AramUserNameType
  @Column({ type: 'simple-json', comment: '配置草稿 JSON' })
  schema: AramJsonType

  @Column({ name: 'sync_version', type: 'bigint', comment: '同步版本号', unsigned: true })
  syncVersion?: AramSchemaVersionType
  @Column({ name: 'schema_name', type: 'varchar', length: 64, comment: '配置草稿名称' })
  schemaName?: string
  @Column({ type: 'varchar', length: 256, comment: '配置草稿描述' })
  description?: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  /** 线上最新版本 */
  public version?: AramSchemaVersionType
}
