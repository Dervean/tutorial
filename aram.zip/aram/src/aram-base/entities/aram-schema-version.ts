import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from '@gfe/zebra-typeorm-client'
import { AramInvalidFormatParamError } from '~/aram-lib/model/aram-error/bad-request/aram-invalid-param-error'
import { AramPublishTypeEnum, AramSchemaVersionTypeEnum } from '~/aram-base/enum/common'

@Entity()
export class AramSchemaVersion {
  @PrimaryGeneratedColumn({ name: 'schema_version_id', type: 'bigint', comment: '配置版本 Id, 配置版本表对应主键', unsigned: true })
  schemaVersionId: AramIdType

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'module_id', type: 'bigint', comment: '模块 Id', unsigned: true })
  moduleId: AramIdType
  @Column({ name: 'schema_id', type: 'bigint', comment: '配置 Id', unsigned: true })
  schemaId: AramIdType
  @Column({ type: 'bigint', comment: '配置版本号', unsigned: true })
  version: AramSchemaVersionType
  @Column({ type: 'varchar', length: 256, comment: 'S3 filename of schema JSON' })
  url: string
  @Column({ type: 'tinyint', default: AramPublishTypeEnum.publish, comment: '发布类型' })
  type: AramPublishTypeEnum
  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string

  @Column({ type: 'varchar', length: 256, default: null, comment: '配置描述' })
  description?: string
  @Column({ name: 'rollback_from', type: 'simple-json', default: null, comment: '回滚自' })
  rollbackFrom?: AramSchemaVersion

  public static PROD_VERSION_REGEX = /^v([1-9][\d]*)$/

  /** 线上版本号 转 线上版本字符串 */
  public static version2str(version: AramSchemaVersionType | AramSchemaVersionTypeEnum) {
    if (version === null || version === undefined) return null
    if (version === AramSchemaVersionTypeEnum.latest) return AramSchemaVersionTypeEnum.latest
    return `v${version}`
  }

  /** 线上版本字符串 转 线上版本号 */
  public static str2version(versionStr: string) {
    if (versionStr === AramSchemaVersionTypeEnum.latest) return AramSchemaVersionTypeEnum.latest
    if (!AramSchemaVersion.PROD_VERSION_REGEX.test(versionStr)) {
      throw new AramInvalidFormatParamError(`参数格式不合法: version=${versionStr}`)
    }
    const [_, version] = AramSchemaVersion.PROD_VERSION_REGEX.exec(versionStr)
    return +version as AramSchemaVersionType
  }
}
