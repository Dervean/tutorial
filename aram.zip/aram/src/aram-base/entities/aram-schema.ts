import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { AramSchemaVersion } from './aram-schema-version'

@Entity()
export class AramSchema {
  @PrimaryGeneratedColumn({ name: 'schema_id', type: 'bigint', comment: '配置Id, 配置表对应主键', unsigned: true })
  schemaId: AramIdType

  @Column({ name: 'schema_uid', type: 'varchar', length: 64, comment: '配置标识' })
  schemaUid: AramUidType
  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'app_uid', type: 'varchar', length: 64, comment: '应用场景标识, 应用场景表对应主键' })
  appUid: AramUidType
  @Column({ name: 'module_id', type: 'bigint', comment: '模块 Id', unsigned: true })
  moduleId: AramIdType
  @Column({ name: 'schema_name', type: 'varchar', length: 256, comment: '配置名称' })
  schemaName: string

  @Column({ name: 'is_deleted', type: 'tinyint', comment: '是否删除', default: 0 })
  isDeleted?: number
  @Column({ type: 'varchar', length: 256, comment: '配置描述' })
  description?: string
  @Column({ name: 'ext', type: 'simple-json', comment: '配置额外数据' })
  ext?: AramJsonType

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  public moduleName?: string
  public version?: AramSchemaVersionType
  public publishTime?: string
  public publishBy?: string

  public toJSON() {
    return {
      schemaId: this.schemaId,
      schemaUid: this.schemaUid,
      projectId: this.projectId,
      appUid: this.appUid,
      moduleId: this.moduleId,
      schemaName: this.schemaName,
      // isDeleted: this.isDeleted,
      description: this.description,
      createdBy: this.createdBy,
      createTime: this.createTime,
      updatedBy: this.updatedBy,
      updateTime: this.updateTime,
      version: AramSchemaVersion.version2str(this.version),
      publishTime: this.publishTime,
      publishBy: this.publishBy,
      moduleName: this.moduleName,
      ext: this.ext,
    }
  }
}
