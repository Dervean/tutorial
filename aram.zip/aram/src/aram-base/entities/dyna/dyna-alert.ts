import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { StateDescEnum, StateEnum } from '~/aram-base/enum/flow'

@Entity()
export class DynaAlert {
  @PrimaryColumn({ name: 'crane_task_id', type: 'varchar', length: 128 })
  craneTaskId: string
  @Column({ name: 'crane_task_name', type: 'varchar', length: 128 })
  craneTaskName: string
  @Column({ name: 'schema_id', type: 'bigint', comment: 'Dyna 配置 Id', unsigned: true })
  schemaId: AramIdType
  @Column({ type: 'simple-json', comment: '提醒人 MIS 号' })
  notifiers: AramUserNameType[]
  @Column({ name: 'remind_time', type: 'datetime', comment: '提醒时间' })
  remindTime: Date
  @Column({ type: 'varchar', length: 256, comment: '备注' })
  remark?: string
  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: StateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: StateDescEnum
  @Column({ type: 'enum', enum: Object.keys(AramStatusEnum), comment: '状态' })
  status: AramStatusEnum

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}
