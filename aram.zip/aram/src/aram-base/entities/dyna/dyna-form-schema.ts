import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { AramStatusEnum } from '~/aram-base/enum/common'

@Entity()
export class DynaFormSchema {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', comment: 'Id, 自增主键', unsigned: true })
  id: AramIdType

  @Column({ name: 'schema_id', type: 'bigint', comment: 'Dyna 配置 Id', unsigned: true })
  schemaId: AramIdType
  @Column({ name: 'aram_schema_id', type: 'bigint', comment: 'Aram 配置 Id', unsigned: true })
  aramSchemaId: AramIdType
  @Column({ name: 'status', type: 'tinyint', comment: '状态', default: 0 })
  status?: AramStatusEnum

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}
