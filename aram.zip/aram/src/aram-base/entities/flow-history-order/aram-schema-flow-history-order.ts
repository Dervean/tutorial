import { Entity, PrimaryColumn, Column, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { AuditStateDescEnum, AuditStateEnum, StateDescEnum, StateEnum } from '~/aram-base/enum/flow'

@Entity()
export class AramSchemaFlowHistoryOrder {
  /** order */
  @PrimaryColumn({ name: 'order_id', type: 'varchar', length: 32, comment: 'ID, 配置历史流程实例表表对应主键' })
  orderId: AramUuidType
  @Column({ name: 'process_name', type: 'varchar', length: 32, comment: '流程定义名称' })
  processName: string
  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: StateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: StateDescEnum
  @Column({ name: 'audit_state', type: 'tinyint', comment: '审核状态' })
  auditState?: AuditStateEnum
  @Column({ name: 'audit_state_desc', type: 'varchar', length: 32, comment: '审核状态描述' })
  auditStateDesc?: AuditStateDescEnum
  @Column({ type: 'varchar', length: 64, comment: '创建人' })
  creator: AramUserNameType
  @Column({ name: 'creator_remark', type: 'varchar', length: 128, comment: '创建人备注' })
  creatorRemark?: string
  /** schema */
  @Column({ name: 'schema_id', type: 'bigint', comment: '配置Id, 配置表对应主键', unsigned: true })
  schemaId: AramIdType
  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: AramIdType
  @Column({ name: 'app_uid', type: 'varchar', length: 64, comment: '应用场景标识, 应用场景表对应主键' })
  appUid: AramUidType
  /** common */
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  public toJSON() {
    return {
      orderId: this.orderId,
      processName: this.processName,
      state: this.state,
      stateDesc: this.stateDesc,
      auditState: this.auditState,
      auditStateDesc: this.auditStateDesc,
      creator: this.creator,
      creatorRemark: this.creatorRemark,

      schemaId: this.schemaId,
      projectId: this.projectId,
      appUid: this.appUid,

      createTime: this.createTime,
      updateTime: this.updateTime,
    }
  }
}
