import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { AuditStateEnum, AuditStateDescEnum } from '~/aram-base/enum/flow'

@Entity()
export class AramFlowApprover {
  @PrimaryColumn({ name: 'approver_id', type: 'varchar', length: 32, comment: '审核人 ID, 流程审核人表主键' })
  approverId: AramUuidType

  @Column({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 ID, 流程实例表主键' })
  orderId: AramUuidType

  @Column({ type: 'varchar', length: 64, comment: '审核人' })
  approver: AramUserNameType
  @Column({ name: 'approver_remark', type: 'varchar', length: 128, comment: '审核评论' })
  approverRemark?: string

  @Column({ name: 'audit_state', type: 'tinyint', comment: '审核状态' })
  auditState: AuditStateEnum
  @Column({ name: 'audit_state_desc', type: 'varchar', length: 32, comment: '审核状态描述' })
  auditStateDesc: AuditStateDescEnum

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
}

export enum ApproverOpinionEnum {
  pass = 'pass',
  reject = 'reject',
}

export type ApproverInput = {
  approver: AramUserNameType
  approverRemark?: string
  opinion: ApproverOpinionEnum
}
