import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { StateEnum, StateDescEnum, AuditStateEnum, AuditStateDescEnum } from '~/aram-base/enum/flow'

@Entity()
export class AramFlowOrder {
  @PrimaryColumn({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 ID, 流程实例表主键' })
  orderId: AramUuidType

  @Column({ name: 'process_id', type: 'varchar', length: 32, comment: '流程定义 ID, 流程定义表主键' })
  processId: AramUuidType
  @Column({ name: 'process_name', type: 'varchar', length: 32, comment: '流程定义名称' })
  processName: string
  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: StateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: StateDescEnum

  @Column({ type: 'varchar', length: 64, comment: '创建人' })
  creator: AramUserNameType
  @Column({ name: 'creator_remark', type: 'varchar', length: 128, comment: '创建人备注' })
  creatorRemark?: string

  @Column({ name: 'parent_id', type: 'varchar', length: 32, comment: '父流程 ID' })
  parentId?: AramUuidType
  @Column({ name: 'parent_node_name', type: 'varchar', length: 32, comment: '父流程名称' })
  parentNodeName?: string

  @Column({ type: 'simple-json', comment: '流程变量' })
  variable?: Record<string, any>

  @Column({ name: 'audit_state', type: 'tinyint', comment: '审核状态' })
  auditState?: AuditStateEnum
  @Column({ name: 'audit_state_desc', type: 'varchar', length: 32, comment: '审核状态描述' })
  auditStateDesc?: AuditStateDescEnum

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  constructor(model?: AramFlowOrder) {
    if (model) {
      if (model.orderId) this.orderId = model.orderId
      if (model.processId) this.processId = model.processId
      if (model.processName) this.processName = model.processName
      if (model.state) this.state = model.state
      if (model.stateDesc) this.stateDesc = model.stateDesc
      if (model.auditState) this.auditState = model.auditState
      if (model.auditStateDesc) this.auditStateDesc = model.auditStateDesc
      if (model.creator) this.creator = model.creator
      if (model.creatorRemark) this.creatorRemark = model.creatorRemark
      if (model.parentId) this.parentId = model.parentId
      if (model.parentNodeName) this.parentNodeName = model.parentNodeName
      if (model.variable) this.variable = model.variable
      if (model.createTime) this.createTime = model.createTime
      if (model.updatedBy) this.updatedBy = model.updatedBy
      if (model.updateTime) this.updateTime = model.updateTime
    }
  }
}
