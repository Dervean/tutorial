import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { FlowProcessModel } from '~/aram-flow/model/flow-process-model'

@Entity()
export class AramFlowProcess {
  @PrimaryColumn({ name: 'process_id', type: 'varchar', length: 32, comment: '流程定义 ID, 流程定义表主键' })
  processId: AramUuidType

  @Column({ name: 'name', type: 'varchar', length: 32, comment: '流程定义名称' })
  name: string
  @Column({ name: 'display_name', type: 'varchar', length: 32, comment: '流程定义显示名称' })
  displayName: string
  @Column({ type: 'tinyint', comment: '状态' })
  status: AramStatusEnum
  @Column({ type: 'int', unsigned: true, comment: '版本' })
  version: number
  @Column({ type: 'blob', comment: '流程定义 XML' })
  content: Buffer

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: AramUserNameType
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: AramUserNameType
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  public model?: FlowProcessModel

  public toJSON() {
    return {
      processId: this.processId,
      name: this.name,
      displayName: this.displayName,
      status: this.status,
      createdBy: this.createdBy,
      createTime: this.createTime,
      updatedBy: this.updatedBy,
      updateTime: this.updateTime,
    }
  }
}
