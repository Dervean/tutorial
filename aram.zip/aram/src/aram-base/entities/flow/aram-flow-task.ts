import { Entity, Column, CreateDateColumn, PrimaryColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { FlowTaskModel } from '~/aram-flow/model/node/flow-task-model'
import { PerformTypeEnum, StateDescEnum, StateEnum } from '~/aram-base/enum/flow'

@Entity()
export class AramFlowTask {
  @PrimaryColumn({ name: 'task_id', type: 'varchar', length: 32, comment: '流程任务 ID, 流程任务表主键' })
  taskId: AramUuidType

  @Column({ name: 'name', type: 'varchar', length: 32, comment: '流程任务名称' })
  name: string
  @Column({ name: 'display_name', type: 'varchar', length: 32, comment: '流程任务显示名称' })
  displayName: string
  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: StateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: StateDescEnum

  @Column({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 ID, 流程实例表主键' })
  orderId: AramUuidType
  @Column({ name: 'perform_type', type: 'varchar', length: 8, comment: '任务类型' })
  performType: PerformTypeEnum // @todo

  @Column({ name: 'parent_task_id', type: 'varchar', length: 32, comment: '父任务 ID' })
  parentTaskId?: AramUuidType
  @Column({ type: 'varchar', length: 64, comment: '处理人' })
  operator?: AramUserNameType
  @Column({ type: 'simple-json', comment: '参与人' })
  actors?: AramUserNameType[]
  @Column({ type: 'simple-json', comment: '变量' })
  variable?: Record<string, any>

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  public model?: FlowTaskModel

  public toJSON() {
    return {
      taskId: this.taskId,
      orderId: this.orderId,
      name: this.name,
      displayName: this.displayName,
      parentTaskId: this.parentTaskId,
      state: this.state,
      stateDesc: this.stateDesc,
      operator: this.operator,
      actors: this.actors,
      createTime: this.createTime,
      updateTime: this.updateTime,
    }
  }
}
