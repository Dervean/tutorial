/** 发布版本字符串枚举类型 */
export enum AramSchemaVersionTypeEnum {
  latest = 'latest',
  latestBeta = 'latest-beta',
}

/** 发布类型 */
export enum AramPublishTypeEnum {
  publish = 0,
  rollback = 1,
}

export enum AramStatusEnum {
  Active = 0,
  Inactive = 1,
}

/** @todo 过渡时期暂时保留, 后期项目扩展属性不在后端校验 */
export enum AramApplicationUidEnum {
  Aram = 'aram',
  Dyna = 'dyna',
}

export enum AramMaraComponentGroupEnum {
  Mara = 0,
  Mtd = 1,
}
