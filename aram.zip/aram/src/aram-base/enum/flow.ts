export enum AuditStateEnum {
  Reviewing = 1,
  Passed = 2,
  Rejected = 3,
  Reviewed = 4,
  Canceled = 5,
}

export enum AuditStateDescEnum {
  Reviewing = '审核中',
  Passed = '已通过',
  Rejected = '已驳回',
  Reviewed = '已审核',
  Canceled = '已取消',
}

export enum StateEnum {
  Pending = 1,
  Active = 2,
  Success = 3,
  Failed = 4,
  Canceled = 5,
}

export enum StateDescEnum {
  Pending = '待执行',
  Active = '进行中',
  Success = '已完成',
  Failed = '已失败',
  Canceled = '已撤销',
}

export enum PerformTypeEnum {
  Any = 'ANY',
  All = 'ALL',
}
