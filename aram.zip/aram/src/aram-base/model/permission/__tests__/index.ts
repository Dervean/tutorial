import { PermissionBuilder, RoleTypeEnum } from '~/aram-base/model/permission/permission-builder'

describe('aram-base/model/permission/permission-builder', () => {
  it('should be defined', () => {
    expect(PermissionBuilder).toBeDefined()
  })

  it('generate empty permission', async () => {
    const pb = new PermissionBuilder()

    const permission = pb.getPermission()
    const hasViewAuth = pb.checkVisitorPermission()
    const hasEditAuth = pb.checkEditorPermission()
    const hasAdminAuth = pb.checkAdminPermission()

    expect(permission).toBe(0)
    expect(hasViewAuth).toBe(false)
    expect(hasEditAuth).toBe(false)
    expect(hasAdminAuth).toBe(false)
  })

  it('generate permission with VIEW and EDIT', async () => {
    const pb = new PermissionBuilder(RoleTypeEnum.Editor)

    const permission = pb.getPermission()
    const hasViewAuth = pb.checkVisitorPermission()
    const hasEditAuth = pb.checkEditorPermission()
    const hasAdminAuth = pb.checkAdminPermission()

    expect(permission).toBe(3)
    expect(hasViewAuth).toBe(true)
    expect(hasEditAuth).toBe(true)
    expect(hasAdminAuth).toBe(false)
  })

  it('generate permission with DELETE', async () => {
    const pb = new PermissionBuilder(RoleTypeEnum.Admin)

    const permission = pb.getPermission()
    const hasViewAuth = pb.checkVisitorPermission()
    const hasEditAuth = pb.checkEditorPermission()
    const hasAdminAuth = pb.checkAdminPermission()

    expect(permission).toBe(7)
    expect(hasViewAuth).toBe(true)
    expect(hasEditAuth).toBe(true)
    expect(hasAdminAuth).toBe(true)
  })
})
