import { EnumHelper } from '~/aram-lib/helper/enum-helper'

export enum RoleTypeEnum {
  Admin = 'admin',
  Visitor = 'visitor',
  Editor = 'editor',
}

export class PermissionBuilder {
  static PERMISSION_VIEW: AramPermissionType = 1 << 0
  static PERMISSION_EDIT: AramPermissionType = 1 << 1
  static PERMISSION_ADMIN: AramPermissionType = 1 << 2

  static permission2role(permission: AramPermissionType) {
    const pb = new PermissionBuilder(permission)
    return pb.permission2role()
  }

  static role2permission(role: RoleTypeEnum) {
    const pb = new PermissionBuilder(role)
    return pb.getPermission()
  }

  private permission: AramPermissionType

  constructor(role: RoleTypeEnum)
  constructor(permission?: AramPermissionType)
  constructor(param?: RoleTypeEnum | AramPermissionType) {
    if (EnumHelper.isEnumMember(param, RoleTypeEnum)) {
      if (param === RoleTypeEnum.Visitor) {
        this.grantViewPermission()
      }
      if (param === RoleTypeEnum.Editor) {
        this.grantViewPermission()
        this.grantEditPermission()
      }
      if (param === RoleTypeEnum.Admin) {
        this.grantViewPermission()
        this.grantEditPermission()
        this.grantAdminPermission()
      }
    } else {
      this.permission = +param || 0
    }
  }

  getPermission() {
    return this.permission
  }

  permission2role(): RoleTypeEnum {
    if (this.hasAdminPermission()) {
      return RoleTypeEnum.Admin
    }
    if (this.hasEditPermission()) {
      return RoleTypeEnum.Editor
    }
    if (this.hasViewPermission()) {
      return RoleTypeEnum.Visitor
    }
  }

  public checkVisitorPermission() {
    return this.hasViewPermission() || this.hasEditPermission() || this.hasAdminPermission()
  }

  public checkEditorPermission() {
    return this.hasEditPermission() || this.hasAdminPermission()
  }

  public checkAdminPermission() {
    return this.hasAdminPermission()
  }

  public grantViewPermission() {
    this.permission |= PermissionBuilder.PERMISSION_VIEW
  }
  public grantEditPermission() {
    this.permission |= PermissionBuilder.PERMISSION_EDIT
  }
  public grantAdminPermission() {
    this.permission |= PermissionBuilder.PERMISSION_ADMIN
  }

  private deleteViewPermission() {
    this.permission ^= PermissionBuilder.PERMISSION_VIEW
  }
  private deleteEditPermission() {
    this.permission ^= PermissionBuilder.PERMISSION_EDIT
  }
  private deleteAdminPermission() {
    this.permission ^= PermissionBuilder.PERMISSION_ADMIN
  }

  private hasViewPermission() {
    const val = (this.permission & PermissionBuilder.PERMISSION_VIEW) >> 0
    return !!val
  }
  private hasEditPermission() {
    const val = (this.permission & PermissionBuilder.PERMISSION_EDIT) >> 1
    return !!val
  }
  private hasAdminPermission() {
    const val = (this.permission & PermissionBuilder.PERMISSION_ADMIN) >> 2
    return !!val
  }
}
