import assert from 'assert'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { MACHINE_ID } from '~/aram-lib/constants/snowflake'

export class SnowFlakeBuilder {
  /** 54 = 1 + 41 + 8 + 4 */
  private static SEQUENCE_BIT = 8
  private static MACHINE_BIT = 4
  private static MAX_SEQUENCE_NUM = -1 ^ (-1 << SnowFlakeBuilder.SEQUENCE_BIT)
  private static MAX_MACHINE_NUM = -1 ^ (-1 << SnowFlakeBuilder.MACHINE_BIT)

  private static MACHINE_LEFT = SnowFlakeBuilder.SEQUENCE_BIT
  private static TIMESTAMP_LEFT = SnowFlakeBuilder.SEQUENCE_BIT + SnowFlakeBuilder.MACHINE_BIT

  private static SCALAR = 1
  private static START_TIMESTAMP = Math.floor(1385720000000 / SnowFlakeBuilder.SCALAR)

  private machine: number
  private sequence = 0
  private lastTimestamp = -1

  constructor() {
    try {
      assert.ok(MACHINE_ID >= 0, `invalid machineId: machineId=${MACHINE_ID}`)
      assert.ok(MACHINE_ID <= SnowFlakeBuilder.MAX_MACHINE_NUM, 'machineId excceed maximum limit')
      this.machine = MACHINE_ID
    } catch (error) {
      AramLogger.logError(`snowflake initialize failed, ${error.message}`)
      throw error
    }
  }

  private getCurrentTimestamp() {
    return Math.floor(new Date().getTime() / SnowFlakeBuilder.SCALAR)
  }

  private getNextTimestamp() {
    let current = this.getCurrentTimestamp()
    while (current <= this.lastTimestamp) current = this.getCurrentTimestamp()
    return current
  }

  public nextId() {
    try {
      let currentTimestamp = this.getCurrentTimestamp()
      assert.ok(
        currentTimestamp >= this.lastTimestamp,
        `clock moved backwards: currentTimestamp=${currentTimestamp}, lastTimestamp=${this.lastTimestamp}`,
      )
      if (currentTimestamp === this.lastTimestamp) {
        this.sequence = (this.sequence + 1) & SnowFlakeBuilder.MAX_SEQUENCE_NUM
        if (this.sequence === 0) {
          currentTimestamp = this.getNextTimestamp()
        }
      } else {
        this.sequence = 0
      }
      this.lastTimestamp = currentTimestamp
      return (
        (currentTimestamp - SnowFlakeBuilder.START_TIMESTAMP) * 2 ** SnowFlakeBuilder.TIMESTAMP_LEFT +
        this.machine * 2 ** SnowFlakeBuilder.MACHINE_LEFT +
        this.sequence
      )
    } catch (error) {
      AramLogger.logError(`failed to generate id, ${error.message}`)
      throw error
    }
  }
}
