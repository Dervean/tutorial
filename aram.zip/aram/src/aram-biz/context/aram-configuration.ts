import assert from 'assert'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramServiceContext } from './aram-service-context'

export class AramConfiguration {
  public async buildAramEngine() {
    AramLogger.logInfo('aram service start...')
    const engine = AramServiceContext.engine

    assert.ok(!!engine, 'engine start failed')

    await engine.configure(this)
    // prettier-ignore
    const craneServiceList = [
      engine.dynaAlert(),
    ]
    await engine.craneTask().addClearCraneJob(craneServiceList)
    await engine.craneTask().activateCraneJobs(craneServiceList)
    return
  }
}
