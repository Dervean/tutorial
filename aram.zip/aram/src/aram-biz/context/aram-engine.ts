import assert from 'assert'

import { SystemService } from '~/aram-biz/service/__system__/system-service'
import { AdminService } from '~/aram-biz/service/admin/admin-service'
import { ApplicationService } from '~/aram-biz/service/application/application-service'
import { MaraService } from '~/aram-biz/service/mara/mara-service'
import { MemberService } from '~/aram-biz/service/member/member-service'
import { ModuleService } from '~/aram-biz/service/module/module-service'
import { ProjectService } from '~/aram-biz/service/project/project-service'
import { SchemaService } from '~/aram-biz/service/schema/schema-service'
import { SchemaVersionService } from '~/aram-biz/service/schema/schema-version-service'
import { FlowService } from '~/aram-biz/service//flow/flow-service'
import { FlowApplySchemaReleaseService } from '~/aram-biz/service/flow/flow-apply-schema-release-service'
import { ORGEmployeeService } from '~/aram-out/org/org-employee-service'
import { AramConfiguration } from './aram-configuration'
import { XmClientService } from '~/aram-out/xm/xm-client-service'
import { FlowHistoryOrderService } from '~/aram-biz/service/flow-history-order/flow-history-order-service'
import { S3TokenService } from '~/aram-out/mss/s3-token-service'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { SchemaDraftService } from '~/aram-biz/service/schema/schema-draft-service'
import { DynaFormSchemaService } from '~/aram-biz/service/dyna/dyna-form-schema-service'
import { ScaffordService } from '~/aram-biz/service/scafford/scafford-service'
import { SchemaMemberService } from '~/aram-biz/service/member/schema-member-service'
import { DynaAlertService } from '~/aram-biz/service/dyna/dyna-alert-service'
import { CraneService } from '~/aram-out/crane/crane-service'
import { CraneTaskService } from '../service/crane-task-service'

export class AramEngine {
  private orgEmployeeService: ORGEmployeeService
  private xmClientService: XmClientService
  private s3TokenService: S3TokenService
  private craneService: CraneService

  private systemService: SystemService
  private scaffoldService: ScaffordService
  private adminService: AdminService
  private applicationService: ApplicationService
  private maraService: MaraService
  private dynaFormSchemaService: DynaFormSchemaService
  private dynaAlertService: DynaAlertService
  private craneTaskService: CraneTaskService
  private memberService: MemberService
  private moduleService: ModuleService
  private projectService: ProjectService
  private schemaService: SchemaService
  private schemaDraftService: SchemaDraftService
  private schemaVersionService: SchemaVersionService
  private flowService: FlowService
  private flowApplySchemaReleaseService: FlowApplySchemaReleaseService
  private flowHistoryOrderService: FlowHistoryOrderService
  private schemaMemberService: SchemaMemberService

  public s3Token() {
    assert.ok(!!this.s3TokenService)
    return this.s3TokenService
  }

  public crane() {
    assert.ok(!!this.craneService)
    return this.craneService
  }

  public org() {
    assert.ok(!!this.orgEmployeeService)
    return this.orgEmployeeService
  }

  public xm() {
    assert.ok(!!this.xmClientService)
    return this.xmClientService
  }

  public system() {
    assert.ok(!!this.systemService)
    return this.systemService
  }

  public craneTask() {
    assert.ok(!!this.craneTaskService)
    return this.craneTaskService
  }

  public scaffold() {
    assert.ok(!!this.scaffoldService)
    return this.scaffoldService
  }

  public admin() {
    assert.ok(!!this.adminService)
    return this.adminService
  }

  public application() {
    assert.ok(!!this.applicationService)
    return this.applicationService
  }

  public mara() {
    assert.ok(!!this.maraService)
    return this.maraService
  }

  public dynaFormSchema() {
    assert.ok(!!this.dynaFormSchemaService)
    return this.dynaFormSchemaService
  }

  public dynaAlert() {
    assert.ok(!!this.dynaAlertService)
    return this.dynaAlertService
  }

  public member() {
    assert.ok(!!this.memberService)
    return this.memberService
  }

  public module() {
    assert.ok(!!this.moduleService)
    return this.moduleService
  }

  public project() {
    assert.ok(!!this.projectService)
    return this.projectService
  }

  public schema() {
    assert.ok(!!this.schemaService)
    return this.schemaService
  }

  public schemaDraft() {
    assert.ok(!!this.schemaDraftService)
    return this.schemaDraftService
  }

  public schemaVersion() {
    assert.ok(!!this.schemaVersionService)
    return this.schemaVersionService
  }

  public flow() {
    assert.ok(!!this.flowService)
    return this.flowService
  }

  public flowApplySchemaRelease() {
    assert.ok(!!this.flowApplySchemaReleaseService)
    return this.flowApplySchemaReleaseService
  }

  public flowHistoryOrder() {
    assert.ok(!!this.flowHistoryOrderService)
    return this.flowHistoryOrderService
  }

  public schemaMember() {
    assert.ok(!!this.schemaMemberService)
    return this.schemaMemberService
  }

  public async configure(configuration: AramConfiguration) {
    this.orgEmployeeService = new ORGEmployeeService()
    this.xmClientService = new XmClientService()
    this.s3TokenService = new S3TokenService()
    this.craneService = new CraneService()

    this.systemService = new SystemService()
    this.craneTaskService = new CraneTaskService()
    this.scaffoldService = new ScaffordService()
    this.adminService = new AdminService()
    this.applicationService = new ApplicationService()
    this.maraService = new MaraService()
    this.dynaAlertService = new DynaAlertService()
    this.dynaFormSchemaService = new DynaFormSchemaService()
    this.memberService = new MemberService()
    this.moduleService = new ModuleService()
    this.projectService = new ProjectService()
    this.schemaService = new SchemaService()
    this.schemaDraftService = new SchemaDraftService()
    this.schemaVersionService = new SchemaVersionService()
    this.flowService = new FlowService()
    this.flowApplySchemaReleaseService = new FlowApplySchemaReleaseService()
    this.flowHistoryOrderService = new FlowHistoryOrderService()
    this.schemaMemberService = new SchemaMemberService()

    // @todo
    // FlowQueryService.setAccess()

    return this
  }

  public isAramId(input: string | number) {
    try {
      ParamChecker.checkAramId(input)
      return true
    } catch (error) {
      return false
    }
  }
}
