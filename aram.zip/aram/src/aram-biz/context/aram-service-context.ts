import { AramEngine } from '~/aram-biz/context/aram-engine'

export class AramServiceContext {
  private static _engine: AramEngine = new AramEngine()
  public static get engine(): AramEngine {
    return AramServiceContext._engine
  }
}
