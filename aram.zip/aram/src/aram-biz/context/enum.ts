export enum FlowProcessEnum {
  ApplySchemaRelease = 'apply-schema-release',
  SchemaRelease = 'schema-release',
}
