import assert from 'assert'
import { FlowProcessEnum } from '~/aram-biz/context/enum'
import { FlowAccessLocalService } from '~/aram-flow/access/flow-access-local-service'
import { FlowConfiguration } from '~/aram-flow/context/flow-configuration'
import { FlowServiceContext } from '~/aram-flow/context/flow-service-context'
import { FlowEngine } from '~/aram-flow/core/flow-engine'
import { StreamHelper } from '~/aram-lib/helper/stream-helper'

describe('aram-biz/model/flow/__tests__/apply-schema-release', () => {
  let processId: AramUuidType
  let engine: FlowEngine

  beforeAll(async () => {
    engine = await new FlowConfiguration().buildFlowEngine()
    const processName = FlowProcessEnum.ApplySchemaRelease
    const definition = FlowServiceContext.EXT_PROCESS_CONFIGURATION.get(processName)?.definition
    assert.ok(!!definition, `流程定义部署失败: ${processName}`)
    const process = await engine.process().deploy(StreamHelper.getStreamFromFilePath(definition))
    processId = process.processId
  })
  it('should', async () => {
    const args: Record<string, any> = {}
    const user = 'wangdeyun'

    args['approvers'] = ['wangdeyun', 'sutengfei']
    args['approverInput'] = { approver: 'wangdeyun', opinion: 'reject' }
    args['schema'] = { schemaId: 33 }
    args['newVal'] = { a: 1 }
    args['oldVal'] = { b: 1 }
    const order = await engine.startInstanceById(processId, 'wangdeyun', args)
    const tasks = await engine.task().getActiveTasks({ orderId: order.orderId })

    expect(tasks.length).toBeGreaterThan(0)
  })

  afterAll(() => {
    const access = engine.query().access() as FlowAccessLocalService
    access.showCurrentDataStore()
  })
})
