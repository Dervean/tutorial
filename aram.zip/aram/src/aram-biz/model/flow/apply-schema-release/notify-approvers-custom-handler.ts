import { AramSchema } from '~/aram-base/entities/aram-schema'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { FlowProcessEnum } from '~/aram-biz/context/enum'
import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AuditStateEnum, AuditStateDescEnum } from '~/aram-base/enum/flow'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { LionClientService, LionConfigKeyEnum } from '~/aram-out/lion/lion-client-service'

@ReflectHelper.collect(FlowProcessEnum.ApplySchemaRelease)
export class NotifyApproversCustomHandler implements IFlowHandler {
  async handle(execution: FlowExecution): Promise<void> {
    const approvers: AramUserNameType[] = execution.args['approvers'] || []
    const schema: AramSchema = execution.args['schema']
    const order = execution.order
    if (approvers.length) {
      order.auditState = AuditStateEnum.Reviewing
      order.auditStateDesc = AuditStateDescEnum.Reviewing
    }

    await Promise.all([
      execution.engine.approver().saveApprovers(order, approvers),
      execution.engine.order().updateOrder(order),
      this.updateHistoryOrder(execution.order),
      this.notify(order, schema, approvers),
    ])

    return
  }

  private async updateHistoryOrder(order: AramFlowOrder) {
    return AramServiceContext.engine.flowHistoryOrder().updateSchemaHistoryOrder(order.orderId)
  }

  private async notify(order: AramFlowOrder, schema: AramSchema, approvers: AramUserNameType[]) {
    const [project, href] = await Promise.all([
      AramServiceContext.engine.project().getActiveProject(schema.projectId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.ApplySchemaReleaseFlowDetailHref),
    ])

    const params = new Map<string, any>()
    params.set('appUid', schema.appUid)
    params.set('projectName', project.projectName)
    params.set('schemaUid', schema.schemaUid)
    params.set('schemaName', schema.schemaName)
    params.set('creator', order.creator)
    params.set('creatorRemark', order.creatorRemark)
    params.set('approvers', approvers)
    params.set('orderId', order.orderId)
    const templateApprover = this.xmTemplateyApprover(params, href)
    const templateProposer = this.xmTemplateProposer(params, href)
    const notifyApproversResult = approvers.map(mis => AramServiceContext.engine.xm().sendCustomMsg(templateApprover, mis))
    const notifyProposerResult = AramServiceContext.engine.xm().sendCustomMsg(templateProposer, order.creator)

    return Promise.all([...notifyApproversResult, notifyProposerResult])
  }

  private xmTemplateProposer(params: Map<string, any>, href: string) {
    const body = {
      messageType: 'custom',
      body: {
        templateName: '配置上线申请',
        contentTitle: '',
        content: [
          `应用ID: ${params.get('appUid')}`,
          `项目名称：${params.get('projectName')}`,
          `配置ID：${params.get('schemaUid')}`,
          `配置名称：${params.get('schemaName')}`,
          `审核人：${params.get('approvers').join(', ')}`,
        ].join('\n'),
        linkName: '审批进度',
        link: StringHelper.parseHref(href, params),
      },
    }
    return body
  }

  private xmTemplateyApprover(params: Map<string, any>, href: string) {
    const body = {
      messageType: 'custom',
      body: {
        templateName: '配置上线申请',
        contentTitle: '',
        content: [
          `应用ID: ${params.get('appUid')}`,
          `项目名称：${params.get('projectName')}`,
          `配置ID：${params.get('schemaUid')}`,
          `配置名称：${params.get('schemaName')}`,
          `申请人：${params.get('creator')}`,
          `申请理由：${params.get('creatorRemark')}`,
        ].join('\n'),
        linkName: '前往审批',
        link: StringHelper.parseHref(href, params),
      },
    }
    return body
  }
}
