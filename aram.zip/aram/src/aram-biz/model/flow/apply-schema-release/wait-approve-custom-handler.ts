import assert from 'assert'
import { AramSchema } from '~/aram-base/entities/aram-schema'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { FlowProcessEnum } from '~/aram-biz/context/enum'
import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { ApproverInput, ApproverOpinionEnum, AramFlowApprover } from '~/aram-base/entities/flow/aram-flow-approver'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AuditStateDescEnum, AuditStateEnum } from '~/aram-base/enum/flow'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { LionClientService, LionConfigKeyEnum } from '~/aram-out/lion/lion-client-service'

@ReflectHelper.collect(FlowProcessEnum.ApplySchemaRelease)
export class WaitApproveCustomHandler implements IFlowHandler {
  async handle(execution: FlowExecution): Promise<void> {
    const approverInput: ApproverInput = execution.args['approverInput']
    const schema: AramSchema = execution.args['schema']
    this.check(approverInput)

    const approverList = await execution.engine.approver().getApprovers(execution.order.orderId)
    const updatedApproverList = this.updateApproversState(approverList, approverInput)
    const updatedOrder = this.updateOrderState(execution.order, approverInput)
    await Promise.all([
      execution.engine.approver().updateApprovers(updatedApproverList),
      execution.engine.order().updateOrder(updatedOrder),
      this.updateHistoryOrder(updatedOrder),
      this.notifyProposer(execution.order, approverInput, schema),
    ])
    return
  }

  private check(approverInput: ApproverInput) {
    const { approver, opinion } = approverInput || {}
    ParamChecker.checkUserName(approver)
    assert.ok(opinion === ApproverOpinionEnum.pass || opinion === ApproverOpinionEnum.reject, `审批结果非法: opinion=${opinion}`)
  }

  private updateApproversState(approverList: AramFlowApprover[], approverInput: ApproverInput) {
    const approver = approverList.find(e => e.approver === approverInput.approver)
    assert.ok(!!approver, `审批人不存在: approver=${approverInput.approver}`)
    if (approverInput.opinion === ApproverOpinionEnum.pass) {
      approver.auditState = AuditStateEnum.Passed
      approver.auditStateDesc = AuditStateDescEnum.Passed
    } else {
      approver.auditState = AuditStateEnum.Rejected
      approver.auditStateDesc = AuditStateDescEnum.Rejected
    }
    approver.approverRemark = approverInput.approverRemark

    const otherApprovers = approverList.filter(e => e.approver !== approverInput.approver)
    for (const other of otherApprovers) {
      other.auditState = AuditStateEnum.Reviewed
      other.auditStateDesc = AuditStateDescEnum.Reviewed
    }
    return [approver, ...otherApprovers]
  }

  private updateOrderState(order: AramFlowOrder, approverInput: ApproverInput) {
    if (approverInput.opinion === ApproverOpinionEnum.pass) {
      order.auditState = AuditStateEnum.Passed
      order.auditStateDesc = AuditStateDescEnum.Passed
    } else {
      order.auditState = AuditStateEnum.Rejected
      order.auditStateDesc = AuditStateDescEnum.Rejected
    }
    return order
  }

  private async updateHistoryOrder(order: AramFlowOrder) {
    return AramServiceContext.engine.flowHistoryOrder().updateSchemaHistoryOrder(order.orderId)
  }

  private async notifyProposer(order: AramFlowOrder, approverInput: ApproverInput, schema: AramSchema) {
    const [project, href] = await Promise.all([
      AramServiceContext.engine.project().getActiveProject(schema.projectId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.ApplySchemaReleaseFlowDetailHref),
    ])

    const params = new Map<string, any>()
    params.set('appUid', schema.appUid)
    params.set('orderId', order.orderId)
    params.set('projectName', project.projectName)
    params.set('schemaUid', schema.schemaUid)
    params.set('approver', approverInput.approver)
    params.set('approverRemark', approverInput.approverRemark || '')
    params.set('auditStateDesc', order.auditStateDesc)
    const template = this.xmTemplate(params, href)

    return AramServiceContext.engine.xm().sendCustomMsg(template, order.creator)
  }

  private xmTemplate(params: Map<string, any>, href: string) {
    const body = {
      messageType: 'custom',
      body: {
        templateName: '审核完成',
        contentTitle: '',
        content: [
          `应用ID: ${params.get('appUid')}`,
          `项目名称：${params.get('projectName')}`,
          `配置名称：${params.get('schemaUid')}`,
          `审批人：${params.get('approver')}`,
          `审批人备注：${params.get('approverRemark')}`,
          `审批状态：${params.get('auditStateDesc')}`,
        ].join('\n'),
        linkName: '审批详情',
        link: StringHelper.parseHref(href, params),
      },
    }
    return body
  }
}
