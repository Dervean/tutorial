import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { FlowProcessEnum } from '~/aram-biz/context/enum'
import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'

@ReflectHelper.collect(FlowProcessEnum.SchemaRelease)
export class CreateOrderCustomHandler implements IFlowHandler {
  async handle(execution: FlowExecution): Promise<void> {
    const order = execution.order

    // prettier-ignore
    await Promise.all([
      execution.engine.order().updateOrder(order),
      this.updateHistoryOrder(execution.order),
    ])

    return
  }

  private async updateHistoryOrder(order: AramFlowOrder) {
    return AramServiceContext.engine.flowHistoryOrder().updateSchemaHistoryOrder(order.orderId)
  }
}
