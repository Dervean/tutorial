import assert from 'assert'

import { AramSchema } from '~/aram-base/entities/aram-schema'
import { AramSchemaVersion } from '~/aram-base/entities/aram-schema-version'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { FlowProcessEnum } from '~/aram-biz/context/enum'
import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { FlowOrderService } from '~/aram-flow/core/flow-order-service'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { StateDescEnum, StateEnum } from '~/aram-base/enum/flow'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'

@ReflectHelper.collect(FlowProcessEnum.SchemaRelease)
export class ReleaseSchemaCustomHandler implements IFlowHandler {
  async handle(execution: FlowExecution): Promise<void> {
    const schema: AramSchema = execution.args['schema']
    const newVal: AramJsonType = execution.args['newVal']
    const remark: string = execution.args[FlowOrderService.ATTR_CREATOR_REMARK]

    let result: { version: number; schemaVersionId: number }
    try {
      result = await AramServiceContext.engine.schemaVersion().createSchemaVersion(schema.schemaId, newVal, remark, execution.order.creator)
      assert.ok(!!result.version, `发布版本异常: version=${result.version}`)
    } catch (error) {
      AramLogger.logError(`发布失败: message=${error.message}`)
      await Promise.all([
        this.notifyProposer(execution.order, { schema, reasonFail: error.message }, this.xmTemplateFail),
        this.updateTask(execution, StateEnum.Failed, StateDescEnum.Failed),
        this.updateHistoryOrder(execution.order, StateEnum.Failed, StateDescEnum.Failed),
        execution.engine.order().complete(execution.order.orderId, StateEnum.Failed, StateDescEnum.Failed),
      ])
      throw error
    }

    const version = AramSchemaVersion.version2str(result.version)
    await Promise.all([
      this.notifyProposer(execution.order, { schema, version }, this.xmTemplateSuccess),
      this.updateHistoryOrder(execution.order, StateEnum.Success, StateDescEnum.Success),
    ])
    return
  }

  private async updateTask(execution: FlowExecution, state: StateEnum, stateDesc: StateDescEnum) {
    execution.task.state = state
    execution.task.stateDesc = stateDesc
    return execution.engine.task().updateTask(execution.task)
  }

  private async updateHistoryOrder(order: AramFlowOrder, state: StateEnum, stateDesc: StateDescEnum) {
    /** @todo 这块应该放在拦截器里 */
    const updatedOrder = new AramFlowOrder(order)
    updatedOrder.state = state
    updatedOrder.stateDesc = stateDesc
    return AramServiceContext.engine.flowHistoryOrder().updateSchemaHistoryOrder(order.orderId, updatedOrder)
  }

  private async notifyProposer(
    order: AramFlowOrder,
    bizParams: { schema: AramSchema; version?: string; reasonFail?: string },
    xmTemplate: (params: Map<string, any>) => any,
  ) {
    const project = await AramServiceContext.engine.project().getActiveProject(bizParams.schema.projectId)

    const params = new Map<string, any>()
    params.set('appUid', bizParams.schema.appUid)
    params.set('orderId', order.orderId)
    params.set('projectName', project.projectName)
    params.set('schemaUid', bizParams.schema.schemaUid)
    params.set('version', bizParams.version)
    params.set('reasonFail', bizParams.reasonFail)
    const template = xmTemplate(params)

    return AramServiceContext.engine.xm().sendCustomMsg(template, order.creator)
  }

  private xmTemplateSuccess(params: Map<string, any>) {
    const body = {
      messageType: 'custom',
      body: {
        templateName: '发布成功',
        contentTitle: '',
        content: [
          `应用ID: ${params.get('appUid')}`,
          `项目名称：${params.get('projectName')}`,
          `配置名称：${params.get('schemaUid')}`,
          `配置版本：${params.get('version')}`,
        ].join('\n'),
      },
    }
    return body
  }

  private xmTemplateFail(params: Map<string, any>) {
    const body = {
      messageType: 'custom',
      body: {
        templateName: '发布失败',
        contentTitle: '',
        content: [
          `应用ID: ${params.get('appUid')}`,
          `项目名称：${params.get('projectName')}`,
          `配置名称：${params.get('schemaUid')}`,
          `失败原因：${params.get('reasonFail')}`,
        ].join('\n'),
      },
    }
    return body
  }
}
