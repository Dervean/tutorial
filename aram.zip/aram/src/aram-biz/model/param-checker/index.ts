import assert from 'assert'

import { AramSchemaBetaVersion } from '~/aram-base/entities/aram-schema-beta-version'
import { AramSchemaVersion } from '~/aram-base/entities/aram-schema-version'
import { AramSchemaVersionTypeEnum } from '~/aram-base/enum/common'
import { RoleTypeEnum } from '~/aram-base/model/permission/permission-builder'
import { ApproverOpinionEnum } from '~/aram-base/entities/flow/aram-flow-approver'
import { EnumHelper } from '~/aram-lib/helper/enum-helper'
import { AramInvalidFormatParamError } from '~/aram-lib/model/aram-error/bad-request/aram-invalid-param-error'
import { AramMissingParamError } from '~/aram-lib/model/aram-error/bad-request/aram-missing-param-error'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { JsonHelper } from '~/aram-lib/helper/json-helper'
import { FlowProcessEnum } from '~/aram-biz/context/enum'
import { DateHelper } from '~/aram-lib/helper/date-helper'

export class ParamChecker {
  /**
   * ------------------------------------------------------------------------------------
   * Primetive Checker
   * ------------------------------------------------------------------------------------
   */
  /**
   * 布尔值校验 并返回 input 对应的 布尔值
   *
   * return true
   *  - number(1)
   *  - boolean(true)
   *  - string('true')
   *
   * return false
   *  - number(0)
   *  - boolean(false)
   *  - string('false')
   *
   * return undefined
   *  - undefined
   * @param flag
   * @returns
   */
  static checkBoolean(flag: boolean | number | string | undefined) {
    const BOOLEAN_FLAGS: unknown[] = [1, 0, true, false, 'true', 'false', undefined]
    try {
      assert(BOOLEAN_FLAGS.includes(flag), `参数不合法: ${flag}`)
      if (flag === undefined) {
        return undefined
      }
      return Boolean(JSON.parse(flag as any))
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkString(param: string, { required = false }) {
    try {
      assert.ok(param !== undefined, `参数缺失`)
    } catch (error) {
      if (required) {
        throw new AramMissingParamError(error.message)
      }
      return
    }
    try {
      assert.ok(typeof param === 'string', `参数格式错误`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkJson(param: Object, { required = true }) {
    try {
      assert.ok(param !== undefined, `参数缺失`)
    } catch (error) {
      if (required) {
        throw new AramMissingParamError(error.message)
      }
      return
    }
    try {
      assert.ok(JsonHelper.isJson(param), `参数格式错误: ${param}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkDate(param: Date, { required = true }) {
    try {
      assert.ok(param !== undefined, `参数缺失`)
    } catch (error) {
      if (required) {
        throw new AramMissingParamError(error.message)
      }
      return
    }
    try {
      return DateHelper.getDate(param)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Aram Type Checker
   * ------------------------------------------------------------------------------------
   */
  static checkAramId(id: string | number) {
    try {
      assert.ok(typeof id === 'number' || typeof id === 'string', `参数缺失`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      if (typeof id === 'string') {
        assert.ok(!!id.length, `参数不合法`)
      }
      assert.ok(Number.isInteger(+id), `参数不合法: ${id}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkAramUuid(id: AramUuidType) {
    try {
      assert.ok(id !== undefined, `参数缺失`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(typeof id === 'string', `参数格式错误`)
      assert.ok(id.length === 32, `参数格式错误`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkAramUid(uid: AramUidType) {
    try {
      assert.ok(uid !== undefined, `参数缺失`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      const ARAM_UID_REGEX = /^[a-zA-Z][\w\-]*$/
      assert.ok(StringHelper.isString(uid), `标识必须是字符串: uid=${uid}`)
      assert.ok(ARAM_UID_REGEX.test(uid), `标识只允许包含英文、数字、下划线和短横线，且以英文开头: uid=${uid}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkAramIdList(idList: number[]) {
    try {
      assert.ok(idList !== undefined, `参数缺失`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(Array.isArray(idList), `参数错误`)
      for (const id of idList) {
        this.checkAramId(id)
      }
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkAramJson(param: AramJsonType, { required = false }) {
    try {
      assert.ok(param !== undefined && param !== null, `参数缺失`)
    } catch (error) {
      if (required) {
        throw new AramMissingParamError(error.message)
      }
      return
    }
    try {
      assert.ok(JsonHelper.isJson(param) || Array.isArray(param), `参数格式错误: ${param}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Mara Checker
   * ------------------------------------------------------------------------------------
   */

  static checkComponentName(componentName: string) {
    try {
      assert.ok(componentName !== undefined, `参数缺失: componentName`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(StringHelper.isString(componentName), `组件名必须是字符串: componentName=${componentName}`)
      assert.ok(!!componentName.length, `组件名不能为空: componentName=${componentName}`)
      /** component name 不能只包含数字 */
      assert.ok(!/^\d+$/.test(componentName), `组件名不能只包含数字: componentName=${componentName}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkComponentType(componentType: AramMaraComponentType) {
    try {
      assert.ok(componentType !== undefined, `参数缺失: componentType`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(Number.isInteger(+componentType), `组件类型必须是整数: componentType=${componentType}`)
      assert.ok(+componentType >= 0, `组件类型取值非法: componentType=${componentType}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * User Checker
   * ------------------------------------------------------------------------------------
   */
  static checkUserName(userName: string) {
    try {
      assert.ok(userName !== undefined, `参数缺失: userName`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(StringHelper.isString(userName), `用户名必须是字符串: userName=${userName}`)
      assert.ok(!!userName.length, `用户名不能为空: userName=${userName}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkUserNameList(userNameList: AramUserNameType[], { required = false }) {
    try {
      assert.ok(userNameList !== undefined && userNameList !== null, `参数缺失`)
    } catch (error) {
      if (required) {
        throw new AramMissingParamError(error.message)
      }
      return
    }
    try {
      assert.ok(Array.isArray(userNameList), `参数格式错误`)
      for (const userName of userNameList) {
        this.checkUserName(userName)
      }
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkDisplayName(displayName: string) {
    try {
      assert.ok(displayName !== undefined, `参数缺失: displayName`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(StringHelper.isString(displayName), `必须是字符串: displayName=${displayName}`)
      assert.ok(!!displayName.length, `不能为空: displayName=${displayName}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Member Checker
   * ------------------------------------------------------------------------------------
   */
  static checkRoleType(role: RoleTypeEnum) {
    try {
      assert.ok(role !== undefined, `参数缺失: role`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(EnumHelper.isEnumMember(role, RoleTypeEnum), `参数不合法: ${role}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Application Checker
   * ------------------------------------------------------------------------------------
   */
  static checkAppName(appName: string) {
    try {
      assert.ok(appName !== undefined, `参数缺失: appName`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(StringHelper.isString(appName), `应用名必须是字符串: appName=${appName}`)
      assert.ok(!!appName, `应用名不能为空: appName=${appName}`)
      assert.ok(!/^\d+$/.test(appName), `应用名不能只包含数字: appName=${appName}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Project Checker
   * ------------------------------------------------------------------------------------
   */
  static checkProjectName(projectName: string) {
    try {
      assert.ok(projectName !== undefined, `参数缺失: projectName`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(StringHelper.isString(projectName), `项目名必须是字符串: projectName=${projectName}`)
      assert.ok(!!projectName, `项目名不能为空: projectName=${projectName}`)
      /** project name 不能只包含数字 */
      assert.ok(!/^\d+$/.test(projectName), `项目名不能只包含数字: projectName=${projectName}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Module Checker
   * ------------------------------------------------------------------------------------
   */
  static checkModuleName(moduleName: string) {
    try {
      assert.ok(moduleName !== undefined, `参数缺失: moduleName`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(StringHelper.isString(moduleName), `模块名必须是字符串: moduleName=${moduleName}`)
      assert.ok(!!moduleName, `模块名不能为空: moduleName=${moduleName}`)
      /** module name 不能只包含数字 */
      assert.ok(!/^\d+$/.test(moduleName), `模块名不能只包含数字: moduleName=${moduleName}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Schema Checker
   * ------------------------------------------------------------------------------------
   */
  static checkSchemaName(schemaName: string) {
    try {
      assert.ok(schemaName !== undefined, `参数缺失: schemaName`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(StringHelper.isString(schemaName), `必须是字符串: schemaName=${schemaName}`)
      assert.ok(!!schemaName, `schema name is empty: schemaName=${schemaName}`)
      /** schema name 不能只包含数字 */
      assert.ok(!/^\d+$/.test(schemaName), `schema 名称不能只包含数字: schemaName=${schemaName}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkSchemaVersion(version: string | AramSchemaVersionTypeEnum) {
    try {
      assert.ok(version !== undefined, `参数缺失: schemaVersion`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      return AramSchemaVersion.str2version(version)
    } catch (error) {
      try {
        return AramSchemaBetaVersion.str2betaVersion(version)
      } catch (error) {
        try {
          return AramSchemaBetaVersion.str2betaVersionV2(version)
        } catch (error) {
          throw new AramInvalidFormatParamError(error.message)
        }
      }
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Flow Checker
   * ------------------------------------------------------------------------------------
   */
  static checkProcessName(name: FlowProcessEnum) {
    try {
      assert.ok(EnumHelper.isEnumMember(name, FlowProcessEnum), `参数不合法: ${name}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkApproverOpinion(opinion: ApproverOpinionEnum) {
    try {
      assert.ok(EnumHelper.isEnumMember(opinion, ApproverOpinionEnum), `参数不合法: ${opinion}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Page Checker
   * ------------------------------------------------------------------------------------
   */
  static checkPageNum(pageNum: number | string) {
    try {
      assert.ok(pageNum !== undefined, `参数缺失: pageNum`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(Number.isInteger(+pageNum), `参数不合法: pageNum=${pageNum}`)
      assert.ok(+pageNum > 0, `参数不合法: pageNum=${pageNum}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  static checkPageSize(pageSize: number | string) {
    try {
      assert.ok(pageSize !== undefined, `参数缺失: pageSize`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(Number.isInteger(+pageSize), `参数不合法: pageSize=${pageSize}`)
      assert.ok(+pageSize > 0, `参数不合法: pageSize=${pageSize}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * S3 Checker
   * ------------------------------------------------------------------------------------
   */
  static checkS3Filename(filename: string) {
    try {
      assert.ok(filename !== undefined, `参数缺失: filename`)
    } catch (error) {
      throw new AramMissingParamError(error.message)
    }
    try {
      assert.ok(!!filename, `S3 文件名不能为空: filename=${filename}`)
      assert.ok(!filename.startsWith('/'), `S3 文件名不能以 '/' 开头, filename=${filename}`)
    } catch (error) {
      throw new AramInvalidFormatParamError(error.message)
    }
  }
}
