import assert from 'assert'
import { SchemaBetaVersionDAO } from '~/aram-base/dao/schema-beta-version-dao'
import { SchemaVersionDAO } from '~/aram-base/dao/schema-version-dao'
import { SchemaDAO } from '~/aram-base/dao/schema-dao'
import { AramAesEncryption } from '~/aram-lib/model/aram-encryption/aram-aes-encryption'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { CDNSourceEnum, S3StreamService } from '~/aram-out/mss/s3-stream-service'
import { AbstractDAO } from '~/aram-base/dao/abstract-dao'
import { AramSchema } from '~/aram-base/entities/aram-schema'
import { AramSchemaBetaVersion } from '~/aram-base/entities/aram-schema-beta-version'
import { AramSchemaVersion } from '~/aram-base/entities/aram-schema-version'
import { AramApplicationUidEnum, AramSchemaVersionTypeEnum } from '~/aram-base/enum/common'

/**
 * 项目维度迁移 Aram S3 文件
 *
 * 幂等
 *
 * prod
 * ------------
 * 源     aram/schema/{{ project_id }}/dist/{{ encrypted_schema_id }}/{{ version }}.json
 * 目标   aram/{{ project_id }}/dist/{{ schema_uid }}/{{ version }}.json
 *
 * beta
 * ------------
 * 源     aram/schema/{{ project_id }}/dist/{{ encrypted_schema_id }}/{{ beta_version }}.json
 * 目标   aram/{{ project_id }}/beta/{{ schema_uid }}/{{ beta_version }}.json
 */
export class BatchCDNMigration {
  private schemaItemList: AramSchema[]
  private prodVersionList: AramSchemaVersion[]
  private betaVersionList: AramSchemaBetaVersion[]
  private schemaVersionDao: SchemaVersionDAO
  private schemaBetaVersionDao: SchemaBetaVersionDAO
  private schemaDao: SchemaDAO
  private appUid: AramApplicationUidEnum

  constructor() {
    this.appUid = AramApplicationUidEnum.Aram
    this.schemaVersionDao = new SchemaVersionDAO()
    this.schemaBetaVersionDao = new SchemaBetaVersionDAO()
    this.schemaDao = new SchemaDAO()
  }

  async init(projectIdList: AramIdType[]) {
    const schemaList = await this.schemaDao.getAllByProjectIdList(projectIdList)
    const schemaIdList = schemaList.map(e => e.schemaId)
    assert(
      schemaList.every(e => !!e.schemaUid),
      `所有配置必须设置 schema_uid`,
    )
    this.schemaItemList = schemaList
    this.prodVersionList = await this.schemaVersionDao.getAllBySchemaIdList(schemaIdList)
    this.betaVersionList = await this.schemaBetaVersionDao.getAllBySchemaIdList(schemaIdList)
  }

  private async precheck(projectId: AramIdType, schemaId: AramIdType, url: string) {
    const schemaUrlRegx = /schema\/(\d+)\/dist\/([\w\=\+\-]+)\/([\w\.\@\-]+).json/

    if (!schemaUrlRegx.test(url)) {
      throw new Error(`链接格式错误: url=${url}`)
    }

    const [_, sProjectId, sEncrySchemaId, sVersion] = schemaUrlRegx.exec(url)
    if (+sProjectId !== +projectId) {
      throw new Error(`解析 projectId 错误: projectId=${sProjectId}`)
    }

    const sSchemaId = await AramAesEncryption.decrypt(sEncrySchemaId)
    if (+sSchemaId !== +schemaId) {
      throw new Error(`解析 schemaId 错误: schemaId=${sSchemaId}`)
    }

    return sVersion
  }

  async migrate(projectId: AramIdType) {
    const updateQueryList = []
    const clientBJ = await S3StreamService.getInstance(this.appUid, CDNSourceEnum.BJ)
    const clientSH = await S3StreamService.getInstance(this.appUid, CDNSourceEnum.SH)

    for (let i = 0; i < this.schemaItemList.length; i++) {
      const schemaItem = this.schemaItemList[i]
      const { schemaUid, schemaId } = schemaItem

      const promises = []
      const subProdVersionList = this.prodVersionList.filter(e => +e.schemaId === +schemaId)
      const subBetaVersionList = this.betaVersionList.filter(e => +e.schemaId === +schemaId)
      let bMigrateProd = false
      let bMigrateBeta = false

      for (let j = 0; j < subProdVersionList.length; j++) {
        const { url, schemaVersionId } = subProdVersionList[j]

        let sVersion: string
        try {
          sVersion = await this.precheck(projectId, schemaId, url)
        } catch (e) {
          AramLogger.logWarning(e.message)
          continue
        }

        bMigrateProd = true
        /** prod migration */
        const version = AramSchemaVersion.str2version(sVersion)
        const targetUrl = SchemaVersionDAO.toSchemaS3ProdURLV2(projectId, schemaUid, version)

        AramLogger.logInfo(`prod migration: schemaVersionId=${schemaVersionId}, source=${url}, target=${targetUrl}`)

        promises.push(clientBJ.copy(url, targetUrl))
        promises.push(
          clientSH.copy(url, targetUrl).catch(e => {
            AramLogger.logWarning(`prod shanghai cdn migration failed: ${e.message}`)
          }),
        )

        updateQueryList.push(`UPDATE \`aram_schema_version\` SET url = "${targetUrl}" WHERE schema_version_id = "${schemaVersionId}";`)
      }

      /** latest migration */
      if (bMigrateProd) {
        const sourceProdLatest = await SchemaVersionDAO.toSchemaS3ProdURL(projectId, +schemaId, AramSchemaVersionTypeEnum.latest)
        const targetProdLatest = SchemaVersionDAO.toSchemaS3ProdURLV2(projectId, schemaUid, AramSchemaVersionTypeEnum.latest)

        AramLogger.logInfo(`prod latest migration: source=${sourceProdLatest}, target=${targetProdLatest};`)

        promises.push(clientBJ.copy(sourceProdLatest, targetProdLatest))
        promises.push(
          clientSH.copy(sourceProdLatest, targetProdLatest).catch(e => {
            AramLogger.logWarning(`prod shanghai latest cdn migration failed: ${e.message}`)
          }),
        )
      }

      for (let j = 0; j < subBetaVersionList.length; j++) {
        const { url, schemaBetaVersionId } = subBetaVersionList[j]

        let sVersion: string
        try {
          sVersion = await this.precheck(projectId, schemaId, url)
        } catch (e) {
          AramLogger.logWarning(e.message)
          continue
        }

        bMigrateBeta = true
        /** beta migration */
        const { version, betaVersion } = AramSchemaBetaVersion.str2betaVersion(sVersion)
        const targetUrl = SchemaBetaVersionDAO.toSchemaS3BetaURLV2(projectId, schemaUid, version as number, betaVersion)

        AramLogger.logInfo(`beta migration: schemaBetaVersionId=${schemaBetaVersionId}, source=${url}, target=${targetUrl}`)

        promises.push(clientBJ.copy(url, targetUrl))
        promises.push(
          clientSH.copy(url, targetUrl).catch(e => {
            AramLogger.logWarning(`beta shanghai cdn migration failed: ${e.message}`)
          }),
        )

        updateQueryList.push(`UPDATE \`aram_schema_beta_version\` SET url = "${targetUrl}" WHERE schema_beta_version_id = "${schemaBetaVersionId}";`)
      }

      /** latest migration */
      if (bMigrateBeta) {
        const sourceBetaLatest = await SchemaBetaVersionDAO.toSchemaS3BetaURL(projectId, +schemaId)
        const targetBetaLatest = SchemaBetaVersionDAO.toSchemaS3BetaURLV2(projectId, schemaUid)

        AramLogger.logInfo(`beta latest migration: source=${sourceBetaLatest}, target=${targetBetaLatest}`)

        promises.push(clientBJ.copy(sourceBetaLatest, targetBetaLatest))
        promises.push(
          clientSH.copy(sourceBetaLatest, targetBetaLatest).catch(e => {
            AramLogger.logWarning(`beta shanghai latest cdn migration failed: ${e.message}`)
          }),
        )
      }
      await Promise.all(promises)
    }

    if (updateQueryList.length) {
      AramLogger.logInfo(['开始执行 SQL 语句', ...updateQueryList].join('\n'))
      await AbstractDAO.runSQL(updateQueryList)
      AramLogger.logInfo('SQL 语句执行完毕')
    }
  }
}
