import { AramLogger } from '~/aram-lib/model/aram-logger'
import { BatchCDNMigration } from '~/aram-biz/service/__system__/batch-cdn-migration'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class SystemService extends AbstractServiceBase {
  constructor() {
    super()
  }

  async batchMigrateAramS3(projectIdList: AramIdType[]) {
    const mi = new BatchCDNMigration()
    await mi.init(projectIdList)

    for (let i = 0; i < projectIdList.length; i++) {
      const projectId = projectIdList[i]

      AramLogger.logInfo(`start: projectId=${projectId}`)
      await mi.migrate(projectId)
      AramLogger.logInfo(`done: projectId=${projectId}`)
    }

    return
  }
}
