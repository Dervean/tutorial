import assert from 'assert'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { FlowServiceContext } from '~/aram-flow/context/flow-service-context'

export abstract class AbstractServiceBase {
  public get flowEngine() {
    assert.ok(!!FlowServiceContext.engine, `FlowEngine 未初始化`)
    return FlowServiceContext.engine
  }

  public get aramEngine() {
    assert.ok(!!AramServiceContext.engine, `AramEngine 未初始化`)
    return AramServiceContext.engine
  }
}
