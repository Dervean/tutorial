import moment from 'moment'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AdministratorDAO } from '~/aram-base/dao/administrator-dao'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramAes256GcmEncryption } from '~/aram-lib/model/aram-encryption/aram-aes256-gcm-encryption'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class AdminService extends AbstractServiceBase {
  private administratorDao: AdministratorDAO

  constructor() {
    super()
    this.administratorDao = new AdministratorDAO()
  }

  private async encryptAdminToken(expiresTimestamp: number, userId: AramIdType, userName: AramUserNameType) {
    const plaintext = `${expiresTimestamp}&${userId}&${userName}`

    const adminToken = await AramAes256GcmEncryption.encrypt(plaintext)
    return adminToken
  }

  private async decryptAdminToken(encryptedAdminToken: string) {
    const adminToken = await AramAes256GcmEncryption.decrypt(encryptedAdminToken)
    const [expiresTimestamp, decryptedUserId, decryptedUserName] = adminToken.split('&')

    return {
      expiresTimestamp: +expiresTimestamp,
      decryptedUserId: +decryptedUserId,
      decryptedUserName,
    }
  }

  async adminLoginAuthenticate() {
    const { userId, userName } = await NestEventHelper.user()
    const adminItem = await this.administratorDao.getByPrimaryKey(userId)

    if (!adminItem) return null

    const expiresTime = moment().add(1, 'hours')
    const encryptedAdminToken = await this.encryptAdminToken(expiresTime.valueOf(), userId, userName)
    return {
      adminToken: encryptedAdminToken,
      expiresTime: expiresTime.utc(),
    }
  }

  async adminIdentityVerify(token: string, userId: AramIdType, userName: AramUserNameType) {
    try {
      if (!token) return false

      const { expiresTimestamp, decryptedUserId, decryptedUserName } = await this.decryptAdminToken(token)
      const current = moment()
      const expires = moment(expiresTimestamp)

      if (userId !== decryptedUserId) return false
      if (userName !== decryptedUserName) return false
      if (expires.isBefore(current)) return false

      return true
    } catch (error) {
      AramLogger.logError(error, { token, userId, userName })
      return false
    }
  }
}
