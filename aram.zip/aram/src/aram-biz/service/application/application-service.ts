import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramPage, AramPageParams } from '~/aram-lib/model/aram-page'
import { ApplicationDAO } from '~/aram-base/dao/application-dao'
import { AramNoApplicationPermissionError } from '~/aram-lib/model/aram-error/forbidden/aram-no-application-permission-error'
import { AramApplicationAlreadyExistedError } from '~/aram-lib/model/aram-error/forbidden/aram-application-already-existed-error'
import { AramApplicationNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-application-not-found-error'
import { AramApplication } from '~/aram-base/entities/aram-application'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class ApplicationService extends AbstractServiceBase {
  private applicationDao: ApplicationDAO

  constructor() {
    super()
    this.applicationDao = new ApplicationDAO()
  }

  public async getApplication(appUid: AramUidType) {
    return this.applicationDao.getByPrimaryKey(appUid)
  }

  /**
   * 获取应用详情
   */
  public async getActiveApplication(appUid: AramUidType) {
    const appItem = await this.getApplication(appUid)
    if (appItem === null) {
      throw new AramApplicationNotFoundError(`应用不存在: appUid=${appUid}`)
    }
    if (appItem.status === AramStatusEnum.Inactive) {
      throw new AramApplicationNotFoundError(`应用已下线: appUid=${appUid}`)
    }
    return appItem
  }

  /**
   * 返回应用列表
   * - 分页查询
   */
  public async searchApplicationList(pageParams: AramPageParams, status?: AramStatusEnum) {
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.applicationDao.search(offset, limit, status)

    const page = new AramPage<AramApplication>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }

  /**
   * 创建应用
   */
  public async createApplication(params: Pick<AramApplication, 'appUid' | 'appName' | 'ext' | 'hooks' | 'description'>) {
    const { userName, isAdministrator } = await NestEventHelper.user()
    const { appUid, appName, ext = null, hooks = null, description = null } = params
    /**
     * @todo 权限校验
     */
    if (!isAdministrator) throw new AramNoApplicationPermissionError(`无创建应用权限`)

    const appItem = await this.applicationDao.getByPrimaryKey(appUid)
    if (appItem) {
      throw new AramApplicationAlreadyExistedError(`应用已存在: appUid=${appUid}`)
    }

    const target = new AramApplication()
    target.appUid = appUid
    target.appName = appName
    target.createdBy = userName
    target.ext = ext
    target.hooks = hooks
    target.description = description
    const data = await this.applicationDao.insert(target)

    const ret = data.identifiers[0] as { appUid: AramUidType }
    return { ...ret }
  }

  /**
   * 下线应用
   */
  public async offlineApplication(params: Pick<AramApplication, 'appUid'>) {
    const { userName, isAdministrator } = await NestEventHelper.user()
    const { appUid } = params
    /**
     * @todo 权限校验
     */
    if (!isAdministrator) throw new AramNoApplicationPermissionError(`无下线应用权限`)

    /** 查找应用 */
    const appItem = await this.applicationDao.getByPrimaryKey(appUid)
    if (!appItem || appItem.status === AramStatusEnum.Inactive) {
      throw new AramApplicationNotFoundError(`应用不存在或已下线: appUid=${appUid}`)
    }

    await this.applicationDao.deleteByPrimaryKey(appUid, userName)
  }

  /**
   * 编辑应用
   */
  public async updateApplicationInfo(params: Pick<AramApplication, 'appUid'> & Partial<AramApplication>) {
    const { userName, isAdministrator } = await NestEventHelper.user()
    const { appUid, appName, ext, hooks, description } = params

    /**
     * @todo 权限校验
     */
    if (!isAdministrator) throw new AramNoApplicationPermissionError(`无编辑应用权限`)

    /** 查找项目 id */
    const appItem = await this.applicationDao.getByPrimaryKey(appUid)
    if (!appItem || appItem.status === AramStatusEnum.Inactive) {
      throw new AramApplicationNotFoundError(`应用不存在或已下线: appUid=${appUid}`)
    }

    await this.applicationDao.updateByPrimaryKey(appUid, {
      updatedBy: userName,
      ...(appName ? { appName } : {}),
      ...(ext ? { ext } : {}),
      ...(hooks ? { hooks } : {}),
      ...(description ? { description } : {}),
    })
  }
}
