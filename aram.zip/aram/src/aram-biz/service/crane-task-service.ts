import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { APP_KEY } from '~/aram-lib/config'
import { CraneService } from '~/aram-out/crane/crane-service'
import { CraneTaskDAO } from '~/aram-base/dao/crane-task-dao'
import { IAramAlertService } from './interface/aram-alert-service'
import { AramCraneTask } from '~/aram-base/entities/aram-crane-task'

export class CraneTaskService extends AbstractServiceBase {
  private dao: CraneTaskDAO
  public static CLEAR_CRANE_JOB = `${APP_KEY}.global.clear.crane.job`

  constructor() {
    super()
    this.dao = new CraneTaskDAO()
  }

  public async activateCraneJobs(services: IAramAlertService[]) {
    // prettier-ignore
    return Promise.all(
      services.map(service => service.activateJobs())
    )
  }

  public async addClearCraneJob(services: IAramAlertService[]) {
    AramLogger.logInfo(`开始创建定时销毁任务`)
    const craneTaskName = CraneTaskService.CLEAR_CRANE_JOB
    const task = await this.dao.getLatestByCraneTaskName(craneTaskName)
    let hit = false
    if (task !== null) {
      try {
        const craneTask = await this.aramEngine.crane().getTask(task.craneTaskId)
        if (craneTask) {
          hit = true
        }
      } catch (error) {
        AramLogger.logWarning(`定时任务获取失败: craneTaskName=${craneTaskName}`)
      }
    }
    if (task === null || !hit) {
      const craneTaskId = await this.aramEngine.crane().createTask({
        taskName: craneTaskName,
        crontab: '0 0/5 * * * ?',
        creator: 'system',
        description: '定时销毁任务',
      })
      const verion = task?.version || 0
      const target = new AramCraneTask()
      target.craneTaskId = craneTaskId
      target.craneTaskName = craneTaskName
      target.version = +verion + 1
      await this.dao.insert(target)
      AramLogger.logInfo(`创建定时任务成功: craneTaskId=${craneTaskId}, craneTaskName=${craneTaskName}`)
    }
    CraneService.addJob(craneTaskName, task => {
      // prettier-ignore
      return Promise.all(
        services.map(service => service.clearJobs())
      )
    })
    AramLogger.logInfo(`创建定时销毁任务成功`)
  }
}
