import { AramLogger } from '~/aram-lib/model/aram-logger'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { DynaAlertDAO } from '~/aram-base/dao/dyna/dyna-alert-dao'
import { DynaAlert } from '~/aram-base/entities/dyna/dyna-alert'
import { IAramAlertService } from '../interface/aram-alert-service'
import { APP_KEY } from '~/aram-lib/config'
import { DateHelper } from '~/aram-lib/helper/date-helper'
import { CraneService } from '~/aram-out/crane/crane-service'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { LionClientService, LionConfigKeyEnum } from '~/aram-out/lion/lion-client-service'
import { AramPage } from '~/aram-lib/model/aram-page'
import { StateDescEnum, StateEnum } from '~/aram-base/enum/flow'

export class DynaAlertService extends AbstractServiceBase implements IAramAlertService {
  private dao: DynaAlertDAO

  constructor() {
    super()
    this.dao = new DynaAlertDAO()
  }

  private craneTaskName(schemaId: AramIdType) {
    return `${APP_KEY}.dyna.alert.${schemaId}.${DateHelper.timestamp()}`
  }

  private xmTemplate(params: Map<string, any>, href: string) {
    const link = StringHelper.parseHref(href, params)
    const body = {
      messageType: 'custom',
      body: {
        templateName: 'Dyna 自动提醒',
        contentTitle: '',
        content: [
          `以下 Dyna 配置即将到期，请您注意验证是否会对线上产生影响，详细设置如下`,
          `-------------------`,
          `项目名称: ${params.get('projectName')}`,
          `配置ID: ${params.get('schemaUid')}`,
          `配置名称: ${params.get('schemaName')}`,
          `备注: ${params.get('remark')}`,
          `被提醒人列表: ${params.get('notifiers').join(',')}`,
          `本次提醒创建人: ${params.get('createdBy')}`,
          `本次提醒创建时间: ${params.get('createTime')}`,
        ].join('\n'),
        linkName: '前往修改',
        link,
      },
    }
    return body
  }

  async activateJobs() {
    const that = this
    const filter = new DynaAlert()
    filter.state = StateEnum.Active
    const activeAlertList = await this.dao.getAlertListBy(filter)
    activeAlertList.map(alert => {
      CraneService.addJob(alert.craneTaskName, async (task: CraneScheduleTask) => {
        return that.handleCron(task)
      })
      AramLogger.logInfo(`激活定时任务成功: craneTaskName=${alert.craneTaskName}`)
    })
  }

  async clearJobs() {
    AramLogger.logInfo(`开始执行清理 Dyna 定时任务`)
    const markedAlertList = await this.dao.getMarkedAlertList()
    await Promise.all(
      markedAlertList.map(alert => {
        return this.destroyCron(alert.craneTaskId)
      }),
    )
    AramLogger.logInfo(`执行清理 Dyna 定时任务成功`)
  }

  async sendXmMessage(alert: DynaAlert) {
    const href = await LionClientService.fetchConfigValue(LionConfigKeyEnum.DynaEmbededPanelHref)
    const schema = await this.aramEngine.schema().getActiveSchema(alert.schemaId)
    const project = await this.aramEngine.project().getActiveProject(schema.projectId)

    const params = new Map<string, any>()
    params.set('projectName', project.projectName)
    params.set('projectId', project.projectId)
    params.set('schemaId', schema.schemaId)
    params.set('schemaUid', schema.schemaUid)
    params.set('schemaName', schema.schemaName)
    params.set('remark', alert.remark)
    params.set('notifiers', alert.notifiers)
    params.set('createdBy', alert.createdBy)
    params.set('createTime', alert.createTime)
    const template = this.xmTemplate(params, href)
    await Promise.all(
      alert.notifiers.map(mis => {
        return this.aramEngine
          .xm()
          .sendCustomMsg(template, mis)
          .then(() => {
            AramLogger.logInfo(`发送 Dyna 自动提醒成功: task=${alert.craneTaskId}, mis=${mis}`)
            return
          })
      }),
    )
    return
  }

  async handleCron(task: CraneScheduleTask) {
    const craneTaskId = task.jobUniqueCode
    try {
      const alert = await this.dao.getByPrimaryKey(task.jobUniqueCode)
      if (alert.state !== StateEnum.Active) {
        return
      }
      await this.sendXmMessage(alert)
      return this.markRemovalCron(craneTaskId, StateEnum.Success)
    } catch (error) {
      AramLogger.logError(`发送 Dyna 自动提醒失败: taskId=${craneTaskId}, message=${error.message}`)
      return this.markRemovalCron(craneTaskId, StateEnum.Failed)
    }
  }

  async createCron(value: DynaAlert) {
    const that = this
    const { userName } = await NestEventHelper.user()
    const craneTaskName = this.craneTaskName(value.schemaId)
    const craneTaskId = await this.aramEngine.crane().createTask({
      taskName: craneTaskName,
      date: DateHelper.getDate(value.remindTime),
      creator: userName,
      description: value.remark,
    })
    CraneService.addJob(craneTaskName, async (task: CraneScheduleTask) => {
      return that.handleCron(task)
    })

    const target = new DynaAlert()
    target.craneTaskId = craneTaskId
    target.craneTaskName = craneTaskName
    target.schemaId = value.schemaId
    target.status = AramStatusEnum.Active
    target.state = StateEnum.Active
    target.stateDesc = StateDescEnum.Active
    target.notifiers = value.notifiers
    target.remark = value.remark
    target.remindTime = value.remindTime
    target.createdBy = userName
    await this.dao.insert(target)
    AramLogger.logInfo(`创建 Dyna 自动提醒任务成功: craneTaskId=${craneTaskId}`)
  }

  async updateCron(value: DynaAlert) {
    if (!value.craneTaskId) {
      throw new Error(`参数错误: ${value}`)
    }
    let date, description
    if (value.remark) description = value.remark
    if (value.remindTime) date = DateHelper.getDate(value.remindTime)
    const model = await this.aramEngine.crane().updateTask(value.craneTaskId, { date, description })
    if (model) {
      const target = new DynaAlert()
      target.notifiers = value.notifiers
      target.remark = value.remark
      target.remindTime = value.remindTime
      await this.dao.updateByPrimaryKey(value.craneTaskId, target)
      AramLogger.logInfo(`更新 Dyna 自动提醒任务成功: craneTaskId=${value.craneTaskId}`)
    }
  }

  private async markRemovalCron(craneTaskId: string, state: StateEnum) {
    const updated = new DynaAlert()
    switch (state) {
      case StateEnum.Failed:
        updated.state = StateEnum.Failed
        updated.stateDesc = StateDescEnum.Failed
        break
      case StateEnum.Success:
        updated.state = StateEnum.Success
        updated.stateDesc = StateDescEnum.Success
        break
      case StateEnum.Canceled:
        updated.state = StateEnum.Canceled
        updated.stateDesc = StateDescEnum.Canceled
        break
      default:
        throw new Error(`未知状态: state=${state}`)
    }
    return this.dao.updateByPrimaryKey(craneTaskId, updated)
  }

  async cancelCron(craneTaskId: string) {
    return this.markRemovalCron(craneTaskId, StateEnum.Canceled)
  }

  async destroyCron(craneTaskId: string) {
    await this.aramEngine.crane().destroyTask(craneTaskId)
    await this.dao.deleteByPrimaryKey(craneTaskId).then(() => {
      AramLogger.logInfo(`下线 Dyna 自动提醒任务成功: craneTaskId=${craneTaskId}`)
      return
    })
  }

  async getActiveAlertList(schemaId?: AramIdType) {
    const { userName } = await NestEventHelper.user()
    try {
      const filter = new DynaAlert()
      filter.state = StateEnum.Active
      filter.schemaId = schemaId
      const list = await this.dao.getAlertListBy(filter)
      const page = new AramPage<DynaAlert>()
      page.setList(list)
      page.setTotalCnt(list.length)
      page.setPageNum(1)
      page.setPageSize(list.length || 10) // just mock
      return page
    } catch (error) {
      AramLogger.logError(error, { userName, schemaId })
      throw error
    }
  }
}
