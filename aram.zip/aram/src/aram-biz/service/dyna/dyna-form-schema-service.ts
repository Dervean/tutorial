import { AramLogger } from '~/aram-lib/model/aram-logger'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { DynaFormSchemaDAO } from '~/aram-base/dao/dyna/dyna-form-schema-dao'
import { DynaFormSchema } from '~/aram-base/entities/dyna/dyna-form-schema'
import { AramStatusEnum } from '~/aram-base/enum/common'

export class DynaFormSchemaService extends AbstractServiceBase {
  private dao: DynaFormSchemaDAO

  constructor() {
    super()
    this.dao = new DynaFormSchemaDAO()
  }

  async saveFormSchema(value: DynaFormSchema) {
    return this.dao.insert(value)
  }

  async getActiveFormSchema(schemaId: AramIdType, aramSchemaId: AramIdType) {
    const record = await this.dao.getBySchemaIdAndAramSchemaId(schemaId, aramSchemaId)
    if (record === null) {
      throw new Error(`表单配置不存在: schemaId=${schemaId}, aramSchemaId=${aramSchemaId}`)
    }
    if (record.status === AramStatusEnum.Inactive) {
      throw new Error(`表单配置已下线: schemaId=${schemaId}, aramSchemaId=${aramSchemaId}`)
    }
    return record
  }

  async linkAramSchema(schemaId: AramIdType, aramSchemaId: AramIdType) {
    const { userName } = await NestEventHelper.user()
    try {
      const value = new DynaFormSchema()
      const [dynaSchema, aramSchema, record] = await Promise.all([
        this.aramEngine.schema().getActiveSchema(schemaId),
        this.aramEngine.schema().getActiveSchema(aramSchemaId),
        this.dao.getBySchemaIdAndAramSchemaId(schemaId, aramSchemaId),
      ])

      if (record !== null) {
        value.status = AramStatusEnum.Active
        value.updatedBy = userName
        await this.dao.updateByPrimaryKey(record.id, value)
        return
      }

      value.createdBy = userName
      value.aramSchemaId = aramSchemaId
      value.schemaId = schemaId
      await this.saveFormSchema(value)
      return
    } catch (error) {
      AramLogger.logError(error, { userName, schemaId, aramSchemaId })
      throw error
    }
  }

  async unlinkAramSchema(schemaId: AramIdType, aramSchemaId: AramIdType) {
    const { userName } = await NestEventHelper.user()
    try {
      const activeFormSchema = await this.getActiveFormSchema(schemaId, aramSchemaId)

      const updated = new DynaFormSchema()
      updated.status = AramStatusEnum.Inactive
      updated.updatedBy = userName

      await this.dao.updateByPrimaryKey(activeFormSchema.id, updated)
      return
    } catch (error) {
      AramLogger.logError(error, { userName, schemaId, aramSchemaId })
      throw error
    }
  }

  async getAramSchemaList(schemaId: AramIdType) {
    const { userName } = await NestEventHelper.user()
    try {
      const filter = new DynaFormSchema()
      filter.status = AramStatusEnum.Active
      const activeFormSchemaList = await this.dao.getAllBySchemaId(schemaId, filter)

      const aramSchemaIds = activeFormSchemaList.map(e => e.aramSchemaId)
      /** 如果 aram schema 已下线，需要手动解绑 */
      return this.aramEngine.schema().getSchemaList(aramSchemaIds)
    } catch (error) {
      AramLogger.logError(error, { userName, schemaId })
      throw error
    }
  }
}
