import { AramSchemaFlowHistoryOrder } from '~/aram-base/entities/flow-history-order/aram-schema-flow-history-order'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { SchemaFlowHistoryOrderDAO } from '~/aram-base/dao/flow-history-order/schema-flow-history-order-dao'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramSchema } from '~/aram-base/entities/aram-schema'
import { StateEnum } from '~/aram-base/enum/flow'
import { FlowProcessEnum } from '~/aram-biz/context/enum'

export class FlowHistoryOrderService extends AbstractServiceBase {
  private schemaFlowHistoryOrderDAO: SchemaFlowHistoryOrderDAO = null

  constructor() {
    super()
    this.schemaFlowHistoryOrderDAO = new SchemaFlowHistoryOrderDAO()
  }

  async getActiveApplySchemaReleaseOrder(schemaId: AramIdType) {
    const filter = new AramSchemaFlowHistoryOrder()
    filter.state = StateEnum.Active
    filter.processName = FlowProcessEnum.ApplySchemaRelease
    const orders = await this.getFilteredSchemaHistoryOrderList(schemaId, filter)
    if (orders.length === 0) {
      return null
    }
    return orders[0]
  }

  async saveSchemaHistoryOrder(order: AramFlowOrder, schema: AramSchema) {
    const histOrder = new AramSchemaFlowHistoryOrder()
    histOrder.schemaId = schema.schemaId
    histOrder.appUid = schema.appUid
    histOrder.projectId = schema.projectId

    histOrder.orderId = order.orderId
    histOrder.processName = order.processName
    histOrder.state = order.state
    histOrder.stateDesc = order.stateDesc
    histOrder.auditState = order.auditState
    histOrder.auditStateDesc = order.auditStateDesc
    histOrder.creator = order.creator
    histOrder.createTime = order.createTime
    histOrder.creatorRemark = order.creatorRemark
    histOrder.updateTime = order.updateTime
    return this.schemaFlowHistoryOrderDAO.insert(histOrder)
  }

  async updateSchemaHistoryOrder(orderId: AramUuidType, order?: AramFlowOrder) {
    order = order || (await this.flowEngine.order().getOrder(orderId))
    const newVal = new AramSchemaFlowHistoryOrder()
    newVal.auditState = order.auditState
    newVal.auditStateDesc = order.auditStateDesc
    newVal.state = order.state
    newVal.stateDesc = order.stateDesc
    return this.schemaFlowHistoryOrderDAO.updateByPrimaryKey(orderId, newVal)
  }

  async getSchemaHistoryOrder(orderId: AramUuidType) {
    return this.schemaFlowHistoryOrderDAO.getByPrimaryKey(orderId)
  }

  async getActiveSchemaHistoryOrder(orderId: AramUuidType) {
    const order = await this.getSchemaHistoryOrder(orderId)
    if (order === null) {
      throw new Error(`流程不存在: orderId=${orderId}`)
    }
    if (order.state !== StateEnum.Active) {
      throw new Error(`流程已结束: orderId=${orderId}, state=${order.state}`)
    }
    return order
  }

  async getFilteredSchemaHistoryOrderList(schemaId: AramIdType, filter: Partial<AramSchemaFlowHistoryOrder>) {
    return this.schemaFlowHistoryOrderDAO.getFilteredOrderList(schemaId, filter)
  }
}
