import assert from 'assert'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramSchemaVersionTypeEnum } from '~/aram-base/enum/common'
import { FlowProcessEnum } from '~/aram-biz/context/enum'
import { FlowServiceContext } from '~/aram-flow/context/flow-service-context'
import { FlowOrderService } from '~/aram-flow/core/flow-order-service'
import { StreamHelper } from '~/aram-lib/helper/stream-helper'
import { StringHelper } from '~/aram-lib/helper/string-helper'
import { LionClientService, LionConfigKeyEnum } from '~/aram-out/lion/lion-client-service'
import { FlowServiceBase } from './flow-service-base'

export class FlowApplySchemaReleaseService extends FlowServiceBase {
  constructor() {
    super()
  }

  async createOrder(schemaId: AramIdType, schema: AramJsonType, remark: string) {
    const { userName } = await NestEventHelper.user()
    /** 校验用户 是否拥有 发布权限 */
    const candidates = await this.aramEngine
      .schemaMember()
      .getAllAdminBySchemaId(schemaId)
      .then(persons => persons.map(p => p.userName))
    if (!candidates.includes(userName)) {
      throw new Error(`无发布权限: ${userName}`)
    }
    const args: Record<string, any> = {}
    return this.startOrder(schemaId, schema, remark, FlowProcessEnum.SchemaRelease, args)
  }

  async createApplyOrder(schemaId: AramIdType, schema: AramJsonType, remark: string, approvers: AramUserNameType[]) {
    assert.ok(!!approvers.length, `审批人列表不能为空`)
    assert.ok(!!remark, `申请信息不能为空`)

    /** 校验用户 是否拥有 编辑权限 */
    await this.aramEngine.schemaMember().verifySchemaEditorPermission(schemaId)

    /** 校验审核人 是否拥有 发布权限 */
    const candidates = await this.aramEngine
      .schemaMember()
      .getAllAdminBySchemaId(schemaId)
      .then(persons => persons.map(p => p.userName))
    const notCandidates = approvers.filter(mis => !candidates.includes(mis))
    if (notCandidates.length) {
      throw new Error(`无发布权限: ${notCandidates.join(',')}`)
    }
    const args: Record<string, any> = {}
    args['approvers'] = approvers

    return this.startOrder(schemaId, schema, remark, FlowProcessEnum.ApplySchemaRelease, args)
  }

  async terminateOrder(orderId: AramUuidType) {
    const { userName } = await NestEventHelper.user()
    const order = await this.flowEngine.order().getOrder(orderId)
    assert(!!order, `流程不存在: orderId=${orderId}`)
    await this.flowEngine.order().terminate(orderId, userName)
    await this.aramEngine.flowHistoryOrder().updateSchemaHistoryOrder(orderId)
    return
  }

  async remindApprovers(orderId: AramUuidType) {
    const historyOrder = await this.aramEngine.flowHistoryOrder().getActiveSchemaHistoryOrder(orderId)

    const [project, schema, approvers, href] = await Promise.all([
      this.aramEngine.project().getActiveProject(historyOrder.projectId),
      this.aramEngine.schema().getActiveSchema(historyOrder.schemaId),
      this.flowEngine.approver().getApprovers(orderId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.ApplySchemaReleaseFlowDetailHref),
    ])

    const params = new Map<string, any>()
    params.set('appUid', schema.appUid)
    params.set('projectName', project.projectName)
    params.set('schemaUid', schema.schemaUid)
    params.set('schemaName', schema.schemaName)
    params.set('creator', historyOrder.creator)
    params.set('creatorRemark', historyOrder.creatorRemark)
    params.set('orderId', orderId)
    const template = this.xmTemplate(params, href)
    const notifyApproversResult = approvers.map((approver, idx) => {
      return this.aramEngine.xm().sendCustomMsg(template, approver.approver)
    })

    return Promise.all(notifyApproversResult)
  }

  private async startOrder(schemaId: AramIdType, schema: AramJsonType, remark: string, processName: FlowProcessEnum, args: Record<string, any>) {
    const { userName } = await NestEventHelper.user()
    // 预校验
    const [schemaItem, schemaVersionItem] = await Promise.all([
      this.aramEngine.schemaVersion().createSchemaVersionPrecheck(schemaId),
      this.aramEngine.schemaVersion().getBySchemaIdAndVersion(schemaId, AramSchemaVersionTypeEnum.latest),
    ])
    let latestVersionValue: AramJsonType = null
    if (schemaVersionItem) {
      latestVersionValue = await this.aramEngine.schemaVersion().getSchemaJson(schemaVersionItem.url, schemaItem.appUid)
    }
    const project = await this.aramEngine.project().getActiveProject(schemaItem.projectId)

    args['schema'] = schemaItem
    args['newVal'] = schema
    args['oldVal'] = latestVersionValue
    args[FlowOrderService.ATTR_CREATOR] = [userName]
    args[FlowOrderService.ATTR_CREATOR_REMARK] = remark

    let process = await this.flowEngine.process().getLatestVersionProcess(processName)
    if (process === null) {
      const definition = FlowServiceContext.EXT_PROCESS_CONFIGURATION.get(processName)?.definition
      assert.ok(!!definition, `流程定义部署失败: ${processName}`)
      process = await this.flowEngine.process().deploy(StreamHelper.getStreamFromFilePath(definition))
    }
    assert.ok(!!process, `流程定义部署失败: processName=${processName}`)

    const order = await this.flowEngine.startInstanceById(process.processId, userName, args)
    await this.aramEngine.flowHistoryOrder().saveSchemaHistoryOrder(order, schemaItem)

    await this.runTasksNaively(process, order, userName, args)
    return order.orderId
  }

  private xmTemplate(params: Map<string, any>, href: string) {
    const body = {
      messageType: 'custom',
      body: {
        templateName: '配置上线审批提醒',
        contentTitle: '',
        content: [
          `应用ID: ${params.get('appUid')}`,
          `项目名称：${params.get('projectName')}`,
          `配置ID：${params.get('schemaUid')}`,
          `配置名称：${params.get('schemaName')}`,
          `申请人：${params.get('creator')}`,
          `申请理由：${params.get('creatorRemark')}`,
        ].join('\n'),
        linkName: '前往审批',
        link: StringHelper.parseHref(href, params),
      },
    }
    return body
  }
}
