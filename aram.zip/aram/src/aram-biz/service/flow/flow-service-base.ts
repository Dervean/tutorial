import { FlowEngine } from '~/aram-flow/core/flow-engine'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { FlowTaskModel } from '~/aram-flow/model/node/flow-task-model'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export abstract class FlowServiceBase extends AbstractServiceBase {
  // @todo 临时解决方案
  protected async runTasksNaively(process: AramFlowProcess, order: AramFlowOrder, userName: AramUserNameType, args: Record<string, any>) {
    for (let i = 0; ; i++) {
      const tasks = await this.flowEngine.task().getActiveTasks({
        orderId: order.orderId,
      })
      // @todo 放在?
      for (const task of tasks) {
        task.model = process.model.getNode(task.name) as FlowTaskModel
      }

      const flag = i === 0 || (!!tasks.length && tasks.some(e => e.model.autoExecute === 'Y'))
      if (!flag) break

      for (const task of tasks) {
        const operator = task.actors === null ? FlowEngine.AUTO : userName
        await this.flowEngine.executeTask(task.taskId, operator, args)
      }
    }
  }
}
