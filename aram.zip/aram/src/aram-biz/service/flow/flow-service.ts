import assert from 'assert'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { FlowServiceContext } from '~/aram-flow/context/flow-service-context'
import { FlowTaskService } from '~/aram-flow/core/flow-task-service'
import { ApproverOpinionEnum } from '~/aram-base/entities/flow/aram-flow-approver'
import { StateEnum } from '~/aram-base/enum/flow'
import { StreamHelper } from '~/aram-lib/helper/stream-helper'
import { FlowServiceBase } from './flow-service-base'
import { FlowProcessEnum } from '~/aram-biz/context/enum'

export class FlowService extends FlowServiceBase {
  constructor() {
    super()
  }

  async deployProcess(processName: FlowProcessEnum) {
    const definition = FlowServiceContext.EXT_PROCESS_CONFIGURATION.get(processName)?.definition
    assert.ok(!!definition, `流程定义部署失败: ${processName}`)
    const process = await this.flowEngine.process().deploy(StreamHelper.getStreamFromFilePath(definition))
    assert.ok(!!process, `流程定义部署失败: ${processName}`)
    return
  }

  async getOrderdetail(orderId: AramUuidType) {
    const [flowOrder, flowTasks, flowApprovers] = await Promise.all([
      this.flowEngine.order().getOrder(orderId),
      this.flowEngine.task().getTasks(orderId),
      this.flowEngine.approver().getApprovers(orderId),
    ])
    const flowProcess = await this.flowEngine.process().getProcessById(flowOrder.processId)
    const sortedFlowTasks = FlowTaskService.sortTasks(flowTasks)
    const flowTasksWithShadows = await this.flowEngine.shadowTask().tasksWithShadows(flowProcess, flowOrder, sortedFlowTasks)
    return {
      flowOrder,
      flowApprovers,
      flowTasks: flowTasksWithShadows,
    }
  }

  async reviewOrder(orderId: AramUuidType, opinion: ApproverOpinionEnum, approverRemark?: string) {
    const { userName } = await NestEventHelper.user()
    // prettier-ignore
    const [order, approvers] = await Promise.all([
        this.flowEngine.order().getOrder(orderId),
        this.flowEngine.approver().getApprovers(orderId),
      ])
    assert.ok(!!order, `流程不存在: orderId=${orderId}`)
    assert.ok(order.state === StateEnum.Active, `流程已结束: stateDesc=${order.stateDesc}`)
    assert.ok(
      approvers.some(e => e.approver === userName),
      `非流程审核人`,
    )
    const args: Record<string, any> = {}
    args['approverInput'] = { approver: userName, opinion, approverRemark }

    const process = await this.flowEngine.process().getProcessById(order.processId)

    // @todo 消息队列 发布不应该在这里执行
    return this.runTasksNaively(process, order, userName, args)
  }
}
