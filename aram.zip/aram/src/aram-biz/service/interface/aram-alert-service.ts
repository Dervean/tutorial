export interface IAramAlertService {
  activateJobs: () => Promise<void>
  clearJobs: () => Promise<void>
}
