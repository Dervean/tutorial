import { MaraBuiltinComponentDAO } from '~/aram-base/dao/mara-builtin-component-dao'
import { AramMaraBuiltinComponent } from '~/aram-base/entities/aram-mara-builtin-component'
import { AramComponentNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-component-not-found-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class MaraService extends AbstractServiceBase {
  private maraBuiltinComponentDao: MaraBuiltinComponentDAO
  // private customComponentDAO: CustomComponentDAO
  // private customComponentVersionDAO: CustomComponentVersionDAO

  constructor() {
    super()
    this.maraBuiltinComponentDao = new MaraBuiltinComponentDAO()
    // this.customComponentDAO = new CustomComponentDAO()
    // this.customComponentVersionDAO = new CustomComponentVersionDAO()
  }

  // /**
  //  * 根据 componentType 判断组件类型是 内置组件 还是 自定义组件
  //  * @param componentType
  //  * @returns
  //  */
  // static checkComponentType(componentType: AramMaraComponentType) {
  //   const parsedComponentType = +componentType
  //   const CUSTOM_NORMAL = 1 << 3
  //   const CUSTOM_CONTAINER = (1 << 3) ^ (1 << 1)
  //   const BUILTIN_NORMAL = 1 << 0
  //   const BUILTIN_CONTAINER = 1 << 1
  //   const checkCustomComponent = parsedComponentType ^ CUSTOM_NORMAL && parsedComponentType ^ CUSTOM_CONTAINER
  //   const checkBuiltinComponent = parsedComponentType ^ BUILTIN_NORMAL && parsedComponentType ^ BUILTIN_CONTAINER
  //   return {
  //     isCustomComponent: !checkCustomComponent,
  //     isBuiltinComponent: !checkBuiltinComponent,
  //   }
  // }

  /**
   * 上传内置组件配置
   */
  async createBuiltinComponent(model: AramMaraBuiltinComponent) {
    const { userName } = await NestEventHelper.user()
    const comp = await this.maraBuiltinComponentDao.getByComponentName(model.componentName)
    if (comp === null) {
      await this.maraBuiltinComponentDao.insert(model)
      return
    }
    if (comp.status === AramStatusEnum.Active) {
      throw new Error(`组件已存在: componentName=${model.componentName}`)
    }
    const newVal = new AramMaraBuiltinComponent(comp)
    newVal.updatedBy = userName
    newVal.status = AramStatusEnum.Active
    return this.maraBuiltinComponentDao.updateByPrimaryKey(comp.componentId, newVal)
  }

  async offlineBuiltinComponent(componentName: string) {
    const { userName } = await NestEventHelper.user()
    /** 合法性校验 */
    const comp = await this.getActiveBuiltinComponentByName(componentName)
    const newVal = new AramMaraBuiltinComponent()
    newVal.status = AramStatusEnum.Inactive
    newVal.updatedBy = userName

    return this.maraBuiltinComponentDao.updateByPrimaryKey(comp.componentId, newVal)
  }

  /**
   * 更新内置组件配置
   */
  async updateBuiltinComponent(componentName: string, model: AramMaraBuiltinComponent) {
    /** 合法性校验 */
    const comp = await this.getActiveBuiltinComponentByName(componentName)

    return this.maraBuiltinComponentDao.updateByPrimaryKey(comp.componentId, model)
  }

  // /**
  //  * 创建自定义组件
  //  */
  // async createCustomComponent(payload: CreateCustomComponentParams) {

  //     const { description, projectId } = payload
  //     /** 校验 projectId 是否合法 */
  //     const projectItem = await this.projectDAO.getByPrimaryKey(projectId)
  //     if (!projectItem) throw new AramProjectNotFoundError(`项目不存在: projectId=${projectId}`)

  //     const { identifiers } = await this.customComponentDAO.insert({
  //       projectId,
  //       ...(description ? { description } : {}),
  //     })
  //     const ret = identifiers[0] as { componentId: AramIdType }
  //     return { ...ret }
  // }

  // /**
  //  * 发布自定义组件配置
  //  */
  // async createCustomComponentVersion(payload: CreateCustomComponentVersionParams) {

  //   const { projectId, componentId, componentName, componentType, schema, bundleMd5, bundleLink, previews, description } = payload
  //     /** 校验 componentType 是否合法 */
  //     const { isCustomComponent } = MaraService.checkComponentType(componentType)
  //     if (!isCustomComponent) throw new AramInvalidComponentTypeError(`组件类型非法: componentType=${componentType}`)

  //     /**
  //      * 1. 校验 projectId 是否合法
  //      * 2. 获取最新版本
  //      */
  //     const [projectItem, latestCustomComponentVersionItem] = await Promise.all([
  //       this.projectDAO.getByPrimaryKey(projectId),
  //       this.getLatestCustomComponentVersion(componentId),
  //     ])
  //     if (!projectItem) throw new AramProjectNotFoundError(`项目不存在: projectId=${projectId}`)

  //     /** 校验 project 是否删除 */
  //     const { isDeleted } = projectItem
  //     if (isDeleted) throw new AramProjectClosedError(`项目已关闭: projectId=${projectId}`)

  //     /**
  //      * 发布新版本组件
  //      *  version = latest version + 1
  //      */
  //     const latestVersion = +latestCustomComponentVersionItem.version || 0

  //     const { identifiers } = await this.customComponentVersionDAO.insert({
  //       projectId,
  //       componentId,
  //       componentType,
  //       componentName,
  //       schema,
  //       bundleMd5,
  //       version: latestVersion + 1,
  //       ...(bundleLink ? { bundleLink } : {}),
  //       ...(previews ? { previews } : {}),
  //       ...(description ? { description } : {}),
  //     })
  //     const ret = identifiers[0] as { componentVersionId: AramIdType }
  //     return { ...ret }
  // }

  /**
   * 获取组件列表
   * @param projectId
   * @returns
   */
  async getActiveComponentList(projectId: AramIdType) {
    /** 校验 projectId 是否合法 */
    const project = await this.aramEngine.project().getActiveProject(projectId)

    const maraBuiltinComponentList = await this.maraBuiltinComponentDao.getAll()
    // const customComponentVersionList = await this.customComponentVersionDAO.getAllLastestVersionByProjectId(projectId)

    const activeBuiltinComps = maraBuiltinComponentList.filter(comp => comp.status === AramStatusEnum.Active)
    // const activeCustomComps = customComponentVersionList.filter(comp => comp.status === AramStatusEnum.Active)
    return activeBuiltinComps
  }

  // /**
  //  * 获取最新版本自定义组件配置
  //  * @param componentId
  //  * @returns
  //  */
  // private async getLatestCustomComponentVersion(componentId: AramIdType) {

  //     const [customComponentItem, latestVersionItem] = await Promise.all([
  //       this.customComponentDAO.getByPrimaryKey(componentId),
  //       this.customComponentVersionDAO.getLastestVersionByComponentId(componentId),
  //     ])
  //     if (!customComponentItem) throw new AramComponentNotFoundError(`自定义组件不存在: componentId=${componentId}`)
  //     if (!latestVersionItem) throw new AramComponentVersionNotFoundError(`找不到自定义组件最新版本数据: componentId=${componentId}`)

  //     return latestVersionItem
  // }

  // /**
  //  * 获取内置组件配置
  //  * @param componentId
  //  * @returns
  //  */
  // private async getActiveBuiltinComponentById(componentId: AramIdType) {
  //   const comp = await this.maraBuiltinComponentDao.getByPrimaryKey(componentId)
  //   if (comp === null) {
  //     throw new AramComponentNotFoundError(`内置组件不存在: componentId=${componentId}`)
  //   }
  //   if (comp.status === AramStatusEnum.Inactive) {
  //     throw new AramComponentNotFoundError(`内置组件已下线: componentId=${componentId}`)
  //   }
  //   return comp
  // }

  private async getActiveBuiltinComponentByName(componentName: string) {
    const comp = await this.maraBuiltinComponentDao.getByComponentName(componentName)
    if (comp === null) {
      throw new AramComponentNotFoundError(`内置组件不存在: componentName=${componentName}`)
    }
    if (comp.status === AramStatusEnum.Inactive) {
      throw new AramComponentNotFoundError(`内置组件已下线: componentName=${componentName}`)
    }
    return comp
  }
}
