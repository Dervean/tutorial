import { MemberDAO } from '~/aram-base/dao/member-dao'
import { PermissionBuilder, RoleTypeEnum } from '~/aram-base/model/permission/permission-builder'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramNoProjectPermissionError } from '~/aram-lib/model/aram-error/forbidden/aram-no-project-permission-error'
import { AramMemberNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-member-not-found-error'
import { AramModifyProjectPermissionRefusedError } from '~/aram-lib/model/aram-error/forbidden/aram-modify-project-permission-refused-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramUserNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-user-not-found-error'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { AramMember } from '~/aram-base/entities/aram-member'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { DateHelper } from '~/aram-lib/helper/date-helper'

export class MemberService extends AbstractServiceBase {
  private memberDao: MemberDAO

  constructor() {
    super()
    this.memberDao = new MemberDAO()
  }

  /** 获取项目权限列表 */
  public async searchRoleListByProjectId(projectId: AramIdType) {
    const memberList = await this.memberDao.getAllByProjectId(projectId)
    const userNameList = memberList.map(e => e.userName)
    const orgInfoList = await AramServiceContext.engine.org().queryByEmpMisList(userNameList)

    return memberList.map(e => {
      const { userName, permission } = e
      const role = new PermissionBuilder(permission).permission2role()
      try {
        const { name: displayName } = orgInfoList.find(p => p.mis == userName)
        return { userName, displayName, role }
      } catch (error) {
        AramLogger.logError(`[internal error] userName not found, userName=${userName}`)
        return { userName, role, displayName: null }
      }
    })
  }

  public async getAllAdminByProjectId(projectId: AramIdType) {
    const permission = PermissionBuilder.role2permission(RoleTypeEnum.Admin)
    const memberList = await this.getAllByProjectIdAndPermission(projectId, permission)
    const userNameList = memberList.map(e => e.userName)
    const orgInfoList = await AramServiceContext.engine.org().queryByEmpMisList(userNameList)

    return memberList.map(e => {
      const { userName } = e
      try {
        const { name: displayName } = orgInfoList.find(p => p.mis == userName)
        return { userName, displayName }
      } catch (error) {
        AramLogger.logError(`[internal error] userName not found, userName=${userName}`)
        return { userName, displayName: null }
      }
    })
  }

  /**
   * 1. 添加项目个人权限
   * 2. 编辑项目个人权限
   * @param projectId
   * @param targetUserName 被修改人 mis
   * @param role
   */
  public async insertOrUpdateMemberRole(projectId: AramIdType, targetUserName: AramUserNameType, role: RoleTypeEnum) {
    await this.preCheckModifyPermission(projectId, targetUserName)

    const permission = new PermissionBuilder(role).getPermission()
    /** 查找是否有已存在角色条目 */
    const member = await this.memberDao.getByProjectIdAndUserName(projectId, targetUserName)

    if (member !== null) {
      const updated = new AramMember()
      updated.memberId = member.memberId
      updated.permission = permission
      if (member.isDeleted === AramStatusEnum.Inactive) {
        updated.isDeleted = AramStatusEnum.Active
        updated.joinTime = DateHelper.getCurrentDatetime()
      }
      return this.memberDao.updateByPrimaryKey(member.memberId, updated)
    }

    const memberItem = new AramMember()
    memberItem.projectId = projectId
    memberItem.userName = targetUserName
    memberItem.permission = permission
    return this.memberDao.insert(memberItem)
  }

  /**
   * 删除个人项目权限
   * @param projectId
   * @param targetUserName 被修改人 mis
   */
  public async deleteMemberRole(projectId: AramIdType, targetUserName: AramUserNameType) {
    await this.preCheckModifyPermission(projectId, targetUserName)

    /** 查找是否有已存在角色条目 */
    const memberItem = await this.memberDao.getByProjectIdAndUserName(projectId, targetUserName)
    if (!memberItem) {
      throw new AramMemberNotFoundError(`项目成员不存在: projectId=${projectId}, userName=${targetUserName}`)
    }

    await this.memberDao.deleteByPrimaryKey(memberItem.memberId)
  }

  /**
   * 校验 用户 拥有项目 管理员 权限
   * @param projectId
   */
  public async verifyProjectAdminPermission(projectId: AramIdType, user?: AramUserNameType) {
    const { userName } = await NestEventHelper.user()
    const pb = await this.getUserPermission(projectId, user || userName)
    const hasRight = pb.checkAdminPermission()
    if (!hasRight) {
      throw new AramNoProjectPermissionError(`项目管理员权限校验不通过: projectId=${projectId}`)
    }
  }

  /**
   * 校验 用户 拥有项目 访客 权限
   * @param projectId
   */
  public async verifyProjectVisitorPermission(projectId: AramIdType, user?: AramUserNameType) {
    const { userName } = await NestEventHelper.user()
    const pb = await this.getUserPermission(projectId, user || userName)
    const hasRight = pb.checkVisitorPermission()
    if (!hasRight) {
      throw new AramNoProjectPermissionError(`项目访客权限校验不通过: projectId=${projectId}`)
    }
  }

  /**
   * 校验 用户 拥有项目 编辑 权限
   * @param projectId
   */
  public async verifyProjectEditorPermission(projectId: AramIdType, user?: AramUserNameType) {
    const { userName } = await NestEventHelper.user()
    const pb = await this.getUserPermission(projectId, user || userName)
    const hasRight = pb.checkEditorPermission()
    if (!hasRight) {
      throw new AramNoProjectPermissionError(`项目编辑权限校验不通过: projectId=${projectId}`)
    }
  }

  public async getAllByUserName(user: AramUserNameType) {
    return this.memberDao.getAllByUserName(user)
  }

  public async getAllByProjectIdAndPermission(projectId: AramIdType, permission: AramPermissionType) {
    return this.memberDao.getAllByProjectIdAndPermission(projectId, permission)
  }

  public async getByProjectIdAndUserName(projectId: AramIdType, operatorUserName: AramUserNameType) {
    return this.memberDao.getByProjectIdAndUserName(projectId, operatorUserName)
  }

  /**
   * 查询 用户 项目权限
   * @param projectId
   * @returns
   */
  public async getUserPermission(projectId: AramIdType, user: AramUserNameType) {
    const { isAdministrator } = await NestEventHelper.user()
    if (isAdministrator) {
      const pb = new PermissionBuilder()
      pb.grantAdminPermission()
      return pb
    }
    const [projectItem, memberItem] = await Promise.all([
      this.aramEngine.project().getActiveProject(projectId),
      this.memberDao.getByProjectIdAndUserName(projectId, user),
    ])
    const { isPrivate } = projectItem
    const pb = new PermissionBuilder(memberItem?.permission)
    if (!isPrivate) {
      pb.grantViewPermission()
    }
    return pb
  }

  /**
   * 增删改权限时的前置校验
   * @param projectId
   * @param targetUserName 被修改人 mis
   */
  private async preCheckModifyPermission(projectId: AramIdType, targetUserName: AramUserNameType) {
    const { userName: operatorUserName } = await NestEventHelper.user()
    /** 前置校验 */
    const [empInfo, _] = await Promise.all([
      AramServiceContext.engine.org().queryByEmpMis(targetUserName),
      this.verifyProjectAdminPermission(projectId, operatorUserName),
    ])
    if (!empInfo) {
      throw new AramUserNotFoundError(`找不到指定用户: userName=${targetUserName}`)
    }
    /** 不能修改自己的权限 */
    if (targetUserName === operatorUserName) {
      throw new AramModifyProjectPermissionRefusedError(`无法编辑自己的权限: targetUserName=${targetUserName}`)
    }
  }
}
