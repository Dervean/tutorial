import { SchemaMemberDao } from '~/aram-base/dao/schema-member-dao'
import { PermissionBuilder, RoleTypeEnum } from '~/aram-base/model/permission/permission-builder'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramNoSchemaPermissionError } from '~/aram-lib/model/aram-error/forbidden/aram-no-schema-permission-error'
import { AramMemberNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-member-not-found-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramUserNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-user-not-found-error'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { DateHelper } from '~/aram-lib/helper/date-helper'
import { AramSchemaMember } from '~/aram-base/entities/aram-schema-member'

export class SchemaMemberService extends AbstractServiceBase {
  private schemaMemberDao: SchemaMemberDao

  constructor() {
    super()
    this.schemaMemberDao = new SchemaMemberDao()
  }

  // 获取配置权限列表
  public async searchRoleListBySchemaId(schemaId: AramIdType) {
    const memberList = await this.schemaMemberDao.getAllBySchemaId(schemaId)
    const userNameList = memberList.map(e => e.userName)
    const orgInfoList = await AramServiceContext.engine.org().queryByEmpMisList(userNameList)

    return memberList.map(e => {
      const { userName, permission } = e
      const role = new PermissionBuilder(permission).permission2role()
      try {
        const { name: displayName } = orgInfoList.find(p => p.mis == userName)
        return { userName, displayName, role }
      } catch (error) {
        AramLogger.logError(`[internal error] userName not found, userName=${userName}`)
        return { userName, role, displayName: null }
      }
    })
  }

  // 添加编辑配置权限
  public async insertOrUpdateSchemaMemberRole(schemaId: AramIdType, targetUserName: AramUserNameType, role: RoleTypeEnum) {
    const { projectId } = await this.aramEngine.schema().getActiveSchema(schemaId)
    await this.preCheckModifyPermission(schemaId, targetUserName)

    const permission = new PermissionBuilder(role).getPermission()
    const member = await this.schemaMemberDao.getBySchemaIdAndUserName(schemaId, targetUserName)

    if (member !== null) {
      const updated = new AramSchemaMember()
      updated.memberId = member.memberId
      updated.permission = permission
      if (member.status === AramStatusEnum.Inactive) {
        updated.status = AramStatusEnum.Active
        updated.joinTime = DateHelper.getCurrentDatetime()
      }
      return this.schemaMemberDao.updateByPrimaryKey(member.memberId, updated)
    }

    const schemaMemberItem = new AramSchemaMember()
    schemaMemberItem.schemaId = schemaId
    schemaMemberItem.projectId = projectId
    schemaMemberItem.userName = targetUserName
    schemaMemberItem.permission = permission

    return this.schemaMemberDao.insert(schemaMemberItem)
  }

  // 删除配置权限
  public async deleteSchemaMemberRole(schemaId: AramIdType, targetUserName: AramUserNameType) {
    await this.preCheckModifyPermission(schemaId, targetUserName)
    // 查看是否已存在角色条目
    const memberItem = await this.schemaMemberDao.getBySchemaIdAndUserName(schemaId, targetUserName)
    if (!memberItem) {
      throw new AramMemberNotFoundError(`项目成员不存在: schemaId=${schemaId}, userName=${targetUserName}`)
    }
    await this.schemaMemberDao.deleteByPrimaryKey(memberItem.memberId)
  }

  private async getAllBySchemaIdAndPermission(schemaId: AramIdType, permission: AramPermissionType) {
    return this.schemaMemberDao.getAllBySchemaIdAndPermission(schemaId, permission)
  }

  public async getAllAdminBySchemaId(schemaId: AramIdType) {
    const schemaItem = await this.aramEngine.schema().getActiveSchema(schemaId)
    const permission = PermissionBuilder.role2permission(RoleTypeEnum.Admin)
    const [projectMemberList, schemaMemberList] = await Promise.all([
      this.aramEngine.member().getAllByProjectIdAndPermission(schemaItem?.projectId, permission),
      this.getAllBySchemaIdAndPermission(schemaId, permission),
    ])
    const userNameList = [...projectMemberList, ...schemaMemberList]
      .map(e => e.userName)
      .filter((name, idx, arr) => {
        return arr.indexOf(name, 0) === idx
      })
    const orgInfoList = await AramServiceContext.engine.org().queryByEmpMisList(userNameList)
    return userNameList.map(userName => {
      try {
        const { name: displayName } = orgInfoList.find(p => p.mis == userName)
        return { userName, displayName }
      } catch (error) {
        AramLogger.logError(`[internal error] userName not found, userName=${userName}`)
        return { userName, displayName: null }
      }
    })
  }

  /**
   * 校验 用户 拥有配置 管理员 权限
   * @param schemaId
   */
  public async verifySchemaAdminPermission(schemaId: AramIdType, user?: AramUserNameType) {
    const { userName } = await NestEventHelper.user()
    const pb = await this.getUserPermission(schemaId, user || userName)
    const hasRight = pb.checkAdminPermission()
    if (!hasRight) {
      throw new AramNoSchemaPermissionError(`配置管理员权限校验不通过: schemaId=${schemaId}, user=${user || userName}`)
    }
  }

  /**
   * 校验 用户 拥有配置 访客 权限
   * @param schemaId
   */
  public async verifySchemaVisitorPermission(schemaId: AramIdType, user?: AramUserNameType) {
    const { userName } = await NestEventHelper.user()
    const pb = await this.getUserPermission(schemaId, user || userName)
    const hasRight = pb.checkVisitorPermission()
    if (!hasRight) {
      throw new AramNoSchemaPermissionError(`配置访客权限校验不通过: schemaId=${schemaId}, user=${user || userName}`)
    }
  }

  /**
   * 校验 用户 拥有配置 编辑 权限
   * @param schemaId
   */
  public async verifySchemaEditorPermission(schemaId: AramIdType, user?: AramUserNameType) {
    const { userName } = await NestEventHelper.user()
    const pb = await this.getUserPermission(schemaId, user || userName)
    const hasRight = pb.checkEditorPermission()
    if (!hasRight) {
      throw new AramNoSchemaPermissionError(`配置编辑权限校验不通过: schemaId=${schemaId}, user=${user || userName}`)
    }
  }

  /**
   * 查询 用户 配置权限
   * @param schemaId
   * @returns
   */
  private async getUserPermission(schemaId: AramIdType, user: AramUserNameType) {
    const { isAdministrator } = await NestEventHelper.user()
    if (isAdministrator) {
      const pb = new PermissionBuilder()
      pb.grantAdminPermission()
      return pb
    }
    const schemaItem = await this.aramEngine.schema().getActiveSchema(schemaId)
    const [projectPermission, schemaMemberItem] = await Promise.all([
      this.aramEngine.member().getUserPermission(schemaItem?.projectId, user),
      this.schemaMemberDao.getBySchemaIdAndUserName(schemaId, user),
    ])
    const pb = new PermissionBuilder(schemaMemberItem?.permission | projectPermission.getPermission())

    return pb
  }

  // 前置校验
  private async preCheckModifyPermission(schemaId: AramIdType, targetUserName: AramUserNameType) {
    const { userName: operatorUserName } = await NestEventHelper.user()
    const [empInfo, _] = await Promise.all([
      AramServiceContext.engine.org().queryByEmpMis(targetUserName),
      this.verifySchemaAdminPermission(schemaId, operatorUserName),
    ])
    if (!empInfo) {
      throw new AramUserNotFoundError(`找不到指定用户: userName=${targetUserName}`)
    }
  }
}
