import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { ModuleDAO } from '~/aram-base/dao/module-dao'
import { AramModuleNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-module-not-found-error'
import { AramPage, AramPageParams } from '~/aram-lib/model/aram-page'
import { AramModule } from '~/aram-base/entities/aram-module'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class ModuleService extends AbstractServiceBase {
  private moduleDao: ModuleDAO

  constructor() {
    super()
    this.moduleDao = new ModuleDAO()
  }

  /** 返回模块列表 分页 */
  async searchModuleList(projectId: AramIdType, keyword: string, pageParams: AramPageParams) {
    let pagedResult: AramPage<AramModule>
    if (this.aramEngine.isAramId(keyword)) {
      pagedResult = await this.searchByProjectIdAndFuzzyModuleId(projectId, +keyword, pageParams)
    } else if (keyword && keyword.length) {
      /** moduleName 不能只包含数字 */
      pagedResult = await this.searchByProjectIdAndFuzzyModuleName(projectId, keyword, pageParams)
    } else {
      /** 查询参数为空 */
      pagedResult = await this.searchByProjectId(projectId, pageParams)
    }
    const list = pagedResult.getList()
    /** 向 pageResult 加入 schema 数目 */
    const moduleIds = list.map(e => e.moduleId)
    const schemaCountGrp = await this.aramEngine.schema().countByModuleIdList(moduleIds)

    const listWithCount = [] as (Partial<AramModule> & { count: number })[]
    list.map(e => {
      const { moduleId } = e
      const { count = 0 } = schemaCountGrp.find(grp => grp.moduleId === moduleId) || {}
      listWithCount.push({ count, ...e })
    })
    pagedResult.setList(listWithCount)
    return pagedResult as AramPage<AramModule & { count: number }>
  }

  /** 返回全部模块列表 不分页 */
  async getModuleListByProjectId(projectId: AramIdType, keyword: string) {
    /** 返回全部模块(暂无搜索功能) */
    return this.moduleDao.getAllByProjectId(projectId)
  }

  public async getModule(moduleId: AramIdType) {
    return this.moduleDao.getByPrimaryKey(moduleId)
  }

  public async getModules(moduleIds: AramIdType[]) {
    return this.moduleDao.getByPrimaryKeyList(moduleIds)
  }

  public async getActiveModule(moduleId: AramIdType) {
    const module = await this.getModule(moduleId)
    if (module === null) {
      throw new AramModuleNotFoundError(`模块不存在: moduleId=${moduleId}`)
    }
    if (module.isDeleted) {
      throw new AramModuleNotFoundError(`模块已下线: moduleId=${moduleId}`)
    }
    return module
  }

  /** 创建模块 */
  public async createModule(params: { projectId: AramIdType; moduleName: string; moduleDesc?: string }) {
    const { userName } = await NestEventHelper.user()
    const { projectId, moduleName, moduleDesc = null } = params
    /**
     * 校验 project id 是否合法
     * 校验是否拥有项目编辑权限
     */
    const [projectItem, _] = await Promise.all([
      this.aramEngine.project().getActiveProject(projectId),
      this.aramEngine.member().verifyProjectEditorPermission(projectId),
    ])
    const { appUid } = projectItem

    const target = new AramModule()
    target.projectId = projectId
    target.appUid = appUid
    target.moduleName = moduleName
    target.createdBy = userName
    target.description = moduleDesc
    const data = await this.moduleDao.insert(target)

    const ret = data.identifiers[0] as { moduleId: string | number }
    return { ...ret }
  }

  /** 删除模块 */
  public async dropModule(params: { moduleId: AramIdType }) {
    const { userName } = await NestEventHelper.user()
    const { moduleId } = params
    /** 查找项目 id */
    const moduleItem = await this.getActiveModule(moduleId)
    const { projectId } = moduleItem
    /** 校验是否拥有项目管理员权限 */
    await this.aramEngine.member().verifyProjectAdminPermission(projectId)

    return this.moduleDao.deleteByPrimaryKey(moduleId, userName)
  }

  /** 编辑模块 */
  public async updateModuleInfo(params: { moduleId: AramIdType; moduleName?: string; moduleDesc?: string }) {
    const { userName } = await NestEventHelper.user()
    const { moduleDesc, moduleName } = params
    const { moduleId } = params
    /** 查找项目 id */
    const moduleItem = await this.getActiveModule(moduleId)
    const { projectId } = moduleItem
    /** 校验是否拥有项目编辑权限 */
    await this.aramEngine.member().verifyProjectEditorPermission(projectId)

    return this.moduleDao.updateByPrimaryKey(moduleId, {
      updatedBy: userName,
      ...(moduleName ? { moduleName } : {}),
      ...(moduleDesc ? { description: moduleDesc } : {}),
    })
  }

  private async searchByProjectIdAndFuzzyModuleId(projectId: AramIdType, fuzzyModuleId: AramIdType, pageParams: AramPageParams) {
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.moduleDao.searchByFuzzyModuleIdAndProjectId(fuzzyModuleId, projectId, offset, limit)

    const page = new AramPage<AramModule>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }

  private async searchByProjectIdAndFuzzyModuleName(projectId: AramIdType, fuzzyModuleName: string, pageParams: AramPageParams) {
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.moduleDao.searchByFuzzyModuleNameAndProjectId(fuzzyModuleName, projectId, offset, limit)

    const page = new AramPage<AramModule>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }

  private async searchByProjectId(projectId: AramIdType, pageParams: AramPageParams) {
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.moduleDao.searchByProjectId(projectId, offset, limit)

    const page = new AramPage<AramModule>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }
}
