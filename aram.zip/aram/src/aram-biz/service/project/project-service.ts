import { ProjectDAO } from '~/aram-base/dao/project-dao'
import { PermissionBuilder, RoleTypeEnum } from '~/aram-base/model/permission/permission-builder'
import { AramPage, AramPageParams } from '~/aram-lib/model/aram-page'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramProject } from '~/aram-base/entities/aram-project'
import { AramMember } from '~/aram-base/entities/aram-member'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { AramProjectNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-project-not-found-error'

export class ProjectService extends AbstractServiceBase {
  private projectDao: ProjectDAO

  constructor() {
    super()
    this.projectDao = new ProjectDAO()
  }

  /**
   * 搜索项目列表
   * @param params
   *  - keyword 模糊搜索关键词
   *  - searchPublic 结果中是否包含公开项目
   * @returns
   */
  public searchProjectList(keyword: string, pageParams: AramPageParams, searchPublic: boolean, appUid: AramUidType) {
    if (this.aramEngine.isAramId(keyword)) return this.search(pageParams, { searchPublicFlag: searchPublic, appUid, fuzzyProjectId: +keyword })
    /** projectName 不能只包含数字 */
    if (keyword && keyword.length) return this.search(pageParams, { searchPublicFlag: searchPublic, appUid, fuzzyProjectName: keyword })
    /** 查询参数为空 */
    return this.search(pageParams, { searchPublicFlag: searchPublic, appUid })
  }

  /** 创建项目 */
  public async createProject(project: AramProject, creator: AramUserNameType) {
    // prettier-ignore
    await Promise.all([
      AramServiceContext.engine.org().queryByEmpMis(creator),
      this.aramEngine.application().getActiveApplication(project.appUid),
    ])
    project.createdBy = creator
    /** 创建者拥有所有权限 */
    const permissionBuiler = new PermissionBuilder(RoleTypeEnum.Admin)
    const admin = new AramMember()
    admin.userName = creator
    admin.permission = permissionBuiler.getPermission()
    const projectId = await this.projectDao.insert(project, admin)
    return { projectId }
  }

  /** 编辑项目 */
  public async updateProjectInfo(projectId: AramIdType, project: AramProject) {
    /** 校验 是否拥有 项目编辑 权限 */
    await AramServiceContext.engine.member().verifyProjectEditorPermission(projectId)

    return this.projectDao.updateByPrimaryKey(projectId, project)
  }

  /** 删除项目 */
  public async offlineProject(projectId: AramIdType) {
    const { userName } = await NestEventHelper.user()
    /** 校验 是否拥有 项目管理员 权限 */
    // prettier-ignore
    await Promise.all([
      AramServiceContext.engine.member().verifyProjectAdminPermission(projectId),
      this.getActiveProject(projectId),
    ])

    return this.projectDao.deleteByPrimaryKey(projectId, userName)
  }

  public async getProject(projectId: AramIdType) {
    return this.projectDao.getByPrimaryKey(projectId)
  }

  public async getActiveProject(projectId: AramIdType) {
    const project = await this.getProject(projectId)
    if (project === null) {
      throw new AramProjectNotFoundError(`项目不存在: projectId=${projectId}`)
    }
    if (project.isDeleted) {
      throw new AramProjectNotFoundError(`项目已下线: projectId=${projectId}`)
    }
    return project
  }

  private async search(
    pageParams: AramPageParams,
    filter: {
      appUid?: AramUidType
      fuzzyProjectName?: string
      searchPublicFlag?: boolean
      fuzzyProjectId?: AramIdType
    },
  ) {
    const { userName, isAdministrator } = await NestEventHelper.user()
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const page = new AramPage<AramProject>()
    if (isAdministrator) {
      const { rows, totalCnt } = await this.projectDao.search(offset, limit, { ...filter })
      page.setList(rows)
      page.setTotalCnt(totalCnt)
    } else {
      const memberList = await this.aramEngine.member().getAllByUserName(userName)
      const projectIdList = memberList.map(e => e.projectId)
      const { rows, totalCnt } = await this.projectDao.search(offset, limit, { projectIdList, ...filter })
      page.setList(rows)
      page.setTotalCnt(totalCnt)
    }

    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }
}
