import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class ScaffordService extends AbstractServiceBase {
  constructor() {
    super()
  }

  async getActiveSchemaList(projectId: AramIdType) {
    const schemaList = await this.aramEngine.schema().getSchemaList(projectId)
    const activeSchemaList = schemaList.filter(schema => schema && !schema.isDeleted)
    if (activeSchemaList.length === 0) {
      return []
    }
    const schemaIds = activeSchemaList.map(e => e.schemaId)
    const schemaLatestVersionGrp = await this.aramEngine.schemaVersion().getAllLatestVersionBySchemaIdList(schemaIds)
    for (const item of activeSchemaList) {
      const { version = null } = schemaLatestVersionGrp.find(itm => itm.schemaId === item.schemaId) || {}
      item.version = version
    }
    return activeSchemaList
  }
}
