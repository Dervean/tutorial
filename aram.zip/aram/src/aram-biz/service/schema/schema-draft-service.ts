import { SchemaDraftDAO } from '~/aram-base/dao/schema-draft-dao'
import { AramSchemaDraftAlreadyExistedError } from '~/aram-lib/model/aram-error/forbidden/aram-schema-draft-already-existed-error'
import { AramNoSchemaDraftPermissionError } from '~/aram-lib/model/aram-error/forbidden/aram-no-schema-draft-permission-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { CDNSourceEnum, S3StreamService } from '~/aram-out/mss/s3-stream-service'
import { AramSchemaDraft } from '~/aram-base/entities/aram-schema-draft'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class SchemaDraftService extends AbstractServiceBase {
  private schemaDraftDAO: SchemaDraftDAO

  constructor() {
    super()
    this.schemaDraftDAO = new SchemaDraftDAO()
  }

  /** 创建配置草稿 */
  async createSchemaDraft(schemaId: AramIdType) {
    const { userName, displayName } = await NestEventHelper.user()
    /** 校验 schemaId 是否合法 */
    const [schemaItem, latestSchemaVersionItem, schemaDraftItem] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.aramEngine.schemaVersion().getLastestVersionBySchemaId(schemaId),
      this.schemaDraftDAO.getBySchemaIdAndUserName(schemaId, userName),
    ])
    if (schemaDraftItem) {
      throw new AramSchemaDraftAlreadyExistedError(`配置草稿已存在: schemaId=${schemaId}, userName=${userName}`)
    }

    const { projectId, moduleId, appUid } = schemaItem
    await this.aramEngine.schemaMember().verifySchemaVisitorPermission(schemaId)

    /**
     * 有版本 从最新版本 checkout
     * 无版本 返回 null
     */
    const { url, version: syncVersion } = latestSchemaVersionItem || {}
    let schema: AramJsonType
    try {
      const client = await S3StreamService.getInstance(appUid, CDNSourceEnum.BJ)
      schema = await client.queryJson(url)
    } catch (error) {
      schema = null
    }

    const draft = new AramSchemaDraft()
    draft.projectId = projectId
    draft.moduleId = moduleId
    draft.schemaId = schemaId
    draft.userName = userName
    draft.schema = schema
    draft.schemaName = `${displayName}的草稿`
    draft.syncVersion = syncVersion || null

    await this.schemaDraftDAO.insert(draft)

    return draft
  }

  /** 获取配置草稿 */
  async getSchemaDraft(schemaId: AramIdType, user: AramUserNameType) {
    const [schemaVersionItem, draft] = await Promise.all([
      this.aramEngine.schemaVersion().getLastestVersionBySchemaId(schemaId),
      this.schemaDraftDAO.getBySchemaIdAndUserName(schemaId, user),
    ])
    if (draft === null) {
      /** 没有草稿 尝试创建草稿 */
      const newDraft = await this.createSchemaDraft(schemaId)
      newDraft.version = schemaVersionItem?.version || null
      return newDraft
    }
    draft.version = schemaVersionItem?.version || null
    return draft
  }

  /** 草稿 checkout */
  async checkoutSchemaDraft(schemaId: AramIdType, user: AramUserNameType) {
    const draft = await this.getSchemaDraft(schemaId, user)
    if (draft.syncVersion === null) {
      return draft
    }
    if (+draft.syncVersion === +draft.version) {
      return draft
    }
    const [prodVersionItem, syncVersionItem] = await Promise.all([
      this.aramEngine.schemaVersion().getSchemaVersion(schemaId, draft.version),
      this.aramEngine.schemaVersion().getSchemaVersion(schemaId, draft.syncVersion),
    ])
    const draftJsonStr = JSON.stringify(draft.schema)
    const syncJsonStr = JSON.stringify(syncVersionItem.schema)
    if (draftJsonStr === syncJsonStr) {
      const target = new AramSchemaDraft()
      target.schema = prodVersionItem.schema
      target.syncVersion = prodVersionItem.version

      await this.updateDraft(draft.schemaDraftId, target)
    }
    return this.getSchemaDraft(schemaId, user)
  }

  /** 保存草稿 */
  async updateSchemaDraft(schemaId: AramIdType, draft: AramSchemaDraft, sync: boolean) {
    const { userName } = await NestEventHelper.user()
    const [schemaDraftItem, schemaVersionItem] = await Promise.all([
      this.getSchemaDraft(schemaId, userName),
      this.aramEngine.schemaVersion().getLastestVersionBySchemaId(schemaId),
    ])

    const { schemaDraftId, userName: schemaDraftOwnerId } = schemaDraftItem
    if (schemaDraftOwnerId != userName) {
      throw new AramNoSchemaDraftPermissionError(`没有草稿的编辑权限: schemaId=${schemaId}, userName=${userName}`)
    }

    await this.aramEngine.schemaMember().verifySchemaVisitorPermission(schemaId)

    if (sync) {
      draft.syncVersion = +schemaVersionItem?.version || null
    }

    return this.updateDraft(schemaDraftId, draft)
  }

  async updateDraft(schemaId: AramIdType, draft: AramSchemaDraft) {
    return this.schemaDraftDAO.updateByPrimaryKey(schemaId, draft)
  }
}
