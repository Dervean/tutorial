import { SchemaDAO } from '~/aram-base/dao/schema-dao'
import { AramPage, AramPageParams } from '~/aram-lib/model/aram-page'
import { AramSchemaNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-schema-not-found-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AramZebraError } from '~/aram-lib/model/aram-error/server/aram-zebra-error'
import { AramSchema } from '~/aram-base/entities/aram-schema'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'

export class SchemaService extends AbstractServiceBase {
  private schemaDao: SchemaDAO

  constructor() {
    super()
    this.schemaDao = new SchemaDAO()
  }

  /** 创建配置 */
  async createSchema(parmas: Pick<AramSchema, 'moduleId' | 'schemaName' | 'schemaUid' | 'description' | 'ext'>) {
    const { userName } = await NestEventHelper.user()
    const { schemaUid, moduleId, schemaName, description = null, ext = null } = parmas
    /** 校验 module id 是否合法 */
    const moduleItem = await this.aramEngine.module().getActiveModule(moduleId)

    const { projectId, appUid } = moduleItem
    await this.aramEngine.member().verifyProjectEditorPermission(projectId)

    /** @todo 暂时使用代码卡控唯一性, 后续所有 schemaUid 补齐后添加唯一索引, 并删除下列代码 */
    const schemaUniqueItem = await this.schemaDao.getByProjectIdAndSchemaUid(projectId, schemaUid)
    if (schemaUniqueItem) {
      throw new AramZebraError(`schemaUid 重复: projectId=${projectId}, schemaUid=${schemaUid}`)
    }

    const schema = new AramSchema()
    schema.schemaUid = schemaUid
    schema.projectId = projectId
    schema.appUid = appUid
    schema.moduleId = moduleId
    schema.schemaName = schemaName
    schema.createdBy = userName
    schema.description = description
    schema.ext = ext
    const data = await this.schemaDao.insert(schema)
    const ret = data.identifiers[0] as { schemaId: string | number }
    return { ...ret }
  }

  /** 删除配置 */
  async dropSchema(schemaId: AramIdType) {
    const { userName } = await NestEventHelper.user()

    /** 管理员权限校验 */
    const schemaItem = await this.schemaDao.getByPrimaryKey(schemaId)
    if (!schemaItem || schemaItem.isDeleted) {
      throw new AramSchemaNotFoundError(`schema 不存在: schemaId=${schemaId}`)
    }
    const { projectId } = schemaItem
    await this.aramEngine.member().verifyProjectAdminPermission(projectId)

    return this.schemaDao.deleteByPrimaryKey(schemaId, userName)
  }

  /**
   * 搜索配置列表，可以通过 projectId 或者 moduleId 搜索
   * @param params
   * @returns
   */
  async searchSchemaList(params: { projectId?: AramIdType; moduleId?: AramIdType; keyword: string; pageParams: AramPageParams }) {
    const { projectId, moduleId, keyword, pageParams } = params

    /** 读权限校验 */
    let projectIdForVerification = projectId
    if (!projectIdForVerification && moduleId) {
      const moduleItem = await this.aramEngine.module().getActiveModule(moduleId)
      projectIdForVerification = moduleItem.projectId
    }
    if (!projectIdForVerification) {
      /** should not be here */
      throw new Error('something weird has happened')
    }
    await this.aramEngine.member().verifyProjectVisitorPermission(projectIdForVerification)

    let pagedResult: AramPage<AramSchema>
    if (this.aramEngine.isAramId(keyword) && moduleId) {
      pagedResult = await this.search(pageParams, { moduleId, fuzzySchemaId: +keyword })
    } else if (this.aramEngine.isAramId(keyword) && projectId) {
      pagedResult = await this.search(pageParams, { projectId, fuzzySchemaId: +keyword })
    } else if (keyword && keyword.length && moduleId) {
      /** schemaName 不能只包含数字 */
      pagedResult = await this.search(pageParams, { moduleId, fuzzySchemaName: keyword })
    } else if (keyword && keyword.length && projectId) {
      pagedResult = await this.search(pageParams, { projectId, fuzzySchemaName: keyword })
    } else if (moduleId) {
      /** keyword 为空 */
      pagedResult = await this.search(pageParams, { moduleId })
    } else if (projectId) {
      /** keyword 为空 */
      pagedResult = await this.search(pageParams, { projectId })
    } else {
      /** should not be here */
      throw new Error('something weird has happened')
    }

    const list = pagedResult.getList()
    /**
     * 向 pageResult 额外注入
     * 1. 最新版本
     * 2. 模块名称
     */
    const schemaIds = list.map(e => e.schemaId)
    const moduleIds = list.map(e => e.moduleId)
    const [schemaLatestVersionGrp, moduleGrp] = await Promise.all([
      this.aramEngine.schemaVersion().getAllLatestVersionBySchemaIdList(schemaIds),
      this.aramEngine.module().getModules(moduleIds),
    ])

    for (const item of list) {
      const { version = null, createTime = '', createdBy = '' } = schemaLatestVersionGrp.find(itm => itm.schemaId === item.schemaId) || {}
      const { moduleName = null } = moduleGrp.find(itm => itm.moduleId === item.moduleId) || {}
      item.moduleName = moduleName
      item.version = version
      item.publishBy = createdBy
      item.publishTime = createTime
    }
    pagedResult.setList(list)
    return pagedResult as AramPage<AramSchema>
  }

  async getActiveSchema(schemaId: AramIdType) {
    const schema = await this.schemaDao.getByPrimaryKey(schemaId)
    if (schema === null) {
      throw new AramSchemaNotFoundError(`配置不存在: schemaId=${schemaId}`)
    }
    if (schema && schema.isDeleted) {
      throw new AramSchemaNotFoundError(`配置已下线: schemaId=${schemaId}`)
    }
    return schema
  }

  async getSchemaList(projectId: AramIdType): Promise<AramSchema[]>
  async getSchemaList(schemaIdList: AramIdType[]): Promise<AramSchema[]>
  async getSchemaList(param: AramIdType[] | AramIdType) {
    if (Array.isArray(param)) {
      return this.schemaDao.getByPrimaryKeyList(param)
    }
    return this.schemaDao.getAllByProjectIdList([param])
  }

  /** 编辑配置基本信息 */
  async updateSchemaBasicInfo(schemaId: AramIdType, schema: AramSchema) {
    const schemaItem = await this.schemaDao.getByPrimaryKey(schemaId)
    if (!schemaItem || schemaItem.isDeleted) {
      throw new AramSchemaNotFoundError(`schema 不存在或已删除: schemaId=${schemaId}`)
    }
    await this.aramEngine.schemaMember().verifySchemaEditorPermission(schemaId)

    /** @todo 过渡 后续 schemaUid 补齐后删除该功能 */
    if (schema.schemaUid && schemaItem.schemaUid) {
      throw new AramZebraError(`配置标识已存在，不能更换: schemaUid=${schemaItem.schemaUid}`)
    }

    return this.schemaDao.updateByPrimaryKey(schemaId, schema)
  }

  async countByModuleIdList(moduleIds: AramIdType[]) {
    return this.schemaDao.countByModuleIdList(moduleIds)
  }

  private async search(
    pageParams: AramPageParams,
    filter: {
      moduleId?: AramIdType
      projectId?: AramIdType
      fuzzySchemaId?: AramIdType
      fuzzySchemaName?: string
    },
  ) {
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.schemaDao.search(offset, limit, filter)

    const page = new AramPage<AramSchema>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }
}
