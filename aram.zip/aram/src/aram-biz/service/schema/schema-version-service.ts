import assert from 'assert'
import { SchemaVersionDAO } from '~/aram-base/dao/schema-version-dao'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramPage, AramPageParams } from '~/aram-lib/model/aram-page'
import { AramSchemaVersionNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-schema-version-not-found-error'
import { AramInvalidRollbackTargetVersionError } from '~/aram-lib/model/aram-error/forbidden/aram-invalid-rollback-target-version-error'
import { AramS3Error } from '~/aram-lib/model/aram-error/server/aram-s3-error'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { SchemaBetaVersionDAO } from '~/aram-base/dao/schema-beta-version-dao'
import { CDNSourceEnum, S3StreamService } from '~/aram-out/mss/s3-stream-service'
import { LionClientService, LionConfigKeyEnum } from '~/aram-out/lion/lion-client-service'
import { AramSchemaBetaVersion } from '~/aram-base/entities/aram-schema-beta-version'
import { AramSchemaVersion } from '~/aram-base/entities/aram-schema-version'
import { AramServiceContext } from '~/aram-biz/context/aram-service-context'
import { AramSchemaVersionTypeEnum, AramPublishTypeEnum } from '~/aram-base/enum/common'
import { AbstractServiceBase } from '~/aram-biz/service/abstract-service-base'
import { AramSchemaDraft } from '~/aram-base/entities/aram-schema-draft'

type SchemaVersionType = Pick<AramSchemaVersion, 'createTime' | 'createdBy' | 'description' | 'type'> & {
  version: string
  rollbackFrom: SchemaVersionType
}
type SchemaBetaVersionType = Pick<AramSchemaBetaVersion, 'createTime' | 'createdBy' | 'description' | 'type'> & {
  version: string
  rollbackFrom: SchemaBetaVersionType
}

export class SchemaVersionService extends AbstractServiceBase {
  private schemaVersionDao: SchemaVersionDAO
  private schemaBetaVersionDao: SchemaBetaVersionDAO

  constructor() {
    super()
    this.schemaVersionDao = new SchemaVersionDAO()
    this.schemaBetaVersionDao = new SchemaBetaVersionDAO()
  }

  /** 转换前端返回值 */
  public static transformer = {
    versionListItem: function (versionItem: Partial<AramSchemaVersion>): SchemaVersionType {
      if (versionItem === null) return null
      const { version: verNum, createdBy, type, description, rollbackFrom, createTime } = versionItem
      return {
        version: AramSchemaVersion.version2str(verNum),
        createTime,
        createdBy,
        type,
        description,
        rollbackFrom: SchemaVersionService.transformer.versionListItem(rollbackFrom),
      }
    },
    betaVersionListItem: function (versionItem: Partial<AramSchemaBetaVersion>): SchemaBetaVersionType {
      if (versionItem === null) return null
      const { version: verNum, betaVersion, createdBy, type, description, rollbackFrom, createTime } = versionItem
      return {
        version: AramSchemaBetaVersion.betaVersion2str(verNum, betaVersion),
        createTime,
        createdBy,
        type,
        description,
        rollbackFrom: SchemaVersionService.transformer.betaVersionListItem(rollbackFrom),
      }
    },
    betaVersionListItemV2: function (versionItem: Partial<AramSchemaBetaVersion>): SchemaBetaVersionType {
      if (versionItem === null) return null
      const { version: verNum, betaVersion, createdBy, type, description, rollbackFrom, createTime } = versionItem
      return {
        version: AramSchemaBetaVersion.betaVersion2strV2(verNum, betaVersion),
        createTime,
        createdBy,
        type,
        description,
        rollbackFrom: SchemaVersionService.transformer.betaVersionListItemV2(rollbackFrom),
      }
    },
  }

  /** 分页查询配置 prod 版本列表 */
  async searchSchemaVersionList(schemaId: AramIdType, operator: AramUserNameType, pageParams: AramPageParams) {
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.schemaVersionDao.searchSchemaVersionListBySchemaIdAndCreatedBy(schemaId, operator, offset, limit)
    const parsedRows = rows.map(e => SchemaVersionService.transformer.versionListItem(e))

    const page = new AramPage<SchemaVersionType>()
    page.setList(parsedRows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }

  /** 分页查询配置 beta 版本列表 */
  async searchSchemaBetaVersionList(schemaId: AramIdType, operator: AramUserNameType, pageParams: AramPageParams) {
    const { pageNum, pageSize } = pageParams
    const offset = AramPage.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const [schemaItem, whiteList, schemaBetaVersionList] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.CdnMigrationWhiteList),
      this.schemaBetaVersionDao.searchSchemaBetaVersionListBySchemaIdAndCreatedBy(schemaId, operator, offset, limit),
    ])
    const { projectId } = schemaItem
    const { rows, totalCnt } = schemaBetaVersionList
    let parsedRows
    if (whiteList.includes(+projectId)) {
      parsedRows = rows.map(e => SchemaVersionService.transformer.betaVersionListItem(e))
    } else {
      parsedRows = rows.map(e => SchemaVersionService.transformer.betaVersionListItemV2(e))
    }

    const page = new AramPage<SchemaBetaVersionType>()
    page.setList(parsedRows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }

  /**
   * 发布前预检查
   *  1. 检查是否发布过 beta 版本
   */
  async releasePrecheck(schemaId: AramIdType) {
    const { userName } = await NestEventHelper.user()

    const [schemaVersionItem, schemaBetaVersionItem] = await Promise.all([
      this.schemaVersionDao.getLastestVersionBySchemaId(schemaId),
      this.schemaBetaVersionDao.getLastestBetaVersionBySchemaId(schemaId),
    ])
    let betaVersionReleased = false

    const { version: verProd } = schemaVersionItem || {}
    const { version: verBeta } = schemaBetaVersionItem || {}

    if (verBeta && (!verProd || +verProd < +verBeta)) {
      const schemaBetaVersionItemList = await this.schemaBetaVersionDao.getAllByBySchemaIdAndVersion(schemaId, +verBeta || 1)
      betaVersionReleased = schemaBetaVersionItemList.some(e => e.createdBy === userName)
    }
    return {
      betaVersionReleased,
    }
  }

  public async createSchemaVersionPrecheck(schemaId: AramIdType) {
    const { userName } = await NestEventHelper.user()
    const [schemaItem, schemaDraftItem, activeOrder] = await Promise.all([
      AramServiceContext.engine.schema().getActiveSchema(schemaId),
      this.aramEngine.schemaDraft().getSchemaDraft(schemaId, userName),
      this.aramEngine.flowHistoryOrder().getActiveApplySchemaReleaseOrder(schemaId),
    ])
    if (activeOrder !== null) {
      throw new Error(`发布中: schemaId=${schemaId}, orderId=${activeOrder.orderId}`)
    }
    return schemaItem
  }

  /** 发布 prod 版本 */
  async createSchemaVersion(schemaId: AramIdType, schema: AramJsonType, description: string, user: AramUserNameType) {
    assert.ok(!!user, `操作用户不存在: user=${user}`)

    /** 校验 module id 是否合法 */
    const [schemaItem, latestSchemaVersionItem, schemaDraftItem, whiteList] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaVersionDao.getLastestVersionBySchemaId(schemaId),
      this.aramEngine.schemaDraft().getSchemaDraft(schemaId, user),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.CdnMigrationWhiteList),
    ])
    const { schemaDraftId } = schemaDraftItem
    /** 校验 是否拥有 项目权限 */
    const { projectId, moduleId, appUid, schemaUid } = schemaItem
    await AramServiceContext.engine.schemaMember().verifySchemaEditorPermission(schemaId, user)

    /** schema version */
    const latestVersion = +latestSchemaVersionItem?.version || 0
    const version = latestVersion + 1

    let pathVersion, pathLatestVersion

    /** @todo 后续下线白名单 */
    if (whiteList.includes(+projectId)) {
      /** 发布 S3, 同时更新 latest 版本 */
      const [s3pathVersion, s3pathLatestVersion] = await Promise.all([
        SchemaVersionDAO.toSchemaS3ProdURL(projectId, schemaId, version),
        SchemaVersionDAO.toSchemaS3ProdURL(projectId, schemaId, AramSchemaVersionTypeEnum.latest),
      ])
      pathVersion = s3pathVersion
      pathLatestVersion = s3pathLatestVersion
    } else {
      pathVersion = SchemaVersionDAO.toSchemaS3ProdURLV2(projectId, schemaUid, version)
      pathLatestVersion = SchemaVersionDAO.toSchemaS3ProdURLV2(projectId, schemaUid, AramSchemaVersionTypeEnum.latest)
    }

    const url = await this.releaseS3SchemaVersion(appUid, pathVersion, pathLatestVersion, schema)

    const schemaVersionItem = new AramSchemaVersion()
    schemaVersionItem.projectId = projectId
    schemaVersionItem.moduleId = moduleId
    schemaVersionItem.schemaId = schemaId
    schemaVersionItem.version = version
    schemaVersionItem.url = url
    schemaVersionItem.type = AramPublishTypeEnum.publish
    schemaVersionItem.description = description
    schemaVersionItem.rollbackFrom = null
    schemaVersionItem.createdBy = user

    const draft = new AramSchemaDraft()
    draft.syncVersion = version

    const [data, _] = await Promise.all([
      this.schemaVersionDao.insert(schemaVersionItem),
      this.aramEngine.schemaDraft().updateDraft(schemaDraftId, draft),
    ])

    const ret = data.identifiers[0] as { schemaVersionId: AramIdType }

    return { ...ret, version }
  }

  /** 发布 beta 版本 */
  async createSchemaBetaVersion(schemaId: AramIdType, schema: AramJsonType, description = null) {
    const { userName } = await NestEventHelper.user()

    /** 校验 schema 是否合法 */
    const [schemaItem, latestSchemaVersionItem, latestSchemaBetaVersionItem, whiteList] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaVersionDao.getLastestVersionBySchemaId(schemaId),
      this.schemaBetaVersionDao.getLastestBetaVersionBySchemaId(schemaId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.CdnMigrationWhiteList),
    ])

    /** 校验 是否拥有 项目权限 */
    const { projectId, moduleId, appUid, schemaUid } = schemaItem
    await AramServiceContext.engine.schemaMember().verifySchemaEditorPermission(schemaId)

    /** schema version */
    const latestVersion = +latestSchemaVersionItem?.version || 0
    const version = latestVersion + 1
    /** schema beta version */
    const lastBetaVersion = +latestSchemaBetaVersionItem?.version === version ? +latestSchemaBetaVersionItem?.betaVersion : 0
    const betaVersion = lastBetaVersion + 1

    let pathVersion, pathLatestVersion

    /** @todo 后续下线白名单 */
    if (whiteList.includes(+projectId)) {
      /** 发布 S3, 同时更新 latest 版本 */
      const [s3pathVersion, s3pathLatestVersion] = await Promise.all([
        SchemaBetaVersionDAO.toSchemaS3BetaURL(projectId, schemaId, version, betaVersion),
        SchemaBetaVersionDAO.toSchemaS3BetaURL(projectId, schemaId),
      ])
      pathVersion = s3pathVersion
      pathLatestVersion = s3pathLatestVersion
    } else {
      pathVersion = SchemaBetaVersionDAO.toSchemaS3BetaURLV2(projectId, schemaUid, version, betaVersion)
      pathLatestVersion = SchemaBetaVersionDAO.toSchemaS3BetaURLV2(projectId, schemaUid)
    }
    const url = await this.releaseS3SchemaVersion(appUid, pathVersion, pathLatestVersion, schema)

    const schemaBetaVersionItem = new AramSchemaBetaVersion()
    schemaBetaVersionItem.projectId = projectId
    schemaBetaVersionItem.moduleId = moduleId
    schemaBetaVersionItem.schemaId = schemaId
    schemaBetaVersionItem.version = version
    schemaBetaVersionItem.betaVersion = betaVersion
    schemaBetaVersionItem.url = url
    schemaBetaVersionItem.type = AramPublishTypeEnum.publish
    schemaBetaVersionItem.description = description
    schemaBetaVersionItem.rollbackFrom = null
    schemaBetaVersionItem.createdBy = userName

    const data = await this.schemaBetaVersionDao.insert(schemaBetaVersionItem)

    const ret = data.identifiers[0] as { schemaBetaVersionId: string | number }

    return { ...ret }
  }

  /** prod 配置回滚 */
  async rollbackSchemaVersion(schemaId: AramIdType, targetVersion: AramSchemaVersionType, description = null) {
    const { userName } = await NestEventHelper.user()
    /**
     * 校验 schemaId 是否存在
     * 校验 target 是否存在
     * 校验 target 是否等于 current
     * */
    const [schemaItem, targetSchemaVersionItem, latestSchemaVersionItem, whiteList] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaVersionDao.getBySchemaIdAndVersion(schemaId, targetVersion),
      this.schemaVersionDao.getLastestVersionBySchemaId(schemaId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.CdnMigrationWhiteList),
    ])
    if (!latestSchemaVersionItem) throw new AramSchemaVersionNotFoundError(`最新版本数据不存在: schemaId=${schemaId}`)
    if (!targetSchemaVersionItem) throw new AramSchemaVersionNotFoundError(`目标版本数据不存在: schemaId=${schemaId}`)
    if (targetSchemaVersionItem.schemaVersionId === latestSchemaVersionItem.schemaVersionId) {
      throw new AramInvalidRollbackTargetVersionError(`回滚目标版本不能与当前版本相同: schemaId=${schemaId}, targetVersion=${targetVersion}`)
    }

    /** 校验 是否拥有 项目权限 */
    const { projectId, moduleId } = targetSchemaVersionItem
    await AramServiceContext.engine.schemaMember().verifySchemaEditorPermission(schemaId)

    /**
     * 发布新 schema
     *  schema json = target json
     *  schema version = latest version + 1
     */
    /** schema */
    const { url: urlSource } = targetSchemaVersionItem
    const { schemaUid, appUid } = schemaItem
    /** schema version */
    const latestVersion = +latestSchemaVersionItem.version
    const version = latestVersion + 1

    let pathVersion, pathLatestVersion

    /** @todo 后续下线白名单 */
    if (whiteList.includes(+projectId)) {
      /** 发布 S3, 同时更新 latest 版本 */
      const [s3pathVersion, s3pathLatestVersion] = await Promise.all([
        SchemaVersionDAO.toSchemaS3ProdURL(projectId, schemaId, version),
        SchemaVersionDAO.toSchemaS3ProdURL(projectId, schemaId, AramSchemaVersionTypeEnum.latest),
      ])
      pathVersion = s3pathVersion
      pathLatestVersion = s3pathLatestVersion
    } else {
      pathVersion = SchemaVersionDAO.toSchemaS3ProdURLV2(projectId, schemaUid, version)
      pathLatestVersion = SchemaVersionDAO.toSchemaS3ProdURLV2(projectId, schemaUid, AramSchemaVersionTypeEnum.latest)
    }

    const url = await this.rollbackS3SchemaVersion(appUid, urlSource, pathVersion, pathLatestVersion)

    const schemaVersionItem = new AramSchemaVersion()
    schemaVersionItem.projectId = projectId
    schemaVersionItem.moduleId = moduleId
    schemaVersionItem.schemaId = schemaId
    schemaVersionItem.version = version
    schemaVersionItem.url = url
    schemaVersionItem.type = AramPublishTypeEnum.rollback
    schemaVersionItem.description = description
    schemaVersionItem.rollbackFrom = targetSchemaVersionItem
    schemaVersionItem.createdBy = userName

    const data = await this.schemaVersionDao.insert(schemaVersionItem)

    const ret = data.identifiers[0] as { schemaVersionId: string | number }

    return { ...ret }
  }

  /** beta 配置回滚 */
  // prettier-ignore
  async rollbackSchemaBetaVersion(schemaId: AramIdType, targetVersion: AramSchemaVersionType, targetBetaVersion: AramSchemaVersionType, description = null) {
    const { userName } = await NestEventHelper.user()
    /**
     * 校验 schemaId 是否存在
     * 校验 target 是否存在
     * 校验 target 是否等于 current
     */
    const [schemaItem, targetSchemaBetaVersionItem, latestSchemaBetaVersionItem, whiteList] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaBetaVersionDao.getBySchemaIdAndVersionAndBetaVersion(schemaId, targetVersion, targetBetaVersion),
      this.schemaBetaVersionDao.getLastestBetaVersionBySchemaId(schemaId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.CdnMigrationWhiteList),
    ])
    if (!latestSchemaBetaVersionItem) throw new AramSchemaVersionNotFoundError(`最新版本数据不存在: schemaId=${schemaId}`)
    if (!targetSchemaBetaVersionItem) throw new AramSchemaVersionNotFoundError(`目标版本数据不存在: schemaId=${schemaId}`)
    if (targetSchemaBetaVersionItem.schemaBetaVersionId === latestSchemaBetaVersionItem.schemaBetaVersionId) {
      throw new AramInvalidRollbackTargetVersionError(`回滚目标版本不能与当前版本相同: schemaId=${schemaId}, targetVersion=${targetVersion}`)
    }

    /** 校验 是否拥有 项目权限 */
    const { projectId, moduleId } = targetSchemaBetaVersionItem
    await AramServiceContext.engine.schemaMember().verifySchemaEditorPermission(schemaId)

    /**
     * 发布新 schema
     *  schema json = target json
     *  schema version = latest version
     *  schema beta version = latest beta version + 1
     */
    /** schema */
    const { url: urlSource } = targetSchemaBetaVersionItem
    const { schemaUid, appUid } = schemaItem
    /** schema version */
    const version = +latestSchemaBetaVersionItem.version
    const latestBetaVersion = +latestSchemaBetaVersionItem.betaVersion || 0
    const betaVersion = latestBetaVersion + 1

    let pathVersion, pathLatestVersion

    /** @todo 后续下线白名单 */
    if (whiteList.includes(+projectId)) {
      /** 发布 S3, 同时更新 latest 版本 */
      const [s3pathVersion, s3pathLatestVersion] = await Promise.all([
        SchemaBetaVersionDAO.toSchemaS3BetaURL(projectId, schemaId, version, betaVersion),
        SchemaBetaVersionDAO.toSchemaS3BetaURL(projectId, schemaId),
      ])
      pathVersion = s3pathVersion
      pathLatestVersion = s3pathLatestVersion
    } else {
      pathVersion = SchemaBetaVersionDAO.toSchemaS3BetaURLV2(projectId, schemaUid, version, betaVersion)
      pathLatestVersion = SchemaBetaVersionDAO.toSchemaS3BetaURLV2(projectId, schemaUid)
    }
    const url = await this.rollbackS3SchemaVersion(appUid, urlSource, pathVersion, pathLatestVersion)

    const schemaBetaVersionItem = new AramSchemaBetaVersion()
    schemaBetaVersionItem.projectId = projectId
    schemaBetaVersionItem.moduleId = moduleId
    schemaBetaVersionItem.schemaId = schemaId
    schemaBetaVersionItem.version = version
    schemaBetaVersionItem.betaVersion = betaVersion
    schemaBetaVersionItem.url = url
    schemaBetaVersionItem.type = AramPublishTypeEnum.rollback
    schemaBetaVersionItem.description = description
    schemaBetaVersionItem.rollbackFrom = targetSchemaBetaVersionItem
    schemaBetaVersionItem.createdBy = userName

    const data = await this.schemaBetaVersionDao.insert(schemaBetaVersionItem)

    const ret = data.identifiers[0] as { schemaVersionId: string | number }

    return { ...ret }
  }

  async getBySchemaIdAndVersion(schemaId: AramIdType, version: AramSchemaVersionType | AramSchemaVersionTypeEnum) {
    if (version === AramSchemaVersionTypeEnum.latest) {
      return this.schemaVersionDao.getLastestVersionBySchemaId(schemaId)
    }
    return this.schemaVersionDao.getBySchemaIdAndVersion(schemaId, +version)
  }

  async getSchemaJson(url: string, appUid: AramUidType, source = CDNSourceEnum.BJ) {
    const client = await S3StreamService.getInstance(appUid, source)
    return client.queryJson(url)
  }

  /** 获取某一 prod 版本配置 */
  async getSchemaVersion(schemaId: AramIdType, version: AramSchemaVersionType | AramSchemaVersionTypeEnum.latest) {
    if (version === AramSchemaVersionTypeEnum.latest) {
      return this.getLatestSchemaVersion(schemaId)
    }
    const [schemaItem, schemaVersionItem] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaVersionDao.getBySchemaIdAndVersion(schemaId, +version),
    ])
    if (!schemaVersionItem) {
      throw new AramSchemaVersionNotFoundError(`配置版本不存在: schemaId=${schemaId}, version=${version}`)
    }

    const schema = await this.getSchemaJson(schemaVersionItem.url, schemaItem.appUid)
    return {
      schema,
      version,
    }
  }

  /** 获取某一 beta 版本配置 */
  async getSchemaBetaVersion(schemaId: AramIdType, version: AramSchemaVersionType | AramSchemaVersionTypeEnum, betaVersion?: AramSchemaVersionType) {
    if (version === AramSchemaVersionTypeEnum.latest) {
      return this.getLatestSchemaBetaVersion(schemaId)
    }
    const [schemaItem, schemaBetaVersionItem] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaBetaVersionDao.getBySchemaIdAndVersionAndBetaVersion(schemaId, +version, +betaVersion),
    ])
    if (!schemaBetaVersionItem) {
      throw new AramSchemaVersionNotFoundError(`配置版本不存在: schemaId=${schemaId}, version=${version}, betaVersion=${betaVersion}`)
    }

    const schema = await this.getSchemaJson(schemaBetaVersionItem.url, schemaItem.appUid)
    return {
      schema,
      version,
    }
  }

  async getLastestVersionBySchemaId(schemaId: AramIdType) {
    return this.schemaVersionDao.getLastestVersionBySchemaId(schemaId)
  }

  async getAllLatestVersionBySchemaIdList(schemaIds: AramIdType[]) {
    return this.schemaVersionDao.getAllLatestVersionBySchemaIdList(schemaIds)
  }

  /** 获取最新 prod 版本配置 */
  private async getLatestSchemaVersion(schemaId: AramIdType) {
    const [schemaItem, latestSchemaVersionItem] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaVersionDao.getLastestVersionBySchemaId(schemaId),
    ])
    if (!latestSchemaVersionItem) {
      throw new AramSchemaVersionNotFoundError(`配置版本不存在: schemaId=${schemaId}`)
    }

    const { url, version } = latestSchemaVersionItem
    const schema = await this.getSchemaJson(url, schemaItem.appUid)
    return {
      schema,
      version,
    }
  }

  /** 获取最新 beta 版本配置 */
  private async getLatestSchemaBetaVersion(schemaId: AramIdType) {
    const [schemaItem, latestSchemaBetaVersionItem] = await Promise.all([
      this.aramEngine.schema().getActiveSchema(schemaId),
      this.schemaBetaVersionDao.getLastestBetaVersionBySchemaId(schemaId),
    ])
    if (!latestSchemaBetaVersionItem) {
      throw new AramSchemaVersionNotFoundError(`配置版本不存在: schemaId=${schemaId}`)
    }

    const { url, version, betaVersion } = latestSchemaBetaVersionItem
    const schema = await this.getSchemaJson(url, schemaItem.appUid)
    return {
      schema,
      version,
      betaVersion,
    }
  }

  /**
   * - 生产/测试环境 发布 S3 并更新 latest 版本
   * - 北京集群上海集群双写 当北京集群写失败时抛错 当上海集群写失败时忽略
   * @param s3pathVersion
   * @param s3pathLatestVersion
   * @param schema
   */
  private async releaseS3SchemaVersion(appUid: AramUidType, s3pathVersion: string, s3pathLatestVersion: string, schema: AramJsonType) {
    const [clientBJ, clientSH] = await Promise.all([
      S3StreamService.getInstance(appUid, CDNSourceEnum.BJ),
      S3StreamService.getInstance(appUid, CDNSourceEnum.SH),
    ])
    const [{ filename: urlBJ }, { filename: urlLatestBJ }, $1, $2] = await Promise.all([
      clientBJ.upload(s3pathVersion, schema),
      clientBJ.upload(s3pathLatestVersion, schema),
      clientSH.upload(s3pathVersion, schema).catch(e => {
        AramLogger.logWarning(`上海侧集群发版失败: ${e.message}`, { s3pathVersion })
      }),
      clientSH.upload(s3pathLatestVersion, schema).catch(e => {
        AramLogger.logWarning(`上海侧集群 latest 发版失败: ${e.message}`, { s3pathVersion })
      }),
    ])
    if (!urlBJ || !urlLatestBJ) throw new AramS3Error(`S3 上传文件失败`)

    return urlBJ
  }

  /**
   * - 生产/测试环境 回滚 S3 版本 和 latest 版本
   * - 北京集群上海集群双写 当北京集群写失败时抛错 当上海集群写失败时忽略
   * @param filename e.g. test.json, schema/test.json
   * @param s3pathVersion
   * @param s3pathLatestVersion
   * @returns
   */
  private async rollbackS3SchemaVersion(appUid: AramUidType, filename: string, s3pathVersion: string, s3pathLatestVersion: string) {
    const [clientBJ, clientSH] = await Promise.all([
      S3StreamService.getInstance(appUid, CDNSourceEnum.BJ),
      S3StreamService.getInstance(appUid, CDNSourceEnum.SH),
    ])
    const [{ filename: urlBJ }, { filename: urlLatestBJ }, $1, $2] = await Promise.all([
      clientBJ.copy(filename, s3pathVersion),
      clientBJ.copy(filename, s3pathLatestVersion),
      clientSH.copy(filename, s3pathVersion).catch(e => {
        AramLogger.logWarning(`上海侧集群版本回滚失败: ${e.message}`, { filename })
      }),
      clientSH.copy(filename, s3pathLatestVersion).catch(e => {
        AramLogger.logWarning(`上海侧集群 latest 版本回滚失败: ${e.message}`, { filename })
      }),
    ])
    if (!urlBJ || !urlLatestBJ) throw new AramS3Error(`S3 上传文件失败`)

    return urlBJ
  }
}
