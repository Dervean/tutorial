import { FlowConfiguration } from '~/aram-flow/context/flow-configuration'
import { FlowEngine } from '~/aram-flow/core/flow-engine'
import { FlowAccessLocalService } from '~/aram-flow/access/flow-access-local-service'
import { StreamHelper } from '~/aram-lib/helper/stream-helper'

describe('aram-flow/__tests__/custom/handler', () => {
  let processId: AramUuidType
  let engine: FlowEngine

  beforeAll(async () => {
    await import('~/aram-flow/__tests__/custom/model/test-flow-custom-handler')

    engine = await new FlowConfiguration().buildFlowEngine()
    const process = await engine.process().deploy(StreamHelper.getStreamFromFilePath('src/aram-resource/flow/__tests__/custom/handler.xml'))
    processId = process.processId
  })
  it('should', async () => {
    const order = await engine.startInstanceById(processId)
    const tasks = await engine.task().getActiveTasks({
      orderId: order.orderId,
    })
    for (const task of tasks) {
      await engine.executeTask(task.taskId)
    }
  })

  afterAll(() => {
    const access = engine.query().access() as FlowAccessLocalService
    access.showCurrentDataStore()
  })
})
