import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'

@ReflectHelper.collect()
export class TestFlowCustomClass {
  async execute(msg: string) {
    const ret = `custom execute :>> ${msg}`
    return ret
  }
}
