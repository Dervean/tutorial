import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'

@ReflectHelper.collect()
export class TestFlowCustomHandler implements IFlowHandler {
  async handle(execution: FlowExecution): Promise<void> {
    console.log('custom handler!!')
  }
}
