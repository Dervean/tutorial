import { FlowAccessLocalService } from '~/aram-flow/access/flow-access-local-service'
import { FlowConfiguration } from '~/aram-flow/context/flow-configuration'
import { FlowEngine } from '~/aram-flow/core/flow-engine'
import { StreamHelper } from '~/aram-lib/helper/stream-helper'

describe('aram-flow/__tests__/decision/handler', () => {
  let processId: AramUuidType
  let engine: FlowEngine

  beforeAll(async () => {
    await import('~/aram-flow/__tests__/decision/model/test-flow-decision-handler')
    engine = await new FlowConfiguration().buildFlowEngine()
    const process = await engine.process().deploy(StreamHelper.getStreamFromFilePath('src/aram-resource/flow/__tests__/decision/handler.xml'))
    processId = process.processId
  })
  it('should', async () => {
    const args: Record<string, any> = {}
    args['task1.operator'] = ['1']
    args['task2.operator'] = ['1']
    args['task3.operator'] = ['1']
    args['target'] = 'toTask3'
    const order = await engine.startInstanceById(processId, 'wangdeyun', args)
    const tasks = await engine.task().getActiveTasks({
      orderId: order.orderId,
    })
    for (const task of tasks) {
      await engine.executeTask(task.taskId, '1')
    }
  })

  afterAll(() => {
    const access = engine.query().access() as FlowAccessLocalService
    access.showCurrentDataStore()
  })
})
