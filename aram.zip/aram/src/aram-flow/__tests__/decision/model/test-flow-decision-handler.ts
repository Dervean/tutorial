import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { IFlowDecisionHandler } from '~/aram-flow/interface/flow-decision-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'

@ReflectHelper.collect()
export class TestFlowDecisionHandler implements IFlowDecisionHandler {
  async decide(execution: FlowExecution) {
    return execution.args['target']
  }
}
