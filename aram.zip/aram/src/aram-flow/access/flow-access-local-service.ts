import { IFlowDBAccess } from '~/aram-flow/interface/flow-db-access'
import { AramFlowApprover } from '~/aram-base/entities/flow/aram-flow-approver'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'
import { StateEnum } from '~/aram-base/enum/flow'
import { AramLogger } from '~/aram-lib/model/aram-logger'

export class FlowAccessLocalService implements IFlowDBAccess {
  private someProcess: Map<AramUuidType, AramFlowProcess> = new Map()
  private someOrder: Map<AramUuidType, AramFlowOrder> = new Map()
  private someTasks: Map<AramUuidType, AramFlowTask> = new Map()
  private someApprovers: Map<AramUuidType, AramFlowApprover> = new Map()

  private objectToArray(obj: Record<string, any>) {
    const res = []
    const keys = Object.keys(obj || {})
    for (const key of keys) {
      res.push([key, obj[key]])
    }
    return res
  }

  async getActiveTasks(filter: Partial<AramFlowTask>) {
    const ret: AramFlowTask[] = []
    for (const [id, task] of this.someTasks.entries()) {
      let ok = true
      for (const [k, v] of this.objectToArray(filter)) {
        // @ts-ignore
        if (task[k] !== v) {
          ok = false
          break
        }
      }
      if (task.state !== StateEnum.Active) {
        ok = false
      }
      if (ok) {
        ret.push(task)
      }
    }
    return ret
  }

  async saveTask(task: AramFlowTask) {
    this.someTasks.set(task.taskId, task)
  }

  async getTask(taskId: AramUuidType) {
    return this.someTasks.get(taskId)
  }

  async getTasks(orderId: AramUuidType) {
    const ret: AramFlowTask[] = []
    for (const [id, task] of this.someTasks.entries()) {
      if (task.orderId === orderId) {
        ret.push(task)
      }
    }
    return ret
  }

  async saveOrder(order: AramFlowOrder) {
    this.someOrder.set(order.orderId, order)
  }

  async getOrder(orderId: AramUuidType) {
    return this.someOrder.get(orderId)
  }

  async getOrders(orderIds: string[]): Promise<AramFlowOrder[]> {
    const ret: AramFlowOrder[] = []
    for (const [id, order] of this.someOrder.entries()) {
      if (orderIds.includes(id)) {
        ret.push(order)
      }
    }
    return ret
  }

  async saveProcess(process: AramFlowProcess) {
    this.someProcess.set(process.processId, process)
  }

  async getProcessById(id: AramUuidType) {
    return this.someProcess.get(id)
  }

  async getLatestVersionProcess(processName: string) {
    for (const [id, process] of this.someProcess.entries()) {
      if (process.name === processName) {
        return process
      }
    }
    return null
  }

  async getApprovers(orderId: AramUuidType) {
    const ret: AramFlowApprover[] = []
    for (const [id, approver] of this.someApprovers.entries()) {
      if (approver.orderId === orderId) {
        ret.push(approver)
      }
    }
    return ret
  }

  async saveApprovers(approvers: AramFlowApprover[]) {
    for (const approver of approvers) {
      this.someApprovers.set(approver.approverId, approver)
    }
  }

  async updateOrder(order: AramFlowOrder) {
    this.someOrder.set(order.orderId, order)
  }

  async updateTask(task: AramFlowTask) {
    this.someTasks.set(task.taskId, task)
  }

  async updateApprovers(approvers: AramFlowApprover[]) {
    for (const approver of approvers) {
      this.someApprovers.set(approver.approverId, approver)
    }
  }

  showCurrentDataStore() {
    AramLogger.logInfo('someOrder :>> ', this.someOrder)
    AramLogger.logInfo('someProcess :>> ', this.someProcess)
    AramLogger.logInfo('someTasks :>> ', this.someTasks)
    AramLogger.logInfo('someApprovers :>> ', this.someApprovers)
  }
}
