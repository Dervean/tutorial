import { FlowApproverDAO } from '~/aram-base/dao/flow/flow-approver-dao'
import { IFlowDBAccess } from '~/aram-flow/interface/flow-db-access'
import { AramFlowApprover } from '~/aram-base/entities/flow/aram-flow-approver'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'
import { StateEnum } from '~/aram-base/enum/flow'
import { FlowOrderDAO } from '~/aram-base/dao/flow/flow-order-dao'
import { FlowProcessDAO } from '~/aram-base/dao/flow/flow-process-dao'
import { FlowTaskDAO } from '~/aram-base/dao/flow/flow-task-dao'

export class FlowAccessRemoteService implements IFlowDBAccess {
  private orderDao: FlowOrderDAO
  private processDao: FlowProcessDAO
  private taskDao: FlowTaskDAO
  private approverDao: FlowApproverDAO

  constructor() {
    this.orderDao = new FlowOrderDAO()
    this.processDao = new FlowProcessDAO()
    this.taskDao = new FlowTaskDAO()
    this.approverDao = new FlowApproverDAO()
  }

  // @todo
  async getActiveTasks(filter: Partial<AramFlowTask>) {
    filter.state = StateEnum.Active
    if (filter.orderId) {
      return this.taskDao.getAllTasksByStateAndOrderId(filter)
    }
  }

  async saveTask(task: AramFlowTask) {
    return this.taskDao.insert(task)
  }

  async getTask(id: AramUuidType) {
    return this.taskDao.getByPrimaryKey(id)
  }

  async getTasks(orderId: AramUuidType) {
    return this.taskDao.getAllByOrderId(orderId)
  }

  async saveOrder(order: AramFlowOrder) {
    return this.orderDao.insert(order)
  }

  async getOrder(id: AramUuidType) {
    return this.orderDao.getByPrimaryKey(id)
  }

  async getOrders(orderIds: string[]): Promise<AramFlowOrder[]> {
    return this.orderDao.getByPrimaryKeyList(orderIds)
  }

  async saveProcess(process: AramFlowProcess) {
    return this.processDao.insert(process)
  }

  async getProcessById(id: AramUuidType) {
    return this.processDao.getByPrimaryKey(id)
  }

  async getLatestVersionProcess(processName: string) {
    const item = await this.processDao.getLatestVersionByProcessName(processName)
    return item
  }

  async getApprovers(orderId: AramUuidType) {
    return this.approverDao.getAllByOrderId(orderId)
  }

  async saveApprovers(approvers: AramFlowApprover[]) {
    return this.approverDao.insertMany(approvers)
  }

  async updateOrder(order: AramFlowOrder) {
    const { orderId, createTime, updateTime, ...param } = order
    return this.orderDao.updateByPrimaryKey(orderId, param)
  }

  async updateTask(task: AramFlowTask) {
    const { taskId, createTime, updateTime, ...param } = task
    return this.taskDao.updateByPrimaryKey(taskId, param)
  }

  async updateApprovers(approvers: AramFlowApprover[]) {
    return this.approverDao.bulkUpdate(approvers)
  }
}
