import { IFlowDBAccess } from '~/aram-flow/interface/flow-db-access'
import { FlowAccessLocalService } from '~/aram-flow/access/flow-access-local-service'
import { FlowAccessRemoteService } from '~/aram-flow/access/flow-access-remote-service'
import { AramLogger } from '~/aram-lib/model/aram-logger'

export abstract class FlowAccessService {
  private static access: IFlowDBAccess = null

  static setAccess() {
    if (FlowAccessService.access !== null) {
      return FlowAccessService.access
    }
    switch (process.env.ARAM_RUNTIME_ENV) {
      case 'jest':
        AramLogger.logInfo('use mock access service ...')
        FlowAccessService.access = new FlowAccessLocalService()
        break
      default:
        FlowAccessService.access = new FlowAccessRemoteService()
        break
    }
  }

  public access() {
    return FlowAccessService.access
  }
}
