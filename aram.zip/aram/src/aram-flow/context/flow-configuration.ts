import assert from 'assert'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { StreamHelper } from '~/aram-lib/helper/stream-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { FlowContext } from '~/aram-flow/context/flow-context'
import { FlowServiceContext } from '~/aram-flow/context/flow-service-context'
import { ConfigHelper } from '~/aram-lib/helper/config-helper'
import { JSItemType, XMLHelper } from '~/aram-lib/helper/xml-helper'

export class FlowConfiguration {
  private static CONFIG_ROOT = 'flow'
  private static BASE_CONFIG_FILE = 'base.config.xml'
  private static EXT_CONFIG_FILE = 'ext.config.xml'

  public static PROCESS_CONFIG = new Map<string, Record<string, string>>()

  constructor(context?: FlowContext) {
    if (!context) {
      context = new FlowContext()
    }
    FlowServiceContext.context = context
  }

  public async buildFlowEngine() {
    AramLogger.logInfo('engine start...')
    await Promise.all([this.parseBase(), this.parseExt()])
    const engine = FlowServiceContext.engine
    assert.ok(!!engine, 'engine start failed')
    return engine.configure(this)
  }

  private async parseBase() {
    const filepath = ConfigHelper.absFilePath(FlowConfiguration.CONFIG_ROOT, FlowConfiguration.BASE_CONFIG_FILE)
    const buffer = StreamHelper.getStreamFromAbsFilePath(filepath)
    const data = await XMLHelper.getFromBuffer(buffer)
    const { $, _, ...children } = data.config
    for (const name of Object.keys(children)) {
      const values = children[name] as JSItemType[]
      switch (name) {
        case 'parser':
          for (const val of values) {
            await import(StreamHelper.absFilePath(val.$.class))
            ReflectHelper.classMap.set(val.$.name, ReflectHelper.classMap.get(val.$.clazz))
          }
          break
        default:
          break
      }
    }
    for (const [name, val] of ReflectHelper.classMap.entries()) {
      FlowServiceContext.put(name, val)
    }
  }

  private async parseExt() {
    const filepath = ConfigHelper.absFilePath(FlowConfiguration.CONFIG_ROOT, FlowConfiguration.EXT_CONFIG_FILE)
    const buffer = StreamHelper.getStreamFromAbsFilePath(filepath)
    const data = await XMLHelper.getFromBuffer(buffer)

    const { $, _, ...children } = data.config
    for (const name of Object.keys(children)) {
      const values = children[name] as JSItemType[]
      switch (name) {
        case 'process':
          for (const val of values) {
            await this.parseProcess(val)
          }
          break
        default:
          break
      }
    }
  }

  private async parseProcess(process: JSItemType) {
    const { $, _, ...children } = process
    const { name, ...attrs } = $

    FlowServiceContext.EXT_PROCESS_CONFIGURATION.set(name, { ...attrs })
    for (const t of Object.keys(children)) {
      const values = children[t] as JSItemType[]
      switch (t) {
        case 'custom-handler':
        case 'decision-handler':
          for (const val of values) {
            await import(StreamHelper.absFilePath(val.$.class))
          }
          break
        default:
          break
      }
    }
  }
}
