export class FlowContext {
  private contextMap: Map<string, Object> = new Map()

  public exists(name: string) {
    return !!this.contextMap.get(name)
  }

  public find<T extends new (...args: any[]) => any>(clz: T) {
    for (const entry of this.contextMap.entries()) {
      const [name, obj] = entry
      if (obj instanceof clz) {
        return obj as T
      }
    }
    return null
  }

  // @todo
  public findByName<T extends Function>(clzName: string, clz: T) {
    for (const entry of this.contextMap.entries()) {
      const [name, obj] = entry
      if (name === clzName && obj instanceof clz) {
        return obj as T
      }
    }
    return null
  }

  public findList<T extends new (...args: any[]) => any>(clz: T) {
    const ret: T[] = []
    for (const entry of this.contextMap.entries()) {
      const [name, obj] = entry
      if (obj instanceof clz) {
        ret.push(obj as T)
      }
    }
    return ret
  }

  public put(name: string, clz: new (...args: any[]) => any) {
    this.contextMap.set(name, new clz())
  }
}
