import assert from 'assert'

import { FlowEngine } from '~/aram-flow/core/flow-engine'
import { FlowContext } from '~/aram-flow/context/flow-context'

export class FlowServiceContext {
  private static _context: FlowContext
  private static _engine: FlowEngine = new FlowEngine()

  public static EXT_PROCESS_CONFIGURATION = new Map<string, Record<string, string>>()

  public static get context(): FlowContext {
    return FlowServiceContext._context
  }
  public static set context(value: FlowContext) {
    FlowServiceContext._context = value
  }
  public static get engine(): FlowEngine {
    return FlowServiceContext._engine
  }

  public static find<T extends new (...args: any[]) => any>(clz: T): T {
    assert.ok(!!this.context, 'context not ready')
    return this.context.find(clz)
  }

  public static findList<T extends new (...args: any[]) => any>(clz: T): T[] {
    assert.ok(!!this.context, 'context not ready')
    return this.context.findList(clz)
  }

  public static put(name: string, clz: new (...args: any[]) => any) {
    assert.ok(!!this.context, 'context not ready')
    return this.context.put(name, clz)
  }
}
