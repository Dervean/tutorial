import { StringHelper } from '~/aram-lib/helper/string-helper'
import { FlowAccessService } from '~/aram-flow/access/flow-access-service'
import { AramFlowApprover } from '~/aram-base/entities/flow/aram-flow-approver'
import { AuditStateEnum, AuditStateDescEnum } from '~/aram-base/enum/flow'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'

export class FlowApproverService extends FlowAccessService {
  public async getApprovers(orderId: AramUuidType) {
    return this.access().getApprovers(orderId)
  }

  public async saveApprovers(order: AramFlowOrder, approvers: AramUserNameType[]) {
    const approverList: AramFlowApprover[] = []
    for (const mis of approvers) {
      const approver = new AramFlowApprover()
      approver.approver = mis
      approver.approverId = StringHelper.generatePrimaryKeyUUID()
      approver.auditState = AuditStateEnum.Reviewing
      approver.auditStateDesc = AuditStateDescEnum.Reviewing
      approver.orderId = order.orderId

      approverList.push(approver)
    }
    return this.access().saveApprovers(approverList)
  }

  public async updateApprovers(approvers: AramFlowApprover[]) {
    return this.access().updateApprovers(approvers)
  }
}
