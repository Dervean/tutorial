import assert from 'assert'
import { FlowConfiguration } from '~/aram-flow/context/flow-configuration'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { FlowOrderService } from '~/aram-flow/core/flow-order-service'
import { FlowProcessService } from '~/aram-flow/core/flow-process-service'
import { FlowTaskService } from '~/aram-flow/core/flow-task-service'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'
import { FlowQueryService } from '~/aram-flow/core/flow-query-service'
import { FlowApproverService } from '~/aram-flow/core/flow-approver-service'
import { FlowShadowTaskService } from '~/aram-flow/core/flow-shadow-task-service'

export class FlowEngine {
  public static AUTO = 'system'

  private flowProcessService: FlowProcessService
  private flowOrderService: FlowOrderService
  private flowTaskService: FlowTaskService
  private flowQueryService: FlowQueryService
  private flowApproverService: FlowApproverService
  private flowShadowTaskService: FlowShadowTaskService

  public process() {
    assert.ok(!!this.flowProcessService)
    return this.flowProcessService
  }

  public order() {
    assert.ok(!!this.flowOrderService)
    return this.flowOrderService
  }

  public task() {
    assert.ok(!!this.flowTaskService)
    return this.flowTaskService
  }

  public shadowTask() {
    assert.ok(!!this.flowShadowTaskService)
    return this.flowShadowTaskService
  }

  public query() {
    assert.ok(!!this.flowQueryService)
    return this.flowQueryService
  }

  public approver() {
    assert.ok(!!this.flowApproverService)
    return this.flowApproverService
  }

  public configure(configuration: FlowConfiguration) {
    this.flowProcessService = new FlowProcessService()
    this.flowOrderService = new FlowOrderService()
    this.flowTaskService = new FlowTaskService()
    this.flowShadowTaskService = new FlowShadowTaskService()
    this.flowQueryService = new FlowQueryService()
    // @todo 抽离扩展服务
    this.flowApproverService = new FlowApproverService()
    FlowQueryService.setAccess()

    // @todo transaction interceptor

    // @todo cache
    return this
  }

  public async startInstanceById(processId: string, operator?: string, args?: Record<string, any>) {
    if (!args) args = {}
    const process = await this.process().getProcessById(processId)
    this.process().check(process, processId)
    return this.startProcess(process, operator, args)
  }

  public async executeTask(taskId: AramUuidType, operator?: string, args?: Record<string, any>): Promise<AramFlowTask[]> {
    const execution = await this.executeT(taskId, operator, args)
    if (!execution) return []

    const model = execution.process.model

    AramLogger.logInfo(`start process model execution...`, { name: model.name })

    if (model) {
      const nm = model.getNode(execution.task.name)
      await nm.execute(execution)
    }
    return execution.tasks
  }

  private async startProcess(process: AramFlowProcess, operator?: string, args?: Record<string, any>) {
    const execution = await this.executeP(process, operator, args, null, null)
    if (process.model) {
      const start = process.model.getStart()
      assert.ok(!!start, `empty start node: process=${process.name}`)
      await start.execute(execution)
    }
    return execution.order
  }

  private async executeP(process: AramFlowProcess, operator: string, args: Record<string, any>, parentId: string, parentNodeName: string) {
    const order = await this.order().createOrder(process, operator, args, parentId, parentNodeName)
    const current = new FlowExecution(this, process, order, args)
    current.operator = operator

    return current
  }

  private async executeT(taskId: AramUuidType, operator?: string, args?: Record<string, any>): Promise<FlowExecution> {
    if (!args) args = {}
    const task = await this.task().complete(taskId, operator, args)

    AramLogger.logInfo(`task is completed`, { taskId: task.taskId })

    const order = await this.query().getOrder(task.orderId)

    assert.ok(!!order, `流程实例已完成或不存在: orderId=${order.orderId}`)

    order.updatedBy = operator
    await this.order().updateOrder(order)

    // @todo 协办任务

    const variable = order.variable
    if (variable) {
      Object.keys(variable).forEach(e => {
        if (args[e] === undefined) {
          args[e] = variable[e]
        }
      })
    }
    const process = await this.process().getProcessById(order.processId)
    const execution = new FlowExecution(this, process, order, args)
    execution.operator = operator
    execution.task = task
    return execution
  }
}
