import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'
import { FlowEngine } from '~/aram-flow/core/flow-engine'

export class FlowExecution {
  public operator: AramUserNameType
  public task: AramFlowTask = null
  // public suspend: boolean

  private _engine: FlowEngine = null
  private _process: AramFlowProcess = null
  private _order: AramFlowOrder = null
  private _args: Record<string, any> = null
  private _tasks: AramFlowTask[] = []

  public get tasks(): AramFlowTask[] {
    return this._tasks
  }
  public get engine(): FlowEngine {
    return this._engine
  }
  public get process(): AramFlowProcess {
    return this._process
  }
  public get order() {
    return this._order
  }
  public get args() {
    return this._args
  }

  constructor(engine: FlowEngine, process: AramFlowProcess, order: AramFlowOrder, args: Record<string, any>) {
    if (!process || !order || !engine) {
      throw new Error(`failed to construct FlowExecution: process=${process}, engine=${engine}, order=${order}`)
    }
    this._engine = engine
    this._process = process
    this._order = order
    this._args = args
    // this.suspend = false
  }

  public addTasks(tasks: AramFlowTask[]) {
    this._tasks.push(...tasks)
  }

  public addTask(task: AramFlowTask) {
    this._tasks.push(task)
  }
}
