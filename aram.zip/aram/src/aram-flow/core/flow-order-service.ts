import { StringHelper } from '~/aram-lib/helper/string-helper'
import { FlowAccessService } from '~/aram-flow/access/flow-access-service'
import { FlowServiceContext } from '~/aram-flow/context/flow-service-context'
import { StateDescEnum, StateEnum } from '~/aram-base/enum/flow'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'

export class FlowOrderService extends FlowAccessService {
  public static ATTR_CREATOR_REMARK = 'creatorRemark'
  public static ATTR_CREATOR = 'creator'

  public async createOrder(process: AramFlowProcess, operator: string, args: Record<string, any>, parentId?: string, parentNodeName?: string) {
    const order = new AramFlowOrder()
    order.orderId = StringHelper.generatePrimaryKeyUUID()
    order.parentId = parentId || null
    order.parentNodeName = parentNodeName || null
    order.creator = operator
    order.creatorRemark = args[FlowOrderService.ATTR_CREATOR_REMARK]
    order.processId = process.processId
    order.processName = process.name
    /** @todo 过期时间？ */
    order.variable = args
    order.state = StateEnum.Active
    order.stateDesc = StateDescEnum.Active

    await this.saveOrder(order)

    return order
  }

  public async terminate(orderId: AramUuidType, operator?: AramUserNameType) {
    const order = await this.getOrder(orderId)
    const engine = FlowServiceContext.engine
    if (order === null) {
      throw new Error(`流程不存在: orderId=${orderId}`)
    }
    if (order.state !== StateEnum.Active) {
      throw new Error(`流程已结束: orderId=${orderId}, state=${order.state}`)
    }

    const tasks = await engine.task().getActiveTasks({ orderId })
    const terminateTasks: Promise<AramFlowTask>[] = []
    for (const task of tasks) {
      const t = engine.task().terminate(task.taskId, operator)
      terminateTasks.push(t)
    }
    await Promise.all(terminateTasks)

    order.state = StateEnum.Canceled
    order.stateDesc = StateDescEnum.Canceled
    return this.updateOrder(order)
  }

  public async complete(orderId: AramUuidType, state = StateEnum.Success, stateDesc = StateDescEnum.Success) {
    const order = await this.getOrder(orderId)
    order.state = state
    order.stateDesc = stateDesc
    return this.updateOrder(order)
  }

  public async saveOrder(order: AramFlowOrder) {
    return this.access().saveOrder(order)
  }

  public async getOrder(orderId: AramUuidType) {
    return this.access().getOrder(orderId)
  }

  public async getOrders(orderIds: AramUuidType[]) {
    const ids = orderIds.filter(e => !!e)
    return this.access().getOrders(ids)
  }

  public async updateOrder(order: AramFlowOrder) {
    return this.access().updateOrder(order)
  }
}
