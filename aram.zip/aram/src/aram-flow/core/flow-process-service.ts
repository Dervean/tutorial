import assert from 'assert'

import { StringHelper } from '~/aram-lib/helper/string-helper'
import { FlowAccessService } from '~/aram-flow/access/flow-access-service'
import { FlowModelParser } from '~/aram-flow/parser/flow-model-parser'
import { AramStatusEnum } from '~/aram-base/enum/common'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'

export class FlowProcessService extends FlowAccessService {
  public check(process: AramFlowProcess, processId: string) {
    assert.ok(!!process, `流程定义不存在: processId=${processId}`)
    if (process.status !== AramStatusEnum.Active) {
      throw new Error(`流程定义未激活: id=${processId}, name=${process.name}`)
    }
  }

  public async deploy(input: Buffer, creator?: AramUserNameType) {
    assert.ok(!!input)
    const model = await FlowModelParser.parse(input)
    const entity = new AramFlowProcess()
    const latestVersionProcess = await this.getLatestVersionProcess(model.name)
    const latestVersion = latestVersionProcess?.version || 0
    entity.processId = StringHelper.generatePrimaryKeyUUID()
    entity.version = latestVersion + 1
    entity.status = AramStatusEnum.Active
    entity.model = model
    entity.createdBy = creator
    entity.name = model.name
    entity.content = input
    entity.displayName = model.displayName
    await this.saveProcess(entity)
    return entity
  }

  public async saveProcess(process: AramFlowProcess) {
    return this.access().saveProcess(process)
  }

  public async getProcessById(processId: AramUuidType) {
    const process = await this.access().getProcessById(processId)
    return this.setProcessModel(process)
  }

  public async getLatestVersionProcess(processName: string) {
    const process = await this.access().getLatestVersionProcess(processName)
    return this.setProcessModel(process)
  }

  private async setProcessModel(process: AramFlowProcess) {
    if (!process) return process
    if (process.model) return process
    const modelInput = process.content
    const model = await FlowModelParser.parse(modelInput)
    process.model = model
    return process
  }
}
