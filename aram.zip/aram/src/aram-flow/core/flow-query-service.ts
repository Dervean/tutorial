import { FlowAccessService } from '~/aram-flow/access/flow-access-service'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'

export class FlowQueryService extends FlowAccessService {
  async getOrder(orderId: AramUuidType) {
    return this.access().getOrder(orderId)
  }

  async getTask(taskId: AramUuidType) {
    return this.access().getTask(taskId)
  }

  async getActiveTasks(filter: Partial<AramFlowTask>) {
    return this.access().getActiveTasks(filter)
  }
}
