import assert from 'assert'

import { StringHelper } from '~/aram-lib/helper/string-helper'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'
import { StateEnum, StateDescEnum } from '~/aram-base/enum/flow'
import { FlowProcessModel } from '~/aram-flow/model/flow-process-model'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'
import { FlowTaskModel } from '~/aram-flow/model/node/flow-task-model'
import { FlowTaskService } from '~/aram-flow/core/flow-task-service'

export class FlowShadowTaskService {
  public async tasksWithShadows(process: AramFlowProcess, order: AramFlowOrder, sortedTasks: AramFlowTask[]) {
    let shadows: AramFlowTask[] = []
    if (sortedTasks && sortedTasks.length) {
      const task = sortedTasks[sortedTasks.length - 1]
      assert(order.processId === process.processId, `流程 ID 校验不通过: orderId=${order.orderId}, processId=${process.processId}`)
      assert(task.orderId === order.orderId, `任务 ID 校验不通过: orderId=${order.orderId}, taskId=${task.taskId}`)
      shadows = await this.shadowTasks(process.model, order.orderId, task)
    }
    return [...sortedTasks, ...shadows]
  }

  private async shadowTasks(processModel: FlowProcessModel, orderId: AramUuidType, task: AramFlowTask) {
    if (!processModel || !task) return []

    const shadowTasks: AramFlowTask[] = []

    let parentTask: AramFlowTask = task
    let parentNode = processModel.getNode(task.name)
    while (true) {
      const size = shadowTasks.length
      const children = this.nextCandidates(parentNode)
      const shadows = children.filter(child => child.shadow === 'Y')

      if (children.length === 1 || shadows.length === 1) {
        const child = children.length === 1 ? children.shift() : shadows.shift()
        const target = this.createShadowTask(child, orderId, parentTask)
        shadowTasks.push(target)
        parentNode = child
        parentTask = target
      }

      if (shadowTasks.length === size) break
    }

    return shadowTasks
  }

  private createShadowTask(taskModel: FlowTaskModel, orderId: AramUuidType, parentTask?: AramFlowTask) {
    const shadowTask = new AramFlowTask()
    shadowTask.taskId = StringHelper.generatePrimaryKeyUUID()
    shadowTask.state = StateEnum.Pending
    shadowTask.stateDesc = StateDescEnum.Pending
    shadowTask.name = taskModel.name
    shadowTask.displayName = taskModel.displayName
    shadowTask.performType = taskModel.performType
    shadowTask.orderId = orderId
    shadowTask.actors = null
    shadowTask.operator = null
    shadowTask.createTime = null
    shadowTask.updateTime = null
    shadowTask.parentTaskId = parentTask?.taskId || FlowTaskService.START
    return shadowTask
  }

  private nextCandidates(node: FlowNodeModel) {
    const o = [node.outputs]
    const candidates: FlowTaskModel[] = []
    while (o.length) {
      const outputs = o.shift()
      for (const output of outputs) {
        const t = output.target
        if (t instanceof FlowTaskModel) {
          candidates.push(t)
        } else {
          o.push(t.outputs)
        }
      }
    }
    return candidates
  }
}
