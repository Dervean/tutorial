import assert from 'assert'

import { StringHelper } from '~/aram-lib/helper/string-helper'
import { FlowAccessService } from '~/aram-flow/access/flow-access-service'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'
import { PerformTypeEnum, StateDescEnum, StateEnum } from '~/aram-base/enum/flow'
import { FlowTaskModel } from '~/aram-flow/model/node/flow-task-model'
import { FlowEngine } from '~/aram-flow/core/flow-engine'
import { FlowExecution } from '~/aram-flow/core/flow-execution'

export class FlowTaskService extends FlowAccessService {
  public static START = 'start'

  public static sortTasks(tasks: AramFlowTask[]) {
    if (!tasks || tasks.length === 0) return null
    const sortedTasks: AramFlowTask[] = []
    for (const task of tasks) {
      const parent = tasks.find(t => t.taskId === task.parentTaskId)
      if (parent === undefined) {
        sortedTasks.push(task)
        break
      }
    }
    while (true) {
      const parent = sortedTasks[sortedTasks.length - 1]
      const child = tasks.find(t => t.parentTaskId === parent.taskId)
      if (!child) break
      sortedTasks.push(child)
    }
    return sortedTasks
  }

  public async complete(taskId: AramUuidType, operator: AramUserNameType, args?: Record<string, any>) {
    const task = await this.getTask(taskId)
    assert.ok(!!task, `指定任务不存在: taskId=${taskId}`)
    // tostring override
    task.variable = args

    if (!this.isAllowed(task, operator)) {
      throw new Error(`无执行任务权限: operator=${operator}, taskId=${taskId}`)
    }

    // @todo 历史任务
    task.state = StateEnum.Success
    task.stateDesc = StateDescEnum.Success
    task.operator = operator

    await this.updateTask(task)
    return task
  }

  public async terminate(taskId: AramUuidType, operator: AramUserNameType) {
    const task = await this.getTask(taskId)
    if (task === null) {
      throw new Error(`指定任务不存在: taskId=${taskId}`)
    }
    if (task.state !== StateEnum.Active) {
      throw new Error(`指定任务已结束: taskId=${taskId}, state=${task.state}`)
    }

    task.state = StateEnum.Canceled
    task.stateDesc = StateDescEnum.Canceled
    task.operator = operator

    await this.updateTask(task)
    return task
  }

  public isAllowed(task: AramFlowTask, operator: AramUserNameType) {
    if (!operator) return false
    if (operator === FlowEngine.AUTO) {
      return true
    }
    if (task.operator) {
      return task.operator === operator
    }
    const actors = task.actors
    if (!actors || !actors.length) return true
    return actors.includes(operator)
  }

  public async createTask(tm: FlowTaskModel, execution: FlowExecution) {
    const tasks = [] as AramFlowTask[]
    const args = execution.args || {}
    // @todo 提醒时间
    // @todo 确定参与者 ?
    const task = new AramFlowTask()
    task.orderId = execution.order.orderId
    task.name = tm.name
    task.displayName = tm.displayName
    // @todo 主办协办
    task.parentTaskId = execution.task?.taskId || FlowTaskService.START
    task.model = tm
    task.state = StateEnum.Active
    task.stateDesc = StateDescEnum.Active
    // @todo 过期时间
    // @tod deep JSON.stringify ?
    task.variable = args
    if (tm.performType === PerformTypeEnum.Any) {
      const t = await this.saveTask(task, execution.args[tm.assignee])
      tasks.push(t)
    } else if (tm.performType === PerformTypeEnum.All) {
      // todo
    }
    return tasks
  }

  private async saveTask(task: AramFlowTask, actors: AramUserNameType[]) {
    task.taskId = StringHelper.generatePrimaryKeyUUID()
    // @todo confirm any?
    task.performType = PerformTypeEnum.Any
    task.actors = Array.isArray(actors) ? [...actors] : null
    await this.access().saveTask(task)
    // actors 不需要单独建表
    return task
  }

  public async getTask(taskId: AramUuidType) {
    return this.access().getTask(taskId)
  }

  public async getTasks(orderId: AramUuidType) {
    return this.access().getTasks(orderId)
  }

  public async getActiveTasks(filter: Partial<AramFlowTask>) {
    return this.access().getActiveTasks(filter)
  }

  public async updateTask(task: AramFlowTask) {
    return this.access().updateTask(task)
  }
}
