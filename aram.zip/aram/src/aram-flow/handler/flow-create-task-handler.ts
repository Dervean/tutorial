import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'
import { FlowTaskModel } from '~/aram-flow/model/node/flow-task-model'

export class FlowCreateTaskHandler implements IFlowHandler {
  private model: FlowTaskModel = null

  constructor(tm: FlowTaskModel) {
    this.model = tm
  }

  public async handle(execution: FlowExecution) {
    const tasks = await execution.engine.task().createTask(this.model, execution)
    execution.addTasks(tasks)
    // @todo 拦截器
  }
}
