import { FlowEngine } from '~/aram-flow/core/flow-engine'
import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'

export class FlowEndProcessHandler implements IFlowHandler {
  public async handle(execution: FlowExecution) {
    const engine = execution.engine
    const order = execution.order

    const tasks = await execution.engine.task().getActiveTasks({ orderId: order.orderId })

    for (const task of tasks) {
      // @todo 主办任务?
      await engine.task().complete(task.taskId, FlowEngine.AUTO)
    }

    await engine.order().complete(order.orderId)

    // @todo 父流程
  }
}
