import { FlowExecution } from '~/aram-flow/core/flow-execution'

export interface IFlowAction {
  execute(execution: FlowExecution): Promise<void>
}
