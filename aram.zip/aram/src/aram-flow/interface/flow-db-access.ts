import { AramFlowApprover } from '~/aram-base/entities/flow/aram-flow-approver'
import { AramFlowOrder } from '~/aram-base/entities/flow/aram-flow-order'
import { AramFlowProcess } from '~/aram-base/entities/flow/aram-flow-process'
import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'

export interface IFlowDBAccess {
  getTask(taskId: AramUuidType): Promise<AramFlowTask>
  getTasks(orderId: AramUuidType): Promise<AramFlowTask[]>
  getActiveTasks(filter: Partial<AramFlowTask>): Promise<AramFlowTask[]>
  getOrder(orderId: AramUuidType): Promise<AramFlowOrder>
  getOrders(orderIds: AramUuidType[]): Promise<AramFlowOrder[]>
  getProcessById(id: AramUuidType): Promise<AramFlowProcess>
  getLatestVersionProcess(processName: string): Promise<AramFlowProcess>

  getApprovers(orderId: AramUuidType): Promise<AramFlowApprover[]>

  saveProcess(process: AramFlowProcess): Promise<void>
  saveOrder(order: AramFlowOrder): Promise<void>
  saveApprovers(approvers: AramFlowApprover[]): Promise<void>
  saveTask(task: AramFlowTask): Promise<void>

  updateTask(task: AramFlowTask): Promise<void>
  updateOrder(order: AramFlowOrder): Promise<void>
  updateApprovers(approvers: AramFlowApprover[]): Promise<void>
}
