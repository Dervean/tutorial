import { FlowExecution } from '~/aram-flow/core/flow-execution'

export interface IFlowDecisionHandler {
  decide(execution: FlowExecution): Promise<string>
}
