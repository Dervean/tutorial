import { FlowExecution } from '~/aram-flow/core/flow-execution'

export interface IFlowHandler {
  handle(execution: FlowExecution): Promise<void>
}

export function isIFlowHandler(arg: any): arg is IFlowHandler {
  return arg && arg.handle && typeof arg.handle === 'function'
}
