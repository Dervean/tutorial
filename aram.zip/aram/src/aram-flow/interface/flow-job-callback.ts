import { AramFlowTask } from '~/aram-base/entities/flow/aram-flow-task'

export interface IFlowJobCallback {
  callback(taskId: AramUuidType, newTasks: AramFlowTask[]): Promise<void>
}
