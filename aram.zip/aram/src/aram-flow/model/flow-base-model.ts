import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { IFlowHandler } from '~/aram-flow/interface/flow-handler'

export class FlowBaseModel {
  public name: string
  public displayName: string

  protected async fire(handler: IFlowHandler, execution: FlowExecution) {
    return handler.handle(execution)
  }
}
