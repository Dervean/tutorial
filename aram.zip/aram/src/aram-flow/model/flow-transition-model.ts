import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { FlowCreateTaskHandler } from '~/aram-flow/handler/flow-create-task-handler'
import { IFlowAction } from '~/aram-flow/interface/flow-action'
import { FlowBaseModel } from '~/aram-flow/model/flow-base-model'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'
import { FlowTaskModel } from '~/aram-flow/model/node/flow-task-model'

export class FlowTransitionModel extends FlowBaseModel implements IFlowAction {
  public source: FlowNodeModel
  public target: FlowNodeModel
  public to: string

  public isEnabled = false

  public async execute(execution: FlowExecution) {
    if (!this.isEnabled) return
    // @todo subprocess
    if (this.target instanceof FlowTaskModel) {
      const taskHandler = new FlowCreateTaskHandler(this.target as FlowTaskModel)
      return this.fire(taskHandler, execution)
    } else {
      return this.target.execute(execution)
    }
  }
}
