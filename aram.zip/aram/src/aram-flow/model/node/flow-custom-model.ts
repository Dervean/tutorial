import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { isIFlowHandler } from '~/aram-flow/interface/flow-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'

export class FlowCustomModel extends FlowNodeModel {
  public scope: string
  public clazz: string
  public methodName: string
  public args: string
  public var: string

  private invokeObject: Object

  public async exec(execution: FlowExecution) {
    if (!this.invokeObject) {
      this.invokeObject = ReflectHelper.newInstance(this.scopedClazz)
    }
    if (!this.invokeObject) {
      throw new Error(`自定义模型对象实例化失败: scope=${this.scope}, clazz=${this.clazz}`)
    }
    if (isIFlowHandler(this.invokeObject)) {
      await this.invokeObject.handle(execution)
    } else {
      const ret = await ReflectHelper.invoke(this.invokeObject, this.methodName, this.getArgs(execution.args, this.args))
      execution.args[this.var] = ret
    }
    return this.runOutTransition(execution)
  }

  private get scopedClazz() {
    return this.scope ? `${this.scope}.${this.clazz}` : this.clazz
  }

  private getArgs(executionArgs: Record<string, any>, args: string) {
    const ret: any[] = []
    if (args) {
      const arr = args.split(',')
      for (let i = 0; i < arr.length; i++) {
        ret.push(executionArgs[arr[i]])
      }
    }
    return ret
  }
}
