import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { IFlowDecisionHandler } from '~/aram-flow/interface/flow-decision-handler'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'

export class FlowDecisionModel extends FlowNodeModel {
  // public expr: string
  public scope: string
  public handleClass: string

  private get scopedHandleClass() {
    return this.scope ? `${this.scope}.${this.handleClass}` : this.handleClass
  }

  private decision: IFlowDecisionHandler
  // private expression: Expression

  public async exec(execution: FlowExecution) {
    // @todo
    // expr 先不做
    if (!this.decision) {
      this.decision = ReflectHelper.newInstance(this.scopedHandleClass)
    }
    if (!this.decision) {
      throw new Error(`自定义决策对象实例化失败: scope=${this.scope}, handleClass=${this.handleClass}`)
    }
    const next = await this.decision.decide(execution)
    AramLogger.logInfo(`decision result: next=${next}`)

    let isFound = false
    for (const tm of this.outputs) {
      if (tm.name === next) {
        tm.isEnabled = true
        await tm.execute(execution)
        isFound = true
      }
    }
    if (!isFound) {
      throw new Error(`decision 节点无法确定下一步执行节点: orderId=${execution.order.orderId}`)
    }
  }
}
