import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { FlowEndProcessHandler } from '~/aram-flow/handler/flow-end-process-handler'
import { FlowTransitionModel } from '~/aram-flow/model/flow-transition-model'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'

export class FlowEndModel extends FlowNodeModel {
  public get outputs() {
    return [] as FlowTransitionModel[]
  }

  public async exec(execution: FlowExecution) {
    await this.fire(new FlowEndProcessHandler(), execution)
    return this.runOutTransition(execution)
  }
}
