import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { IFlowAction } from '~/aram-flow/interface/flow-action'
import { FlowBaseModel } from '~/aram-flow/model/flow-base-model'
import { FlowTransitionModel } from '~/aram-flow/model/flow-transition-model'

export abstract class FlowNodeModel extends FlowBaseModel implements IFlowAction {
  private _inputs: FlowTransitionModel[] = []
  public get inputs(): FlowTransitionModel[] {
    return this._inputs
  }
  public set inputs(value: FlowTransitionModel[]) {
    this._inputs = value
  }

  private _outputs: FlowTransitionModel[] = []
  public get outputs(): FlowTransitionModel[] {
    return this._outputs
  }
  public set outputs(value: FlowTransitionModel[]) {
    this._outputs = value
  }

  protected abstract exec(execution: FlowExecution): Promise<void>

  public async execute(execution: FlowExecution) {
    // @todo 拦截器？
    return this.exec(execution)
  }

  protected async runOutTransition(execution: FlowExecution) {
    for (const tm of this.outputs) {
      tm.isEnabled = true
      await tm.execute(execution)
    }
  }
}
