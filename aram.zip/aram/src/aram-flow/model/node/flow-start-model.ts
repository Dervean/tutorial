import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { FlowTransitionModel } from '~/aram-flow/model/flow-transition-model'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'

export class FlowStartModel extends FlowNodeModel {
  public get inputs() {
    return [] as FlowTransitionModel[]
  }

  public async exec(execution: FlowExecution) {
    return this.runOutTransition(execution)
  }
}
