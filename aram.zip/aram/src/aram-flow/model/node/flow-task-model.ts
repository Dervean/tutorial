import assert from 'assert'

import { FlowExecution } from '~/aram-flow/core/flow-execution'
import { PerformTypeEnum } from '~/aram-base/enum/flow'
import { IFlowJobCallback } from '~/aram-flow/interface/flow-job-callback'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'

export class FlowTaskModel extends FlowNodeModel {
  public performType: PerformTypeEnum = PerformTypeEnum.Any
  public autoExecute: TextConditionType = 'Y'
  public shadow: TextConditionType = 'N'

  public assignee: string // not user name

  private _callbackObj: IFlowJobCallback
  public get callbackObj(): IFlowJobCallback {
    return this._callbackObj
  }

  private _callback: string
  public get callback(): string {
    return this._callback
  }
  public set callback(value: string) {
    if (value) {
      this._callback = value
      this._callbackObj = ReflectHelper.newInstance(value)
      assert.ok(!!this._callbackObj, '回调处理类实例化失败')
    }
  }

  public async exec(execution: FlowExecution) {
    if (this.performType === PerformTypeEnum.Any) {
      return this.runOutTransition(execution)
    }
    {
      // @todo all
    }
  }
}
