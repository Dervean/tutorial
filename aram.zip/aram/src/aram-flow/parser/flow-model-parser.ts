import assert from 'assert'
import { JSItemType, XMLHelper } from '~/aram-lib/helper/xml-helper'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { FlowServiceContext } from '~/aram-flow/context/flow-service-context'
import { FlowProcessModel } from '~/aram-flow/model/flow-process-model'
import { FlowNodeParser } from '~/aram-flow/parser/flow-node-parser'

export class FlowModelParser {
  public static async parse(buffer: Buffer) {
    const pm = new FlowProcessModel()
    const data = await XMLHelper.getFromBuffer(buffer)

    assert.ok(!!data, `empty xml input`)

    const attrs = data.process.$

    pm.displayName = attrs[FlowNodeParser.ATTR_DISPLAYNAME]
    pm.name = attrs[FlowNodeParser.ATTR_NAME]

    const { $, _, ...children } = data.process

    Object.keys(children).forEach(name => {
      const valueList = children[name] as JSItemType[]
      valueList.forEach(value => {
        const nm = this.parseNode(name, value)
        pm.nodes.push(nm)
      })
    })

    for (const node of pm.nodes) {
      for (const transition of node.outputs) {
        const to = transition.to
        for (const nodeTo of pm.nodes) {
          if (to === nodeTo.name) {
            nodeTo.inputs.push(transition)
            transition.target = nodeTo
          }
        }
      }
    }
    return pm
  }

  private static parseNode(name: string, value: JSItemType) {
    try {
      // @todo type declr
      const parser = FlowServiceContext.context.findByName(name, FlowNodeParser) as any
      parser.parse(value)
      return parser.model
    } catch (e) {
      AramLogger.logError(`parse failed`, { message: e.message, name, value })
      throw e
    }
  }
}
