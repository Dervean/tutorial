import { JSItemType } from '~/aram-lib/helper/xml-helper'
import { FlowTransitionModel } from '~/aram-flow/model/flow-transition-model'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'

export abstract class FlowNodeParser {
  public static NODE_TRANSITION = 'transition'

  public static ATTR_NAME = 'name'
  public static ATTR_DISPLAYNAME = 'displayName'
  // public static ATTR_INSTANCEURL = 'instanceUrl'
  // public static ATTR_INSTANCENOCLASS = 'instanceNoClass'
  // public static ATTR_EXPR = 'expr'
  public static ATTR_HANDLECLASS = 'handleClass'
  // public static ATTR_FORM = 'form'
  // public static ATTR_FIELD = 'field'
  // public static ATTR_VALUE = 'value'
  // public static ATTR_ATTR = 'attr'
  // public static ATTR_TYPE = 'type'
  public static ATTR_ASSIGNEE = 'assignee'
  // public static ATTR_ASSIGNEE_HANDLER = 'assignmentHandler'
  public static ATTR_PERFORMTYPE = 'performType'
  // public static ATTR_TASKTYPE = 'taskType'
  public static ATTR_TO = 'to'
  // public static ATTR_PROCESSNAME = 'processName'
  // public static ATTR_VERSION = 'version'
  // public static ATTR_EXPIRETIME = 'expireTime'
  public static ATTR_AUTOEXECUTE = 'autoExecute'
  public static ATTR_SHADOW = 'shadow'
  public static ATTR_CALLBACK = 'callback'
  // public static ATTR_REMINDERTIME = 'reminderTime'
  // public static ATTR_REMINDERREPEAT = 'reminderRepeat'
  public static ATTR_CLAZZ = 'clazz'
  public static ATTR_SCOPE = 'scope'
  public static ATTR_METHODNAME = 'methodName'
  public static ATTR_ARGS = 'args'
  public static ATTR_VAR = 'var'
  // public static ATTR_LAYOUT = 'layout'
  // public static ATTR_G = 'g'
  // public static ATTR_OFFSET = 'offset'
  // public static ATTR_PREINTERCEPTORS = 'preInterceptors'
  // public static ATTR_POSTINTERCEPTORS = 'postInterceptors'

  private _model: FlowNodeModel

  protected get model(): FlowNodeModel {
    return this._model
  }

  protected abstract newModel(): FlowNodeModel

  protected abstract parseNode(model: FlowNodeModel, element: JSItemType): void

  public parse(element: JSItemType) {
    this._model = this.newModel()

    const attrs = element.$
    this._model.displayName = attrs[FlowNodeParser.ATTR_DISPLAYNAME]
    this._model.name = attrs[FlowNodeParser.ATTR_NAME]

    const transitions = (element.transition || []) as JSItemType[]
    for (const t of transitions) {
      const transition = new FlowTransitionModel()
      const tAttrs = t.$
      transition.displayName = tAttrs[FlowNodeParser.ATTR_DISPLAYNAME]
      transition.name = tAttrs[FlowNodeParser.ATTR_NAME]
      transition.to = tAttrs[FlowNodeParser.ATTR_TO]
      // source
      // expr
      this._model.outputs.push(transition)
    }
    this.parseNode(this.model, element)
  }
}
