import { FlowDecisionModel } from '~/aram-flow/model/node/flow-decision-model'
import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'
import { JSItemType } from '~/aram-lib/helper/xml-helper'
import { FlowNodeParser } from '~/aram-flow/parser/flow-node-parser'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'

@ReflectHelper.collect()
export class FlowDecisionParser extends FlowNodeParser {
  protected parseNode(model: FlowNodeModel, element: JSItemType): void {
    const task = model as FlowDecisionModel
    const attrs = element.$
    // task.expr = attrs[FlowNodeParser.ATTR_EXPR]
    task.scope = attrs[FlowNodeParser.ATTR_SCOPE] || ''
    task.handleClass = attrs[FlowNodeParser.ATTR_HANDLECLASS]
  }

  protected newModel() {
    return new FlowDecisionModel()
  }
}
