import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'
import { FlowStartModel } from '~/aram-flow/model/node/flow-start-model'
import { JSItemType } from '~/aram-lib/helper/xml-helper'
import { FlowNodeParser } from '~/aram-flow/parser/flow-node-parser'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'

@ReflectHelper.collect()
export class FlowStartParser extends FlowNodeParser {
  protected parseNode(model: FlowNodeModel, element: JSItemType): void {}

  protected newModel() {
    return new FlowStartModel()
  }
}
