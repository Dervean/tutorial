import { FlowNodeModel } from '~/aram-flow/model/node/flow-node-model'
import { FlowTaskModel } from '~/aram-flow/model/node/flow-task-model'
import { JSItemType } from '~/aram-lib/helper/xml-helper'
import { FlowNodeParser } from '~/aram-flow/parser/flow-node-parser'
import { ReflectHelper } from '~/aram-lib/helper/reflect-helper'
import { PerformTypeEnum } from '~/aram-base/enum/flow'

@ReflectHelper.collect()
export class FlowTaskParser extends FlowNodeParser {
  protected parseNode(model: FlowNodeModel, element: JSItemType): void {
    const task = model as FlowTaskModel

    const attrs = element.$
    if (attrs[FlowNodeParser.ATTR_PERFORMTYPE]) {
      task.performType = attrs[FlowNodeParser.ATTR_PERFORMTYPE] as PerformTypeEnum
    }
    if (attrs[FlowNodeParser.ATTR_AUTOEXECUTE]) {
      task.autoExecute = attrs[FlowNodeParser.ATTR_AUTOEXECUTE] as TextConditionType
    }
    if (attrs[FlowNodeParser.ATTR_SHADOW]) {
      task.shadow = attrs[FlowNodeParser.ATTR_SHADOW] as TextConditionType
    }
    task.assignee = attrs[FlowNodeParser.ATTR_ASSIGNEE]
    // taskType
    // assignment handler
    task.callback = attrs[FlowNodeParser.ATTR_CALLBACK]
  }

  protected newModel() {
    return new FlowTaskModel()
  }
}
