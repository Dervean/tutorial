export const APP_KEY = 'com.sankuai.aram'
