export const enum AramResponseStatusEnum {
  /** 保留 0 */
  Normal = 0,

  /** ************************ */
  /** 400 入参异常 */
  BadRequestInvalidFormatParam = 6000, // 参数格式错误
  BadRequestMissingParam = 6001, // 参数缺失

  /** ************************ */
  /** 403 拒绝处理 - 应用/项目/模块 */
  ForbiddenNoProjectPermission = 7000, // 项目权限校验失败
  ForbiddenModifyProjectPermissionRefused = 7001, // 修改项目权限被拒绝
  ForbiddenProjectClosed = 7002, // 项目已关闭
  ForbiddenNoApplicationPermission = 7003, // 应用权限校验失败
  ForbiddenApplicationAlreadyExisted = 7004, // 应用已存在
  ForbiddenNoSchemaPermission = 7005, // 配置权限校验失败
  /** 403 拒绝处理 - 草稿 */
  ForbiddenNoSchemaDraftPermission = 7100, // 草稿权限校验失败
  ForbiddenSchemaDraftAlreadyExisted = 7101, // 草稿已存在
  /** 403 拒绝处理 - 线上发布 */
  ForbiddenInvalidRollbackTargetVersion = 7200, // 回滚目标版本不合法
  /** 403 拒绝处理 - 组件 */
  ForbiddenInvalidComponentType = 7300, // 组件类型不合法
  /** 403 拒绝处理 - mara */

  /** ************************ */
  /** 404 资源不存在 */
  NotFoundUserNotFound = 8000, // 用户不存在
  NotFoundProjectNotFound = 8001, // 项目不存在 或 已关闭
  NotFoundMemberNotFound = 8002, // 项目成员不存在 或 已删除
  NotFoundModuleNotFound = 8003, // 模块不存在 或 已关闭

  NotFoundSchemaNotFound = 8004, // 配置不存在 或 已关闭
  NotFoundSchemaDraftNotFound = 8005, // 配置草稿不存在
  NotFoundSchemaVersionNotFound = 8006, // 配置版本不存在

  NotFoundComponentNotFound = 8007, // 组件配置不存在 或 已删除
  NotFoundComponentVersionNotFound = 8008, // 组件配置版本不存在

  NotFoundMaraConfigNotFound = 8009, // mara 版本不存在
  // NotFoundMaraComponentConfigNotFound = 8010, // mara 组件库配置不存在

  NotFoundApplicationNotFound = 8011, // 应用不存在
  /** ************************ */
  /** 500 服务异常 */
  ServerErrorUnkownError = 50000, // 未知错误
  ServerErrorSSOUnauthorized = 50001, // SSO 认证异常
  ServerErrorZebraError = 50002, // 数据修改失败
  ServerErrorS3Error = 50003, // S3 操作失败
  ServerErrorORGError = 50004, // ORG 操作失败
  ServerErrorKMSError = 50005, // KMS 查询失败
  ServerErrorLionError = 50006, // Lion 查询失败
  ServerErrorHttpRequestError = 50007, // http 请求失败

  RuntimeErrorClassNotFoundError = 90001, // 类不存在
  RuntimeErrorReflectError = 90002, // 反射错误
}
