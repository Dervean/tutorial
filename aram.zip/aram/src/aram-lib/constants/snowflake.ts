export const MACHINE_ID = 0
