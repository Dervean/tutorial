import { AramLogger } from '~/aram-lib/model/aram-logger'

export class ClassHelper {
  public static instantiate(clz: new (...args: any[]) => any) {
    try {
      return new clz()
    } catch ({ message }) {
      AramLogger.logError('实例化失败', { message, clz })
    }
  }
}
