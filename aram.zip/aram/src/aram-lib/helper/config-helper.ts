import path from 'path'

export class ConfigHelper {
  private static root = 'aram-resource'

  public static absFilePath(...paths: string[]) {
    const src = path.resolve(__dirname, '..', '..')
    return path.posix.join(src, ConfigHelper.root, ...paths)
  }
}
