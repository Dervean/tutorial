import * as crypto from 'crypto'

export class CryptoHelper {
  public static hmac(key: any, data: any, digest: any, fn: string) {
    if (!digest) {
      digest = 'binary'
    }
    if (digest === 'buffer') {
      digest = undefined
    }
    if (!fn) {
      fn = 'sha256'
    }
    if (typeof data === 'string') {
      data = Buffer.from(data)
    }
    return crypto.createHmac(fn, key).update(data).digest(digest)
  }

  public static hash(algorithm: string) {
    return crypto.createHash(algorithm)
  }

  public static md5(data: any, digest: any) {
    if (!digest) {
      digest = 'binary'
    }
    if (digest === 'buffer') {
      digest = undefined
    }
    if (typeof data === 'string') {
      data = Buffer.from(data)
    }
    return CryptoHelper.hash('md5').update(data).digest(digest)
  }

  public static sha256(data: any, digest: any) {
    if (!digest) {
      digest = 'binary'
    }
    if (digest === 'buffer') {
      digest = undefined
    }
    if (typeof data === 'string') {
      data = Buffer.from(data)
    }
    return CryptoHelper.hash('sha256').update(data).digest(digest)
  }

  public static toHex(data: any) {
    const out = []
    for (let i = 0; i < data.length; i++) {
      out.push(('0' + data.charCodeAt(i).toString(16)).substr(-2, 2))
    }
    return out.join('')
  }
}
