import moment from 'moment'

export class DateHelper {
  public static MS_PER_MINUTE = 60 * 1000
  public static MS_PER_HOUR = 60 * 60 * 1000
  public static MS_PER_DAY = 1000 * 60 * 60 * 24

  public static getDate(value?: undefined | number | string | Date) {
    if (!value) {
      return new Date()
    } else if (value instanceof Date) {
      return value
    } else if (typeof value === 'number' && /^\d+$/.test(`${value}`)) {
      return new Date(value)
    } else if (typeof value === 'string' && value.match(/^\d{4}/)) {
      // iso8601
      return new Date(value)
    } else if (typeof value === 'string' && value.match(/^\w{3},/)) {
      // rfc822
      return new Date(value)
    } else {
      throw new Error(`非法日期: ${value}`)
    }
  }

  /**
   * @param date
   * @returns timestamp
   */
  public static timestamp(date?: number | string | Date) {
    return DateHelper.getDate(date).getTime()
  }

  /**
   * @param date
   * @returns the date in ISO-8601 format
   */
  public static iso8601(date?: any) {
    return DateHelper.getDate(date).toISOString()
  }

  /**
   * @param date
   * @returns the date in RFC 822 format
   */
  public static rfc822(date?: any) {
    return DateHelper.getDate(date).toUTCString()
  }

  public static getCurrentDatetime() {
    const FORMAT = 'YYYY-MM-DD HH:mm:ss'
    const current = DateHelper.getDate()
    return moment(current).format(FORMAT)
  }
}
