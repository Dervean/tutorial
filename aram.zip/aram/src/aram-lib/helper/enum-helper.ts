export class EnumHelper {
  public static isEnumMember<T>(value: any, targetEnum: { [key: string]: T }) {
    return Object.values(targetEnum).includes(value)
  }
}
