export class JsonHelper {
  public static isJson(t: any) {
    if (typeof t !== 'object') return false
    return Object.prototype.toString.call(t).toLowerCase() === '[object object]' && !t.length
  }

  public static isJsonString(t: string) {
    if (typeof t == 'string') {
      try {
        if (typeof JSON.parse(t) == 'object') {
          return true
        }
      } catch (e) {
        return false
      }
    }
    return false
  }
}
