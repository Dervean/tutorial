import assert from 'assert'

export class MathHelper {
  public static dec2bin(dec: number, maxlen = 53) {
    assert.ok(Number.isInteger(dec), `noninteger number is not supported: dec=${dec}`)
    if (dec >= 0) return dec.toString(2).padStart(maxlen, '0')
    if (dec < 0) return (dec >>> 0).toString(2).padStart(maxlen, '1')
  }
  public static dec2hex(dec: number, maxlen = 14) {
    assert.ok(dec >= 0, `negative number is not supported: dec=${dec}`)
    return dec.toString(16).padStart(maxlen, '0')
  }
  public static hex2dec(hex: string) {
    assert.ok(/^[0-9a-f]+$/i.test(hex), `invalid hex string: ${hex}`)
    return parseInt(hex, 16)
  }
}
