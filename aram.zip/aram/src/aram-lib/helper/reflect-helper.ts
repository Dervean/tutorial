import 'reflect-metadata'

import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramReflectError } from '~/aram-lib/model/aram-error/runtime/aram-reflect-error'
import { AramClassNotFoundError } from '~/aram-lib/model/aram-error/runtime/aram-class-not-found-error'

export class ReflectHelper {
  public static classMap: Map<string, new (...args: any[]) => any> = new Map()

  public static collect(scope?: string) {
    return function (clz: new (...args: any[]) => any) {
      const name = scope ? `${scope}.${clz.name}` : clz.name
      if (ReflectHelper.classMap.get(name)) {
        throw new Error('duplicated class anotation')
      }
      ReflectHelper.classMap.set(name, clz)
    }
  }

  public static newInstance(clzName: string) {
    try {
      const clz = ReflectHelper.classMap.get(clzName)
      if (!clz) {
        throw new AramClassNotFoundError(`实例化目标类不存在: clz=${clz}, classMap=${ReflectHelper.classMap}`)
      }
      return new clz()
    } catch ({ message }) {
      AramLogger.logError('实例化失败', { message, clzName })
    }
  }

  public static invoke(instance: Object, fnName: string, args: any[]) {
    try {
      const fn = Reflect.get(instance, fnName)
      return fn(...args)
    } catch ({ message }) {
      AramLogger.logError('方法调用失败', { message, instance: instance.constructor, fnName, args })
      throw new AramReflectError()
    }
  }
}
