import * as fs from 'fs'
import path from 'path'

export class StreamHelper {
  public static absFilePath(filepath: string) {
    const root = path.resolve(__dirname, '..', '..', '..')
    return path.posix.join(root, filepath)
  }

  public static getStreamFromFilePath(filepath: string) {
    const p = this.absFilePath(filepath)
    return fs.readFileSync(p)
  }

  public static getStreamFromAbsFilePath(filepath: string) {
    return fs.readFileSync(filepath)
  }
}
