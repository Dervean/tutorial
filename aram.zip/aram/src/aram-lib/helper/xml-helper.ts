import * as xml2js from 'xml2js'
import { AramLogger } from '../model/aram-logger'

/**
 * @todo
 */
export type JSItemType = {
  [key: string]: JSItemType[] | Record<string, string> | string
  $?: Record<string, string>
  _?: string
}

export type JSType = {
  [key: string]: JSItemType
}

export class XMLHelper {
  public static getFromBuffer(buffer: Buffer): Promise<JSType> {
    try {
      const parser = new xml2js.Parser()
      return parser.parseStringPromise(buffer)
    } catch (e) {
      AramLogger.logError(`xml build failed, please check xml format, message=${e.message}`)
      throw e
    }
  }
}
