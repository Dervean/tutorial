import { AramAesEncryption } from '~/aram-lib/model/aram-encryption/aram-aes-encryption'

describe('aram-lib/model/aram-encryption/aram-aes-encryption', () => {
  it('should be defined', () => {
    expect(AramAesEncryption).toBeDefined()
  })

  it('should return encrypt Aes text', async () => {
    const cipher = await AramAesEncryption.encrypt('cdcmdm///213a')
    expect(cipher).toEqual('Salv2r160gfOuH4Km9KdYQ==')
  })

  it('should return decrypt Aes text', async () => {
    const plain = await AramAesEncryption.decrypt('Salv2r160gfOuH4Km9KdYQ==')
    expect(plain).toEqual('cdcmdm///213a')
  })
})
