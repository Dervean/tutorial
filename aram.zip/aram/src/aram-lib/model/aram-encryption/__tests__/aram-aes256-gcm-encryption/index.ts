import { AramAes256GcmEncryption } from '~/aram-lib/model/aram-encryption/aram-aes256-gcm-encryption'

describe('aram-lib/model/aram-encryption/aram-aes256-gcm-encryption', () => {
  it('should be defined', () => {
    expect(AramAes256GcmEncryption).toBeDefined()
  })

  it('should return encrypt Aes256Gcm text', async () => {
    const plaintext = '1646715330881&2929794&wangdeyun'
    const ciphertext = await AramAes256GcmEncryption.encrypt(plaintext)
    switch (process.env.ARAM_ENV) {
      case 'production':
        expect(ciphertext).toEqual('auzdxrMikMkTz8qyNxPlAcsRCb-xKin7WPiE1I6u4VFncFVjbWl0WGJKRBry1KliojMo73A-lN4o5mU=')
        break
      case 'test':
      default:
        expect(ciphertext).toEqual('R1exiYfKOTmTIzGXMJG5FKFDILjj+AoboOB803ZOrUdUeGpJZEJpV3ZCVd8IBDb8CcqozAFcgHfS7FA=')
        break
    }
  })

  it('should return decrypt Aes256Gcm text', async () => {
    let ciphertext
    switch (process.env.ARAM_ENV) {
      case 'production':
        ciphertext = 'auzdxrMikMkTz8qyNxPlAcsRCb-xKin7WPiE1I6u4VFncFVjbWl0WGJKRBry1KliojMo73A-lN4o5mU='
        break
      case 'test':
      default:
        ciphertext = 'R1exiYfKOTmTIzGXMJG5FKFDILjj+AoboOB803ZOrUdUeGpJZEJpV3ZCVd8IBDb8CcqozAFcgHfS7FA='
        break
    }
    const plaintext = await AramAes256GcmEncryption.decrypt(ciphertext)
    expect(plaintext).toEqual('1646715330881&2929794&wangdeyun')
  })
})
