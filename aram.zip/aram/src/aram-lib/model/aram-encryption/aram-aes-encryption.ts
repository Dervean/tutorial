import * as cryptoJS from 'crypto-js'
import { KMSConfigKeyEnum, KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'
import { AramKMSError } from '../aram-error/server/aram-kms-error'

/**
 * 与 SDK 加密算法一致 使用 crypto-js
 */
export class AramAesEncryption {
  public static key: string = null
  public static iv: string = null

  private static async init() {
    try {
      if (!this.key || !this.iv) {
        const [iv, key] = await Promise.all([
          KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.EncryptionSdkAesIv),
          KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.EncryptionSdkAesKey),
        ])
        this.key = key
        this.iv = iv
      }
    } catch (error) {
      throw new AramKMSError()
    }
  }

  static async encrypt(plaintext: string) {
    await this.init()

    const key = cryptoJS.enc.Utf8.parse(this.key)
    const iv = cryptoJS.enc.Utf8.parse(this.iv)
    const encryptor = cryptoJS.algo.AES.createEncryptor(key, { iv })

    const encrypted = encryptor.process(plaintext)
    encrypted.concat(encryptor.finalize())
    const ciphertext = encrypted.toString(cryptoJS.enc.Base64)
    return ciphertext.replace(/\//g, '-')
  }

  static async decrypt(ciphertext: string) {
    await this.init()

    const processedCt = cryptoJS.enc.Base64.parse(ciphertext.replace(/\-/g, '/'))

    const key = cryptoJS.enc.Utf8.parse(this.key)
    const iv = cryptoJS.enc.Utf8.parse(this.iv)
    const decryptor = cryptoJS.algo.AES.createDecryptor(key, { iv })

    const decrypted = decryptor.process(processedCt)
    decrypted.concat(decryptor.finalize())
    const plaintext = decrypted.toString(cryptoJS.enc.Utf8)
    return plaintext
  }
}
