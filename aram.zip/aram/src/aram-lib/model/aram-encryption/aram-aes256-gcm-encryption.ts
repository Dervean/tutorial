import * as crypto from 'crypto'
import { KMSConfigKeyEnum, KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'
import { AramKMSError } from '../aram-error/server/aram-kms-error'

export class AramAes256GcmEncryption {
  public static key: string = null
  public static iv: string = null

  private static async init() {
    try {
      if (!this.key || !this.iv) {
        const [iv, key] = await Promise.all([
          KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.EncryptionAramAesIv),
          KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.EncryptionAramAesKey),
        ])
        this.key = key
        this.iv = iv
      }
    } catch (error) {
      throw new AramKMSError()
    }
  }

  static async encrypt(plaintext: string) {
    await this.init()

    const key = Buffer.from(this.key)
    const iv = Buffer.from(this.iv)
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv)
    const enc1 = cipher.update(plaintext, 'utf8')
    const enc2 = cipher.final()
    // prettier-ignore
    const encrypted = Buffer.concat([enc1, enc2, iv, cipher.getAuthTag()])
      .toString('base64')
      .replace(/\//g, '-')
    return encrypted
  }

  static async decrypt(ciphertext: string) {
    await this.init()

    const key = this.key
    const buffer = Buffer.from(ciphertext.replace(/\-/g, '/'), 'base64')
    const enc = buffer.slice(0, buffer.length - 28)
    const iv = buffer.slice(buffer.length - 28, buffer.length - 16)
    const tag = buffer.slice(buffer.length - 16)

    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv)
    decipher.setAuthTag(tag)
    const s1 = decipher.update(enc, null, 'utf8')
    const s2 = decipher.final('utf8')
    return [s1, s2].join('')
  }
}
