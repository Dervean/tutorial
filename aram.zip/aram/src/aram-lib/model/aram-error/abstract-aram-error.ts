import { AramResponseStatusEnum } from '~/aram-lib/constants/response'

export abstract class AbstractAramError extends Error {
  public code: AramResponseStatusEnum
  constructor(msg?: string) {
    super(msg)
    Object.setPrototypeOf(this, AbstractAramError.prototype)
  }
}

/*
class AramError {
  protected static AramUndefinedError = 'UndefinedError'
  constructor(message: string, name?: string) {
    const error = Error(message)
    // set immutable object properties
    Object.defineProperty(error, 'message', {
      get() {
        return message
      },
    })
    Object.defineProperty(error, 'name', {
      get() {
        return name || AramError.AramUndefinedError
      },
    })
    // capture where error occured
    Error.captureStackTrace(error, AramError)
    // @ts-ignore
    Object.setPrototypeOf(error, AramError.prototype)
    return error
  }
}
*/
