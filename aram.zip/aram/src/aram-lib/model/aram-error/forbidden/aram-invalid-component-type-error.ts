import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramInvalidComponentTypeError extends AbstractAramError {
  constructor(msg?: string) {
    super(msg)
    this.code = AramResponseStatusEnum.ForbiddenInvalidComponentType
    Object.setPrototypeOf(this, AramInvalidComponentTypeError.prototype)
  }
}
