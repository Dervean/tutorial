import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramNoApplicationPermissionError extends AbstractAramError {
  constructor(msg?: string) {
    super(msg)
    this.code = AramResponseStatusEnum.ForbiddenNoApplicationPermission
    Object.setPrototypeOf(this, AramNoApplicationPermissionError.prototype)
  }
}
