import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramNoSchemaPermissionError extends AbstractAramError {
  constructor(msg?: string) {
    super(msg)
    this.code = AramResponseStatusEnum.ForbiddenNoSchemaPermission
    Object.setPrototypeOf(this, AramNoSchemaPermissionError.prototype)
  }
}
