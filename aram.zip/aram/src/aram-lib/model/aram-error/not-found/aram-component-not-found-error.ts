import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramComponentNotFoundError extends AbstractAramError {
  constructor(msg?: string) {
    super(msg)
    this.code = AramResponseStatusEnum.NotFoundComponentNotFound
    Object.setPrototypeOf(this, AramComponentNotFoundError.prototype)
  }
}
