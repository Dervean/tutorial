import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramMaraConfigNotFoundError extends AbstractAramError {
  constructor(msg?: string) {
    super(msg)
    this.code = AramResponseStatusEnum.NotFoundMaraConfigNotFound
    Object.setPrototypeOf(this, AramMaraConfigNotFoundError.prototype)
  }
}
