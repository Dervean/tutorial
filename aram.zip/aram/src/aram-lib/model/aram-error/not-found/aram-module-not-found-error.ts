import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramModuleNotFoundError extends AbstractAramError {
  constructor(msg?: string) {
    super(msg)
    this.code = AramResponseStatusEnum.NotFoundModuleNotFound
    Object.setPrototypeOf(this, AramModuleNotFoundError.prototype)
  }
}
