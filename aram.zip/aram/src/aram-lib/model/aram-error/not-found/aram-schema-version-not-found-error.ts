import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramSchemaVersionNotFoundError extends AbstractAramError {
  constructor(msg?: string) {
    super(msg)
    this.code = AramResponseStatusEnum.NotFoundSchemaVersionNotFound
    Object.setPrototypeOf(this, AramSchemaVersionNotFoundError.prototype)
  }
}
