import { Context } from 'koa'
import * as HTTP from '~/aram-lib/constants/http'
import { AramResponseStatusEnum } from '~/aram-lib/constants/response'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramHttpResponse {
  public static NormalMsg = 'success'
  private status: number
  private message: string
  private data: Record<string, any>
  private headers: Map<HTTP.HeaderEnum, any>

  constructor()
  constructor(data: Record<string, any>)
  constructor(error: Error)
  constructor(param?: Record<string, any> | Error) {
    if (param instanceof Error) {
      this.status = AramResponseStatusEnum.ServerErrorUnkownError
      if (param instanceof AbstractAramError) {
        this.status = param.code
      }
      this.message = param.message || null
      this.data = null
    } else {
      this.status = AramResponseStatusEnum.Normal
      this.message = AramHttpResponse.NormalMsg
      this.data = param || null
    }
    const DefaultHeaders = new Map<HTTP.HeaderEnum, any>()
    DefaultHeaders.set(HTTP.HeaderEnum.ACESS_CONTROL_ALLOW_HEADERS, 'Content-Type')
    DefaultHeaders.set(HTTP.HeaderEnum.CONTENT_TYPE, 'application/json;charset=utf-8')
    this.headers = DefaultHeaders
  }

  public setMessage(message: string): void {
    this.message = message
  }

  public setData(data: Record<string, any>): void {
    this.data = data
  }

  public setHeader(header: HTTP.HeaderEnum, value: any) {
    this.headers.set(header, value)
  }

  private buildHeaders(ctx: Context) {
    for (const [key, val] of this.headers.entries()) {
      ctx.set(key, val)
    }
    return ctx
  }

  private buildBody(ctx: Context) {
    ctx.body = {
      status: this.status,
      message: this.message,
      data: JSON.parse(JSON.stringify(this.data)),
    }
    return ctx
  }

  public build(ctx: Context) {
    this.buildHeaders(ctx)
    this.buildBody(ctx)
    return ctx
  }

  public buildDxResponse(ctx: Context, message: string, rescode: number) {
    this.buildHeaders(ctx)
    ctx.body = {
      data: {
        message,
      },
      rescode,
    }
    return ctx
  }
}
