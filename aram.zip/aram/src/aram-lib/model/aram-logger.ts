import log4js from 'log4js'
import { NestEventHelper } from '~/aram-app/model/nest-event-helper'
import { AbstractAramError } from '~/aram-lib/model/aram-error/abstract-aram-error'

export class AramLogger {
  private static _logger: log4js.Logger = null
  private static NAME = 'ARAM'
  private static PROD_MODE = 'prod'
  private static TEST_MODE = 'test'

  private static get mode() {
    if (process.env.ARAM_ENV === 'production') {
      return AramLogger.PROD_MODE
    }
    return AramLogger.TEST_MODE
  }

  private static init() {
    log4js.configure({
      appenders: {
        [AramLogger.NAME]: {
          type: 'stdout',
          layout: {
            type: 'pattern',
            pattern: '[%[%d{yyyy-MM-dd hh.mm.ss}%]]%[[%p]%][%x{filepath}:%l][%x{user}] %m',
            tokens: {
              user: function (logEvent) {
                return NestEventHelper.info?.userName
              },
              filepath: function (logEvent) {
                const fileName: string = (logEvent as any).fileName || ''
                return fileName.slice(fileName.indexOf('src/aram-') || 0)
              },
            },
          },
        },
      },
      categories: {
        default: {
          enableCallStack: true,
          appenders: [AramLogger.NAME],
          level: 'debug',
        },
        [AramLogger.TEST_MODE]: {
          enableCallStack: true,
          appenders: [AramLogger.NAME],
          level: 'debug',
        },
        [AramLogger.PROD_MODE]: {
          enableCallStack: true,
          appenders: [AramLogger.NAME],
          level: 'info',
        },
      },
    })
    AramLogger._logger = log4js.getLogger(AramLogger.mode)
  }

  private static get logger(): log4js.Logger {
    if (AramLogger._logger === null) {
      AramLogger.init()
    }
    return AramLogger._logger
  }

  public static logInfo(message: string, data?: Record<string, any> | null): void {
    const optstr = AramLogger.buildOptionMsg(data)
    const msg = `${message}${optstr}`
    return AramLogger.logger.info(msg)
  }

  public static logWarning(message: string, data?: Record<string, any> | null): void {
    const optstr = AramLogger.buildOptionMsg(data)
    const msg = `${message}${optstr}`
    return AramLogger.logger.warn(msg)
  }

  public static logError(payload: string | Error, data?: Record<string, any> | null): void {
    let message = payload
    if (payload instanceof AbstractAramError) return
    if (payload instanceof Error) message = payload.message
    const optstr = AramLogger.buildOptionMsg(data)
    const msg = `${message}${optstr}`
    return AramLogger.logger.error(msg)
  }

  public static logDebug(message: string, data?: Record<string, any> | null): void {
    const optstr = AramLogger.buildOptionMsg(data)
    const msg = `${message}${optstr}`
    return AramLogger.logger.debug(msg)
  }

  public static logFatal(message: string, data?: Record<string, any> | null): void {
    const optstr = AramLogger.buildOptionMsg(data)
    const msg = `${message}${optstr}`
    return AramLogger.logger.fatal(msg)
  }

  private static buildOptionMsg(data: Record<string, any> | null = null) {
    const keys = Object.keys(data || {})
    const opt = keys.map(k => `${k}=${JSON.stringify(data[k])}`)
    const optstr = data && Object.keys(data).length > 0 ? `: ${opt.join(', ')}` : ''
    return optstr
  }
}
