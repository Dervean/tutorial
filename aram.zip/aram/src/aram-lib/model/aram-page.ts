export type AramPageParams = {
  pageNum?: number
  pageSize?: number
}

export class AramPage<T> {
  /** 当前是第几页，默认为1 */
  private pageNum = 1
  /** 页的大小，默认为20 */
  private pageSize = 20
  /** 总数 */
  private totalCnt = 0
  /** 开始序号 */
  private list: Partial<T>[]

  constructor(pageNum?: number, pageSize?: number, totalCnt?: number) {
    this.processPageNum(pageNum)
    this.processPageSize(pageSize)
    this.processTotalCnt(totalCnt)
  }

  public static getOffsetByPageNum(pageNum: number, pageSize: number) {
    if (!pageNum || !pageSize) return 0

    const intPageNum = Math.round(pageNum)
    const intPageSize = Math.round(pageSize)
    if (intPageNum < 1 || intPageSize < 0) return 0

    return (intPageNum - 1) * intPageSize
  }

  public getPageNum() {
    return this.pageNum
  }

  public setPageNum(pageNum: number) {
    this.pageNum = pageNum
  }

  public getPageSize() {
    return this.pageSize
  }

  public setPageSize(pageSize: number) {
    this.pageSize = pageSize
  }

  public getTotalCnt() {
    return this.totalCnt
  }

  public setTotalCnt(totalCnt: number) {
    this.totalCnt = totalCnt
  }

  public getList() {
    return this.list
  }

  public setList(list: Partial<T>[]) {
    this.list = list
  }

  private processPageNum(pageNum?: number) {
    if (!pageNum || pageNum < 1) {
      return 1
    }
    return Math.round(pageNum)
  }

  private processPageSize(pageSize?: number) {
    if (!pageSize || pageSize < 1) {
      return 20
    }
    return Math.round(pageSize)
  }

  private processTotalCnt(totalCnt?: number) {
    if (!totalCnt || totalCnt < 1) {
      return 0
    }
    return Math.round(totalCnt)
  }
}
