import * as HTTP from '~/aram-lib/constants/http'
import { DateHelper } from '~/aram-lib/helper/date-helper'
import { CryptoHelper } from '~/aram-lib/helper/crypto-helper'

export abstract class AbstractCredentialService {
  private _clientId: string
  private _clientSecret: string

  public set clientId(value: string) {
    if (typeof value !== 'string') {
      throw new Error(`empty clientId`)
    }
    this._clientId = value
  }

  public set clientSecret(value: string) {
    if (typeof value !== 'string') {
      throw new Error(`empty clientSecret`)
    }
    this._clientSecret = value
  }

  /**
   * 生成签名 并添加至 header
   * https://km.sankuai.com/page/28107651
   * @param credential 认证信息
   * @param date
   * @returns
   */
  protected _authorization(authorization: AuthorizationModel, date: Date) {
    const { api, method } = authorization
    authorization.headers[HTTP.HeaderEnum.DATE] = DateHelper.rfc822(date)
    authorization.headers[HTTP.HeaderEnum.CONTENT_TYPE] = 'application/json; charset=utf-8'

    const datestr = DateHelper.rfc822(date)
    const str2sign = `${method} ${api}\n${datestr}`
    const signature = this.sign(this._clientSecret, str2sign)
    authorization.headers[HTTP.HeaderEnum.AUTHORIZATION] = `MWS ${this._clientId}:${signature}`
  }

  private sign(secret: string, data: string) {
    return CryptoHelper.hmac(secret, data, 'base64', 'sha1')
  }
}
