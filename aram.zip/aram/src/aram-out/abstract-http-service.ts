import { request as requestHttp } from 'http'
import { request as requestHttps, RequestOptions } from 'https'
import * as HTTP from '~/aram-lib/constants/http'
import { AramLogger } from '~/aram-lib/model/aram-logger'

export abstract class AbstractHttpService {
  protected _request(options: RequestOptions, payload = '') {
    const isGetMethod = options.method === HTTP.MethodEnum.GET
    const isHttps = options.port === HTTP.ProtocalEnum.HTTPS
    const request = isHttps ? requestHttps : requestHttp
    return new Promise((resolve, reject) => {
      const opt = {
        ...options,
        headers: {
          ...(!isGetMethod ? { [HTTP.HeaderEnum.CONTENT_LENGTH]: Buffer.byteLength(payload) } : {}),
          ...(options.headers || {}),
        },
      }
      const req = request(opt, res => {
        res.setEncoding('utf-8')
        const buffer: any[] = []
        res.on('data', chunk => buffer.push(Buffer.from(chunk)))
        res.on('end', () => {
          const data = Buffer.concat(buffer).toString()
          try {
            const parsedData = JSON.parse(data)
            resolve(parsedData)
          } catch (e) {
            AramLogger.logError(`some error occurred during data transforming`, { data })
            reject(e)
          }
        })
      })
      req.on('error', e => {
        AramLogger.logError('request failed', e)
      })
      if (!isGetMethod) {
        req.write(payload)
      }
      req.end()
    })
  }
}
