import assert from 'assert'
const Tair = require('@mtfe/node-tair-promise')

import { AramLogger } from '~/aram-lib/model/aram-logger'
import { KMSConfigKeyEnum, KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'

interface CellarType {
  get: (key: string) => Promise<any>
  set: (key: string, value: any) => Promise<any>
  vset: (key: string, value: any, version: any) => Promise<any>
  mget: (keys: string[]) => Promise<any>
  remove: (key: string) => Promise<any>
  isReady: boolean
}

interface WrappedResult<T = null> {
  version?: string
  data: T
}
interface Global {
  namespace: ReturnType<typeof setNamespace>
  cellar: CellarType | null
}

const GLOBAL: Global = {
  namespace: {} as ReturnType<typeof setNamespace>,
  cellar: null,
}

const initTair = async () => {
  const [appKey, groupName, area] = await Promise.all([
    KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.CellarAppKey),
    KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.CellarGroupName),
    KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.CellarArea),
  ])
  const client = new Tair(groupName, appKey, {})
  const tairReady = await client.ready()
  return {
    get: (key: any) => client.get(key, area),
    set: (key: any, value: any) => client.set(key, value, 0, area),
    vset: (key: any, value: any, version: any) => client.set(key, value, 0, area, version),
    mget: (keys: any) => client.mget(keys, area),
    remove: (key: any) => client.remove(key, area),
    isReady: tairReady,
  }
}

/** 生成版本号 */
const buildVersion = () => new Date().toISOString()

const setNamespace = (moduleName: string) => {
  const prefix = `hfe::aram::${moduleName}`
  return {
    itemPrefix: `${prefix}::item`,
    confPrefix: `${prefix}::conf`,
  }
}

export const setup = async (cellar: CellarType | null, namespace: string) => {
  if (!GLOBAL.cellar && cellar) {
    GLOBAL.cellar = cellar
  } else if (!GLOBAL.cellar) {
    GLOBAL.cellar = await initTair()
  }
  GLOBAL.namespace = setNamespace(namespace)
}

/** 存 */
export const saveItem = async <T>(itemName: string, itemValue: T | WrappedResult<T>) => {
  try {
    assert.ok(!!itemName.length, 'empty tair key')
    assert.ok(!!GLOBAL.cellar, 'cellar initialized failed')

    /** version */
    let finalValue: WrappedResult<T>
    if ((itemValue as any)?.version) {
      const { data } = itemValue as WrappedResult<T>
      finalValue = { data, version: buildVersion() }
    } else {
      finalValue = { data: itemValue as T, version: buildVersion() }
    }

    /** save */
    const data = await GLOBAL.cellar.vset(`${GLOBAL.namespace.itemPrefix}::${itemName}`, JSON.stringify(finalValue), finalValue.version)
    AramLogger.logInfo(`save item successfully`, { itemName })
    return data
  } catch (error) {
    AramLogger.logError(`save ${itemName} failed, ${error.message}`, { itemValue })
    throw error
  }
}

/** 取 */
export const getItem = async <T = null>(itemName: string) => {
  try {
    assert.ok(!!GLOBAL.cellar, 'cellar initialized failed')

    const key = `${GLOBAL.namespace.itemPrefix}::${itemName}`
    const res = await GLOBAL.cellar.get(key)

    assert.ok(!!res, `cellar item [${key}] not exists`)

    AramLogger.logInfo(`get item successfully`, { itemName })
    const parsedData = JSON.parse(res)
    if ('version' in parsedData) {
      const { data } = parsedData as WrappedResult<T>
      return data
    }
    return parsedData as T
  } catch (error) {
    AramLogger.logError(`get ${itemName} failed, ${error.message}`)
    return error
  }
}
