import { DateHelper } from '~/aram-lib/helper/date-helper'
import { CraneService } from '../../crane-service'

describe('aram-out/crane/crane-http-service', () => {
  it('should be defined', () => {
    expect(CraneService).toBeDefined()
  })

  // it('should create http task', async () => {
  //   const crane = new CraneService()
  //   const current = DateHelper.timestamp()
  //   const target = new Date(current + 300000)

  //   const taskId = await crane.createTask({
  //     taskName: `unittest_create_task_${DateHelper.timestamp(target)}`,
  //     date: target,
  //     creator: 'wangdeyun',
  //     description: '测试一下',
  //   })

  //   expect(taskId).toMatch(/^task_[\d]+$/)
  // })

  // it('should update http task', async () => {
  //   const crane = new CraneService()
  //   const current = DateHelper.timestamp()
  //   const target = new Date(current + 600000)

  //   const taskId = 'task_1555414481285202009'

  //   const { taskid } = await crane.updateTask(taskId, {
  //     date: target,
  //     description: '一次性更新测试一下',
  //   })

  //   expect(taskid).toEqual(taskId)
  // })

  // it('should destroy http task', async () => {
  //   const crane = new CraneService()
  //   const taskId = 'task_1555418610413920353'

  //   const id = await crane.destroyTask(taskId)
  //   expect(id).toEqual(taskId)
  // })
})
