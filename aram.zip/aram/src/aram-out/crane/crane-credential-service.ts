import { AbstractCredentialService } from '../abstract-credential-service'

export class CraneCredentialService extends AbstractCredentialService {
  constructor() {
    super()
  }

  authorization(authorization: AuthorizationModel, date: Date) {
    this._authorization(authorization, date)
  }
}
