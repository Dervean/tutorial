import { RequestOptions } from 'http'
import * as CraneClient from '@dp/crane-client'
import * as HTTP from '~/aram-lib/constants/http'
import { DateHelper } from '~/aram-lib/helper/date-helper'
import { AramHttpRequestError } from '~/aram-lib/model/aram-error/server/aram-http-request-error'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AbstractHttpService } from '../abstract-http-service'
import { KMSConfigKeyEnum, KMSSecretManageService } from '../kms/kms-secret-manage-service'
import { CraneCredentialService } from './crane-credential-service'
import { APP_KEY } from '~/aram-lib/config'

export class CraneService extends AbstractHttpService {
  private credentialService: CraneCredentialService = null
  private hostname: string
  private port: number

  public static addJob(jobName: string, handler: (task: CraneScheduleTask) => Promise<unknown>) {
    CraneClient.addJob(jobName, {
      handle: (task: CraneScheduleTask) => handler(task),
      appname: APP_KEY,
    })
  }

  public async createTask(payload: CraneHttpPayload) {
    try {
      await this.setup()
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: '/v2/tasks',
        path: '/v2/tasks',
        method: HTTP.MethodEnum.POST,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const data = {
        taskName: payload.taskName,
        crontab: payload.crontab || this.crontab(payload.date),
        creator: payload.creator,
        description: payload.description,
      }
      const taskId = await this.request(authorization, JSON.stringify(data))
      AramLogger.logInfo(`创建 Crane 任务成功: taskId=${taskId}`)
      return taskId as string
    } catch (error) {
      AramLogger.logError('创建 Crane 任务失败', { payload })
      throw error
    }
  }

  public async getTask(taskId: string) {
    try {
      await this.setup()
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/v2/tasks/${taskId}`,
        path: `/v2/tasks/${taskId}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const task = await this.request({ ...authorization })
      AramLogger.logInfo(`获取 Crane 任务成功: taskId=${taskId}`)
      return task as CraneTaskModel
    } catch (error) {
      AramLogger.logError('获取 Crane 任务失败', { taskId })
      throw error
    }
  }

  public async updateTask(taskId: string, payload: Pick<CraneHttpPayload, 'date' | 'description' | 'crontab'>) {
    try {
      if (!payload.date && !payload.description && !payload.crontab) {
        AramLogger.logWarning(`无输入, 跳过更新 Crane 任务: taskId=${taskId}, payload=${JSON.stringify(payload)}`)
        return
      }
      await this.setup()
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/v2/tasks/${taskId}`,
        path: `/v2/tasks/${taskId}`,
        method: HTTP.MethodEnum.PUT,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const data = {
        crontab: payload.crontab || this.crontab(payload.date),
        description: payload.description,
      }
      const res = await this.request(authorization, JSON.stringify(data))
      AramLogger.logInfo(`更新 Crane 任务成功: taskId=${taskId}, payload=${JSON.stringify(payload)}`)
      return res as CraneTaskModel
    } catch (error) {
      AramLogger.logError('更新 Crane 任务失败', { taskId, payload })
      throw error
    }
  }

  public async destroyTask(taskId: string) {
    try {
      await this.setup()
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/v2/tasks/${taskId}`,
        path: `/v2/tasks/${taskId}`,
        method: HTTP.MethodEnum.DELETE,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const id = await this.request(authorization)
      AramLogger.logInfo(`销毁 Crane 任务成功: taskId=${taskId}`)
      return id as string
    } catch (error) {
      AramLogger.logError('销毁 Crane 任务失败', { taskId })
      throw error
    }
  }

  private async setup() {
    if (this.credentialService === null) {
      const [clientId, clientSecret, hostname, port] = await Promise.all([
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.CraneClientId),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.CraneClientSecret),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.CraneHostName),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.CraneHostPort),
      ])
      this.credentialService = new CraneCredentialService()
      this.credentialService.clientId = clientId
      this.credentialService.clientSecret = clientSecret
      this.hostname = hostname
      this.port = +port
    }
  }

  private async request(options: RequestOptions, payload?: string) {
    return this._request(options, payload).then((res: { message?: string; data: unknown; status: number }) => {
      const { status, message, data } = res || {}
      if (status === 0) {
        return data
      }
      throw new AramHttpRequestError(`Crane 请求失败: status=${status}, message=${message}`)
    })
  }

  public customCronTab(params: { month?: number; day?: number; hour?: number; minite?: number; second?: number }) {
    const { month, day, hour } = params
  }

  private crontab(date: Date) {
    const second = date.getSeconds()
    const minute = date.getMinutes()
    const hour = date.getHours()
    const day = date.getDate()
    const month = date.getMonth() + 1
    return `${second} ${minute} ${hour} ${day} ${month} ?`
  }
}
