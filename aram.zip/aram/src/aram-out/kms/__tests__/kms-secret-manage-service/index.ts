import { KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'

describe('aram-out/kms/kms-secret-manage-service', () => {
  it('should be defined', () => {
    expect(KMSSecretManageService).toBeDefined()
  })

  it('should return mss config', async () => {
    const config = await KMSSecretManageService.fetchMSSConfig()
    expect(config).toMatchObject({
      akClient: expect.stringMatching(/.+/),
      skClient: expect.stringMatching(/.+/),
      akServer: expect.stringMatching(/.+/),
      skServer: expect.stringMatching(/.*/),
      bucket: expect.stringMatching(/.+/),
      endpointSH: expect.stringMatching(/.+/),
      endpointBJ: expect.stringMatching(/.+/),
      objectUrlSH: expect.stringMatching(/.+/),
      objectUrlBJ: expect.stringMatching(/.+/),
    })
  })
})
