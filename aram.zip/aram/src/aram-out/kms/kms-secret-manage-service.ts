import assert from 'assert'
// @ts-ignore
import { getKeyByName } from '@dp/node-kms'
import { APP_KEY } from '~/aram-lib/config'
import { AramKMSError } from '~/aram-lib/model/aram-error/server/aram-kms-error'
import { AramLogger } from '~/aram-lib/model/aram-logger'

export interface MSSConfig {
  akClient: string
  skClient: string
  akServer: string
  skServer: string
  bucket: string
  endpointBJ: string
  endpointSH: string
  objectUrlBJ: string
  objectUrlSH: string
}

export enum KMSConfigKeyEnum {
  /** 大象应用号 */
  XmPubId = 'xm_pub_id',
  XmKey = 'xm_key',
  XmToken = 'xm_token',

  /** ORG */
  OrgClientId = 'org_client',
  OrgClientSecret = 'org_secret',
  OrgHostName = 'org_hostname',
  OrgHostPort = 'org_hostport',

  /** Cellar */
  CellarGroupName = 'cellar_group_name',
  CellarAppKey = 'cellar_app_key',
  CellarArea = 'cellar_area',

  /** Encryption */
  EncryptionAramAesIv = 'encryption_aram_aes_iv',
  EncryptionAramAesKey = 'encryption_aram_aes_key',
  EncryptionSdkAesIv = 'encryption_sdk_aes_iv',
  EncryptionSdkAesKey = 'encryption_sdk_aes_key',

  /** RDS */
  RdsConnType = 'rds_conn_type',
  RdsRouteType = 'rds_route_type',
  RdsJdbcRef = 'rds_jdbcref',

  /** Crane */
  CraneClientId = 'crane_client_id',
  CraneClientSecret = 'crane_client_secret',
  CraneHostName = 'crane_hostname',
  CraneHostPort = 'crane_hostport',
}

interface KMSConfigValueType {
  /** 大象应用号 */
  [KMSConfigKeyEnum.XmPubId]: string
  [KMSConfigKeyEnum.XmKey]: string
  [KMSConfigKeyEnum.XmToken]: string

  /** ORG */
  [KMSConfigKeyEnum.OrgClientId]: string
  [KMSConfigKeyEnum.OrgClientSecret]: string
  [KMSConfigKeyEnum.OrgHostName]: string
  [KMSConfigKeyEnum.OrgHostPort]: string

  /** Cellar */
  [KMSConfigKeyEnum.CellarGroupName]: string
  [KMSConfigKeyEnum.CellarAppKey]: string
  [KMSConfigKeyEnum.CellarArea]: string

  /** Encryption */
  [KMSConfigKeyEnum.EncryptionAramAesIv]: string
  [KMSConfigKeyEnum.EncryptionAramAesKey]: string
  [KMSConfigKeyEnum.EncryptionSdkAesIv]: string
  [KMSConfigKeyEnum.EncryptionSdkAesKey]: string

  /** RDS */
  [KMSConfigKeyEnum.RdsConnType]: 'mysql' | 'mariadb'
  [KMSConfigKeyEnum.RdsRouteType]: 'master-only' | 'master-slave' | 'slave-only'
  [KMSConfigKeyEnum.RdsJdbcRef]: string

  /** Crane */
  [KMSConfigKeyEnum.CraneClientId]: string
  [KMSConfigKeyEnum.CraneClientSecret]: string
  [KMSConfigKeyEnum.CraneHostName]: string
  [KMSConfigKeyEnum.CraneHostPort]: string
}

type ValueOf<T, Key extends keyof T> = T[Key]

export class KMSSecretManageService {
  static async fetchConfigValue<Key extends KMSConfigKeyEnum>(key: Key) {
    try {
      const value = await getKeyByName(APP_KEY, key)
      assert.ok(!!value.length, `获取 KMS 失败: key=${key}, value=${value}`)
      return value as ValueOf<KMSConfigValueType, Key>
    } catch (error) {
      AramLogger.logError(`fetch ${key} failed, message=${error.message}`)
      throw new AramKMSError(error.message)
    }
  }

  static async fetchMSSConfig() {
    try {
      AramLogger.logInfo(`start fetch mss kms config`)
      const [akClient, skClient, akServer, skServer, bucket, endpointBJ, endpointSH, objectUrlBJ, objectUrlSH] = await Promise.all([
        getKeyByName(APP_KEY, 'mss_client_access_key'),
        getKeyByName(APP_KEY, 'mss_client_secret_key'),
        getKeyByName(APP_KEY, 'mss_service_access_key'),
        getKeyByName(APP_KEY, 'mss_service_secret_key'),
        getKeyByName(APP_KEY, 'mss_bucket'),
        getKeyByName(APP_KEY, 'mss_endpoint_beijing'),
        getKeyByName(APP_KEY, 'mss_endpoint_shanghai'),
        getKeyByName(APP_KEY, 'mss_object_url_beijing'),
        getKeyByName(APP_KEY, 'mss_object_url_shanghai'),
      ])
      AramLogger.logInfo(`fetch mss kms config successfully`)

      return { akClient, skClient, akServer, skServer, bucket, endpointBJ, endpointSH, objectUrlBJ, objectUrlSH } as MSSConfig
    } catch (error) {
      AramLogger.logFatal(`fetch mss kms config failed`, error.message)
      throw new AramKMSError()
    }
  }
}
