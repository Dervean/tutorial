const lion = require('@dp/lion-client')

import { APP_KEY } from '~/aram-lib/config'
import { AramLionError } from '~/aram-lib/model/aram-error/server/aram-lion-error'
import { AramLogger } from '~/aram-lib/model/aram-logger'

export enum LionConfigKeyEnum {
  /** CDN 迁移白名单 */
  CdnMigrationWhiteList = 'cdn_migration_white_list',

  /** 应用与 bucket 映射关系 */
  MSSAppBucketMap = 'mss_app_bucket_map',
  MSSEndPointSH = 'mss_endpoint_shanghai',
  MSSEndPointBJ = 'mss_endpoint_beijing',
  MSSObjectUrlSH = 'mss_object_url_shanghai',
  MSSObjectUrlBJ = 'mss_object_url_beijing',

  /** 审批流详情链接 */
  ApplySchemaReleaseFlowDetailHref = 'apply_schema_release_flow_detail_href',
  DynaEmbededPanelHref = 'dyna_embeded_panel_href',
}

interface LionConfigValueType {
  /** CDN 迁移白名单 */
  [LionConfigKeyEnum.CdnMigrationWhiteList]: number[]

  /** 应用与 bucket 映射关系 */
  [LionConfigKeyEnum.MSSAppBucketMap]: Record<string, string>
  [LionConfigKeyEnum.MSSEndPointSH]: string
  [LionConfigKeyEnum.MSSEndPointBJ]: string
  [LionConfigKeyEnum.MSSObjectUrlSH]: string
  [LionConfigKeyEnum.MSSObjectUrlBJ]: string

  /** 审批流详情链接 */
  [LionConfigKeyEnum.ApplySchemaReleaseFlowDetailHref]: string

  /** Dyna 配置面板连接 */
  [LionConfigKeyEnum.DynaEmbededPanelHref]: string
}

type ValueOf<T, Key extends keyof T> = T[Key]

export class LionClientService {
  static async fetchConfigValue<Key extends LionConfigKeyEnum>(key: Key) {
    const lionConfigJson = [LionConfigKeyEnum.CdnMigrationWhiteList, LionConfigKeyEnum.MSSAppBucketMap]
    try {
      let value = await lion.getProperty(`${APP_KEY}.${key}`, '')
      AramLogger.logInfo(`fetch successfully: ${key}=${value}`)
      if (lionConfigJson.includes(key)) {
        value = JSON.parse(value)
      }
      return value as ValueOf<LionConfigValueType, Key>
    } catch (error) {
      AramLogger.logError(`fetch ${key} failed`, { message: error.message })
      throw new AramLionError('获取 Lion 配置失败')
    }
  }
}
