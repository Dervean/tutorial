import { AramApplicationUidEnum } from '~/aram-base/enum/common'
import { CDNSourceEnum, S3StreamService } from '~/aram-out/mss/s3-stream-service'

describe('aram-out/mss/s3-stream-service', () => {
  it('should be defined', () => {
    expect(S3StreamService).toBeDefined()
  })

  it('should upload json file successfully', async () => {
    const appUid = AramApplicationUidEnum.Aram
    const source = CDNSourceEnum.BJ
    const file = '__tests__/aram-out/source.json'
    const content = {
      description: 'hello world',
    }

    const client = await S3StreamService.getInstance(appUid, source)
    const { filename } = await client.upload(file, content)

    expect(filename).toEqual(file)
  })

  it('should query json file successfully', async () => {
    const appUid = AramApplicationUidEnum.Aram
    const source = CDNSourceEnum.BJ
    const file = '__tests__/aram-out/source.json'

    const client = await S3StreamService.getInstance(appUid, source)
    const content = await client.query(file)

    expect(content.length).toBeGreaterThan(0)
  })

  it('should copy json file successfully', async () => {
    const appUid = AramApplicationUidEnum.Aram
    const source = CDNSourceEnum.BJ
    const sourceFile = '__tests__/aram-out/source.json'
    const targetFile = '__tests__/aram-out/target.json'

    const client = await S3StreamService.getInstance(appUid, source)
    const { filename } = await client.copy(sourceFile, targetFile)

    expect(filename).toEqual(targetFile)
  })
})
