import { S3TokenService } from '~/aram-out/mss/s3-token-service'

describe('aram-out/mss/s3-token-service', () => {
  it('should be defined', () => {
    expect(S3TokenService).toBeDefined()
  })

  it('should return post token object', async () => {
    const postTokenService = new S3TokenService()
    const token = await postTokenService.genPostToken()

    expect(token).toMatchObject({
      accessKey: expect.stringMatching(/.+/),
      policy: expect.stringMatching(/.+/),
      signature: expect.stringMatching(/.+/),
      dir: expect.stringMatching(/.*/),
      expiration: expect.stringMatching(/.+/),
      bucketName: expect.stringMatching(/.+/),
      host: expect.stringMatching(/.+/),
      objectPath: expect.stringMatching(/.+/),
    })
  })
})
