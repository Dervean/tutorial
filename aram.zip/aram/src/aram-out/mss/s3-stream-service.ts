const mss = require('mos-mss')

import { RequestOptions } from 'https'
import { ParamChecker } from '~/aram-biz/model/param-checker'
import { AramKMSError } from '~/aram-lib/model/aram-error/server/aram-kms-error'
import { AramLionError } from '~/aram-lib/model/aram-error/server/aram-lion-error'
import { AramS3Error } from '~/aram-lib/model/aram-error/server/aram-s3-error'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'
import { LionClientService, LionConfigKeyEnum } from '~/aram-out/lion/lion-client-service'
import * as HTTP from '~/aram-lib/constants/http'

interface MSSResponseError {
  Code: string
  Message: string
}

interface MSSResponse {
  code: number
  data: {
    content: string
  }
  error: MSSResponseError | null
}

interface MSSClient {
  putObject: (filename: string, buffer: Buffer, options?: RequestOptions) => Promise<MSSResponse>
  getBuffer: (filename: string) => Promise<MSSResponse>
  copyObject: (source: string, target: string) => Promise<MSSResponse>
  listObject: (options?: RequestOptions) => Promise<MSSResponse>
  deleteObject: (key: string, options?: RequestOptions) => Promise<MSSResponse>
}

export enum CDNSourceEnum {
  SH = 'SH',
  BJ = 'BJ',
}

class MSSClientWrapper {
  public appUid: AramUidType
  public source: CDNSourceEnum
  private bucket: string
  private client: MSSClient

  constructor(appUid: AramUidType, bucket: string, source: CDNSourceEnum, accessKeyId: string, accessKeySecret: string, endpoint: string) {
    this.appUid = appUid
    this.bucket = bucket
    this.source = source
    this.client = new mss({ accessKeyId, accessKeySecret, bucket, endpoint })
  }

  /**
   * 上传
   * @param filename e.g. test.json, schema/test.json
   * @param content
   * @returns
   */
  async upload(filename: string, content: Array<unknown> | Record<string, unknown>) {
    ParamChecker.checkS3Filename(filename)

    const result = await this.client.putObject(filename, Buffer.from(JSON.stringify(content)), {
      headers: {
        [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json; charset=utf-8',
        [HTTP.HeaderEnum.CACHE_CONTROL]: 'no-cache',
      },
    })

    if (!result) {
      throw new AramS3Error(`S3 上传文件失败: filename=${filename}`)
    }
    if (result.code !== 200) {
      AramLogger.logError(`result=${JSON.stringify(result)}`)
      throw new AramS3Error(`错误: filename=${filename}, errorCode=${result?.error?.Code}, errorMsg=${result?.error?.Message}`)
    }

    return {
      filename,
    }
  }

  /**
   * 下载
   * @param filename e.g. test.json, schema/test.json
   * @returns
   */
  async query(filename: string) {
    ParamChecker.checkS3Filename(filename)

    const result = await this.client.getBuffer(filename)

    if (!result) {
      throw new AramS3Error(`S3 请求文件失败: filename=${filename}`)
    }
    if (result.code !== 200) {
      AramLogger.logError(`result=${JSON.stringify(result)}`)
      throw new AramS3Error(`错误: filename=${filename}, errorCode=${result?.error?.Code}, errorMsg=${result?.error?.Message}`)
    }

    return result.data.content
  }

  async queryJson(filename: string) {
    ParamChecker.checkS3Filename(filename)

    const content = await this.query(filename)
    return JSON.parse(content) as AramJsonType
  }

  /**
   * 拷贝
   * @param source e.g. test.json, schema/test.json
   * @param target e.g. test.json, schema/test.json
   */
  async copy(source: string, target: string) {
    ParamChecker.checkS3Filename(source)
    ParamChecker.checkS3Filename(target)

    const sourceEsp = this.escapedS3Filename(source)
    const targetEsp = this.escapedS3Filename(target)
    const sourcePath = `/${this.bucket}/${sourceEsp}`
    const targetPath = `/${this.bucket}/${targetEsp}`

    const result = await this.client.copyObject(sourcePath, targetPath)

    if (!result) {
      throw new AramS3Error(`S3 拷贝文件失败: source=${source}, target=${target}`)
    }
    if (result.code !== 200) {
      AramLogger.logError(`result=${JSON.stringify(result)}`)
      throw new AramS3Error(
        `错误: source=${source}, target=${target}, code=${result.code}, errorCode=${result?.error?.Code}, errorMsg=${result?.error?.Message}`,
      )
    }

    return {
      filename: target,
    }
  }

  private escapedS3Filename(filename: string) {
    return filename.replace(/\+/g, '%2B')
  }
}

export class S3StreamService {
  private static singleton: S3StreamService
  private pool: MSSClientWrapper[]

  constructor() {
    this.pool = []
  }

  private async init() {
    const [{ akClient, skClient }, [endPointBJ, endPointSH, bucketMap]] = await Promise.all([
      KMSSecretManageService.fetchMSSConfig().catch(err => {
        throw new AramKMSError(err.message)
      }),
      Promise.all([
        LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSEndPointBJ),
        LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSEndPointSH),
        LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAppBucketMap),
      ]).catch(err => {
        throw new AramLionError(err.message)
      }),
    ])
    return {
      accessKeyId: akClient,
      accessKeySecret: skClient,
      endPointBJ,
      endPointSH,
      bucketMap,
    }
  }

  public static async getInstance(appUid: AramUidType, source: CDNSourceEnum) {
    if (!this.singleton) {
      this.singleton = new S3StreamService()
    }
    const instance = this.singleton.pool.find(inst => inst.appUid === appUid && inst.source === source)
    if (instance) {
      return instance
    }

    const cfg = await this.singleton.init()

    let endpoint: string
    switch (source) {
      case CDNSourceEnum.BJ:
        endpoint = cfg.endPointBJ
        break
      case CDNSourceEnum.SH:
        endpoint = cfg.endPointSH
        break
      default:
        throw new AramS3Error(`未知集群: source=${source}`)
    }

    const bucket = cfg.bucketMap[appUid]
    if (!bucket) {
      throw new AramS3Error(`应用桶未创建: appUid=${appUid}, source=${source}`)
    }

    const candidate = new MSSClientWrapper(appUid, bucket, source, cfg.accessKeyId, cfg.accessKeySecret, endpoint)
    this.singleton.pool.push(candidate)
    return candidate
  }
}
