import { CryptoHelper } from '~/aram-lib/helper/crypto-helper'
import { DateHelper } from '~/aram-lib/helper/date-helper'
import { MSSConfig, KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'

export class S3TokenService {
  private expirationTime: number
  private config: MSSConfig = null

  constructor(expirationTime = DateHelper.MS_PER_MINUTE * 5) {
    this.expirationTime = expirationTime
  }

  private async init() {
    if (this.config) return
    this.config = await KMSSecretManageService.fetchMSSConfig()
  }

  async genPostToken(dir = '') {
    await this.init()

    // todo
    const { skServer: secretKey, akServer: accessKey, endpointBJ: host, objectUrlBJ, bucket: bucketName } = this.config
    const expiration = this.expiration()
    const policy = this.policy(bucketName, expiration, dir)
    const signature = this.sign(secretKey, policy)
    const objectPath = `${objectUrlBJ}/${bucketName}/${dir}`
    return { accessKey, policy, signature, dir, expiration, bucketName, host, objectPath }
  }

  private policy(bucket: string, expiration: string, dir: string) {
    const policy = {
      conditions: [{ bucket }, ['starts-with', '$key', `${dir}`]],
      expiration,
    }
    return Buffer.from(JSON.stringify(policy)).toString('base64')
  }

  private expiration() {
    const current = DateHelper.timestamp()
    return DateHelper.iso8601(current + this.expirationTime)
  }

  private sign(secret: string, data: string) {
    return CryptoHelper.hmac(secret, data, 'base64', 'sha1')
  }
}
