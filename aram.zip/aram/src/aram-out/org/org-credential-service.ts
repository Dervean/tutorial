import * as HTTP from '~/aram-lib/constants/http'
import { AbstractCredentialService } from '../abstract-credential-service'

export class ORGCredentialService extends AbstractCredentialService {
  constructor() {
    super()
  }

  authorization(authorization: AuthorizationModel, date: Date) {
    this._authorization(authorization, date)
    authorization.headers[HTTP.HeaderEnum.ORG_DATA_SCOPE] = 'tenantId=1;sources=ALL'
  }
}
