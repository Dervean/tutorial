import { ORGCredentialService } from '~/aram-out/org/org-credential-service'
import * as HTTP from '~/aram-lib/constants/http'
import { AramLogger } from '~/aram-lib/model/aram-logger'
import { AramUserNotFoundError } from '~/aram-lib/model/aram-error/not-found/aram-user-not-found-error'
import { KMSSecretManageService, KMSConfigKeyEnum } from '~/aram-out/kms/kms-secret-manage-service'
import { DateHelper } from '~/aram-lib/helper/date-helper'
import { AbstractHttpService } from '../abstract-http-service'
import { AramHttpRequestError } from '~/aram-lib/model/aram-error/server/aram-http-request-error'
import { RequestOptions } from 'https'

export interface OrgEmpInfo {
  tenantId: number // 1
  source: string // MT
  empId: string
  mis: string
  name: string
}

export class ORGEmployeeService extends AbstractHttpService {
  private credentialService: ORGCredentialService = null
  private hostname: string = null
  private port: number = null

  private async init() {
    if (this.credentialService === null) {
      const [clientId, clientSecret, hostname, port] = await Promise.all([
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.OrgClientId),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.OrgClientSecret),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.OrgHostName),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.OrgHostPort),
      ])
      this.credentialService = new ORGCredentialService()
      this.credentialService.clientId = clientId
      this.credentialService.clientSecret = clientSecret
      this.hostname = hostname
      this.port = +port
    }
  }

  private async request(options: RequestOptions, payload?: string) {
    return this._request(options, payload).then((res: { message?: string; data: unknown }) => {
      if (!res || res.message) {
        throw new AramHttpRequestError(`ORG 请求失败: message=${res.message}`)
      }
      return res.data
    })
  }

  /**
   * 根据 ID 查询单个员工
   * @param empId
   * @returns
   */
  async queryByEmpId(empId: string) {
    try {
      await this.init()
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/api/org2/emps/${empId}`,
        path: `/api/org2/emps/${empId}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const res = await this.request({ ...authorization })
      return res as OrgEmpInfo
    } catch (error) {
      AramLogger.logError('request org info failed', { empId })
      throw error
    }
  }

  /**
   * 根据 ID 批量查询员工
   * 上限 200
   * @param empIdList
   * @returns
   */
  async queryByEmpIdList(empIdList: string[]) {
    try {
      await this.init()
      const empIds = empIdList.join(',')
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/api/org2/emps/_batch`,
        path: `/api/org2/emps/_batch?empIds=${empIds}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const res = await this.request({ ...authorization })
      return res as OrgEmpInfo[]
    } catch (error) {
      AramLogger.logError('request org info failed', { empIdList })
      throw error
    }
  }

  /**
   * 根据 MIS 批量查询员工
   * 上限 200
   * @param empMisList
   * @returns
   */
  async queryByEmpMisList(empMisList: string[]) {
    try {
      await this.init()
      const mises = empMisList.join(',')
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/api/org2/emps/_batch`,
        path: `/api/org2/emps/_batch?mises=${mises}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const res = await this.request({ ...authorization })
      return res as OrgEmpInfo[]
    } catch (error) {
      AramLogger.logError('request org info failed', { empMisList })
      throw error
    }
  }

  /**
   * 根据 mis 查询单个员工
   * @param mis
   * @returns
   */
  async queryByEmpMis(mis: string) {
    try {
      const res = await this.queryByEmpMisList([mis])
      if (!res || !res.length) throw new AramUserNotFoundError(`数据不存在: mis=${mis}`)
      return res[0]
    } catch (error) {
      AramLogger.logError('request org info failed', { mis })
      throw error
    }
  }

  /**
   * 根据 mis 关键字搜索员工
   * 全匹配
   * @param fuzzyMis
   * @returns
   */
  async searchByEmpMis(fuzzyMis: string) {
    try {
      if (!fuzzyMis) return []

      await this.init()
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/api/org2/emps`,
        path: `/api/org2/emps?keyword=${fuzzyMis}&searchFields=mis&matchType=1`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const res = (await this.request({ ...authorization })) as { count: number; items: any[] }
      if (!res || !res.items) return []
      return res.items.map((e: any) => ({ mis: e.mis, name: e.name })) as OrgEmpInfo[]
    } catch (error) {
      AramLogger.logError('request org info failed', { fuzzyMis })
      throw error
    }
  }

  /**
   * 根据 name 关键字搜索员工
   * 全匹配
   * @param fuzzyName
   * @returns
   */
  async searchByEmpName(fuzzyName: string) {
    try {
      if (!fuzzyName) return []

      await this.init()
      const authorization: AuthorizationModel = {
        hostname: this.hostname,
        port: this.port,
        api: `/api/org2/emps`,
        path: encodeURI(`/api/org2/emps?keyword=${fuzzyName}&searchFields=name&matchType=1`),
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.credentialService.authorization(authorization, DateHelper.getDate())
      const res = (await this.request({ ...authorization })) as { count: number; items: any[] }
      if (!res || !res.items) return []
      return res.items.map((e: any) => ({ mis: e.mis, name: e.name })) as OrgEmpInfo[]
    } catch (error) {
      AramLogger.logError('request org info failed', { fuzzyName })
      throw error
    }
  }
}
