import * as HTTP from '~/aram-lib/constants/http'
import { DateHelper } from '~/aram-lib/helper/date-helper'
import { CryptoHelper } from '~/aram-lib/helper/crypto-helper'

export type RDSCredentialModel = {
  accessKey: string
  secretKey: string
  action: string
}

export type RDSAuthorizationModel = {
  headers: {
    [key in HTTP.HeaderEnum]?: any
  }
  hostname: string
  port: number
  path: string
  method: string
}

type RDSResponseModel = {
  code: number
  userMessage: string
  message: string
  data: any
  ctx: {
    requestId: string
    sentryEventId: null | string
  }
}

export class RDSAuthorizationService {
  private request: RDSAuthorizationModel

  constructor(authorization: RDSAuthorizationModel) {
    this.request = authorization
  }
  /**
   * 生成签名请求信息
   * https://km.sankuai.com/page/28107651
   * @param credential 认证信息
   * @param date
   * @returns
   */
  authorization(credential: RDSCredentialModel, date: Date) {
    const request = this.request as RDSAuthorizationModel

    const { accessKey, secretKey, action } = credential
    const { path } = request
    const datestr = DateHelper.rfc822(date)
    const str2sign = `POST ${path} ${action}\n${datestr}`

    const signature = this.sign(secretKey, str2sign)
    const authorization = `MWS ${accessKey}:${signature}`

    request.headers[HTTP.HeaderEnum.AUTHORIZATION] = authorization
    request.headers[HTTP.HeaderEnum.X_DATE] = datestr

    return request
  }
  private sign(secret: string, data: string) {
    return CryptoHelper.hmac(secret, data, 'base64', 'sha1')
  }
}
