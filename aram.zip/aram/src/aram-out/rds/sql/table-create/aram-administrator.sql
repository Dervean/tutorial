CREATE TABLE `aram_administrator`(
`user_id` int unsigned NOT NULL PRIMARY KEY COMMENT 'SSO 环境下为用户 ID',
`user_name` varchar(64) NOT NULL COMMENT 'SSO 环境下为 MIS 号',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
UNIQUE KEY (`user_id`, `user_name`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT '超级管理员表';