CREATE TABLE `aram_application`(
`app_uid` varchar(64) PRIMARY KEY NOT NULL COMMENT '应用场景标识, 应用场景表对应主键',
`app_name` varchar(64) NOT NULL COMMENT '应用场景名称',

`status` tinyint NOT NULL DEFAULT 0 COMMENT '状态',
`ext` JSON DEFAULT NULL COMMENT '外部配置',
`hooks` JSON DEFAULT NULL COMMENT '生命周期钩子配置',

`description` varchar(256) COMMENT '描述',
`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '应用场景表';
