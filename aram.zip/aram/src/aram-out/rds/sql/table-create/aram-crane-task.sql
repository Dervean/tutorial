CREATE TABLE `aram_crane_task` (
  `crane_task_id` varchar(128) NOT NULL,
  `crane_task_name` varchar(128) NOT NULL,
  `version` bigint unsigned NOT NULL COMMENT '版本号',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`crane_task_id`),
  UNIQUE KEY `uniq_crane_task_name_version`(`crane_task_name`, `version`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='定时任务表'

