CREATE TABLE `aram_custom_component_version`(
`component_version_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '自定义组件版本 ID, 自定义组件版本表对应主键',

`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',
`component_id` bigint unsigned NOT NULL COMMENT '自定义组件 ID',
`component_name` varchar(64) NOT NULL COMMENT '自定义组件名称',
`component_type` tinyint NOT NULL COMMENT '组件类型',
`version` bigint unsigned NOT NULL COMMENT '自定义组件版本号',
`schema` JSON NOT NULL COMMENT '自定义组件 配置项 JSON',
`bundle_md5` varchar(256) NOT NULL COMMENT '打包代码 MD5',

`bundle_link` varchar(256) COMMENT '打包代码 链接',
`previews` JSON COMMENT '预览信息',
`description` varchar(256) COMMENT '自定义组件版本描述',

`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
UNIQUE KEY (`component_id`, `bundle_md5`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '自定义组件版本表';
