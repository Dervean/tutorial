CREATE TABLE `aram_custom_component`(
`component_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '自定义组件ID, 自定义组件表对应主键',

`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',

`is_deleted` tinyint NOT NULL DEFAULT 0 COMMENT '是否删除',
`description` varchar(256) COMMENT '自定义组件描述',

`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',

`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '自定义组件表';