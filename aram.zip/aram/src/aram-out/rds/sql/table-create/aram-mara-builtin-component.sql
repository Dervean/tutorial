CREATE TABLE `aram_mara_builtin_component`(
`component_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT 'Mara 内置组件 ID, Mara 内置组件表 对应主键',
`component_name` varchar(256) NOT NULL COMMENT '内置组件名称',
`component_type` tinyint NOT NULL COMMENT '组件类型',
`schema` JSON NOT NULL COMMENT '内置组件 配置项 JSON',
`icon` varchar(512) COMMENT '组件图标资源',
`display_name` varchar(256) COMMENT '组件展示名称',
`description` varchar(256) COMMENT '组件描述',
`group` tinyint NOT NULL DEFAULT 0 COMMENT '分组',
`status` tinyint NOT NULL DEFAULT 0 COMMENT '状态',
`version` int unsigned NOT NULL DEFAULT 1 COMMENT '版本',
`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
UNIQUE KEY `idx_name_version`(`component_name`, `version`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT 'Mara 内置组件表';
