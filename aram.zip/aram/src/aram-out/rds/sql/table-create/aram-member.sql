CREATE TABLE `aram_member`(
`member_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '成员 ID, 成员信息表对应主键',
`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',
`user_name` varchar(64) NOT NULL COMMENT 'SSO 环境下为 MIS 号',
`permission` int unsigned NOT NULL COMMENT '权限 32-bit integer',

`is_deleted` tinyint NOT NULL DEFAULT 0 COMMENT '是否删除',
`join_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
`drop_time` datetime DEFAULT NULL COMMENT '退出时间',
UNIQUE KEY (`project_id`, `user_name`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '成员信息表';
