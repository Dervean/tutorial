CREATE TABLE `aram_module`(
`module_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '模块 ID, 项目模块表对应主键',
`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',
`app_uid` varchar(64) NOT NULL COMMENT '应用场景标识, 应用场景表对应主键',
`module_name` varchar(64) NOT NULL COMMENT '模块名称',

`is_deleted` tinyint NOT NULL DEFAULT 0 COMMENT '是否删除',
`description` varchar(256) COMMENT '模块描述',

`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',

`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '项目模块表';
