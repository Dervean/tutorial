CREATE TABLE `aram_project`(
`project_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '项目 ID, 项目表对应主键',
`project_name` varchar(64) NOT NULL COMMENT '项目名称',
`app_uid` varchar(64) NOT NULL COMMENT '应用场景标识, 应用场景表对应主键',

`is_private` tinyint NOT NULL DEFAULT 1 COMMENT '是否私有',
`is_deleted` tinyint NOT NULL DEFAULT 0 COMMENT '是否删除',
`description` varchar(256) COMMENT '项目描述',
`xattrs` JSON DEFAULT NULL COMMENT '应用扩展属性',

`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '项目表';
