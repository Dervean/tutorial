CREATE TABLE `aram_schema_draft`(
`schema_draft_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '配置草稿 ID, 配置草稿表对应主键',
`schema_id` bigint unsigned NOT NULL COMMENT '配置 ID',
`user_name` varchar(64) NOT NULL COMMENT 'SSO 环境下为 MIS 号',
`module_id` bigint unsigned NOT NULL COMMENT '模块 ID',
`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',
`schema` JSON NOT NULL COMMENT '配置草稿 JSON',

`sync_version` bigint unsigned DEFAULT NULL COMMENT '同步版本号',
`schema_name` varchar(64) DEFAULT NULL COMMENT '配置草稿名称',
`description` varchar(256) COMMENT '配置草稿描述',

`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
UNIQUE KEY (`schema_id`, `user_name`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '配置草稿表';