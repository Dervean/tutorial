CREATE TABLE `aram_schema_version`(
`schema_version_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '配置版本 ID, 配置版本表对应主键',
`schema_id` bigint unsigned NOT NULL COMMENT '配置 ID',
`module_id` bigint unsigned NOT NULL COMMENT '模块 ID',
`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',
`url` varchar(256) NOT NULL COMMENT 'S3 filename of schema JSON',
`version` bigint unsigned NOT NULL COMMENT '配置版本号',
`type` tinyint NOT NULL DEFAULT 0 COMMENT '发布类型',

`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',

`description` varchar(256) DEFAULT NULL COMMENT '配置描述',
`rollback_from` JSON DEFAULT NULL COMMENT '回滚自',
UNIQUE KEY (`schema_id`, `version`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '配置版本表';
