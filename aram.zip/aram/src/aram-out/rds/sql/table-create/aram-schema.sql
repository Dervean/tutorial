CREATE TABLE `aram_schema`(
`schema_id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '配置ID, 配置表对应主键',
`schema_uid` varchar(64) NOT NULL COMMENT '配置标识',
`module_id` bigint unsigned NOT NULL COMMENT '模块 ID',
`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',
`app_uid` varchar(64) NOT NULL COMMENT '应用场景标识, 应用场景表对应主键',
`schema_name` varchar(64) NOT NULL COMMENT '配置名称',

`is_deleted` tinyint NOT NULL DEFAULT 0 COMMENT '是否删除',
`description` varchar(256) COMMENT '配置描述',

`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
-- @todo 增加联合主键
-- UNIQUE KEY (`project_id`, `schema_uid`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '配置表';
