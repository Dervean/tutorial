CREATE TABLE `dyna_alert` (
  `crane_task_id` varchar(128) NOT NULL,
  `crane_task_name` varchar(128) NOT NULL,
  `schema_id` bigint(20) unsigned NOT NULL COMMENT '配置 ID',
  `notifiers` json COMMENT '提醒人 MIS 号数组',
  `remind_time` datetime NOT NULL COMMENT '提醒时间',
  `remark` varchar(128) COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  `state` tinyint NOT NULL COMMENT '状态',
  `state_desc` varchar(32) NOT NULL COMMENT '状态描述',
  `created_by` varchar(64) NOT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`crane_task_id`),
  UNIQUE KEY `idx_crane_task_name`(`crane_task_name`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Dyna 自动提醒表'

