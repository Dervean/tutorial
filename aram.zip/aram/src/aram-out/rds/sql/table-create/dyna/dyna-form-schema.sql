CREATE TABLE `dyna_form_schema`(
`id` bigint unsigned PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT 'ID, 自增主键',

`schema_id` bigint unsigned NOT NULL COMMENT 'Dyna 配置 ID',
`aram_schema_id` bigint unsigned NOT NULL COMMENT 'Aram 配置 ID',
`status` tinyint NOT NULL DEFAULT 0 COMMENT '状态',

`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
UNIQUE KEY (`schema_id`, `aram_schema_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT 'Dyna 表单配置表';
