CREATE TABLE `aram_schema_flow_history_order`(
-- order
`order_id` varchar(32) PRIMARY KEY NOT NULL COMMENT 'ID, 配置历史流程实例表对应主键',
`process_name` varchar(32) NOT NULL COMMENT '流程定义名称',
`state` tinyint NOT NULL COMMENT '状态',
`state_desc` varchar(32) NOT NULL COMMENT '状态描述',
`audit_state` tinyint COMMENT '审批状态',
`audit_state_desc` varchar(32) COMMENT '审批状态描述',
`creator` varchar(64) NOT NULL COMMENT '创建人',
`creator_remark` varchar(128) COMMENT '创建人备注',
-- schema
`schema_id` bigint unsigned NOT NULL COMMENT '配置ID, 配置表对应主键',
`app_uid` varchar(64) NOT NULL COMMENT '应用场景标识, 应用场景表对应主键',
`project_id` bigint unsigned NOT NULL COMMENT '项目 ID',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '配置历史流程实例表';
