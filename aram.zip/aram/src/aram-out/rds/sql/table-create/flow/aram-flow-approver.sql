CREATE TABLE `aram_flow_approver`(
`approver_id` varchar(32) PRIMARY KEY NOT NULL COMMENT '审核人 ID, 流程审核人表主键',
`order_id` varchar(32) NOT NULL COMMENT '流程实例 ID, 流程实例表主键',
`approver` varchar(64) NOT NULL COMMENT '审批人 MIS 号',
`approver_remark` varchar(128) DEFAULT NULL COMMENT '审批评论',
`audit_state` tinyint NOT NULL COMMENT '审批状态',
`audit_state_desc` varchar(32) NOT NULL COMMENT '审批状态描述',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '状态更新时间',
UNIQUE KEY `idx_approver`(`order_id`, `approver`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '流程审核人表';