CREATE TABLE `aram_flow_order`(
`order_id` varchar(32) PRIMARY KEY NOT NULL COMMENT '流程实例 ID, 流程实例表主键',
`process_id` varchar(32) NOT NULL COMMENT '流程定义 ID, 流程定义表主键',
`process_name` varchar(32) NOT NULL COMMENT '流程定义名称',
`state` tinyint NOT NULL COMMENT '状态',
`state_desc` varchar(32) NOT NULL COMMENT '状态描述',
`audit_state` tinyint COMMENT '审批状态',
`audit_state_desc` varchar(32) COMMENT '审批状态描述',
`creator` varchar(64) NOT NULL COMMENT '创建人',
`creator_remark` varchar(128) COMMENT '创建人备注',
`parent_id` varchar(32) COMMENT '父流程示例 ID',
`parent_node_name` varchar(32) COMMENT '父流程定义节点名称',
`variable` JSON COMMENT '变量',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '流程实例表';
