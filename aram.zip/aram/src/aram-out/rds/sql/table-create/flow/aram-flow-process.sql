CREATE TABLE `aram_flow_process`(
`process_id` varchar(32) PRIMARY KEY NOT NULL COMMENT '流程定义 ID, 流程定义表主键',
`name` varchar(32) NOT NULL COMMENT '流程定义名称',
`display_name` varchar(32) NOT NULL COMMENT '流程定义显示名称',
`status` tinyint NOT NULL COMMENT '状态',
`version` int unsigned NOT NULL COMMENT '版本',
`content` Blob COMMENT '流程定义 XML',
`created_by` varchar(64) NOT NULL COMMENT '创建人',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updated_by` varchar(64) DEFAULT NULL COMMENT '操作人',
`update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '流程定义表';
