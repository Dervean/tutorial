CREATE TABLE `aram_flow_task`(
`task_id` varchar(32) PRIMARY KEY NOT NULL COMMENT '流程任务 ID, 流程任务表主键',
`name` varchar(32) NOT NULL COMMENT '流程任务名称',
`display_name` varchar(32) NOT NULL COMMENT '流程任务显示名称',
`state` tinyint NOT NULL COMMENT '状态',
`state_desc` varchar(32) NOT NULL COMMENT '状态描述',
`order_id` varchar(32) NOT NULL COMMENT '流程实例 ID, 流程实例表主键',
`perform_type` varchar(8) NOT NULL COMMENT '任务类型',
`parent_task_id` varchar(32) COMMENT '父任务 ID',
`operator` varchar(64) COMMENT '处理人',
`actors` JSON COMMENT '参与人',
`variable` JSON COMMENT '变量',
`create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 COMMENT '流程任务表';
