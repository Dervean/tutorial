import Xm from '@mtfe/daxiang'

import { AramLogger } from '~/aram-lib/model/aram-logger'
import { KMSConfigKeyEnum, KMSSecretManageService } from '~/aram-out/kms/kms-secret-manage-service'

export class XmClientService {
  private static _client: any = null
  public static REGEX_GROUP = /^[0-9]+$/
  public static REGEX_PERSON = /^[a-z]+\.?[a-z]*[0-9]*$/

  public static async client() {
    if (this._client === null) {
      const [Key, PubId, Token] = await Promise.all([
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.XmKey),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.XmPubId),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.XmToken),
      ])
      this._client = new Xm({
        PubId,
        Key,
        Token,
      })
    }
    return this._client
  }

  constructor() {}

  public async sendTextMsg(msg: string, receivers: string[]) {
    const client = await XmClientService.client()
    if (!msg || receivers.length <= 0) {
      AramLogger.logWarning('消息格式错误', { msg, receivers })
      throw new Error(`消息格式错误 ${msg} ${receivers}`)
    }
    if (msg.length) {
      receivers.forEach(item => {
        const dxText = String(item).trim()
        // 大象通知MIS账号
        if (XmClientService.REGEX_PERSON.test(dxText)) {
          return client
            .send(client.text(msg, { bold: true, fontSize: 32 }), dxText)
            .then(() => {
              AramLogger.logInfo('消息推送成功', { msg, receivers })
              return
            })
            .catch((err: Error) => {
              AramLogger.logError(`消息推送失败: ${err.message}`)
              throw err
            })
        }
        // 大象通知群组
        if (XmClientService.REGEX_GROUP.test(String(dxText))) {
          return client
            .group(client.text(msg, { bold: true, fontSize: 32 }), Number(dxText))
            .then(() => {
              AramLogger.logInfo('消息推送成功', { msg, receivers })
              return
            })
            .catch((err: Error) => {
              AramLogger.logError(`消息推送失败: ${err.message}`)
              throw err
            })
        }
      })
    }
  }

  public async sendCustomMsg(msg: any, receiver: AramUserNameType) {
    const client = await XmClientService.client()
    return client.send(msg, receiver)
  }
}
