type AramIdType = number
type AramUidType = string
type AramUuidType = string
type AramUserNameType = string
type AramPermissionType = number
type AramPrimaryKeyType = string | number
type AramMaraComponentType = number
type AramComponentVersionType = number
type AramSchemaVersionType = number
type AramJsonType = Array<unknown> | Record<string, unknown>
type PagedResult<T> = {
  rows: Partial<T>[]
  totalCnt: number
}
