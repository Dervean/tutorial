declare module '@fdfe/ecf-http-adapter'
declare module '@mtfe/daxiang'
declare module '@mtfe/sso-client'
declare module '@mtfe/thrift'
