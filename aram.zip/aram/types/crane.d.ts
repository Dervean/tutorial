interface CraneHttpPayload {
  taskName?: string
  date?: Date
  crontab?: string
  creator?: string
  description?: string
}

interface CraneTaskModel {
  taskid: string
  name: string
}

interface CraneScheduleTask {
  type: string
  taskName: string
  jobUniqueCode: string
  traceId: string
  runState: number
  subTask: number
  taskItems: unknown[]
  shardItems: unknown[]
  shardCount: number
  callbackAddress: string[]
  runCommond: unknown
}
