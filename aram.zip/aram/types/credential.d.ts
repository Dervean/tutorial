interface AuthorizationModel {
  headers: {
    [key in HTTP.HeaderEnum]?: any
  }
  hostname?: string
  port?: number
  path?: string
  api?: string
  method?: string
  qs?: Record<string, unknown>
}
