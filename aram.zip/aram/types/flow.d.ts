type TextConditionType = 'Y' | 'N'
