# Iris

搭建 PaaS 通用服务基础能力

## 开发

### 安装

```bash
npm install @nibfe/iris
```

## 目录结构
```
.
├── README.md
├── iris                              通用能力引擎（数据模型定义和业务逻辑复用）
│   ├── iris-app                      控制层（请求模型定义）
│   ├── iris-base                     数据访问层（包括公共实体、对应的dao方法以及相关枚举）
│   ├── iris-biz                      业务逻辑层（包括公共业务逻辑，暴露通用能力引擎）
│   ├── iris-lib                      一些lib方法、error定义
│   ├── iris-out                      对接外部基建或者服务（例如kms、lion、S3、ORG）
│   ├── iris-flow                     工作流服务
│   └── iris-resource                 静态资源。例如服务配置和thrift idl定义
├── package-lock.json                 
├── package.json
├── gulpfile.ts                       gulp 构建
└── tsconfig.json
```

## 附录

### Nest Node 服务本地环境配置项

``` bash
# 1. 创建 /data 目录
# 如何在 mac 上配置 /data 路径: https://km.sankuai.com/page/584291320

# 2. Zebra 配置
# /data/webapps/appenv
env=test
deployenv=qa
zkserver=lion-zk.test.vip.sankuai.com:2181

# 3. Cat 配置
# /data/appdatas/cat/client.xml
<config>
  <servers>
    <server ip="10.72.204.18" port="2280" />
    <server ip="10.72.204.19" port="2280" />
    <server ip="10.72.234.28" port="2280" />
  </servers>
</config>

# 4. 创建日志目录
# /opt/logs/
# /data/applogs/cat
```
