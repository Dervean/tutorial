import { Gulpclass, Task, SequenceTask, MergedTask } from 'gulpclass'

import tar from 'tar'
import fs from 'fs-extra'
import gulp from 'gulp'
import { execSync } from 'child_process'
import { prompt } from 'enquirer'
import * as semver from 'semver'
import assert from 'assert'
import chalk from 'chalk'
import shell from 'gulp-shell'

@Gulpclass()
export class GulpFiles {
  private targetVersion: string

  @Task()
  async clean() {
    fs.removeSync('dist')
    fs.removeSync('iris.tgz')
  }

  @Task()
  async runTestSuit() {
    execSync('npm install && npm run test')
  }

  @Task()
  async compile() {
    execSync('npm install && tsc -p tsconfig.json')
  }

  @Task()
  async compileAlias() {
    execSync('npm install && tsc-alias -p tsconfig.json')
  }

  @Task()
  async packageCopyResource() {
    fs.copySync('./iris/iris-resource', './dist/iris-resource')
  }

  @Task()
  async packageCreateEsmIndex() {
    const distDir = './dist'
    const irisAppDir = 'iris-app'
    const irisBizDir = 'iris-biz'
    const irisBaseDir = 'iris-base'
    const irisFlowDir = 'iris-flow'
    const irisOutDir = 'iris-out'
    const irisLibDir = 'iris-lib'
    const indexMjsContent = `export * from './index.js'\n`

    fs.writeFileSync(`${distDir}/index.mjs`, indexMjsContent, 'utf8')
    fs.writeFileSync(`${distDir}/${irisAppDir}/index.mjs`, indexMjsContent, 'utf8')
    fs.writeFileSync(`${distDir}/${irisBizDir}/index.mjs`, indexMjsContent, 'utf8')
    fs.writeFileSync(`${distDir}/${irisBaseDir}/index.mjs`, indexMjsContent, 'utf8')
    fs.writeFileSync(`${distDir}/${irisFlowDir}/index.mjs`, indexMjsContent, 'utf8')
    fs.writeFileSync(`${distDir}/${irisOutDir}/index.mjs`, indexMjsContent, 'utf8')
    fs.writeFileSync(`${distDir}/${irisLibDir}/index.mjs`, indexMjsContent, 'utf8')
  }

  @Task()
  async packageGzip() {
    return tar
      .c(
        {
          gzip: true,
        },
        ['iris/'],
      )
      .pipe(fs.createWriteStream('./iris.tgz'))
  }

  @Task()
  async prompt() {
    const BETA = 'beta'
    const ALPHA = 'alpha'
    const DEV = 'dev'

    const types = [BETA, ALPHA, DEV]

    const genVersionChoices = (latestVersion: string, latestTag?: string) => {
      const choices: string[] = ['custom']

      if (latestTag) {
        const vnext = semver.inc(latestTag, 'prerelease', tag)
        vnext && choices.unshift(vnext)
      }
      const latestTagVersion = latestTag?.split('-')?.[0]

      if (latestTagVersion && semver.compare(latestTagVersion, latestVersion) === 1) {
        return choices
      }
      const vnext = semver.inc(latestVersion, 'prerelease', tag)
      vnext && choices.unshift(vnext)
      return choices
    }

    const tags = execSync('npm dist-tags @nibfe/iris')
      .toString('utf8')
      .split('\n')
      .filter(e => !!e)
      .map(e => {
        return e.split(': ')
      })
    const latest = tags.find(e => e[0] === 'latest')?.[1]
    assert.ok(!!latest, `fetch version list failed`)

    const { tag } = await prompt<{ tag: string }>({
      type: 'select',
      name: 'tag',
      message: 'select tag',
      choices: types,
    })

    const latestTag = tags.find(e => e[0] === tag)?.[1]

    let target = (
      await prompt<{ target: string }>({
        type: 'select',
        name: 'target',
        message: `current ${tag} version is ${latestTag || 'empty'}, current latest version is ${latest}, select release version`,
        choices: genVersionChoices(latest, latestTag),
      })
    ).target

    if (target === 'custom') {
      target = (
        await prompt<{ custom: string }>({
          type: 'input',
          name: 'custom',
          message: 'input custom version',
        })
      ).custom
    }

    if (!semver.valid(target)) {
      throw new Error(`invalid target version: ${target}`)
    }

    const { yes } = await prompt<{ yes: string }>({
      type: 'confirm',
      name: 'yes',
      message: `Are you sure you want to release v${target}?`,
    })

    if (!yes) {
      process.exit(0)
    }

    this.targetVersion = target
  }

  @Task()
  async packagePrerelease() {
    if (!semver.valid(this.targetVersion)) {
      throw new Error(`invalid target version: ${this.targetVersion}`)
    }
    const tag = semver.prerelease(this.targetVersion)?.[0]

    // prettier-ignore
    const branch = execSync('git rev-parse --abbrev-ref HEAD')
      .toString('utf8')
      .trim()

    console.log(chalk.cyan('\nUpdate package.json version...'))

    const pkg = JSON.parse(fs.readFileSync('./package.json', 'utf-8'))
    pkg.version = this.targetVersion
    fs.writeFileSync('./package.json', JSON.stringify(pkg, null, 2) + '\n')

    console.log(chalk.cyan('\nCommit changes...'))

    execSync('npm install')
    execSync('git add .')
    execSync(`git commit -m "release: v${this.targetVersion}"`)

    console.log(chalk.cyan('\nNPM publish...'))

    execSync(`npm --registry=http://r.npm.sankuai.com --cache=$HOME/.cache/mnpm --userconfig=$HOME/.mnpmrc publish --tag ${tag}`)

    console.log(chalk.green('\nNPM publish Success'))

    console.log(chalk.cyan('\nPush to Code...'))
    execSync(`git tag v${this.targetVersion}`)
    execSync(`git push origin refs/tags/v${this.targetVersion}`)
    execSync(`git push --set-upstream origin ${branch}`)

    console.log(chalk.green('\nPush to Code Success'))
  }

  @Task()
  async inspectCircular() {
    // prettier-ignore
    return gulp
      .src('package.json', { read: false })
      .pipe(shell([
        'npx madge --circular dist'
      ]))
  }

  @SequenceTask()
  package() {
    // prettier-ignore
    return [
      'clean',
      'compile',
      'compileAlias',
      ['packageCopyResource', 'packageCreateEsmIndex', 'packageGzip'],
    ]
  }

  @SequenceTask()
  prerelease() {
    return ['prompt', 'clean', 'runTestSuit', 'package', 'packagePrerelease']
  }

  @SequenceTask()
  madge() {
    return ['package', 'inspectCircular']
  }
}
