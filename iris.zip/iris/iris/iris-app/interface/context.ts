export interface Context {
  request?: any
  query?: any
  cookies?: any
  headers?: any
  body?: any
  set?: any
}
