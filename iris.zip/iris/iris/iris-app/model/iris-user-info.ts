export class IrisUserInfo {
  userId: string
  userName: string
  displayName: string

  public toJSON() {
    return {
      userId: this.userId,
      userName: this.userName,
      displayName: this.displayName,
    }
  }
}
