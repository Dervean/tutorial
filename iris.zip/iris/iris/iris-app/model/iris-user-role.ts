import { RoleTypeEnum } from 'iris/iris-biz/model/permission-builder'
import { IrisUserInfo } from 'iris/iris-app/model/iris-user-info'

export class IrisUserRole extends IrisUserInfo {
  role?: RoleTypeEnum

  public toJSON() {
    return {
      userId: this.userId,
      userName: this.userName,
      displayName: this.displayName,
      role: this.role,
    }
  }
}
