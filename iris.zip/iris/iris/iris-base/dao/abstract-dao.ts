import assert from 'assert'
import { createConnection, Connection, LoggerOptions, EntityTarget, ObjectType } from '@gfe/zebra-typeorm-client'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'
import { KMSSecretManageService, KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { IrisZebraError } from 'iris/iris-lib/model/iris-error'
import { ConfigHelper } from 'iris/iris-lib/helper/config-helper'

export type IrisSearchResult<T> = {
  rows: Partial<T>[]
  totalCnt: number
}

export type Columns<T> = {
  [key in keyof Omit<T, 'toJSON'>]: key
}

export interface IAbstractDAO<T> {
  /**
   * 插入一条或者多条数据
   * @param row
   */
  insert(row: T): Promise<T>

  /**
   * 插入多条数据
   * @param rows
   */
  insertMany(rows: T[]): Promise<T[]>

  /**
   * 主键删除
   * - 如果表上存在 status 字段，默认以 status 字段执行假删
   * - 否则物理删除
   * @param key
   * @param operator
   */
  deleteByPrimaryKey(key: string | number, operator?: string): Promise<void>
  /**
   * 根据主键更新数据
   * @param key
   * @param data
   */
  updateByPrimaryKey(key: string | number, data: Partial<T>): Promise<void>
  /**
   * 根据主键获取一条数据
   */
  getByPrimaryKey(key: string | number): Promise<T>
  /**
   * 根据主键列表获取一组数据
   */
  getByPrimaryKeyList(keys: (string | number)[]): Promise<T[]>
}

type IEntity<T> = ObjectType<T> & { columns: Columns<T> }

export abstract class AbstractDAO<T> implements IAbstractDAO<T> {
  public static entities: Array<Function> = null
  private static connection: Connection = null

  protected repository: EntityTarget<T>
  protected primaryKey: string
  protected tableName: string
  protected columns: Columns<T>

  protected _logger: IrisLogger = null

  public logger(): IrisLogger {
    if (this._logger === null) {
      this._logger = new IrisLogger()
    }
    return this._logger
  }

  public setLogger(logger: IrisLogger) {
    if (logger) {
      this._logger = logger
    }
  }

  protected setRepository(repository: IEntity<T>) {
    this.repository = repository
    this.tableName = AbstractDAO.getTableName(repository)
    this.columns = repository.columns
  }

  protected setPrimaryKey(primaryKey: string & keyof T) {
    this.primaryKey = primaryKey
  }

  protected async getRepository() {
    if (AbstractDAO.connection === null) {
      await AbstractDAO.initConnection()
    }
    if (!AbstractDAO.connection.isConnected) {
      await AbstractDAO.connection.connect()
    }
    return AbstractDAO.connection.getRepository<T>(this.repository)
  }

  public static getTableName<T>(repository: ObjectType<T>) {
    return StringHelper.transformFromCamelCase(repository.name, 'snake')
  }

  /**
   * 一般不使用
   * 通过事务执行多个 raw query
   * @param queryList
   * @returns
   */
  public static async runSQL(queryList: string[]) {
    const logger = new IrisLogger()
    try {
      if (AbstractDAO.connection === null) {
        await AbstractDAO.initConnection()
      }
      const queryRunner = AbstractDAO.connection.createQueryRunner()

      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        for (let i = 0; i < queryList.length; i++) {
          await queryRunner.manager.query(queryList[i])
        }
        await queryRunner.commitTransaction()
      } catch (e) {
        logger.logError(e, { message: 'transaction is failed', queryList })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      logger.logError(error, { queryList })
      throw error
    }
  }

  public static async initConnection() {
    const logger = new IrisLogger()
    try {
      assert.ok(this.entities !== null, `服务未注册 ORM 实体`)
      const [jdbcRef, routeType, type, logOptions] = await Promise.all([
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.RdsJdbcRef),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.RdsRouteType),
        KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.RdsConnType),
        LionClientService.fetchConfigValue(LionConfigKeyEnum.RdsLogOptions).catch(error => {
          logger.logInfo('没有 typeorm 日志选项')
          return null
        }),
      ])
      const appName = ConfigHelper.getAppKey()
      const DefaultLogOptions: LoggerOptions = ['error', 'query', 'schema', 'warn', 'info', 'log']
      AbstractDAO.connection = await createConnection({
        appName,
        jdbcRef,
        routeType,
        type,
        entities: AbstractDAO.entities,
        logging: logOptions || DefaultLogOptions,
      })
    } catch (error) {
      logger.logError(error, { message: `Zebra 链接失败` })
      throw new IrisZebraError(`服务异常: ${(error as Error).message}`)
    }
  }

  public static async closeConnection() {
    const logger = new IrisLogger()
    try {
      if (AbstractDAO.connection && AbstractDAO.connection.isConnected) {
        await AbstractDAO.connection.close()
        logger.logInfo(`zebra connection closed`)
      }
    } catch (error) {
      logger.logError(error, { message: `zebra connection close failed` })
      throw new IrisZebraError(`服务异常: ${(error as Error).message}`)
    }
  }

  public async insert(row: T) {
    const repo = await this.getRepository()
    const result = await repo
      .createQueryBuilder()
      .insert()
      .into(this.repository)
      .values([JSON.parse(JSON.stringify(row))])
      .execute()
    return result.identifiers[0] as T
  }

  public async insertMany(rows: T[]) {
    const repo = await this.getRepository()
    const result = await repo
      .createQueryBuilder()
      .insert()
      .into(this.repository)
      .values(JSON.parse(JSON.stringify(rows)))
      .execute()
    return result.identifiers as T[]
  }

  public async deleteByPrimaryKey(
    key: string | number,
    operator?: string,
    softDeleteParams = {
      statusField: 'status',
      updatedByField: 'updatedBy',
    },
  ) {
    const repo = await this.getRepository()
    const { updatedByField, statusField } = softDeleteParams || {}
    /**
     * 如果表上存在 status 字段，走假删逻辑
     */
    if (statusField in this.columns) {
      const hasUpdatedBy = updatedByField in this.columns
      const updated = {
        [`${statusField}`]: IrisStatusEnum.Inactive,
        ...(operator && hasUpdatedBy
          ? {
              [`${updatedByField}`]: operator,
            }
          : {}),
      }
      return this.updateByPrimaryKey(key, updated as Partial<T>)
    }
    /**
     * 物理删除
     */
    // prettier-ignore
    await repo
      .createQueryBuilder()
      .delete()
      .from(this.repository)
      .where(`${this.primaryKey} = :key`, { key })
      .execute()
    return
  }

  public async updateByPrimaryKey(key: string | number, data: Partial<T>) {
    try {
      const repo = await this.getRepository()
      const target = JSON.parse(JSON.stringify(data))
      // prettier-ignore
      const result = await repo
        .createQueryBuilder()
        .update(this.repository)
        .set(target)
        .where(`${this.primaryKey} = :key`, { key })
        .execute()

      if (result.affected !== 1) throw new IrisZebraError()
    } catch (error) {
      this.logger().logError(error, { key, data })
      throw error
    }
  }

  public async getByPrimaryKey(key: string | number): Promise<T> {
    try {
      const repo = await this.getRepository()

      // prettier-ignore
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.primaryKey} = :key`, { key })
        .getOne()

      return (result || null) as T
    } catch (error) {
      this.logger().logError(error, { key })
      throw error
    }
  }

  public async getByPrimaryKeyList(keys: (string | number)[]): Promise<T[]> {
    try {
      const repo = await this.getRepository()

      if (keys.length === 0) {
        return []
      }

      // prettier-ignore
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.primaryKey} IN (:keys)`, { keys })
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { keys })
      throw error
    }
  }
}
