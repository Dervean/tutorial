import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IAdministratorDAO<T> extends IAbstractDAO<T> {
  /**
   * 根据用户 org id 获取
   * @param userId
   */
  getByUserId(userId: string): Promise<T>
}
