import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IBaAuthDAO<T> extends IAbstractDAO<T> {
  /**
   * 获取全部 BA 秘钥对
   */
  getList(): Promise<T[]>
}
