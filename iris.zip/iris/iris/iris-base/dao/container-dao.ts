import { IrisSearchResult, IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IContainerDAO<T> extends IAbstractDAO<T> {
  /**
   * 分页搜索列表
   * @param offset
   * @param limit
   * @param filter
   */
  search(offset: number, limit: number, filter: Partial<T>): Promise<IrisSearchResult<T>>

  /**
   * 获取页面容器列表
   * @param filter
   */
  getContainerList(filter: Partial<T>): Promise<T[]>
}
