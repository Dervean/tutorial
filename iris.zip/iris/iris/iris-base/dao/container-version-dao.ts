import { IrisSearchResult, IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IContainerVersionDAO<T> extends IAbstractDAO<T> {
  /**
   * 分页搜索列表
   * @param offset
   * @param limit
   * @param filter
   */
  search(offset: number, limit: number, filter: Partial<T>): Promise<IrisSearchResult<T>>

  /**
   * 根据容器 id 获取最新容器版本
   * @param containerId
   * @param filter
   */
  getLatestVersionByContainerId(containerId: string, filter: Partial<T>): Promise<T>

  /**
   * 根据容器 id 和版本获取
   * @param containerId
   * @param version
   */
  getByContainerIdAndVersion(containerId: string, version: string): Promise<T>
}
