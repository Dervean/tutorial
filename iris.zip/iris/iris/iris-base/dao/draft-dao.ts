import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IDraftDAO<T> extends IAbstractDAO<T> {
  /**
   * 根据页面 id 和用户 id 获取
   * @param pageId
   * @param userId
   */
  getByPageIdAndUserId(pageId: string, userId: string): Promise<T>

  /**
   * 根据用户 id 批量获取草稿
   * @param userId
   * @param filter
   */
  getDraftListByUserId(userId: string, filter: Partial<T> & { pageIdList?: string[] }): Promise<T[]>
}
