import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisCanaryStateEnum } from 'iris/iris-base/enum/canary'

export interface IHtmlCanaryStrategyDAO<T> extends IAbstractDAO<T> {
  /**
   * 根据 orderId 获取灰度策略
   * @param orderId
   */
  getByOrderId(orderId: string): Promise<T>

  /**
   * 获取灰度策略列表
   * @param filter
   */
  getStrategyList(filter: Partial<T> & { states?: IrisCanaryStateEnum[] }): Promise<T[]>
}
