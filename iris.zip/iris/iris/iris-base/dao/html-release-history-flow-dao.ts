import { IrisSearchResult, IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisTargetEnvEnum, IrisPublishTypeEnum } from 'iris/iris-base/enum/common'

export interface IHtmlReleaseHistoryFlowDAO<T> extends IAbstractDAO<T> {
  /**
   * 分页搜索列表
   * @param offset
   * @param limit
   * @param filter
   * @returns
   */
  search(
    offset: number,
    limit: number,
    filter: Partial<T> & {
      createTimeBegin?: string
      createTimeEnd?: string
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
    },
  ): Promise<IrisSearchResult<T>>
}
