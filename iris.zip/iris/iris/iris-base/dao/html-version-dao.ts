import { IrisSearchResult, IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisTargetEnvEnum, IrisPublishTypeEnum } from 'iris/iris-base/enum/common'

export interface IHtmlVersionDAO<T> extends IAbstractDAO<T> {
  /**
   * 分页搜索列表
   * @param offset
   * @param limit
   * @param filter
   */
  search(
    offset: number,
    limit: number,
    filter: Partial<T> & {
      createTimeBegin?: string
      createTimeEnd?: string
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
    },
  ): Promise<IrisSearchResult<T>>

  /**
   * 根据页面 id 获取页面最新版本
   * @param pageId
   * @param filter 其他过滤参数
   */
  getLastestVersionByPageId(pageId: string, filter: Partial<T>): Promise<T>

  /**
   * 根据页面 id 和版本获取
   * @param pageId
   * @param version
   */
  getByPageIdAndVersion(pageId: string, version: string): Promise<T>

  /**
   * 根据发布流程 id 获取
   * @param orderId
   */
  getByOrderId(orderId: string): Promise<T>

  /**
   * 根据页面 id 列表获取对应页面所有环境最新版本列表
   * @param pageIdList
   */
  getLatestVersionListByPageIdList(pageIdList: string[]): Promise<T[]>
}
