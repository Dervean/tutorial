import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisAdministrator } from 'iris/iris-base/entities/iris-administrator'
import { IAdministratorDAO } from 'iris/iris-base/dao/administrator-dao'

export class AdministratorDAO extends AbstractDAO<IrisAdministrator> implements IAdministratorDAO<IrisAdministrator> {
  constructor() {
    super()
    this.setRepository(IrisAdministrator)
    this.setPrimaryKey(IrisAdministrator.columns.id)
  }

  async getByUserId(userId: string) {
    try {
      const repo = await this.getRepository()
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.userId} = :key`, { key: userId })
        .limit(1)
        .getOne()
      return result || null
    } catch (error) {
      this.logger().logError(error)
      throw error
    }
  }
}
