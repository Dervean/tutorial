import { IrisBaAuth } from 'iris/iris-base/entities/iris-ba-auth'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IBaAuthDAO } from 'iris/iris-base/dao/ba-auth-dao'

export class BaAuthDAO extends AbstractDAO<IrisBaAuth> implements IBaAuthDAO<IrisBaAuth> {
  constructor() {
    super()
    this.setRepository(IrisBaAuth)
    this.setPrimaryKey(IrisBaAuth.columns.id)
  }

  async getList() {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.status} = :key`, { key: IrisStatusEnum.Active })
        .getMany()

      return result as IrisBaAuth[]
    } catch (error) {
      this.logger().logError(error)
      throw error
    }
  }
}
