import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisContainer } from 'iris/iris-base/entities/iris-container'
import { IContainerDAO } from 'iris/iris-base/dao/container-dao'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'

export class ContainerDAO extends AbstractDAO<IrisContainer> implements IContainerDAO<IrisContainer> {
  constructor() {
    super()
    this.setRepository(IrisContainer)
    this.setPrimaryKey(IrisContainer.columns.id)
  }

  async search(offset: number, limit: number, filter: { status?: IrisStatusEnum }) {
    try {
      const repo = await this.getRepository()
      const { status } = filter || {}

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .skip(offset)
        .take(limit)
        .orderBy(`${this.tableName}.${this.columns.updateTime}`, 'DESC')
        .getManyAndCount()
      return { rows: data, totalCnt } as IrisSearchResult<IrisContainer>
    } catch (error) {
      this.logger().logError(error)
      throw error
    }
  }

  async getContainerList(filter: { name?: string; status?: IrisStatusEnum }) {
    try {
      const repo = await this.getRepository()
      const { name, status } = filter || {}

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .andWhere(!!name ? `${this.tableName}.${this.columns.name} = :name` : `1=1`, { name })
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }
}
