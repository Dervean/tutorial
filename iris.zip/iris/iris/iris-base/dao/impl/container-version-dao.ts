import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisContainerVersion } from 'iris/iris-base/entities/iris-container-version'
import { IContainerVersionDAO } from 'iris/iris-base/dao/container-version-dao'

export class ContainerVersionDAO extends AbstractDAO<IrisContainerVersion> implements IContainerVersionDAO<IrisContainerVersion> {
  constructor() {
    super()
    this.setRepository(IrisContainerVersion)
    this.setPrimaryKey(IrisContainerVersion.columns.id)
  }

  async search(
    offset: number,
    limit: number,
    filter: { version?: string; engineVersionStart?: string; engineVersionEnd?: string; containerId?: string },
  ) {
    try {
      const repo = await this.getRepository()
      const { engineVersionStart: start, engineVersionEnd: end, version, containerId } = filter
      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!containerId ? `${this.tableName}.${this.columns.containerId} = :containerId` : `1=1`, { containerId })
        .andWhere(!!start ? `${this.tableName}.${this.columns.engineVersionStart} <= :start` : '1=1', { start })
        .andWhere(!!end ? `${this.tableName}.${this.columns.engineVersionEnd} >= :end` : '1=1', { end })
        .andWhere(!!version ? `${this.tableName}.${this.columns.version} = :version` : '1=1', { version })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, 'DESC')
        .skip(offset)
        .take(limit)
        .getManyAndCount()
      return { rows: data, totalCnt } as IrisSearchResult<IrisContainerVersion>
    } catch (error) {
      this.logger().logError(error)
      throw error
    }
  }

  async getLatestVersionByContainerId(containerId: string, filter: { version?: string; engineVersionStart?: string; engineVersionEnd?: string }) {
    try {
      const repo = await this.getRepository()
      const { engineVersionEnd: end, engineVersionStart: start, version } = filter

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.containerId} = :containerId`, { containerId })
        .andWhere(!!start ? `${this.tableName}.${this.columns.engineVersionStart} <= :start` : '1=1', { start })
        .andWhere(!!end ? `${this.tableName}.${this.columns.engineVersionEnd} >= :end` : '1=1', { end })
        .andWhere(!!version ? `${this.tableName}.${this.columns.version} = :version` : '1=1', { version })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, 'DESC')
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { containerId, ...filter })
      throw error
    }
  }

  async getByContainerIdAndVersion(containerId: string, version: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.containerId} = :containerId`, { containerId })
        .andWhere(`${this.tableName}.${this.columns.version} = :version`, { version })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { containerId, version })
      throw error
    }
  }
}
