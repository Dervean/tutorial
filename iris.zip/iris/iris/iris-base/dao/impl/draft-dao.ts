import { IrisDraft } from 'iris/iris-base/entities/iris-draft'
import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IDraftDAO } from 'iris/iris-base/dao/draft-dao'

export class DraftDAO extends AbstractDAO<IrisDraft> implements IDraftDAO<IrisDraft> {
  constructor() {
    super()
    this.setRepository(IrisDraft)
    this.setPrimaryKey(IrisDraft.columns.id)
  }

  async getByPageIdAndUserId(pageId: string, userId: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.pageId} = :pageId`, { pageId })
        .andWhere(`${this.tableName}.${this.columns.userId} = :userId`, { userId })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { pageId, userId })
      throw error
    }
  }

  async getDraftListByUserId(userId: string, filter: { pageIdList?: string[] }) {
    try {
      const repo = await this.getRepository()

      const { pageIdList } = filter || {}

      const result = await repo
        .createQueryBuilder(this.tableName)
        .select(`${this.tableName}.${this.columns.pageId}`)
        .addSelect(`${this.tableName}.${this.columns.updateTime}`)
        .where(`${this.tableName}.${this.columns.userId} = :userId`, { userId })
        .andWhere(pageIdList?.length ? `${this.tableName}.${this.columns.pageId} IN (:...pageIdList)` : '1=1', { pageIdList })
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { userId, filter })
      throw error
    }
  }
}
