import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisHtmlCanaryStrategy } from 'iris/iris-base/entities/iris-html-canary-strategy'
import { IHtmlCanaryStrategyDAO } from 'iris/iris-base/dao/html-canary-strategy-dao'
import { IrisCanaryStateEnum } from 'iris/iris-base/enum/canary'

export class HtmlCanaryStrategyDAO extends AbstractDAO<IrisHtmlCanaryStrategy> implements IHtmlCanaryStrategyDAO<IrisHtmlCanaryStrategy> {
  constructor() {
    super()
    this.setRepository(IrisHtmlCanaryStrategy)
    this.setPrimaryKey(IrisHtmlCanaryStrategy.columns.id)
  }

  async getByOrderId(orderId: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.orderId} = :orderId`, { orderId })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { orderId })
      throw error
    }
  }

  async getStrategyList(filter: { projectId?: string; pageId?: string; states?: IrisCanaryStateEnum[] }) {
    try {
      const repo = await this.getRepository()
      const { projectId, pageId, states } = filter

      const qb = repo
        .createQueryBuilder(this.tableName)
        .where(`1=1`)
        .andWhere(!!projectId ? `${this.tableName}.${this.columns.projectId} = :projectId` : `1=1`, { projectId })
        .andWhere(!!pageId ? `${this.tableName}.${this.columns.pageId} = :pageId` : `1=1`, { pageId })
        .andWhere(states && states.length ? `${this.tableName}.${this.columns.state} IN (:states)` : '1!=1', { states })

      const ret = await qb.getMany()
      return ret
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }
}
