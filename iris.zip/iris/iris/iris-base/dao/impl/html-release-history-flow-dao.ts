import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisHtmlReleaseHistoryFlow } from 'iris/iris-base/entities/iris-html-release-history-flow'
import { IrisTargetEnvEnum, IrisPublishTypeEnum } from 'iris/iris-base/enum/common'
import { IrisFlowStateEnum } from 'iris/iris-base/enum/flow'
import { IHtmlReleaseHistoryFlowDAO } from 'iris/iris-base/dao/html-release-history-flow-dao'

export class HtmlReleaseHistoryFlowDAO
  extends AbstractDAO<IrisHtmlReleaseHistoryFlow>
  implements IHtmlReleaseHistoryFlowDAO<IrisHtmlReleaseHistoryFlow>
{
  constructor() {
    super()
    this.setRepository(IrisHtmlReleaseHistoryFlow)
    this.setPrimaryKey(IrisHtmlReleaseHistoryFlow.columns.orderId)
  }

  async search(
    offset: number,
    limit: number,
    filter: {
      pageId?: string
      projectId?: string
      state?: IrisFlowStateEnum
      createdBy?: string
      createTimeBegin?: string
      createTimeEnd?: string
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
      version?: string
      swimlane?: string
    },
  ) {
    try {
      const repo = await this.getRepository()
      const { pageId, createdBy, state, projectId, targets, createTimeBegin, types, createTimeEnd, version, swimlane } = filter || {}
      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!pageId ? `${this.tableName}.${this.columns.pageId} = :pageId` : `1=1`, { pageId })
        .andWhere(!!createdBy ? `${this.tableName}.${this.columns.createdBy} = :createdBy` : `1=1`, { createdBy })
        .andWhere(!!targets?.length ? `${this.tableName}.${this.columns.target} IN (:...targets)` : `1=1`, { targets })
        .andWhere(!!types?.length ? `${this.tableName}.${this.columns.type} IN (:...types)` : `1=1`, { types })
        .andWhere(!!state ? `${this.tableName}.${this.columns.state} = :state` : `1=1`, { state })
        .andWhere(!!projectId ? `${this.tableName}.${this.columns.projectId} = :projectId` : `1=1`, { projectId })
        .andWhere(!!createTimeBegin ? `${this.tableName}.${this.columns.createTime} >= :createTimeBegin` : `1=1`, { createTimeBegin })
        .andWhere(!!createTimeEnd ? `${this.tableName}.${this.columns.createTime} <= :createTimeEnd` : `1=1`, { createTimeEnd })
        .andWhere(!!version ? `${this.tableName}.${this.columns.version} = :version` : `1=1`, { version })
        .andWhere(!!swimlane ? `${this.tableName}.${this.columns.swimlane} = :swimlane` : `1=1`, { swimlane })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, `DESC`)
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as IrisSearchResult<IrisHtmlReleaseHistoryFlow>
    } catch (error) {
      this.logger().logError(error, { offset, limit, filter })
      throw error
    }
  }
}
