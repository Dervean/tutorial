import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisHtmlVersion } from 'iris/iris-base/entities/iris-html-version'
import { IrisPublishTypeEnum, IrisTargetEnvEnum } from 'iris/iris-base/enum/common'
import { IHtmlVersionDAO } from 'iris/iris-base/dao/html-version-dao'

export class HtmlVersionDAO extends AbstractDAO<IrisHtmlVersion> implements IHtmlVersionDAO<IrisHtmlVersion> {
  constructor() {
    super()
    this.setRepository(IrisHtmlVersion)
    this.setPrimaryKey(IrisHtmlVersion.columns.id)
  }

  async search(
    offset: number,
    limit: number,
    filter: {
      pageId?: string
      createdBy?: string
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
      version?: string
      createTimeBegin?: string
      createTimeEnd?: string
      swimlane?: string
    },
  ) {
    try {
      const repo = await this.getRepository()

      const { pageId, swimlane, createdBy, targets, types, version, createTimeBegin, createTimeEnd } = filter || {}
      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!pageId ? `${this.tableName}.${this.columns.pageId} = :pageId` : `1=1`, { pageId })
        .andWhere(!!createdBy ? `${this.tableName}.${this.columns.createdBy} = :createdBy` : `1=1`, { createdBy })
        .andWhere(!!version ? `${this.tableName}.${this.columns.version} = :version` : `1=1`, { version })
        .andWhere(!!targets?.length ? `${this.tableName}.${this.columns.target} IN (:...targets)` : `1=1`, { targets })
        .andWhere(!!types?.length ? `${this.tableName}.${this.columns.type} IN (:...types)` : `1=1`, { types })
        .andWhere(!!createdBy ? `${this.tableName}.${this.columns.createdBy} = :createdBy` : `1=1`, { createdBy })
        .andWhere(!!createTimeBegin ? `${this.tableName}.${this.columns.createTime} >= :createTimeBegin` : `1=1`, { createTimeBegin })
        .andWhere(!!createTimeEnd ? `${this.tableName}.${this.columns.createTime} <= :createTimeEnd` : `1=1`, { createTimeEnd })
        .andWhere(!!swimlane ? `${this.tableName}.${this.columns.swimlane} = :swimlane` : `1=1`, { swimlane })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, `DESC`)
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as IrisSearchResult<IrisHtmlVersion>
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }

  async getLastestVersionByPageId(
    pageId: string,
    filter: { target?: IrisTargetEnvEnum; createdBy?: string; swimlane?: string; type?: IrisPublishTypeEnum },
  ) {
    try {
      const repo = await this.getRepository()
      const { target, createdBy, swimlane, type } = filter || {}

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.pageId} = :pageId`, { pageId })
        .andWhere(!!createdBy ? `${this.tableName}.${this.columns.createdBy} = :createdBy` : `1=1`, { createdBy })
        .andWhere(!!target ? `${this.tableName}.${this.columns.target} = :target` : `1=1`, { target })
        .andWhere(!!swimlane ? `${this.tableName}.${this.columns.swimlane} = :swimlane` : `1=1`, { swimlane })
        .andWhere(!!type ? `${this.tableName}.${this.columns.type} = :type` : `1=1`, { type })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, `DESC`)
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { pageId })
      throw error
    }
  }

  async getByPageIdAndVersion(pageId: string, version: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.pageId} = :pageId`, { pageId })
        .andWhere(`${this.tableName}.${this.columns.version} = :version`, { version })
        .limit(1)
        .getOne()
      return result || null
    } catch (error) {
      this.logger().logError(error, { pageId })
      throw error
    }
  }

  async getByOrderId(orderId: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.orderId} = :orderId`, { orderId })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { orderId })
      throw error
    }
  }

  async getLatestVersionListByPageIdList(pageIdList: string[]) {
    try {
      if (!pageIdList?.length) return [] as IrisHtmlVersion[]

      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .select(`${this.tableName}.${this.columns.pageId}`)
        .addSelect(`${this.tableName}.${this.columns.target}`)
        .addSelect(`${this.tableName}.${this.columns.projectId}`)
        .addSelect(`${this.tableName}.${this.columns.version}`)
        .addSelect(`MAX(${this.tableName}.${this.columns.createTime})`)
        .groupBy(`${this.tableName}.${this.columns.pageId}`)
        .addGroupBy(`${this.tableName}.${this.columns.target}`)
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { pageIdList })
      throw error
    }
  }
}
