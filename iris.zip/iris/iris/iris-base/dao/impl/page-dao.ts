import { IrisPage } from 'iris/iris-base/entities/iris-page'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IPageDAO } from 'iris/iris-base/dao/page-dao'

export class PageDAO extends AbstractDAO<IrisPage> implements IPageDAO<IrisPage> {
  constructor() {
    super()
    this.setRepository(IrisPage)
    this.setPrimaryKey(IrisPage.columns.pageId)
  }

  async getPageList(filter: { projectIdList?: string[]; status?: IrisStatusEnum }) {
    try {
      const { status, projectIdList } = filter || {}
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!projectIdList?.length ? `${this.tableName}.${this.columns.projectId} IN (:...projectIdList)` : '1=1', { projectIdList })
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }

  async getByProjectIdAndPath(projectId: string, path: string) {
    try {
      const repo = await this.getRepository()
      /**
       * 这里不限制 status
       * projectId & path 是联合索引
       * 新增 page 也会受到被标记删除的 page 的限制
       */
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.path} = :path`, { path })
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { projectId, path })
      throw error
    }
  }

  async search(
    offset: number,
    limit: number,
    filter: {
      pageIdList?: string[]
      projectId?: string
      sceneId?: string
      fuzzyPageName?: string
      createdBy?: string
      fuzzyPageId?: string
      status?: IrisStatusEnum
    },
  ) {
    try {
      const repo = await this.getRepository()
      const { projectId, sceneId, createdBy, fuzzyPageName, pageIdList, fuzzyPageId, status } = filter

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .andWhere(!!projectId ? `${this.tableName}.${this.columns.projectId} = :projectId` : `1=1`, { projectId })
        .andWhere(!!sceneId ? `${this.tableName}.${this.columns.sceneId} = :sceneId` : `1=1`, { sceneId })
        .andWhere(!!createdBy ? `${this.tableName}.${this.columns.createdBy} = :createdBy` : `1=1`, { createdBy })
        .andWhere(!!pageIdList?.length ? `${this.tableName}.${this.primaryKey} IN (:keys)` : '1=1', { pageIdList })
        .andWhere(fuzzyPageName ? `${this.tableName}.${this.columns.pageName} like :fuzzyPageName` : `1=1`, {
          fuzzyPageName: `%${fuzzyPageName}%`,
        })
        .andWhere(fuzzyPageId ? `${this.tableName}.${this.columns.pageId} like :fuzzyPageId` : `1=1`, {
          fuzzyPageId: `%${fuzzyPageId}%`,
        })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, `DESC`)
        .skip(offset)
        .take(limit)
        .getManyAndCount()

      return { rows: data, totalCnt } as IrisSearchResult<IrisPage>
    } catch (error) {
      this.logger().logError(error, { offset, limit, filter })
      throw error
    }
  }
}
