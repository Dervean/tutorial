import { IrisPageMember } from 'iris/iris-base/entities/iris-page-member'
import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IPageMemberDAO } from 'iris/iris-base/dao/page-member-dao'

export class PageMemberDAO extends AbstractDAO<IrisPageMember> implements IPageMemberDAO<IrisPageMember> {
  constructor() {
    super()
    this.setRepository(IrisPageMember)
    this.setPrimaryKey(IrisPageMember.columns.id)
  }

  async getMemberList(filter: { userId?: string; pageId?: string; permission?: number; projectId?: string }) {
    try {
      const repo = await this.getRepository()
      const { userId, pageId, permission, projectId } = filter

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!userId ? `${this.tableName}.${this.columns.userId} = :userId` : `1=1`, { userId })
        .andWhere(!!pageId ? `${this.tableName}.${this.columns.pageId} = :pageId` : `1=1`, { pageId })
        .andWhere(!!projectId ? `${this.tableName}.${this.columns.projectId} = :projectId` : `1=1`, { projectId })
        .andWhere(!!permission ? `${this.tableName}.${this.columns.permission} = :permission` : `1=1`, { permission })
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }

  async getByPageIdAndUserId(pageId: string, userId: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.pageId} = :pageId`, { pageId })
        .andWhere(`${this.tableName}.${this.columns.userId} = :userId`, { userId })
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { pageId, userId })
      throw error
    }
  }
}
