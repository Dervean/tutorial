import assert from 'assert'
import { Brackets } from '@gfe/zebra-typeorm-client'
import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisProject } from 'iris/iris-base/entities/iris-project'
import { IrisProjectMember } from 'iris/iris-base/entities/iris-project-member'
import { IrisProjectTag } from 'iris/iris-base/entities/iris-project-tag'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { IProjectDAO } from 'iris/iris-base/dao/project-dao'

export class ProjectDAO extends AbstractDAO<IrisProject> implements IProjectDAO<IrisProject> {
  constructor() {
    super()
    this.setRepository(IrisProject)
    this.setPrimaryKey(IrisProject.columns.projectId)
  }

  async insert(rowProject: IrisProject, rowMember?: IrisProjectMember, rowTags: string[] = []) {
    try {
      assert.ok(!!rowMember, `项目成员必填`)
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        const { identifiers } = await queryRunner.manager.getRepository(this.repository).insert(rowProject)
        const target = identifiers[0] as IrisProject

        rowMember.projectId = target.projectId
        const tags = rowTags.map(tagId => {
          const tag = new IrisProjectTag()
          tag.createdBy = rowProject.createdBy
          tag.tagId = tagId
          tag.projectId = target.projectId
          return tag
        })
        await queryRunner.manager.getRepository(IrisProjectMember).insert(rowMember)
        await queryRunner.manager.getRepository(IrisProjectTag).insert(tags)
        await queryRunner.commitTransaction()
        return target
      } catch (e) {
        this.logger().logError(e, { message: '项目创建失败', rowProject, rowMember, rowTags })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { rowProject, rowMember, rowTags })
      throw error
    }
  }

  async search(
    offset: number,
    limit: number,
    filter: {
      status?: IrisStatusEnum
      projectIdList?: string[]
      searchPublic?: boolean
      fuzzyProjectId?: string
      fuzzyProjectName?: string
    },
  ) {
    try {
      const repo = await this.getRepository()

      const { fuzzyProjectId, fuzzyProjectName, projectIdList, searchPublic, status } = filter
      const qb = repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .andWhere(!!fuzzyProjectId ? `${this.tableName}.${this.columns.projectId} like :fuzzyProjectId` : `1=1`, {
          fuzzyProjectId: `%${fuzzyProjectId}%`,
        })
        .andWhere(!!fuzzyProjectName ? `${this.tableName}.${this.columns.projectName} like :fuzzyProjectName` : `1=1`, {
          fuzzyProjectName: `%${fuzzyProjectName}%`,
        })

      if (searchPublic || projectIdList) {
        qb.andWhere(
          new Brackets(qb => {
            // prettier-ignore
            qb.where(!!projectIdList?.length ? `${this.tableName}.${this.primaryKey} IN (:projectIdList)` : '1!=1', { projectIdList })
              .orWhere(searchPublic ? `${this.tableName}.${this.columns.isPrivate} = :isPrivate` : '1!=1', { isPrivate: Number(false) })
          }),
        )
      }

      const [data, totalCnt] = await qb.skip(offset).take(limit).getManyAndCount()

      return { rows: data, totalCnt } as IrisSearchResult<IrisProject>
    } catch (error) {
      this.logger().logError(error, { offset, limit, filter })
      throw error
    }
  }
}
