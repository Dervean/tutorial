import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisProjectMember } from 'iris/iris-base/entities/iris-project-member'
import { IProjectMemberDAO } from 'iris/iris-base/dao/project-member-dao'

export class ProjectMemberDAO extends AbstractDAO<IrisProjectMember> implements IProjectMemberDAO<IrisProjectMember> {
  constructor() {
    super()
    this.setRepository(IrisProjectMember)
    this.setPrimaryKey(IrisProjectMember.columns.id)
  }

  async getMemberList(filter: { userId?: string; projectId?: string; permission?: number }) {
    try {
      const repo = await this.getRepository()
      const { userId, projectId, permission } = filter

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!userId ? `${this.tableName}.${this.columns.userId} = :userId` : `1=1`, { userId })
        .andWhere(!!projectId ? `${this.tableName}.${this.columns.projectId} = :projectId` : `1=1`, { projectId })
        .andWhere(!!permission ? `${this.tableName}.${this.columns.permission} = :permission` : `1=1`, { permission })
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }

  async getByProjectIdAndUserId(projectId: string, userId: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.projectId} = :projectId`, { projectId })
        .andWhere(`${this.tableName}.${this.columns.userId} = :userId`, { userId })
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { projectId, userId })
      throw error
    }
  }
}
