import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisProjectTag } from 'iris/iris-base/entities/iris-project-tag'
import { IrisTag } from 'iris/iris-base/entities/iris-tag'
import { IProjectTagDAO } from 'iris/iris-base/dao/project-tag-dao'

export class ProjectTagDAO extends AbstractDAO<IrisProjectTag> implements IProjectTagDAO<IrisProjectTag> {
  constructor() {
    super()
    this.setRepository(IrisProjectTag)
    this.setPrimaryKey(IrisProjectTag.columns.id)
  }

  async getProjectTagList(filter: Partial<IrisProjectTag>) {
    try {
      const repo = await this.getRepository()

      const { projectId, tagId, id } = filter
      const joinTableName = AbstractDAO.getTableName(IrisTag)
      const result = await repo
        .createQueryBuilder(this.tableName)
        .leftJoinAndMapOne(
          `${this.tableName}.${this.columns.tag}`,
          IrisTag,
          joinTableName,
          `${this.tableName}.${this.columns.tagId} = ${joinTableName}.id`,
        )
        .where(`1=1`)
        .andWhere(!!id ? `${this.tableName}.${this.columns.id} = :id` : `1=1`, { id })
        .andWhere(!!projectId ? `${this.tableName}.${this.columns.projectId} = :projectId` : `1=1`, { projectId })
        .andWhere(!!tagId ? `${this.tableName}.${this.columns.tagId} = :tagId` : `1=1`, { tagId })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, `DESC`)
        .getMany()
      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }

  async updateProjectTags(projectId: string, tags: IrisProjectTag[]) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        await queryRunner.manager.getRepository(this.repository).delete({ projectId })
        await queryRunner.manager.getRepository(this.repository).insert(tags)
        await queryRunner.commitTransaction()
        return
      } catch (e) {
        this.logger().logError(e, { message: '项目标签更新失败', projectId, tags })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { projectId, tags })
      throw error
    }
  }
}
