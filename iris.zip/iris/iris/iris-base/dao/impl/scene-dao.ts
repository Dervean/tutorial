import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisScene } from 'iris/iris-base/entities/iris-scene'
import { IrisSceneTag } from 'iris/iris-base/entities/iris-scene-tag'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { ISceneDAO } from 'iris/iris-base/dao/scene-dao'

export class SceneDAO extends AbstractDAO<IrisScene> implements ISceneDAO<IrisScene> {
  constructor() {
    super()
    this.setRepository(IrisScene)
    this.setPrimaryKey(IrisScene.columns.id)
  }

  async search(offset: number, limit: number, filter: { status?: IrisStatusEnum }) {
    try {
      const repo = await this.getRepository()
      const { status } = filter || {}

      const [data, totalCnt] = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .skip(offset)
        .take(limit)
        .orderBy(`${this.tableName}.${this.columns.updateTime}`, 'DESC')
        .getManyAndCount()
      return { rows: data, totalCnt } as IrisSearchResult<IrisScene>
    } catch (error) {
      this.logger().logError(error)
      throw error
    }
  }

  async getSceneList(filter: { name?: string; status?: IrisStatusEnum }) {
    try {
      const repo = await this.getRepository()

      const { name, status } = filter || {}
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .andWhere(!!name ? `${this.tableName}.${this.columns.name} = :name` : `1=1`, { name })
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }

  public async insert(rowScene: IrisScene, rowTags: string[] = []) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        // prettier-ignore
        const { identifiers } = await queryRunner
          .manager
          .getRepository(this.repository)
          .insert([JSON.parse(JSON.stringify(rowScene))])
        const target = identifiers[0] as IrisScene
        const tags = rowTags.map(tagId => {
          const tag = new IrisSceneTag()
          tag.createdBy = rowScene.createdBy
          tag.tagId = tagId
          tag.sceneId = target.id
          return tag
        })
        await queryRunner.manager.getRepository(IrisSceneTag).insert(tags)
        await queryRunner.commitTransaction()
        return target
      } catch (e) {
        this.logger().logError(e, { message: '场景创建失败', rowScene, rowTags })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { rowScene, rowTags })
      throw error
    }
  }
}
