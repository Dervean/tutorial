import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisSceneTag } from 'iris/iris-base/entities/iris-scene-tag'
import { ISceneTagDAO } from 'iris/iris-base/dao/scene-tag-dao'
import { IrisTag } from 'iris/iris-base/entities/iris-tag'

export class SceneTagDAO extends AbstractDAO<IrisSceneTag> implements ISceneTagDAO<IrisSceneTag> {
  constructor() {
    super()
    this.setRepository(IrisSceneTag)
    this.setPrimaryKey(IrisSceneTag.columns.id)
  }

  async getSceneTagList(filter: Partial<IrisSceneTag>) {
    try {
      const repo = await this.getRepository()

      const { sceneId, tagId, id } = filter
      const joinTableName = AbstractDAO.getTableName(IrisTag)
      const result = await repo
        .createQueryBuilder(this.tableName)
        .leftJoinAndMapOne(
          `${this.tableName}.${this.columns.tag}`,
          IrisTag,
          joinTableName,
          `${this.tableName}.${this.columns.tagId} = ${joinTableName}.id`,
        )
        .where(`1=1`)
        .andWhere(!!id ? `${this.tableName}.${this.columns.id} = :id` : `1=1`, { id })
        .andWhere(!!sceneId ? `${this.tableName}.${this.columns.sceneId} = :sceneId` : `1=1`, { sceneId })
        .andWhere(!!tagId ? `${this.tableName}.${this.columns.tagId} = :tagId` : `1=1`, { tagId })
        .orderBy(`${this.tableName}.${this.columns.createTime}`, `DESC`)
        .getMany()
      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }

  async getSceneIdListByTagIdList(tagIdList: string[]) {
    try {
      const repo = await this.getRepository()
      if (!tagIdList?.length) return []
      const result = await repo
        .createQueryBuilder(this.tableName)
        .select(`${this.tableName}.${this.columns.sceneId}`)
        .where(`${this.tableName}.${this.columns.tagId} IN (:...tagIdList)`, { tagIdList })
        .groupBy(`${this.tableName}.${this.columns.sceneId}`)
        .having(`COUNT(*) > ${tagIdList.length - 1}`)
        .getMany()

      return result.map(e => e.sceneId)
    } catch (error) {
      this.logger().logError(error, { tagIdList })
      throw error
    }
  }

  async updateSceneTags(sceneId: string, tags: IrisSceneTag[]) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        await queryRunner.manager.getRepository(this.repository).delete({ sceneId })
        await queryRunner.manager.getRepository(this.repository).insert(tags)
        await queryRunner.commitTransaction()
        return
      } catch (e) {
        this.logger().logError(e, { message: '场景标签更新失败', sceneId, tags })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { sceneId, tags })
      throw error
    }
  }
}
