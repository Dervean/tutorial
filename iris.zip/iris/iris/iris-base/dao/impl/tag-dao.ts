import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisTag } from 'iris/iris-base/entities/iris-tag'
import { ITagDAO } from 'iris/iris-base/dao/tag-dao'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'

export class TagDAO extends AbstractDAO<IrisTag> implements ITagDAO<IrisTag> {
  constructor() {
    super()
    this.setRepository(IrisTag)
    this.setPrimaryKey(IrisTag.columns.id)
  }

  async getTagList(filter: { source?: string; tagType?: string; id?: string; tagValue?: string; status?: IrisStatusEnum; tagIdList?: string[] }) {
    try {
      const repo = await this.getRepository()

      const { source, tagType, id, tagValue, status, tagIdList } = filter
      const result = await repo
        .createQueryBuilder(this.tableName)
        .where('1=1')
        .andWhere(!!status ? `${this.tableName}.${this.columns.status} = :status` : '1=1', { status })
        .andWhere(!!id ? `${this.tableName}.${this.columns.id} = :id` : `1=1`, { id })
        .andWhere(!!source ? `${this.tableName}.${this.columns.source} = :source` : `1=1`, { source })
        .andWhere(!!tagType ? `${this.tableName}.${this.columns.tagType} = :tagType` : `1=1`, { tagType })
        .andWhere(!!tagValue ? `${this.tableName}.${this.columns.tagValue} = :tagValue` : `1=1`, { tagValue })
        .andWhere(!!tagIdList?.length ? `${this.tableName}.${this.columns.id} IN (:...tagIdList)` : '1=1', { tagIdList })
        .orderBy(`${this.tableName}.${this.columns.updateTime}`, `DESC`)
        .getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { filter })
      throw error
    }
  }
}
