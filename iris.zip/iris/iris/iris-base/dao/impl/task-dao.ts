import { Like, Not, In } from '@gfe/zebra-typeorm-client'
import { AbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisTask } from 'iris/iris-base/entities/iris-task'
import { IrisTaskPage } from 'iris/iris-base/entities/iris-task-page'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'
import { ITaskDAO } from 'iris/iris-base/dao/task-dao'
import { IrisTaskStatusEnum } from 'iris/iris-base/enum/task'

export class TaskDAO extends AbstractDAO<IrisTask> implements ITaskDAO<IrisTask> {
  constructor() {
    super()
    this.setRepository(IrisTask)
    this.setPrimaryKey(IrisTask.columns.taskId)
  }

  async insert(task: IrisTask, pageIdList: string[] = []) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        // prettier-ignore
        const { identifiers } = await queryRunner
          .manager
          .getRepository(this.repository)
          .insert([JSON.parse(JSON.stringify(task))])
        const target = identifiers[0] as IrisTask
        if (pageIdList?.length) {
          const taskPage = pageIdList.map(pageId => {
            const entity = new IrisTaskPage()
            entity.pageId = pageId
            entity.task = target
            return entity
          })
          await queryRunner.manager.getRepository(IrisTaskPage).insert(taskPage)
        }
        await queryRunner.commitTransaction()
        return target
      } catch (e) {
        this.logger().logError(e, { message: '创建任务失败', task, pageIdList })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { task, pageIdList })
      throw error
    }
  }

  async update(taskId: string, task: IrisTask, pageIdList: string[]) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        await queryRunner.manager
          .getRepository(this.repository)
          .createQueryBuilder()
          .update(this.repository)
          .set(task)
          .where(`${IrisTask.columns.taskId} = :key`, { key: taskId })
          .execute()

        if (pageIdList?.length) {
          await queryRunner.manager
            .getRepository(IrisTaskPage)
            .createQueryBuilder()
            .delete()
            .from(IrisTaskPage)
            .where(`${IrisTaskPage.columns.taskId} = :key`, { key: taskId })
            .execute()
          const taskPage = pageIdList.map(pageId => {
            const entity = new IrisTaskPage()
            entity.pageId = pageId
            entity.task = task
            return entity
          })
          await queryRunner.manager.getRepository(IrisTaskPage).insert(taskPage)
        }
        await queryRunner.commitTransaction()
        return
      } catch (e) {
        this.logger().logError(e, { message: '更新任务失败', task, pageIdList })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { task, pageIdList })
      throw error
    }
  }

  async search(
    offset: number,
    limit: number,
    filter: {
      projectId?: string
      name?: string
      createdBy?: string
      statusList?: IrisTaskStatusEnum[]
      hidePublic?: boolean
    },
  ) {
    try {
      const repo = await this.getRepository()

      const { projectId, name, statusList, hidePublic = false, createdBy } = filter
      const whereConditions: any = {}
      if (projectId) {
        whereConditions[IrisTask.columns.projectId] = projectId
      }
      if (name) {
        whereConditions[IrisTask.columns.name] = Like(`%${name}%`)
      }
      if (statusList) {
        whereConditions[IrisTask.columns.status] = In(statusList)
      } else {
        whereConditions[IrisTask.columns.status] = Not(IrisTaskStatusEnum.Inactive)
      }
      if (!!hidePublic) {
        whereConditions[IrisTask.columns.createdBy] = createdBy
      }
      const [data, totalCnt] = await repo.findAndCount({
        relations: [this.columns.pageList, `${this.columns.pageList}.${IrisTaskPage.columns.page}`, this.columns.taskRecordList],
        where: whereConditions,
        order: {
          [IrisTask.columns.createTime]: 'DESC',
        },
        skip: offset,
        take: limit,
      })
      return { rows: data, totalCnt } as IrisSearchResult<IrisTask>
    } catch (error) {
      this.logger().logError(error, { offset, limit, filter })
      throw error
    }
  }

  async detail(taskId: string) {
    try {
      const repo = await this.getRepository()
      const data = await repo.findOne({
        relations: [this.columns.pageList, `${this.columns.pageList}.${IrisTaskPage.columns.page}`],
        where: { [IrisTask.columns.taskId]: taskId },
      })
      return data || null
    } catch (error) {
      this.logger().logError(error, { taskId })
      throw error
    }
  }

  public async updateTaskAndTaskRecord(taskId: string, task: IrisTask, taskRecordId: string, taskRecord: IrisTaskRecord) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        /* 1. 更新任务 */
        await queryRunner.manager
          .getRepository(this.repository)
          .createQueryBuilder()
          .update(this.repository)
          .set(task)
          .where(`${this.columns.taskId} = :key`, { key: taskId })
          .execute()

        /* 2. 更新任务记录 */
        await queryRunner.manager
          .getRepository(IrisTaskRecord)
          .createQueryBuilder()
          .update(IrisTaskRecord)
          .set(taskRecord)
          .where(`${IrisTaskRecord.columns.id} = :key`, { key: taskRecordId })
          .execute()

        await queryRunner.commitTransaction()
      } catch (e) {
        this.logger().logError(e, { message: '更新任务和任务记录失败', taskId, taskRecordId, task, taskRecord })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { taskId, taskRecordId, task, taskRecord })
      throw error
    }
  }

  public async updateTaskAndCreateTaskRecord(taskId: string, task: IrisTask, taskRecord: IrisTaskRecord) {
    try {
      const repo = await this.getRepository()
      const queryRunner = repo.manager.connection.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()
      try {
        /* 1. 更新任务 */
        await queryRunner.manager
          .getRepository(this.repository)
          .createQueryBuilder()
          .update(this.repository)
          .set(task)
          .where(`${this.columns.taskId} = :key`, { key: taskId })
          .execute()

        /* 2. 创建任务记录 */
        const { identifiers } = await queryRunner.manager.getRepository(IrisTaskRecord).insert(taskRecord)
        await queryRunner.commitTransaction()
        return identifiers[0] as IrisTaskRecord
      } catch (e) {
        this.logger().logError(e, { message: '更新任务和任务记录失败', taskId, task, taskRecord })
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction()
        }
        throw e
      } finally {
        await queryRunner.release()
      }
    } catch (error) {
      this.logger().logError(error, { taskId, task, taskRecord })
      throw error
    }
  }
}
