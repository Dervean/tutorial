import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisTaskPage } from 'iris/iris-base/entities/iris-task-page'
import { ITaskPageDAO } from 'iris/iris-base/dao/task-page-dao'
import { IrisPage } from 'iris/iris-base/entities/iris-page'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'

export class TaskPageDAO extends AbstractDAO<IrisTaskPage> implements ITaskPageDAO<IrisTaskPage> {
  constructor() {
    super()
    this.setRepository(IrisTaskPage)
    this.setPrimaryKey(IrisTaskPage.columns.taskId)
  }

  async getTaskPageList(taskId: string) {
    try {
      const repo = await this.getRepository()
      const result = await repo.find({
        relations: [this.columns.page],
        where: {
          taskId,
          // 过滤掉已废弃的页面
          [this.columns.page]: { [IrisPage.columns.status]: IrisStatusEnum.Active },
        },
      })
      return result
    } catch (error) {
      this.logger().logError(error, { taskId })
      throw error
    }
  }
}
