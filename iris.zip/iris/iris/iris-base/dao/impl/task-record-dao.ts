import { In } from '@gfe/zebra-typeorm-client'
import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisTask } from 'iris/iris-base/entities/iris-task'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'
import { ITaskRecordDAO } from 'iris/iris-base/dao/task-record-dao'
import { IrisTaskStatusEnum } from 'iris/iris-base/enum/task'

export class TaskRecordDAO extends AbstractDAO<IrisTaskRecord> implements ITaskRecordDAO<IrisTaskRecord> {
  constructor() {
    super()
    this.setRepository(IrisTaskRecord)
    this.setPrimaryKey(IrisTaskRecord.columns.taskId)
  }

  async insert(taskRecord: IrisTaskRecord) {
    const repo = await this.getRepository()
    const abnormalTaskRecord = await this.getNeedlessTaskRecordByTaskId(taskRecord.taskId)
    // 可能因为运行任务时出现异常，导致创建了空的任务记录(没有事务进行控制)，这里手动删除
    if (abnormalTaskRecord) {
      // prettier-ignore
      await repo
        .createQueryBuilder()
        .delete()
        .from(this.repository)
        .where(`${this.columns.taskId} = :key`, { key: taskRecord.taskId })
        .execute()
    }
    const result = await repo
      .createQueryBuilder()
      .insert()
      .into(this.repository)
      .values([JSON.parse(JSON.stringify(taskRecord))])
      .execute()
    return result.identifiers[0] as IrisTaskRecord
  }

  async getTaskRecord(taskRecordId: string) {
    try {
      const repo = await this.getRepository()
      const data = await repo.findOne({
        where: { [this.columns.id]: taskRecordId },
      })
      return data
    } catch (error) {
      this.logger().logError(error, { taskRecordId })
      throw error
    }
  }

  async getSuccessfulTaskRecordByTaskId(taskId: string) {
    try {
      const repo = await this.getRepository()
      const data = await repo.findOne({
        relations: [this.columns.task],
        where: {
          [this.columns.taskId]: taskId,
          [this.columns.status]: IrisTaskStatusEnum.Success,
          [this.columns.task]: {
            [IrisTask.columns.taskId]: taskId,
            [IrisTask.columns.status]: IrisTaskStatusEnum.Success,
          },
        },
      })
      return data
    } catch (error) {
      this.logger().logError(error, { taskId })
      throw error
    }
  }

  private async getNeedlessTaskRecordByTaskId(taskId: string) {
    try {
      const repo = await this.getRepository()
      const data = await repo.findOne({
        relations: [this.columns.task],
        where: {
          [this.columns.taskId]: taskId,
          [this.columns.status]: In([IrisTaskStatusEnum.Pending, IrisTaskStatusEnum.Active]),
        },
      })
      return data
    } catch (error) {
      this.logger().logError(error, { taskId })
      throw error
    }
  }
}
