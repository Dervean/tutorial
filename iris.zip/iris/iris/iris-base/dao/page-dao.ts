import { IrisSearchResult, IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IPageDAO<T> extends IAbstractDAO<T> {
  /**
   * 获取页面列表
   * @param filter
   */
  getPageList(filter: Partial<T> & { projectIdList?: string[] }): Promise<T[]>

  /**
   * 根据项目 id 和页面路径获取
   * @param projectId
   * @param path
   */
  getByProjectIdAndPath(projectId: string, path: string): Promise<T>

  /**
   * 分页搜索列表
   * @param offset
   * @param limit
   * @param filter
   */
  search(
    offset: number,
    limit: number,
    filter: Partial<T> & {
      pageIdList?: string[]
      fuzzyPageName?: string
      fuzzyPageId?: string
    },
  ): Promise<IrisSearchResult<T>>
}
