import { IAbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'
import { IrisProjectMember } from 'iris/iris-base/entities/iris-project-member'

export interface IProjectDAO<T> extends IAbstractDAO<T> {
  /**
   * 创建项目
   * @param rowProject
   * @param rowMember
   */
  insert(rowProject: T, rowMember?: IrisProjectMember, rowTags?: string[]): Promise<T>

  /**
   * 分页搜素
   * @param offset
   * @param limit
   * @param filter
   */
  search(
    offset: number,
    limit: number,
    filter: Partial<T> & {
      projectIdList?: string[]
      searchPublic?: boolean
      fuzzyProjectId?: string
      fuzzyProjectName?: string
    },
  ): Promise<IrisSearchResult<T>>
}
