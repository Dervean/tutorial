import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IProjectMemberDAO<T> extends IAbstractDAO<T> {
  /**
   * 获取项目成员列表
   * @param filter
   */
  getMemberList(filter: Partial<T>): Promise<T[]>

  /**
   * 根据项目 id 和用户 id 获取
   * @param projectId
   * @param userId
   */
  getByProjectIdAndUserId(projectId: string, userId: string): Promise<T>
}
