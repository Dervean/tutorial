import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface IProjectTagDAO<T> extends IAbstractDAO<T> {
  /**
   * 获取标签应用关联关系列表
   * @param filter
   */
  getProjectTagList(filter: Partial<T>): Promise<T[]>

  /**
   * 批量修改标签应用关联关系
   * @param tags
   */
  updateProjectTags(projectId: string, tags: T[]): Promise<void>
}
