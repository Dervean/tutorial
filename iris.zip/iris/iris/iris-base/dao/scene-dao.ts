import { IAbstractDAO, IrisSearchResult } from 'iris/iris-base/dao/abstract-dao'

export interface ISceneDAO<T> extends IAbstractDAO<T> {
  /**
   * 分页搜索
   * @param offset
   * @param limit
   * @param filter
   */
  search(offset: number, limit: number, filter: Partial<T>): Promise<IrisSearchResult<T>>

  /**
   * 获取场景列表
   * @param filter
   */
  getSceneList(filter: Partial<T>): Promise<T[]>

  /**
   * 创建场景（同时创建tag关联关系）
   * @param rowScene
   * @param rowTags
   */
  insert(rowScene: Partial<T>, rowTags?: string[]): Promise<T>
}
