import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface ISceneTagDAO<T> extends IAbstractDAO<T> {
  /**
   * 获取项目标签列表
   * @param filter
   */
  getSceneTagList(filter: Partial<T>): Promise<T[]>

  /**
   * 获取已关联 tagIdList 的所有的场景(id)
   * @param tagIdList
   */
  getSceneIdListByTagIdList(tagIdList: string[]): Promise<string[]>

  /**
   * 批量修改标签关联关系
   * @param tags
   */
  updateSceneTags(sceneId: string, tags: T[]): Promise<void>
}
