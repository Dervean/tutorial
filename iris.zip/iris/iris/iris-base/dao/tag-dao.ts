import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface ITagDAO<T> extends IAbstractDAO<T> {
  /**
   * 获取tag列表
   * @param filter
   */
  getTagList(filter: Partial<T> & { tagIdList?: string[] }): Promise<T[]>
}
