import { IrisSearchResult, IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'
import { IrisTaskStatusEnum } from 'iris/iris-base//enum/task'

export interface ITaskDAO<T> extends IAbstractDAO<T> {
  /**
   * 新增任务
   * @param task
   * @param pageIdList
   */
  insert(task: Partial<T>, pageIdList?: string[]): Promise<T>

  /**
   * 更新任务
   * @param taskId
   * @param task
   * @param pageIdList
   */
  update(taskId: string, task: T, pageIdList: string[]): Promise<void>

  /**
   * 分页搜索任务列表
   * @param offset
   * @param limit
   * @param filter
   */
  search(
    offset: number,
    limit: number,
    filter: Partial<T> & { statusList?: IrisTaskStatusEnum[]; hidePublic?: boolean },
  ): Promise<IrisSearchResult<T>>

  /**
   * 查询任务详情
   * @param taskId
   */
  detail(taskId: string): Promise<T>

  /**
   * 更新任务和更新任务记录
   * @param taskId
   * @param task
   * @param taskRecordId
   * @param taskRecord
   */
  updateTaskAndTaskRecord(taskId: string, task: T, taskRecordId: string, taskRecord: IrisTaskRecord): Promise<void>

  /**
   * 更新任务并创建任务记录
   * @param taskId
   * @param task
   * @param taskRecord
   * @returns
   */
  updateTaskAndCreateTaskRecord(taskId: string, task: T, taskRecord: IrisTaskRecord): Promise<IrisTaskRecord>
}
