import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface ITaskPageDAO<T> extends IAbstractDAO<T> {
  /**
   * 获取任务关联的页面列表
   * @param filter
   */
  getTaskPageList(taskId: string): Promise<T[]>
}
