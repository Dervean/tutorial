import { IAbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export interface ITaskRecordDAO<T> extends IAbstractDAO<T> {
  /**
   * 新增任务运行记录
   * @param taskRecord
   */
  insert(taskRecord: T): Promise<T>

  /**
   * 获取任务运行记录
   * @param taskRecordId
   */
  getTaskRecord(taskRecordId: string): Promise<T>

  /**
   * 获取任务运行成功的记录
   * @param taskId
   */
  getSuccessfulTaskRecordByTaskId(taskId: string): Promise<T>
}
