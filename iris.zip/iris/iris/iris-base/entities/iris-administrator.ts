import { Entity, Column, CreateDateColumn, PrimaryGeneratedColumn } from '@gfe/zebra-typeorm-client'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisAdministrator {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: 'id' })
  id: string

  @Column({ name: 'user_id', type: 'varchar', length: 32, comment: 'org emp id' })
  userId: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string

  static get columns(): Columns<IrisAdministrator> {
    return {
      id: 'id',
      userId: 'userId',
      createTime: 'createTime',
    }
  }
}
