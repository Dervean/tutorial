import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { IrisStatusEnum } from 'iris/iris-flow/enum/common'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisBaAuth {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: 'id' })
  id: string

  @Column({ name: 'client_id', type: 'varchar', length: 16, comment: '16 位随机 id' })
  clientId: string
  @Column({ name: 'client_secret', type: 'varchar', length: 32, comment: '32 位随机 id' })
  clientSecret: string
  @Column({ name: 'user_id', type: 'varchar', length: 64, comment: '负责人' })
  userId: string
  @Column({ name: 'name', type: 'varchar', length: 64, comment: '名称' })
  name: string

  @Column({ name: 'status', type: 'tinyint', comment: '状态', default: IrisStatusEnum.Active })
  status?: number
  @Column({ name: 'description', type: 'varchar', length: 256, comment: '描述信息' })
  description?: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  static get columns(): Columns<IrisBaAuth> {
    return {
      id: 'id',
      clientId: 'clientId',
      clientSecret: 'clientSecret',
      description: 'description',
      userId: 'userId',
      name: 'name',
      status: 'status',
      /** 可选项 */
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
  }
}
