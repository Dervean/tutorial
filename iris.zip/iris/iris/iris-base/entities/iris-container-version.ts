import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from '@gfe/zebra-typeorm-client'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisContainerVersion {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: '页面容器版本id 页面容器版本表对应主键' })
  id: string
  @Column({ name: 'container_id', type: 'bigint', comment: '页面容器 ID', unsigned: true })
  containerId: string
  @Column({ name: 'version', type: 'varchar', length: 64, comment: '页面容器版本名' })
  version: string
  @Column({ name: 'source', type: 'varchar', length: 300, comment: '页面容器S3地址' })
  source: string
  @Column({ name: 'engine_version_start', type: 'bigint', unsigned: true, comment: '编辑器引擎版本范围起始' })
  engineVersionStart: string
  @Column({ name: 'engine_version_end', type: 'bigint', unsigned: true, comment: '编译器引擎版本范围终点' })
  engineVersionEnd: string
  @Column({ name: 'description', type: 'varchar', length: 256, comment: '描述信息' })
  description?: string
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string

  static get columns(): Columns<IrisContainerVersion> {
    return {
      id: 'id',
      containerId: 'containerId',
      version: 'version',
      source: 'source',
      engineVersionStart: 'engineVersionStart',
      engineVersionEnd: 'engineVersionEnd',
      description: 'description',
      createdBy: 'createdBy',
      createTime: 'createTime',
    }
  }
}
