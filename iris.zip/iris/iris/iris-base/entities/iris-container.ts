import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisContainer {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: '页面容器id 页面容器表对应主键' })
  id: string
  @Column({ name: 'name', type: 'varchar', length: 64, comment: '场景名称' })
  name: string
  @Column({ name: 'status', type: 'tinyint', comment: '页面容器状态', default: IrisStatusEnum.Active })
  status?: number
  @Column({ name: 'description', type: 'varchar', length: 256, comment: '描述信息' })
  description?: string
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  static get columns(): Columns<IrisContainer> {
    return {
      id: 'id',
      name: 'name',
      status: 'status',
      description: 'description',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }
}
