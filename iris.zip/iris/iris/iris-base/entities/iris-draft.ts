import { Entity, PrimaryGeneratedColumn, Column, UpdateDateColumn, CreateDateColumn } from '@gfe/zebra-typeorm-client'
import assert from 'assert'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { JsonHelper } from 'iris/iris-lib/helper/json-helper'
import { IrisInvalidFormatParamError } from 'iris/iris-lib/model/iris-error'

@Entity()
export class IrisDraft {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', comment: '草稿 id', unsigned: true })
  id: string

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: string
  @Column({ name: 'page_id', type: 'bigint', comment: '页面 Id', unsigned: true })
  pageId: string
  @Column({ name: 'user_id', type: 'varchar', length: 32, comment: 'org emp id' })
  userId: string
  @Column({ type: 'simple-json', comment: '草稿 JSON' })
  dsl: JSON
  @Column({ name: 'sync_version', type: 'varchar', length: 32, comment: '同步版本号' })
  syncVersion?: string
  @Column({ name: 'sync_version_test', type: 'varchar', length: 32, comment: '同步泳道版本号' })
  syncVersionTest?: string
  @Column({ name: 'sync_version_test01', type: 'varchar', length: 32, comment: '同步版本号' })
  syncVersionTest01?: string
  @Column({ name: 'swimlane', type: 'varchar', length: 32, comment: '泳道' })
  swimlane?: string

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  static get columns(): Columns<IrisDraft> {
    return {
      id: 'id',
      /** 必填项 */
      projectId: 'projectId',
      pageId: 'pageId',
      userId: 'userId',
      dsl: 'dsl',
      /** 可选项 */
      syncVersion: 'syncVersion',
      syncVersionTest: 'syncVersionTest',
      syncVersionTest01: 'syncVersionTest01',
      swimlane: 'swimlane',
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
  }

  static validateDSL(dsl: JSON) {
    try {
      assert.ok(JsonHelper.isJson(dsl) || Array.isArray(dsl), `DSL格式错误`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }
}
