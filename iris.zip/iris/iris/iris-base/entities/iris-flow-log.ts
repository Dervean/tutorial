import { Entity, Column, CreateDateColumn, PrimaryColumn, JoinColumn, ManyToOne } from '@gfe/zebra-typeorm-client'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { IrisLogLevelEnum } from 'iris/iris-base/enum/common'
import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'

@Entity()
export class IrisFlowLog {
  @PrimaryColumn({ name: 'id', type: 'varchar', length: 32, unsigned: true })
  id: string

  @Column({ name: 'order_id', type: 'varchar', length: 32, comment: '流程 ID' })
  orderId: string
  @Column({ name: 'task_id', type: 'varchar', length: 32, comment: '流程任务 ID' })
  taskId?: string
  @Column({ type: 'varchar', length: 16, comment: '日志类型' })
  level: IrisLogLevelEnum
  @Column({ type: 'simple-json', comment: '日志内容' })
  content: Record<string, any>

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string

  @ManyToOne(() => IrisFlowOrder)
  @JoinColumn({ name: 'order_id' })
  order: IrisFlowOrder
  @ManyToOne(() => IrisFlowTask)
  @JoinColumn({ name: 'task_id' })
  task: IrisFlowTask

  static get columns(): Columns<IrisFlowLog> {
    return {
      id: 'id',
      level: 'level',
      content: 'content',
      createTime: 'createTime',
      order: 'order',
      orderId: 'orderId',
      task: 'task',
      taskId: 'taskId',
    }
  }

  public toJSON() {
    return {
      id: this.id,
      level: this.level,
      content: this.content,
      createTime: this.createTime,
    }
  }
}
