import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn, OneToMany } from '@gfe/zebra-typeorm-client'
import { StateEnum, StateDescEnum } from 'iris/iris-flow/enum/flow'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'

@Entity()
export class IrisFlowOrder {
  @PrimaryColumn({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 ID, 流程实例表主键' })
  orderId: string

  @Column({ name: 'process_id', type: 'varchar', length: 32, comment: '流程定义 ID, 流程定义表主键' })
  processId: string
  @Column({ name: 'process_name', type: 'varchar', length: 256, comment: '流程定义名称' })
  processName: string
  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: StateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: StateDescEnum

  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy: string
  @Column({ name: 'remark', type: 'varchar', length: 256, comment: '创建人备注' })
  remark?: string

  @Column({ name: 'parent_id', type: 'varchar', length: 32, comment: '父流程 ID' })
  parentId?: string
  @Column({ name: 'parent_node_name', type: 'varchar', length: 256, comment: '父流程名称' })
  parentNodeName?: string

  @Column({ type: 'simple-json', comment: '流程变量' })
  variable?: Record<string, any>

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  @OneToMany(type => IrisFlowLog, entity => entity.order)
  logs?: IrisFlowLog[]

  /** @todo 后续删除 */
  constructor(model?: IrisFlowOrder) {
    if (model) {
      if (model.orderId) this.orderId = model.orderId
      if (model.processId) this.processId = model.processId
      if (model.processName) this.processName = model.processName
      if (model.state) this.state = model.state
      if (model.stateDesc) this.stateDesc = model.stateDesc
      if (model.createdBy) this.createdBy = model.createdBy
      if (model.remark) this.remark = model.remark
      if (model.parentId) this.parentId = model.parentId
      if (model.parentNodeName) this.parentNodeName = model.parentNodeName
      if (model.variable) this.variable = model.variable
      if (model.createTime) this.createTime = model.createTime
      if (model.updatedBy) this.updatedBy = model.updatedBy
      if (model.updateTime) this.updateTime = model.updateTime
    }
  }

  static get columns(): Columns<IrisFlowOrder> {
    return {
      orderId: 'orderId',
      processId: 'processId',
      processName: 'processName',
      state: 'state',
      stateDesc: 'stateDesc',
      parentId: 'parentId',
      parentNodeName: 'parentNodeName',
      variable: 'variable',
      logs: 'logs',
      createdBy: 'createdBy',
      remark: 'remark',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }
}
