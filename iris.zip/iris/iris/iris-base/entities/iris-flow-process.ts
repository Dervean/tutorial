import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { FlowProcessModel } from 'iris/iris-flow/model/flow-process-model'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisFlowProcess {
  @PrimaryColumn({ name: 'process_id', type: 'varchar', length: 32, comment: '流程定义 ID, 流程定义表主键' })
  processId: string

  @Column({ name: 'name', type: 'varchar', length: 256, comment: '流程定义名称' })
  name: string
  @Column({ name: 'display_name', type: 'varchar', length: 256, comment: '流程定义显示名称' })
  displayName?: string
  @Column({ type: 'int', unsigned: true, comment: '版本' })
  version: number
  @Column({ type: 'blob', comment: '流程定义 XML' })
  content: Buffer

  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  public model?: FlowProcessModel

  static get columns(): Columns<IrisFlowProcess> {
    return {
      processId: 'processId',
      name: 'name',
      displayName: 'displayName',
      version: 'version',
      content: 'content',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  public toJSON() {
    return {
      processId: this.processId,
      name: this.name,
      displayName: this.displayName,
      version: this.version,
      createdBy: this.createdBy,
      createTime: this.createTime,
      updatedBy: this.updatedBy,
      updateTime: this.updateTime,
    }
  }
}
