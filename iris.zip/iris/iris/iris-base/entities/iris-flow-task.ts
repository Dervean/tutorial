import { Entity, Column, CreateDateColumn, PrimaryColumn, UpdateDateColumn, OneToMany } from '@gfe/zebra-typeorm-client'
import { PerformTypeEnum, StateDescEnum, StateEnum } from 'iris/iris-flow/enum/flow'
import { FlowTaskModel } from 'iris/iris-flow/model/node/flow-task-model'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'

@Entity()
export class IrisFlowTask {
  @PrimaryColumn({ name: 'task_id', type: 'varchar', length: 32, comment: '流程任务 ID, 流程任务表主键' })
  taskId: string

  @Column({ name: 'name', type: 'varchar', length: 256, comment: '流程任务名称' })
  name: string
  @Column({ name: 'display_name', type: 'varchar', length: 256, comment: '流程任务显示名称' })
  displayName?: string
  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: StateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: StateDescEnum
  @Column({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 ID, 流程实例表主键' })
  orderId: string
  @Column({ name: 'perform_type', type: 'varchar', length: 8, comment: '任务类型' })
  performType: PerformTypeEnum // @todo

  @Column({ name: 'tag', type: 'varchar', length: 64, comment: '任务Tag' })
  tag?: string
  @Column({ name: 'parent_task_id', type: 'varchar', length: 32, comment: '父任务 ID' })
  parentTaskId?: string
  @Column({ type: 'varchar', length: 32, comment: '处理人' })
  operator?: string
  @Column({ type: 'simple-json', comment: '参与人' })
  actors?: string[]
  @Column({ type: 'simple-json', comment: '变量' })
  variable?: Record<string, any>

  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  @OneToMany(type => IrisFlowLog, entity => entity.task)
  logs?: IrisFlowLog[]

  public model?: FlowTaskModel

  static get columns(): Columns<IrisFlowTask> {
    return {
      taskId: 'taskId',
      name: 'name',
      displayName: 'displayName',
      state: 'state',
      stateDesc: 'stateDesc',
      orderId: 'orderId',
      performType: 'performType',
      parentTaskId: 'parentTaskId',
      operator: 'operator',
      actors: 'actors',
      tag: 'tag',
      variable: 'variable',
      logs: 'logs',
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
  }

  public toJSON() {
    return {
      taskId: this.taskId,
      name: this.name,
      displayName: this.displayName,
      state: this.state,
      stateDesc: this.stateDesc,
      orderId: this.orderId,
      performType: this.performType,
      parentTaskId: this.parentTaskId,
      operator: this.operator,
      actors: this.actors,
      tag: this.tag,
      logs: this.logs,
      createTime: this.createTime,
      updateTime: this.updateTime,
    }
  }
}
