import { Entity, Column, CreateDateColumn, PrimaryColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { IrisCanaryStateDescEnum, IrisCanaryStateEnum } from 'iris/iris-base/enum/canary'
import { CanaryStrategyModel } from 'iris/iris-biz/model/canary-strategy-model'

@Entity()
export class IrisHtmlCanaryStrategy {
  @PrimaryColumn({ name: 'id', type: 'varchar', length: 32, comment: '灰度策略 id' })
  id: string

  @Column({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 id' })
  orderId: string
  @Column({ name: 'page_id', type: 'bigint', comment: '页面 id', unsigned: true })
  pageId: string
  @Column({ name: 'project_id', type: 'bigint', comment: '项目 id', unsigned: true })
  projectId: string

  @Column({ name: 'canary_args', type: 'varchar', length: 64, comment: '灰度参数' })
  canaryArgs: string
  @Column({ name: 'origin_args', type: 'varchar', length: 64, comment: '主干参数' })
  originArgs: string
  @Column({ name: 'version', type: 'varchar', length: 32, comment: '灰度版本' })
  version: string

  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: IrisCanaryStateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: IrisCanaryStateDescEnum

  @Column({ name: 'online_time', type: 'datetime', comment: '上线时间' })
  onlineTime?: Date
  @Column({ name: 'offline_time', type: 'datetime', comment: '下线时间' })
  offlineTime?: Date

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  public canaryStrategy?: CanaryStrategyModel

  static get columns(): Columns<IrisHtmlCanaryStrategy> {
    return {
      id: 'id',
      orderId: 'orderId',
      pageId: 'pageId',
      projectId: 'projectId',
      canaryArgs: 'canaryArgs',
      originArgs: 'originArgs',
      version: 'version',
      state: 'state',
      stateDesc: 'stateDesc',
      onlineTime: 'onlineTime',
      offlineTime: 'offlineTime',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }
}
