import { Entity, Column, CreateDateColumn, UpdateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { IrisPublishTypeEnum, IrisTargetEnvEnum } from 'iris/iris-base/enum/common'
import { IrisFlowStateDescEnum, IrisFlowStateEnum } from 'iris/iris-base/enum/flow'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisHtmlReleaseHistoryFlow {
  @PrimaryColumn({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 ID' })
  orderId: string

  @Column({ name: 'page_id', type: 'bigint', comment: 'id', unsigned: true })
  pageId: string
  @Column({ name: 'project_id', type: 'bigint', comment: '项目 id', unsigned: true })
  projectId: string
  @Column({ name: 'target', type: 'varchar', length: 16, comment: '页面发布环境' })
  target: IrisTargetEnvEnum
  @Column({ name: 'type', type: 'varchar', length: 16, comment: '页面发布类型' })
  type: IrisPublishTypeEnum
  @Column({ name: 'version', type: 'varchar', length: 32, comment: '版本号' })
  version: string
  @Column({ name: 'container_id', type: 'bigint', comment: '页面容器 ID', unsigned: true })
  containerId: string
  @Column({ name: 'container_version', type: 'varchar', length: 32, comment: '页面容器版本' })
  containerVersion: string
  @Column({ name: 'process_name', type: 'varchar', length: 256, comment: '流程定义名称' })
  processName: string
  @Column({ name: 'state', type: 'tinyint', comment: '状态' })
  state: IrisFlowStateEnum
  @Column({ name: 'state_desc', type: 'varchar', length: 32, comment: '状态描述' })
  stateDesc: IrisFlowStateDescEnum

  @Column({ name: 'swimlane', type: 'varchar', length: 32, comment: '泳道号' })
  swimlane?: string
  @Column({ name: 'remark', type: 'varchar', length: 256, comment: '创建人备注' })
  remark?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  static get columns(): Columns<IrisHtmlReleaseHistoryFlow> {
    return {
      orderId: 'orderId',
      pageId: 'pageId',
      projectId: 'projectId',
      createdBy: 'createdBy',
      remark: 'remark',
      version: 'version',
      type: 'type',
      target: 'target',
      containerId: 'containerId',
      containerVersion: 'containerVersion',
      processName: 'processName',
      swimlane: 'swimlane',
      state: 'state',
      stateDesc: 'stateDesc',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }
}
