import { Entity, Column, CreateDateColumn, PrimaryColumn } from '@gfe/zebra-typeorm-client'
import { IrisPublishTypeEnum, IrisTargetEnvEnum } from 'iris/iris-base/enum/common'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisHtmlVersion {
  @PrimaryColumn({ name: 'id', type: 'varchar', length: 32 })
  id: string

  @Column({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例 ID' })
  orderId: string
  @Column({ name: 'page_id', type: 'bigint', comment: 'id', unsigned: true })
  pageId: string
  @Column({ name: 'project_id', type: 'bigint', comment: '项目 id', unsigned: true })
  projectId: string
  @Column({ name: 'target', type: 'varchar', length: 16, comment: '页面发布环境' })
  target: IrisTargetEnvEnum
  @Column({ name: 'type', type: 'varchar', length: 16, comment: '页面发布类型' })
  type: IrisPublishTypeEnum
  @Column({ name: 'version', type: 'varchar', length: 32, comment: '版本号' })
  version: string
  @Column({ name: 'container_id', type: 'bigint', comment: '页面容器 ID', unsigned: true })
  containerId: string
  @Column({ name: 'container_version', type: 'varchar', length: 32, comment: '页面容器版本' })
  containerVersion: string
  @Column({ type: 'varchar', length: 32, comment: 'md5' })
  md5: string
  @Column({ name: 'swimlane', type: 'varchar', length: 32, comment: '泳道号' })
  swimlane?: string
  @Column({ name: 'remark', type: 'varchar', length: 256, comment: '创建人备注' })
  remark?: string

  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string

  public html?: string

  public dsl?: JSON

  static get columns(): Columns<IrisHtmlVersion> {
    return {
      id: 'id',
      orderId: 'orderId',
      pageId: 'pageId',
      projectId: 'projectId',
      remark: 'remark',
      version: 'version',
      type: 'type',
      target: 'target',
      md5: 'md5',
      containerId: 'containerId',
      containerVersion: 'containerVersion',
      swimlane: 'swimlane',
      createdBy: 'createdBy',
      createTime: 'createTime',
    }
  }

  /**
   * 返回无 target 的 html 路径
   * 用于自定义域名和 WebStatic
   * @param projectId 项目ID
   * @param path 路径
   * @returns targetless html obj path
   */
  public static genTargetlessHtmlObjPath(projectId: string, path: string) {
    return `${projectId}${path}index.html`
  }

  public static genS3DslObjPath(target: IrisTargetEnvEnum, projectId: string, pageId: string, version: string) {
    return `${target}/dsl/${projectId}/${pageId}/${version}.json`
  }

  public static genS3HtmlBackupObjPath(target: IrisTargetEnvEnum, projectId: string, pageId: string, version: string) {
    return `${target}/html/${projectId}/${pageId}/${version}/index.html`
  }

  public static genS3HtmlObjPath(target: IrisTargetEnvEnum, projectId: string, path: string, swimlane?: string) {
    const objPath = IrisHtmlVersion.genTargetlessHtmlObjPath(projectId, path)
    if (target === IrisTargetEnvEnum.Test) {
      return `${target}/${swimlane}/${objPath}`
    }
    return `${target}/${objPath}`
  }

  public static genWebStaticHtmlObjPath(projectId: string, path: string) {
    return IrisHtmlVersion.genTargetlessHtmlObjPath(projectId, path)
  }
}
