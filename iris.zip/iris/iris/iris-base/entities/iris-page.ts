import assert from 'assert'
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'
import { IrisInvalidFormatParamError } from 'iris/iris-lib/model/iris-error'

@Entity()
export class IrisPage {
  @PrimaryGeneratedColumn({ name: 'page_id', type: 'bigint', comment: 'id', unsigned: true })
  pageId: string

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 id', unsigned: true })
  projectId: string
  @Column({ name: 'scene_id', type: 'bigint', comment: '场景 id', unsigned: true })
  sceneId: string
  @Column({ name: 'page_name', type: 'varchar', length: 64, comment: '页面名称' })
  pageName: string
  @Column({ name: 'path', type: 'varchar', length: 128, comment: '页面路径' })
  path: string
  @Column({ name: 'engine_version', type: 'bigint', unsigned: true, comment: '编辑器引擎版本' })
  engineVersion: string

  @Column({ name: 'status', type: 'tinyint', comment: '状态', default: IrisStatusEnum.Active })
  status?: IrisStatusEnum
  @Column({ type: 'varchar', length: 256, comment: '描述' })
  description?: string
  @Column({ name: 'created_by', type: 'varchar', length: 64, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 64, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  public static REGX_URL_PATH = /^(\/[-a-zA-Z0-9@:%\_\+\.~#?&=]+)*\/$/
  public static REGX_ENGINE_VERSION = /^[1-9]\d*$/

  static get columns(): Columns<IrisPage> {
    return {
      pageId: 'pageId',
      /** 必填项 */
      projectId: 'projectId',
      sceneId: 'sceneId',
      pageName: 'pageName',
      path: 'path',
      engineVersion: 'engineVersion',
      /** 可选项 */
      status: 'status',
      description: 'description',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }

  public static validatePageName(pageName: string) {
    try {
      assert.ok(StringHelper.isString(pageName), `页面名称必须是字符串: pageName=${pageName}`)
      assert.ok(!!pageName, `页面名称不能为空: pageName=${pageName}`)
      /** 不能只包含数字 */
      assert.ok(!/^\d+$/.test(pageName), `页面名称不能只包含数字: ${pageName}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  /**
   * 页面路径格式必须以 '/' 开头, 以 '/' 结尾
   * @param path e.g. '/', '/adca/'
   */
  public static validatePath(path: string) {
    try {
      assert.ok(!!path, `页面路径不能为空: path=${path}`)
      assert.ok(IrisPage.REGX_URL_PATH.test(path), `页面路径格式错误: path=${path}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  public static validateEngineVersion(engineVersion: string) {
    try {
      assert.ok(!!engineVersion, `编辑器引擎版本不能为空: engineVersion=${engineVersion}`)
      assert.ok(Number.isInteger(+engineVersion), `编辑器引擎版本格式错误: engineVersion=${engineVersion}`)
      assert.ok(IrisPage.REGX_ENGINE_VERSION.test(`${engineVersion}`), `编辑器引擎版本格式错误: engineVersion=${engineVersion}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }
}
