import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisProjectMember {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: '成员 id' })
  id: string

  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: string
  @Column({ name: 'user_id', type: 'varchar', length: 32, comment: 'org emp id' })
  userId: string
  @Column({ type: 'int', comment: '权限 32-bit integer', unsigned: true })
  permission: number

  /** 可选项 */
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  static get columns(): Columns<IrisProjectMember> {
    return {
      id: 'id',
      /** 必填项 */
      projectId: 'projectId',
      userId: 'userId',
      permission: 'permission',
      /** 可选项 */
      createTime: 'createTime',
      updateTime: 'updateTime',
    }
  }
}
