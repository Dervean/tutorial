import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, ManyToOne, JoinColumn } from '@gfe/zebra-typeorm-client'
import { IrisTag } from 'iris/iris-base/entities/iris-tag'
import { IrisProject } from 'iris/iris-base/entities/iris-project'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisProjectTag {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: 'id' })
  id: string
  @Column({ name: 'project_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  projectId: string
  @Column({ name: 'tag_id', type: 'bigint', comment: '标签 Id', unsigned: true })
  tagId: string
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy?: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string

  @ManyToOne(type => IrisProject)
  @JoinColumn({ name: 'project_id' })
  project?: IrisProject
  @ManyToOne(type => IrisTag)
  @JoinColumn({ name: 'id' })
  tag?: IrisTag

  static get columns(): Columns<IrisProjectTag> {
    return {
      id: 'id',
      projectId: 'projectId',
      tagId: 'tagId',
      createdBy: 'createdBy',
      createTime: 'createTime',
      /** relation column */
      tag: 'tag',
      project: 'project',
    }
  }
}
