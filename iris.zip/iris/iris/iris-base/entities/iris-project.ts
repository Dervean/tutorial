import assert from 'assert'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, OneToMany } from '@gfe/zebra-typeorm-client'
import { IrisProjectTag } from 'iris/iris-base/entities/iris-project-tag'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'
import { IrisInvalidFormatParamError } from 'iris/iris-lib/model/iris-error'
import { JsonHelper } from 'iris/iris-lib/helper/json-helper'

@Entity()
export class IrisProject {
  @PrimaryGeneratedColumn({ name: 'project_id', type: 'bigint', unsigned: true, comment: '项目 id' })
  projectId: string

  @Column({ name: 'project_name', type: 'varchar', length: 64, comment: '项目名称' })
  projectName?: string
  @Column({ name: 'is_private', type: 'tinyint', comment: '是否私有', default: Number(false) })
  isPrivate?: number
  @Column({ name: 'status', type: 'tinyint', comment: '状态', default: IrisStatusEnum.Active })
  status?: number
  @Column({ type: 'varchar', length: 256, comment: '项目描述' })
  description?: string
  @Column({ type: 'varchar', length: 512, comment: 'icon 地址' })
  icon?: string
  @Column({ type: 'simple-json', comment: '页面容器注入属性' })
  config?: JSON
  @Column({ name: 'leader', type: 'varchar', length: 32, comment: '项目负责人' })
  leader: string

  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy?: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  @OneToMany(type => IrisProjectTag, IrisProjectTag => IrisProjectTag.project)
  projectTags?: IrisProjectTag[]

  static get columns(): Columns<IrisProject> {
    return {
      projectId: 'projectId',
      projectName: 'projectName',
      isPrivate: 'isPrivate',
      status: 'status',
      description: 'description',
      icon: 'icon',
      leader: 'leader',
      config: 'config',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
      /** relation column */
      projectTags: 'projectTags',
    }
  }

  public static validateProjectName(projectName: string) {
    try {
      assert.ok(StringHelper.isString(projectName), `项目名称必须是字符串: projectName=${projectName}`)
      assert.ok(!!projectName, `项目名称不能为空: projectName=${projectName}`)
      /** 不能只包含数字 */
      assert.ok(!/^\d+$/.test(projectName), `项目名称不能只包含数字: ${projectName}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  public static validateConfig(config: JSON) {
    try {
      assert.ok(JsonHelper.isJson(config), `系统配置格式错误`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }
}
