import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, ManyToOne, JoinColumn } from '@gfe/zebra-typeorm-client'
import { IrisScene } from 'iris/iris-base/entities/iris-scene'
import { IrisTag } from 'iris/iris-base/entities/iris-tag'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisSceneTag {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: 'id' })
  id: string
  @Column({ name: 'scene_id', type: 'bigint', comment: '项目 Id', unsigned: true })
  sceneId: string
  @Column({ name: 'tag_id', type: 'bigint', comment: '标签 Id', unsigned: true })
  tagId: string
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy?: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string

  @ManyToOne(type => IrisScene)
  @JoinColumn({ name: 'id' })
  scene?: IrisScene
  @ManyToOne(type => IrisTag)
  @JoinColumn({ name: 'id' })
  tag?: IrisTag

  static get columns(): Columns<IrisSceneTag> {
    return {
      id: 'id',
      /** 必填项 */
      sceneId: 'sceneId',
      tagId: 'tagId',
      createdBy: 'createdBy',
      /** 可选项 */
      createTime: 'createTime',
      /** relation column */
      tag: 'tag',
      scene: 'scene',
    }
  }
}
