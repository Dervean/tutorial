import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, OneToMany } from '@gfe/zebra-typeorm-client'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { IrisSceneTag } from 'iris/iris-base/entities/iris-scene-tag'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisScene {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: '场景id 场景表对应主键' })
  id: string
  @Column({ name: 'name', type: 'varchar', length: 64, comment: '场景名称' })
  name: string
  @Column({ name: 'container_id', type: 'bigint', comment: '页面容器 ID', unsigned: true })
  containerId: string
  @Column({ type: 'varchar', length: 512, comment: '头图地址' })
  image?: string
  @Column({ name: 'status', type: 'tinyint', comment: '场景状态', default: IrisStatusEnum.Active })
  status?: number
  @Column({ name: 'description', type: 'varchar', length: 256, comment: '描述信息' })
  description?: string
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  @OneToMany(type => IrisSceneTag, IrisSceneTag => IrisSceneTag.scene)
  sceneTags?: IrisSceneTag[]

  static get columns(): Columns<IrisScene> {
    return {
      id: 'id',
      name: 'name',
      image: 'image',
      containerId: 'containerId',
      status: 'status',
      description: 'description',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
      /** relation column */
      sceneTags: 'sceneTags',
    }
  }
}
