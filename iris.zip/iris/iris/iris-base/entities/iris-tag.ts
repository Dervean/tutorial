import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from '@gfe/zebra-typeorm-client'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { Columns } from 'iris/iris-base/dao/abstract-dao'

@Entity()
export class IrisTag {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: '标签id 场景表对应主键' })
  id: string
  @Column({ name: 'parent_tag_id', type: 'bigint', unsigned: true, comment: '标签父级ID' })
  parentTagId?: string
  @Column({ name: 'source', type: 'varchar', length: 256, comment: '标签来源' })
  source: string
  @Column({ name: 'tag_type', type: 'varchar', length: 256, comment: '标签类型' })
  tagType: string
  @Column({ name: 'tag_value', type: 'varchar', length: 64, comment: '标签值' })
  tagValue: string
  @Column({ name: 'tag_name', type: 'varchar', length: 256, comment: '标签名称' })
  tagName?: string
  @Column({ name: 'status', type: 'tinyint', comment: '场景状态', default: IrisStatusEnum.Active })
  status?: number
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy?: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string

  static get columns(): Columns<IrisTag> {
    return {
      id: 'id',
      parentTagId: 'parentTagId',
      source: 'source',
      tagType: 'tagType',
      tagValue: 'tagValue',
      tagName: 'tagName',
      status: 'status',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
    }
  }
}
