import { Entity, PrimaryColumn, ManyToOne, JoinColumn } from '@gfe/zebra-typeorm-client'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { IrisTask } from 'iris/iris-base/entities/iris-task'
import { IrisPage } from 'iris/iris-base/entities/iris-page'

@Entity()
export class IrisTaskPage {
  @PrimaryColumn({ name: 'task_id', type: 'bigint', unsigned: true, comment: '任务ID' })
  taskId: string
  @PrimaryColumn({ name: 'page_id', type: 'bigint', unsigned: true, comment: '页面ID' })
  pageId: string
  @ManyToOne(() => IrisPage)
  @JoinColumn({ name: 'page_id' })
  page: IrisPage
  @ManyToOne(() => IrisTask)
  @JoinColumn({ name: 'task_id' })
  task: IrisTask

  static get columns(): Columns<IrisTaskPage> {
    return {
      taskId: 'taskId',
      pageId: 'pageId',
      page: 'page',
      task: 'task',
    }
  }
}
