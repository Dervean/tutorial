import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from '@gfe/zebra-typeorm-client'
import { IrisTaskStatusEnum } from 'iris/iris-base/enum/task'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { IrisTask } from 'iris/iris-base/entities/iris-task'

@Entity()
export class IrisTaskRecord {
  @PrimaryGeneratedColumn({ name: 'id', type: 'bigint', unsigned: true, comment: '任务执行记录ID' })
  id: string
  @Column({ name: 'task_id', type: 'bigint', unsigned: true, comment: '任务ID' })
  taskId: string
  @Column({ name: 'workflow_id', type: 'bigint', unsigned: true, comment: '工作流ID' })
  workflowId: string
  @Column({ name: 'order_id', type: 'varchar', length: 32, comment: '流程实例ID' })
  orderId: string
  @Column({ name: 'description', type: 'varchar', length: 255, comment: '上线/回滚描述' })
  description?: string
  @Column({ name: 'error_msg', type: 'varchar', length: 255, comment: '错误原因' })
  errorMsg?: string
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy?: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: string
  @Column({ name: 'status', type: 'tinyint', comment: '任务状态', default: IrisTaskStatusEnum.Active })
  status?: IrisTaskStatusEnum
  @ManyToOne(() => IrisTask)
  @JoinColumn({ name: 'task_id' })
  task: IrisTask

  static get columns(): Columns<IrisTaskRecord> {
    return {
      id: 'id',
      taskId: 'taskId',
      workflowId: 'workflowId',
      orderId: 'orderId',
      errorMsg: 'errorMsg',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
      status: 'status',
      task: 'task',
    }
  }
}
