import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, OneToMany } from '@gfe/zebra-typeorm-client'
import { IrisTaskTypeEnum, IrisTaskStatusEnum } from 'iris/iris-base/enum/task'
import { Columns } from 'iris/iris-base/dao/abstract-dao'
import { IrisTaskPage } from 'iris/iris-base/entities/iris-task-page'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'

@Entity()
export class IrisTask {
  @PrimaryGeneratedColumn({ name: 'task_id', type: 'bigint', unsigned: true, comment: '任务id' })
  taskId: string
  @Column({ name: 'project_id', type: 'bigint', unsigned: true, comment: '项目ID' })
  projectId: string
  @Column({ name: 'name', type: 'varchar', length: 64, comment: '任务名称' })
  name: string
  @Column({ name: 'type', type: 'tinyint', comment: '任务类型', default: IrisTaskTypeEnum.Requirements })
  type: number
  @Column({ name: 'ones_project_id', type: 'bigint', unsigned: true, comment: 'ones项目ID' })
  onesProjectId?: string
  @Column({ name: 'ones_task_id', type: 'bigint', unsigned: true, comment: 'ones任务ID' })
  onesTaskId?: string
  @Column({ name: 'ones_requirement_id', type: 'bigint', unsigned: true, comment: 'ones需求ID' })
  onesRequirementId?: string
  @Column({ name: 'ones_requirement_status', type: 'tinyint', comment: 'ones需求状态' })
  onesRequirementStatus?: number
  @Column({ name: 'swimlane', type: 'varchar', length: 32, comment: '泳道' })
  swimlane?: string
  @Column({ name: 'created_by', type: 'varchar', length: 32, comment: '创建人' })
  createdBy: string
  @CreateDateColumn({ name: 'create_time', type: 'datetime', comment: '创建时间' })
  createTime?: Date | string
  @Column({ name: 'updated_by', type: 'varchar', length: 32, comment: '操作人' })
  updatedBy?: string
  @UpdateDateColumn({ name: 'update_time', type: 'datetime', comment: '更新时间' })
  updateTime?: Date | string
  @Column({ name: 'status', type: 'tinyint', comment: '任务状态', default: IrisTaskStatusEnum.Pending })
  status: number
  @UpdateDateColumn({ name: 'rd', type: 'text', comment: '研发', default: '[]' })
  rd?: string
  @UpdateDateColumn({ name: 'qa', type: 'text', comment: '研发', default: '[]' })
  qa?: string
  @UpdateDateColumn({ name: 'pm', type: 'text', comment: '研发', default: '[]' })
  pm?: string
  @OneToMany(() => IrisTaskPage, entity => entity.task)
  pageList: IrisTaskPage[]
  @OneToMany(() => IrisTaskRecord, entity => entity.task)
  taskRecordList: IrisTaskRecord[]

  static get columns(): Columns<IrisTask> {
    return {
      taskId: 'taskId',
      projectId: 'projectId',
      name: 'name',
      type: 'type',
      onesProjectId: 'onesProjectId',
      onesTaskId: 'onesTaskId',
      onesRequirementId: 'onesRequirementId',
      onesRequirementStatus: 'onesRequirementStatus',
      swimlane: 'swimlane',
      createdBy: 'createdBy',
      createTime: 'createTime',
      updatedBy: 'updatedBy',
      updateTime: 'updateTime',
      status: 'status',
      rd: 'rd',
      qa: 'qa',
      pm: 'pm',
      pageList: 'pageList',
      taskRecordList: 'taskRecordList',
    }
  }
}
