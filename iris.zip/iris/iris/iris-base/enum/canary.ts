export enum IrisCanaryStateEnum {
  Pending = 1,
  Online = 2,
  Modifying = 3,
  Offline = 4,
  Deleted = 5,
}

export enum IrisCanaryStateDescEnum {
  Pending = '待上线',
  Online = '已上线',
  Modifying = '修改中',
  Offline = '已下线',
  Deleted = '已删除',
}

export enum CanaryUserInputActionEnum {
  /** 下线灰度 */
  Offline = 'offline',
  /** 全量上线 */
  Online = 'online',
}
