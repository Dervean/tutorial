/** 状态枚举 */
export enum IrisStatusEnum {
  Active = 1,
  Inactive = -1,
}

export enum IrisTagSource {
  TAM = 1,
}

/** 发布类型 */
export enum IrisPublishTypeEnum {
  Publish = 'publish',
  Rollback = 'rollback',
  Canary = 'canary',
}

/** 发布环境 */
export enum IrisTargetEnvEnum {
  Production = 'production',
  Test01 = 'test01',
  Test = 'test',
}

export enum IrisLogLevelEnum {
  Debug = 'debug',
  Info = 'info',
  Error = 'error',
  Warn = 'warn',
  Fatal = 'fatal',
}
