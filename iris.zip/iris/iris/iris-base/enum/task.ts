export enum IrisTaskTypeEnum {
  Requirements = 1,
  Hotfix = 2,
}

export enum IrisTaskStatusEnum {
  Inactive = -1,
  Pending = 1,
  Active = 2,
  Success = 3,
  Failed = 4,
  Canceled = 5,
  Rollback = 6,
}

export enum IrisTaskStatusDescEnum {
  Pending = '待执行',
  Active = '进行中',
  Success = '已完成',
  Failed = '已失败',
  Canceled = '已撤销',
  Rollback = '已回滚',
}
