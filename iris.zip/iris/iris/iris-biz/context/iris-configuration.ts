import assert from 'assert'
import { existsSync } from 'fs'
import { IrisServiceContext } from 'iris/iris-biz/context/iris-service-context'
import { IrisContext } from 'iris/iris-biz/context/iris-context'
import { IrisLogger, XMLHelper, JSItemType, ReflectHelper } from 'iris/iris-lib'
import { StreamHelper } from 'iris/iris-lib/helper/stream-helper'

export class IrisConfiguration {
  private static SERVICE_CONFIG = 'service.config.xml'

  constructor(context?: IrisContext) {
    IrisServiceContext.context = context
  }

  /**
   * 搜集依赖
   * @param 目录绝对路径
   */
  protected async walk(rootDir: string): Promise<void>
  protected async walk(rootDirList: string[]): Promise<void>
  protected async walk(param: string[] | string) {
    const logger = new IrisLogger()
    let files: string[] = []
    logger.logInfo(`start collecting deps: ${param}`)
    if (Array.isArray(param)) {
      param.forEach(p => {
        const fList = StreamHelper.walk(p)
        files.push(...fList)
      })
    } else {
      files = StreamHelper.walk(param)
    }
    await Promise.all(
      files
        .filter(f => f.endsWith('.js'))
        .map(async f => {
          try {
            await import(f)
          } catch (e: any) {
            logger.logWarning(`collect deps failed: file=${f}, msg=${e.message}`)
          }
        }),
    )
    logger.logInfo(`collect deps successfully: ${param}`)
    return
  }

  protected async parser(resource?: string) {
    const logger = new IrisLogger()
    logger.logInfo('iris service parser start...')
    if (resource) {
      assert.ok(existsSync(resource), `resource not exists: resource=${resource}`)
    }
    return this.parse(resource)
  }

  public async configure(resource?: string) {
    await this.parser(resource)
    return
  }

  private async parse(resource?: string) {
    const filepath = StreamHelper.absFilePath('iris-resource', IrisConfiguration.SERVICE_CONFIG)
    await this.parseConfig(filepath)
    if (resource) {
      await this.parseConfig(resource)
    }
  }

  private async parseConfig(filepath: string) {
    const buffer = StreamHelper.getStreamFromAbsFilePath(filepath)

    const data = await XMLHelper.getFromBuffer(buffer)
    const { $, _, ...children } = data.config
    return this.parseService(children)
  }

  private async parseService(children: JSItemType) {
    for (const name of Object.keys(children)) {
      const values = children[name] as JSItemType[]
      switch (name) {
        case 'service':
          for (const val of values) {
            await this.importClass(val)
            const { $, _, ...dao } = val
            await this.parseService(dao)
          }
          break
        case 'dao':
          for (const val of values) {
            await this.importClass(val)
          }
          break
        default:
          break
      }
    }
  }

  private async importClass(val: JSItemType) {
    const name = val.$.name
    const clazz = val.$.clazz
    const clazzPath = val.$.class
    let target
    if (clazzPath) {
      const imports = await import(StreamHelper.absFilePath(clazzPath))
      target = imports[val.$.clazz]
    } else if (clazz) {
      target = ReflectHelper.classMap.get(clazz)
    } else {
      return
    }
    assert.ok(!!name, `name is required`)
    assert.ok(!!target, `target class not exists: name=${name}, clazz=${clazz}`)
    IrisServiceContext.put(name, target)
  }
}
