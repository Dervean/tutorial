export class IrisContext {
  private contextMap: Map<string, any> = new Map()

  public exists(name: string) {
    return !!this.contextMap.get(name)
  }

  public find(clzName: string) {
    for (const entry of this.contextMap.entries()) {
      const [name, obj] = entry
      if (name === clzName) {
        return obj
      }
    }
    return null
  }

  public put(name: string, clz: new (...args: any[]) => any) {
    this.contextMap.set(name, clz)
  }
}
