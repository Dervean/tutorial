import assert from 'assert'

import { IProjectService } from 'iris/iris-biz/service/project-service'
import { IProjectMemberService } from 'iris/iris-biz/service/project-member-service'
import { IPageService } from 'iris/iris-biz/service/page-service'
import { IPageMemberService } from 'iris/iris-biz/service/page-member-service'
import { IDraftService } from 'iris/iris-biz/service/draft-service'
import { IProjectTagService } from 'iris/iris-biz/service/project-tag-service'
import { ISceneService } from 'iris/iris-biz/service/scene-service'
import { IContainerService } from 'iris/iris-biz/service/container-service'
import { IContainerVersionService } from 'iris/iris-biz/service/container-version-service'
import { IHtmlService } from 'iris/iris-biz/service/html-service'
import { IHtmlReleaseHistoryFlowService } from 'iris/iris-biz/service/html-release-history-flow-service'
import { IHtmlVersionService } from 'iris/iris-biz/service/html-version-service'
import { ITagService } from 'iris/iris-biz/service/tag-service'
import { ITaskService } from 'iris/iris-biz/service/task-service'
import { ITaskPageService } from 'iris/iris-biz/service/task-page-service'
import { ITaskRecordService } from 'iris/iris-biz/service/task-record-service'
import { IrisServiceContext } from 'iris/iris-biz/context/iris-service-context'
import { AdministratorDAO } from 'iris/iris-base/dao/impl/administrator-dao'
import { ProjectDAO } from 'iris/iris-base/dao/impl/project-dao'
import { ProjectMemberDAO } from 'iris/iris-base/dao/impl/project-member-dao'
import { ProjectTagDAO } from 'iris/iris-base/dao/impl/project-tag-dao'
import { PageDAO } from 'iris/iris-base/dao/impl/page-dao'
import { PageMemberDAO } from 'iris/iris-base/dao/impl/page-member-dao'
import { DraftDAO } from 'iris/iris-base/dao/impl/draft-dao'
import { SceneDAO } from 'iris/iris-base/dao/impl/scene-dao'
import { ContainerDAO } from 'iris/iris-base/dao/impl/container-dao'
import { ContainerVersionDAO } from 'iris/iris-base/dao/impl/container-version-dao'
import { HtmlVersionDAO } from 'iris/iris-base/dao/impl/html-version-dao'
import { HtmlReleaseHistoryFlowDAO } from 'iris/iris-base/dao/impl/html-release-history-flow-dao'
import { TagDAO } from 'iris/iris-base/dao/impl/tag-dao'
import { TaskDAO } from 'iris/iris-base/dao/impl/task-dao'
import { TaskPageDAO } from 'iris/iris-base/dao/impl/task-page-dao'
import { TaskRecordDAO } from 'iris/iris-base/dao/impl/task-record-dao'
import { ContainerService } from 'iris/iris-biz/service/impl/container-service'
import { ContainerVersionService } from 'iris/iris-biz/service/impl/container-version-service'
import { DraftService } from 'iris/iris-biz/service/impl/draft-service'
import { HtmlReleaseHistoryFlowService } from 'iris/iris-biz/service/impl/html-release-history-flow-service'
import { HtmlService } from 'iris/iris-biz/service/impl/html-service'
import { HtmlVersionService } from 'iris/iris-biz/service/impl/html-version-service'
import { PageMemberService } from 'iris/iris-biz/service/impl/page-member-service'
import { PageService } from 'iris/iris-biz/service/impl/page-service'
import { ProjectService } from 'iris/iris-biz/service/impl/project-service'
import { ProjectTagService } from 'iris/iris-biz/service/impl/project-tag-service'
import { SceneService } from 'iris/iris-biz/service/impl/scene-service'
import { ProjectMemberService } from 'iris/iris-biz/service/impl/project-member-service'
import { TagService } from 'iris/iris-biz/service/impl/tag-service'
import { TaskService } from 'iris/iris-biz/service/impl/task-service'
import { TaskPageService } from 'iris/iris-biz/service/impl/task-page-service'
import { TaskRecordService } from 'iris/iris-biz/service/impl/task-record-service'
import { ISceneTagService } from 'iris/iris-biz/service/scene-tag-service'
import { SceneTagDAO } from 'iris/iris-base/dao/impl/scene-tag-dao'
import { SceneTagService } from 'iris/iris-biz/service/impl/scene-tag-service'
import { IHtmlCanaryStrategyService } from 'iris/iris-biz/service/html-canary-strategy-service'
import { HtmlCanaryStrategyService } from 'iris/iris-biz/service/impl/html-canary-strategy-service'
import { HtmlCanaryStrategyDAO } from 'iris/iris-base/dao/impl/html-canary-strategy-dao'
import { IAdministratorService } from 'iris/iris-biz/service/administrator-service'
import { AdministratorService } from 'iris/iris-biz/service/impl/administrator-service'
import { IrisUserInfo } from 'iris/iris-app/model/iris-user-info'
import { Context } from 'iris/iris-app/interface/context'
import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'
import { ORGEmployeeService, DamService, TamService, FedoService, WebStaticClientService, WebStaticAdminService, OnesService } from 'iris/iris-out'
import { IrisBizException, IrisUnauthorizedError } from 'iris/iris-lib/model/iris-error'
import { BaAuthService } from 'iris/iris-biz/service/impl/ba-auth-service'
import { IBaAuthService } from 'iris/iris-biz/service/ba-auth-service'
import { BaAuthDAO } from 'iris/iris-base/dao/impl/ba-auth-dao'

export interface IHasEngine {
  setEngine(engine: IrisEngine): void

  get irisEngine(): IrisEngine
}

export class IrisEngine {
  protected _context: Context = null
  protected _user: IrisUserInfo = null
  protected _logger: IrisLogger = null
  protected _flowEngine: FlowEngine = null

  protected orgEmployeeService: ORGEmployeeService
  protected damService: DamService
  protected tamService: TamService
  protected fedoService: FedoService
  protected onesService: OnesService
  protected webstaticService: WebStaticClientService
  protected webstaticAdminService: WebStaticAdminService

  protected adminService: IAdministratorService
  protected baAuthService: IBaAuthService
  protected projectService: IProjectService
  protected projectMemberService: IProjectMemberService
  protected projectTagService: IProjectTagService

  protected pageService: IPageService
  protected pageMemberService: IPageMemberService

  protected draftService: IDraftService
  protected sceneService: ISceneService
  protected sceneTagService: ISceneTagService
  protected containerService: IContainerService
  protected containerVersionService: IContainerVersionService

  protected htmlService: IHtmlService
  protected htmlCanaryStrategyService: IHtmlCanaryStrategyService
  protected htmlReleaseHistoryFlowService: IHtmlReleaseHistoryFlowService
  protected htmlVersionService: IHtmlVersionService

  protected tagService: ITagService

  protected taskService: ITaskService
  protected taskPageService: ITaskPageService
  protected taskRecordService: ITaskRecordService

  constructor(context: Context, user: IrisUserInfo) {
    this._context = context
    this._user = user
  }

  /**
   * 返回登录信息，未设置时抛错
   * @returns
   */
  public user() {
    if (this._user === null) {
      throw new IrisUnauthorizedError(`用户身份信息未初始化`)
    }
    return this._user
  }

  /**
   * 强制改变当前用户信息
   * @param user
   */
  public setUser(user: IrisUserInfo) {
    if (user) {
      this._user = user
    }
  }

  public logger() {
    if (this._logger === null) {
      const logger = new IrisLogger()
      this.setLogger(logger)
    }
    return this._logger
  }

  /**
   * 返回请求上下文
   * @returns
   */
  public context() {
    return this._context
  }

  public setLogger(logger: IrisLogger) {
    if (logger) {
      this._logger = logger
      this._logger.setUser(this._user)
    }
  }

  public setFlowEngine(engine: FlowEngine) {
    if (engine) {
      this._flowEngine = engine
    }
  }

  /**
   * http get 请求数据解构
   * @param event
   * @returns
   */
  public unifyGetRequestQuery() {
    return this._context.query
  }

  /**
   * http post 请求数据解构
   * @param event
   * @returns
   */
  public unifyPostRequestBody() {
    return this._context.request?.body
  }

  /**
   * ==================
   * 公共服务
   * ==================
   */
  public org() {
    if (this.orgEmployeeService) {
      return this.orgEmployeeService
    }
    return this.service(ORGEmployeeService)
  }

  public tam() {
    if (this.tamService) {
      return this.tamService
    }
    return this.service(TamService)
  }

  public dam() {
    if (this.damService) {
      return this.damService
    }
    return this.service(DamService)
  }

  public fedo() {
    if (this.fedoService) {
      return this.fedoService
    }
    return this.service(FedoService)
  }

  public ones() {
    if (this.onesService) {
      return this.onesService
    }
    return this.service(OnesService)
  }

  /**
   * webstatic 部署服务
   * @returns
   */
  public webstatic() {
    if (this.webstaticService) {
      return this.webstaticService
    }
    return this.service(WebStaticClientService)
  }

  /**
   * webstatic 灰度服务
   * @returns
   */
  public webstaticAdmin() {
    if (this.webstaticAdminService) {
      return this.webstaticAdminService
    }
    return this.service(WebStaticAdminService)
  }

  /**
   * ==================
   * 业务服务
   * ==================
   */
  public admin() {
    if (this.adminService) {
      return this.adminService
    }
    return this.service(AdministratorService)
  }

  public baAuth() {
    if (this.baAuthService) {
      return this.baAuthService
    }
    return this.service(BaAuthService)
  }

  public project() {
    if (this.projectService) {
      return this.projectService
    }
    return this.service(ProjectService)
  }

  public projectMember() {
    if (this.projectMemberService) {
      return this.projectMemberService
    }
    return this.service(ProjectMemberService)
  }

  public projectTag() {
    if (this.projectTagService) {
      return this.projectTagService
    }
    return this.service(ProjectTagService)
  }

  public sceneTag() {
    if (this.sceneTagService) {
      return this.sceneTagService
    }
    return this.service(SceneTagService)
  }

  public page() {
    if (this.pageService) {
      return this.pageService
    }
    return this.service(PageService)
  }

  public pageMember() {
    if (this.pageMemberService) {
      return this.pageMemberService
    }
    return this.service(PageMemberService)
  }

  public draft() {
    if (this.draftService) {
      return this.draftService
    }
    return this.service(DraftService)
  }

  public scene() {
    if (this.sceneService) {
      return this.sceneService
    }
    return this.service(SceneService)
  }

  public container() {
    if (this.containerService) {
      return this.containerService
    }
    return this.service(ContainerService)
  }

  public containerVersion() {
    if (this.containerVersionService) {
      return this.containerVersionService
    }
    return this.service(ContainerVersionService)
  }

  public html() {
    if (this.htmlService) {
      return this.htmlService
    }
    return this.service(HtmlService)
  }

  public htmlVersion() {
    if (this.htmlVersionService) {
      return this.htmlVersionService
    }
    return this.service(HtmlVersionService)
  }

  public htmlCanaryStrategy() {
    if (this.htmlCanaryStrategyService) {
      return this.htmlCanaryStrategyService
    }
    return this.service(HtmlCanaryStrategyService)
  }

  public htmlReleaseHistoryFlow() {
    if (this.htmlReleaseHistoryFlowService) {
      return this.htmlReleaseHistoryFlowService
    }
    return this.service(HtmlReleaseHistoryFlowService)
  }

  public tag() {
    if (this.tagService) {
      return this.tagService
    }
    return this.service(TagService)
  }

  public task() {
    if (this.taskService) {
      return this.taskService
    }
    return this.service(TaskService)
  }

  public taskPage() {
    if (this.taskPageService) {
      return this.taskPageService
    }
    return this.service(TaskPageService)
  }

  public taskRecord() {
    if (this.taskRecordService) {
      return this.taskRecordService
    }
    return this.service(TaskRecordService)
  }

  service(clz: new (...args: any[]) => TaskRecordService): ITaskRecordService
  service(clz: new (...args: any[]) => TaskPageService): ITaskPageService
  service(clz: new (...args: any[]) => TaskService): ITaskService
  service(clz: new (...args: any[]) => AdministratorService): IAdministratorService
  service(clz: new (...args: any[]) => TagService): ITagService
  service(clz: new (...args: any[]) => HtmlReleaseHistoryFlowService): IHtmlReleaseHistoryFlowService
  service(clz: new (...args: any[]) => SceneService): ISceneService
  service(clz: new (...args: any[]) => ContainerService): IContainerService
  service(clz: new (...args: any[]) => DraftService): IDraftService
  service(clz: new (...args: any[]) => PageMemberService): IPageMemberService
  service(clz: new (...args: any[]) => HtmlVersionService): IHtmlVersionService
  service(clz: new (...args: any[]) => HtmlCanaryStrategyService): IHtmlCanaryStrategyService
  service(clz: new (...args: any[]) => HtmlService): IHtmlService
  service(clz: new (...args: any[]) => ContainerVersionService): IContainerVersionService
  service(clz: new (...args: any[]) => BaAuthService): IBaAuthService
  service(clz: new (...args: any[]) => SceneTagService): ISceneTagService
  service(clz: new (...args: any[]) => PageService): IPageService
  service(clz: new (...args: any[]) => ProjectTagService): IProjectTagService
  service(clz: new (...args: any[]) => ProjectMemberService): IProjectMemberService
  service(clz: new (...args: any[]) => ProjectService): IProjectService
  service(clz: new (...args: any[]) => ORGEmployeeService): ORGEmployeeService
  service(clz: new (...args: any[]) => TamService): TamService
  service(clz: new (...args: any[]) => DamService): DamService
  service(clz: new (...args: any[]) => FedoService): FedoService
  service(clz: new (...args: any[]) => WebStaticAdminService): WebStaticAdminService
  service(clz: new (...args: any[]) => OnesService): OnesService
  service(clz: new (...args: any[]) => WebStaticClientService): WebStaticClientService
  service(clz: Object) {
    const logger = this.logger()
    if (clz === TaskRecordService) {
      this.taskRecordService = IrisServiceContext.service(TaskRecordService.name, TaskRecordDAO.name, logger)
      assert.ok(!!this.taskRecordService, `任务记录服务未初始化`)
      this.taskRecordService.setEngine(this)
      this.taskRecordService.setFlowEngine(this._flowEngine)
      return this.taskRecordService
    }
    if (clz === TaskPageService) {
      this.taskPageService = IrisServiceContext.service(TaskPageService.name, TaskPageDAO.name, logger)
      assert.ok(!!this.taskPageService, `任务页面服务未初始化`)
      this.taskPageService.setEngine(this)
      this.taskPageService.setFlowEngine(this._flowEngine)
      return this.taskPageService
    }
    if (clz === TaskService) {
      this.taskService = IrisServiceContext.service(TaskService.name, TaskDAO.name, logger)
      assert.ok(!!this.taskService, `任务服务未初始化`)
      this.taskService.setEngine(this)
      this.taskService.setFlowEngine(this._flowEngine)
      return this.taskService
    }
    if (clz === AdministratorService) {
      this.adminService = IrisServiceContext.service(AdministratorService.name, AdministratorDAO.name, logger)
      assert.ok(!!this.adminService, `管理员服务未初始化`)
      this.adminService.setEngine(this)
      this.adminService.setFlowEngine(this._flowEngine)
      return this.adminService
    }
    if (clz === TagService) {
      this.tagService = IrisServiceContext.service(TagService.name, TagDAO.name, logger)
      assert.ok(!!this.tagService, `标签服务未初始化`)
      this.tagService.setEngine(this)
      this.tagService.setFlowEngine(this._flowEngine)
      return this.tagService
    }
    if (clz === HtmlReleaseHistoryFlowService) {
      this.htmlReleaseHistoryFlowService = IrisServiceContext.service(HtmlReleaseHistoryFlowService.name, HtmlReleaseHistoryFlowDAO.name, logger)
      assert.ok(!!this.htmlReleaseHistoryFlowService, `页面发布记录服务未初始化`)
      this.htmlReleaseHistoryFlowService.setEngine(this)
      this.htmlReleaseHistoryFlowService.setFlowEngine(this._flowEngine)
      return this.htmlReleaseHistoryFlowService
    }
    if (clz === SceneService) {
      this.sceneService = IrisServiceContext.service(SceneService.name, SceneDAO.name, logger)
      assert.ok(!!this.sceneService, `场景服务未初始化`)
      this.sceneService.setEngine(this)
      this.sceneService.setFlowEngine(this._flowEngine)
      return this.sceneService
    }
    if (clz === ContainerService) {
      this.containerService = IrisServiceContext.service(ContainerService.name, ContainerDAO.name, logger)
      assert.ok(!!this.containerService, `页面容器服务未初始化`)
      this.containerService.setEngine(this)
      this.containerService.setFlowEngine(this._flowEngine)
      return this.containerService
    }
    if (clz === DraftService) {
      this.draftService = IrisServiceContext.service(DraftService.name, DraftDAO.name, logger)
      assert.ok(!!this.draftService, `草稿服务未初始化`)
      this.draftService.setEngine(this)
      this.draftService.setFlowEngine(this._flowEngine)
      return this.draftService
    }
    if (clz === PageMemberService) {
      this.pageMemberService = IrisServiceContext.service(PageMemberService.name, PageMemberDAO.name, logger)
      assert.ok(!!this.pageMemberService, `页面权限服务未初始化`)
      this.pageMemberService.setEngine(this)
      this.pageMemberService.setFlowEngine(this._flowEngine)
      return this.pageMemberService
    }
    if (clz === HtmlVersionService) {
      this.htmlVersionService = IrisServiceContext.service(HtmlVersionService.name, HtmlVersionDAO.name, logger)
      assert.ok(!!this.htmlVersionService, `页面版本服务未初始化`)
      this.htmlVersionService.setEngine(this)
      this.htmlVersionService.setFlowEngine(this._flowEngine)
      return this.htmlVersionService
    }
    if (clz === HtmlCanaryStrategyService) {
      this.htmlCanaryStrategyService = IrisServiceContext.service(HtmlCanaryStrategyService.name, HtmlCanaryStrategyDAO.name, logger)
      assert.ok(!!this.htmlCanaryStrategyService, `页面灰度服务未初始化`)
      this.htmlCanaryStrategyService.setEngine(this)
      this.htmlCanaryStrategyService.setFlowEngine(this._flowEngine)
      return this.htmlCanaryStrategyService
    }
    if (clz === HtmlService) {
      this.htmlService = IrisServiceContext.service(HtmlService.name)
      assert.ok(!!this.htmlService, `最终产物服务未初始化`)
      this.htmlService.setEngine(this)
      this.htmlService.setFlowEngine(this._flowEngine)
      return this.htmlService
    }
    if (clz === ContainerVersionService) {
      this.containerVersionService = IrisServiceContext.service(ContainerVersionService.name, ContainerVersionDAO.name, logger)
      assert.ok(!!this.containerVersionService, `页面容器版本服务未初始化`)
      this.containerVersionService.setEngine(this)
      this.containerVersionService.setFlowEngine(this._flowEngine)
      return this.containerVersionService
    }
    if (clz === SceneTagService) {
      this.sceneTagService = IrisServiceContext.service(SceneTagService.name, SceneTagDAO.name, logger)
      assert.ok(!!this.sceneTagService, `场景标签服务未初始化`)
      this.sceneTagService.setEngine(this)
      this.sceneTagService.setFlowEngine(this._flowEngine)
      return this.sceneTagService
    }
    if (clz === PageService) {
      this.pageService = IrisServiceContext.service(PageService.name, PageDAO.name, logger)
      assert.ok(!!this.pageService, `页面服务未初始化`)
      this.pageService.setEngine(this)
      this.pageService.setFlowEngine(this._flowEngine)
      return this.pageService
    }
    if (clz === ProjectTagService) {
      this.projectTagService = IrisServiceContext.service(ProjectTagService.name, ProjectTagDAO.name, logger)
      assert.ok(!!this.projectTagService, `项目标签服务未初始化`)
      this.projectTagService.setEngine(this)
      this.projectTagService.setFlowEngine(this._flowEngine)
      return this.projectTagService
    }
    if (clz === ProjectMemberService) {
      this.projectMemberService = IrisServiceContext.service(ProjectMemberService.name, ProjectMemberDAO.name, logger)
      assert.ok(!!this.projectMemberService, `项目权限服务未初始化`)
      this.projectMemberService.setEngine(this)
      this.projectMemberService.setFlowEngine(this._flowEngine)
      return this.projectMemberService
    }
    if (clz === ProjectService) {
      this.projectService = IrisServiceContext.service(ProjectService.name, ProjectDAO.name, logger)
      assert.ok(!!this.projectService, `项目服务未初始化`)
      this.projectService.setEngine(this)
      this.projectService.setFlowEngine(this._flowEngine)
      return this.projectService
    }
    if (clz === BaAuthService) {
      this.baAuthService = IrisServiceContext.service(BaAuthService.name, BaAuthDAO.name, logger)
      assert.ok(!!this.baAuthService, `BA 认证服务未初始化`)
      this.baAuthService.setEngine(this)
      this.baAuthService.setFlowEngine(this._flowEngine)
      return this.baAuthService
    }
    /**
     * 公共服务
     */
    if (clz === ORGEmployeeService) {
      this.orgEmployeeService = new ORGEmployeeService()
      assert.ok(!!this.orgEmployeeService, `ORG 服务未初始化`)
      return this.orgEmployeeService
    }
    if (clz === TamService) {
      this.tamService = new TamService()
      assert.ok(!!this.tamService, `TAM 服务未初始化`)
      return this.tamService
    }
    if (clz === DamService) {
      this.damService = new DamService()
      assert.ok(!!this.damService, `DAM 服务未初始化`)
      return this.damService
    }
    if (clz === FedoService) {
      this.fedoService = new FedoService()
      assert.ok(!!this.fedoService, `FEDO 服务未初始化`)
      return this.fedoService
    }
    if (clz === OnesService) {
      this.onesService = new OnesService()
      assert.ok(!!this.onesService, `Ones 服务未初始化`)
      return this.onesService
    }
    if (clz === WebStaticClientService) {
      this.webstaticService = new WebStaticClientService()
      assert.ok(!!this.webstaticService, `WebStatic 服务未初始化`)
      return this.webstaticService
    }
    if (clz === WebStaticAdminService) {
      this.webstaticAdminService = new WebStaticAdminService()
      assert.ok(!!this.webstaticAdminService, `WebStatic Admin 服务未初始化`)
      return this.webstaticAdminService
    }
    throw new IrisBizException(`未知服务: clz=${clz}`)
  }

  public isIrisId(input: string) {
    try {
      assert.ok(typeof input === 'string' && /^\d{1,}$/.test(input), `参数不合法`)
      return true
    } catch (error) {
      return false
    }
  }
}
