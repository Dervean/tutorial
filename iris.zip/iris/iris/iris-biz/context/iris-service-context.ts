import assert from 'assert'
import { IrisContext } from 'iris/iris-biz/context/iris-context'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'

export class IrisServiceContext {
  private static _context: IrisContext = null

  public static get context(): IrisContext {
    if (this._context === null) {
      this._context = new IrisContext()
    }
    return this._context
  }

  public static set context(value: IrisContext) {
    if (value) {
      this._context = value
    }
  }

  public static find(clzName: string): new (...args: any[]) => any {
    assert.ok(!!this.context, 'context not ready')
    return this.context.find(clzName)
  }

  public static put(name: string, clz: new (...args: any[]) => any) {
    assert.ok(!!this.context, 'context not ready')
    return this.context.put(name, clz)
  }

  /**
   * 获取服务实例
   * @param serviceName
   * @param daoName
   * @returns
   */
  public static service(serviceName: string, daoName?: string, logger?: IrisLogger) {
    const serviceCon = this.find(serviceName)
    assert.ok(!!serviceCon, `service class not exists: serviceName=${serviceName}`)
    if (daoName) {
      const daoCon = this.find(daoName)
      assert.ok(!!daoCon, `dao class not exists: dao=${daoCon}`)
      const dao = new daoCon()
      dao.setLogger(logger)
      const service = new serviceCon(dao)
      return service
    }
    const service = new serviceCon()
    return service
  }
}
