import { CanaryStrategyItem, CanaryStrategyPercentageItem, WebStaticCanaryStrategyModel } from 'iris/iris-out/webstatic/webstatic-admin-service'

export class CanaryStrategyModel {
  private _id: string = null
  private _status: 'on' | 'off' = null
  private _strategy: CanaryStrategyItem[][] = []
  private _path: string[] = []

  constructor(value: WebStaticCanaryStrategyModel) {
    this._strategy = value?.strategy || []
    this._path = value?.path || []
    this._id = value?.id || null
    this._status = value?.status || null
  }

  public get strategy() {
    return this._strategy
  }

  public get path() {
    return this._path
  }

  public get id() {
    return this._id
  }

  public get status() {
    return this._status
  }

  public get strategyPercentage() {
    for (let i = 0; i < this._strategy.length; i++) {
      const strategy = this._strategy[i]?.find(e => e.type === 'percentage')
      if (strategy) {
        return strategy as CanaryStrategyPercentageItem
      }
    }
    return null
  }

  public toJSON() {
    const percentage = this.strategyPercentage?.value
    return {
      percentage: typeof percentage === 'number' ? percentage : null,
    }
  }
}
