import { EnumHelper } from 'iris/iris-lib/helper/enum-helper'

export enum RoleTypeEnum {
  Admin = 'admin',
  Visitor = 'visitor',
  Editor = 'editor',
}

export class PermissionBuilder {
  static PERMISSION_VIEW = 1 << 0
  static PERMISSION_EDIT = 1 << 1
  static PERMISSION_ADMIN = 1 << 2

  static permission2role(permission: number) {
    const pb = new PermissionBuilder(permission)
    return pb.permission2role()
  }

  static role2permission(role: RoleTypeEnum) {
    const pb = new PermissionBuilder(role)
    return pb.getPermission()
  }

  private permission: number

  constructor(role: RoleTypeEnum)
  constructor(permission?: number)
  constructor(param?: RoleTypeEnum | number) {
    if (EnumHelper.isEnumMember(param, RoleTypeEnum)) {
      if (param === RoleTypeEnum.Visitor) {
        this.grantViewPermission()
      }
      if (param === RoleTypeEnum.Editor) {
        this.grantEditPermission()
      }
      if (param === RoleTypeEnum.Admin) {
        this.grantAdminPermission()
      }
    } else {
      this.permission = +param || 0
    }
  }

  getPermission() {
    return this.permission
  }

  permission2role() {
    if (this.hasAdminPermission()) {
      return RoleTypeEnum.Admin
    }
    if (this.hasEditPermission()) {
      return RoleTypeEnum.Editor
    }
    if (this.hasViewPermission()) {
      return RoleTypeEnum.Visitor
    }
    return null
  }

  public checkVisitorPermission() {
    return this.hasViewPermission() || this.hasEditPermission() || this.hasAdminPermission()
  }

  public checkEditorPermission() {
    return this.hasEditPermission() || this.hasAdminPermission()
  }

  public checkAdminPermission() {
    return this.hasAdminPermission()
  }

  public grantViewPermission() {
    this.permission |= PermissionBuilder.PERMISSION_VIEW
  }

  public grantEditPermission() {
    this.permission |= PermissionBuilder.PERMISSION_EDIT
  }

  public grantAdminPermission() {
    this.permission |= PermissionBuilder.PERMISSION_ADMIN
  }

  public deleteViewPermission() {
    this.permission ^= PermissionBuilder.PERMISSION_VIEW
    this.permission ^= PermissionBuilder.PERMISSION_EDIT
    this.permission ^= PermissionBuilder.PERMISSION_ADMIN
  }

  public deleteEditPermission() {
    this.permission ^= PermissionBuilder.PERMISSION_EDIT
    this.permission ^= PermissionBuilder.PERMISSION_ADMIN
  }

  public deleteAdminPermission() {
    this.permission ^= PermissionBuilder.PERMISSION_ADMIN
  }

  private hasViewPermission() {
    const val = (this.permission & PermissionBuilder.PERMISSION_VIEW) >> 0
    return !!val
  }

  private hasEditPermission() {
    const val = (this.permission & PermissionBuilder.PERMISSION_EDIT) >> 1
    return !!val
  }

  private hasAdminPermission() {
    const val = (this.permission & PermissionBuilder.PERMISSION_ADMIN) >> 2
    return !!val
  }
}
