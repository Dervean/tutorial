import assert from 'assert'
import { FlowServiceContext } from 'iris/iris-flow/context/flow-service-context'
import { FlowEngine, IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine, IrisEngine } from 'iris/iris-biz/context/iris-engine'

export abstract class AbstractService implements IHasEngine, IHasFlowEngine {
  protected engine: IrisEngine = null
  protected flowEngine: FlowEngine = null

  public setEngine(engine: IrisEngine) {
    if (engine) {
      this.engine = engine
    }
  }

  public setFlowEngine(engine: FlowEngine) {
    if (engine) {
      this.flowEngine = engine
    }
  }

  get irisEngine() {
    assert.ok(!!this.engine, `IrisEngine 未初始化`)
    return this.engine
  }

  get irisFlowEngine() {
    if (this.flowEngine) {
      return this.flowEngine
    }
    return FlowServiceContext.engine
  }
}
