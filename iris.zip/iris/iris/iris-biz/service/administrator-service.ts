import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisAdministrator } from 'iris/iris-base/entities/iris-administrator'

export interface IAdministratorService extends IHasEngine, IHasFlowEngine {
  /**
   * 超级管理员登录
   */
  adminLoginAuthenticate(): Promise<{
    token: string
    expiresTime: moment.Moment
  }>

  /**
   * 判断当前用户是否有超级管理员权限
   */
  isAdministrator(): Promise<boolean>

  /**
   * 根据用户 id 获取超级管理员
   * @param userId
   */
  getAdministrator(userId: string): Promise<IrisAdministrator>
}
