import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisBaAuth } from 'iris/iris-base/entities/iris-ba-auth'
import { Context } from 'iris/iris-app/interface/context'

export interface IBaAuthService extends IHasEngine, IHasFlowEngine {
  /**
   * 创建 BA 秘钥
   * @param auth
   */
  createBaAuth(auth: IrisBaAuth): Promise<IrisBaAuth>

  /**
   * 获取全部 BA 秘钥列表
   */
  getList(): Promise<IrisBaAuth[]>

  /**
   * 根据 Koa Context 的字段验证是否通过 BA 认证
   * - 如果通过则返回 IrisBaAuth
   * - 如果不通过则抛错 IrisBAUnauthorizedError
   * @param ctx
   */
  verify(ctx: Context): Promise<IrisBaAuth>
}
