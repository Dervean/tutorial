import { IrisContainer } from 'iris/iris-base/entities/iris-container'
import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

export interface IContainerService extends IHasEngine, IHasFlowEngine {
  /**
   * 搜索版本容器列表
   * @param pageParams
   */
  searchContainer(pageParams: IrisPageParams): Promise<IrisPageResult<IrisContainer>>

  /**
   * 查页面容器详情
   * @param id
   */
  getContainer(id: string): Promise<IrisContainer>

  /**
   * 创建页面容器
   * @param container
   */
  createContainer(container: IrisContainer): Promise<IrisContainer>

  /**
   * 编辑页面容器基础信息
   * @param containerId
   * @param container
   */
  updateContainer(containerId: string, container: IrisContainer): Promise<void>

  /**
   * 下线页面容器
   * @param containerId
   */
  offlineContainer(containerId: string): Promise<void>

  /**
   * 获取容器列表
   * @param filter
   */
  getContainerList(filter: Partial<IrisContainer>): Promise<IrisContainer[]>
}
