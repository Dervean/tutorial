import { IrisContainerVersion } from 'iris/iris-base/entities/iris-container-version'
import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

export interface IContainerVersionService extends IHasEngine, IHasFlowEngine {
  /**
   * 搜索页面容器版本列表
   * @param pageParams
   * @param filter
   */
  searchContainerVersion(pageParams: IrisPageParams, filter: Partial<IrisContainerVersion>): Promise<IrisPageResult<IrisContainerVersion>>

  /**
   * 查页面容器版本详情
   * @param containerVersionId
   */
  getContainerVersion(containerVersionId: string): Promise<IrisContainerVersion>

  /**
   * 根据容器ID和容器版本查询
   * @param containerId
   * @param version
   */
  getByContainerIdAndVersion(containerId: string, version: string): Promise<IrisContainerVersion>

  /**
   * 获取最新的页面容器版本
   * @param containerId
   * @param filter
   */
  getLatestContainerVersion(containerId: string, filter: Partial<IrisContainerVersion>): Promise<IrisContainerVersion>

  /**
   * 创建页面容器版本
   * @param containerVersion
   */
  createContainerVersion(containerVersion: IrisContainerVersion): Promise<IrisContainerVersion>
}
