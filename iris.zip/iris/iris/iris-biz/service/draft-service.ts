import { IrisDraft } from 'iris/iris-base/entities/iris-draft'
import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'

export interface IDraftService extends IHasEngine, IHasFlowEngine {
  /**
   * 根据页面 id 获取当前草稿，没有草稿时创建
   */
  getDraft(pageId: string): Promise<IrisDraft>

  /**
   * 根据页面 id 检出草稿
   * @param pageId
   */
  checkoutDraft(pageId: string): Promise<IrisDraft>

  /**
   * 更新/同步草稿
   * @param pageId
   * @param draft
   */
  updateDraft(
    pageId: string,
    draft: IrisDraft,
    params: {
      sync?: string
    },
  ): Promise<void>

  /**
   * 批量获取当前用户的草稿
   * @param filter
   */
  getDraftList(filter: { pageIdList?: string[] }): Promise<IrisDraft[]>

  /**
   * @deprecated
   * 根据页面 id 列表批量获取当前用户的草稿
   * @param pageIdList
   */
  getDraftListByPageIds(pageIdList: string[]): Promise<IrisDraft[]>

  /**
   * 是否已经同步泳道
   * @param pageId
   */
  hasSyncTest(pageId: string): Promise<boolean>

  /**
   * 是否已经同步测试主干
   * @param pageId
   */
  hasSyncTest01(pageId: string): Promise<boolean>

  /**
   * 是否已经同步线上
   * @param pageId
   */
  hasSyncProd(pageId: string): Promise<boolean>
}
