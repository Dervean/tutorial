import { IrisHtmlCanaryStrategy } from 'iris/iris-base/entities/iris-html-canary-strategy'
import { IrisCanaryStateEnum } from 'iris/iris-base/enum/canary'
import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'

export interface IHtmlCanaryStrategyService extends IHasEngine, IHasFlowEngine {
  /**
   * 创建灰度策略
   * @param params
   */
  createStrategy(params: { orderId: string; canaryArgs?: string; originArgs?: string; canaryVersion?: string }): Promise<IrisHtmlCanaryStrategy>

  /**
   * 上线灰度策略
   * @param strategyId 灰度策略 id
   */
  onlineStrategy(strategyId: string): Promise<void>

  /**
   * 下线灰度策略
   * @param strategyId 灰度策略 id
   */
  offlineStrategy(strategyId: string): Promise<void>

  getStrategyByOrderId(orderId: string): Promise<IrisHtmlCanaryStrategy>

  getStrategy(strategyId: string): Promise<IrisHtmlCanaryStrategy>

  /**
   * 删除灰度策略
   * @param strategyId 灰度策略 id
   */
  deleteStrategy(strategyId: string): Promise<void>

  /**
   * 调整灰度百分比
   * @param strategyId 灰度策略 id
   * @param percentage 百分比
   */
  adjustPercentage(strategyId: string, percentage: number): Promise<void>

  /**
   * 清空页面关联的所有灰度策略
   * @param pageId
   */
  clearPageCanaryStrategy(pageId: string): Promise<void>

  /**
   * 查询灰度策略列表
   * @param params
   */
  searchStrategyList(filter: Partial<IrisHtmlCanaryStrategy> & { states?: IrisCanaryStateEnum[] }): Promise<IrisHtmlCanaryStrategy[]>
}
