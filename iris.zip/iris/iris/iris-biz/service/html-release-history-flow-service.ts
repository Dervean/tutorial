import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisHtmlReleaseHistoryFlow } from 'iris/iris-base/entities/iris-html-release-history-flow'
import { IrisTargetEnvEnum, IrisPublishTypeEnum } from 'iris/iris-base/enum/common'
import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

export interface IHtmlReleaseHistoryFlowService extends IHasEngine, IHasFlowEngine {
  /**
   * 分页查询页面发布记录列表
   * @param pageParams
   * @param filter
   * @param params
   */
  searchFlow(
    pageParams: IrisPageParams,
    filter: Partial<IrisHtmlReleaseHistoryFlow> & {
      createTimeBegin?: string
      createTimeEnd?: string
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
    },
  ): Promise<IrisPageResult<IrisHtmlReleaseHistoryFlow>>

  /**
   * 获取页面历史发布流程
   * @param orderId
   */
  getFlow(orderId: string): Promise<IrisHtmlReleaseHistoryFlow>

  /**
   * 更新历史发布流程
   * @param id
   * @param flow
   */
  updateFlow(id: string, flow: IrisHtmlReleaseHistoryFlow): Promise<void>

  /**
   * 创建线上发布流程
   * @param pageId
   * @param dsl
   * @param htmlTemplate
   * @param processName
   * @param remark
   */
  createProdReleaseFlow(pageId: string, dsl: JSON, htmlTemplate: string, processName: string, remark?: string): Promise<IrisFlowOrder>

  /**
   * 创建主干发布流程
   * @param pageId
   * @param dsl
   * @param htmlTemplate
   * @param processName
   * @param remark
   */
  createTest01ReleaseFlow(pageId: string, dsl: JSON, htmlTemplate: string, processName: string, remark?: string): Promise<IrisFlowOrder>

  /**
   * 创建泳道发布流程
   * @param pageId
   * @param dsl
   * @param htmlTemplate
   * @param processName
   * @param swimlane
   * @param remark
   */
  createTestReleaseFlow(
    pageId: string,
    dsl: JSON,
    htmlTemplate: string,
    processName: string,
    swimlane: string,
    remark?: string,
  ): Promise<IrisFlowOrder>

  createRollbackFlow(pageId: string, oldVersion: string, processName: string, remark: string): Promise<IrisFlowOrder>

  createCanaryReleaseFlow(pageId: string, dsl: JSON, htmlTemplate: string, processName: string, remark?: string): Promise<IrisFlowOrder>

  /**
   * 全量灰度发布
   * @param orderId
   */
  completeCanaryRelease(orderId: string): Promise<void>

  /**
   * 取消灰度发布
   * @param orderId
   */
  cancelCanaryRelease(orderId: string): Promise<void>

  /**
   * 强制关闭（取消）发布流程
   * @param orderId
   */
  terminateFlow(orderId: string): Promise<void>
}
