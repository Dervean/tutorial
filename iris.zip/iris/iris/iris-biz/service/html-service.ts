import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisDraft } from 'iris/iris-base/entities/iris-draft'

type ReleasePreviewInfo = {
  htmlTemplate: string
  draft: IrisDraft
}

export interface IHtmlService extends IHasEngine, IHasFlowEngine {
  /**
   * 发布前预览接口
   * @param pageId
   * @param env
   * @returns
   */
  genReleasePreview(pageId: string, env: 'production' | 'test'): Promise<ReleasePreviewInfo>

  /**
   * 生产最终发布的 HTML
   * @param dslURL dsl url
   * @param template html template
   */
  genHTML(dslURL: string, template: string): Promise<string>
}
