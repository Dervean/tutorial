import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisHtmlReleaseHistoryFlow } from 'iris/iris-base/entities/iris-html-release-history-flow'
import { IrisHtmlVersion } from 'iris/iris-base/entities/iris-html-version'
import { IrisTargetEnvEnum, IrisPublishTypeEnum } from 'iris/iris-base/enum/common'
import { S3UploadResponse } from 'iris/iris-out/mss/mss-client-service'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

export interface IHtmlVersionService extends IHasEngine, IHasFlowEngine {
  /**
   * 分页查询页面版本列表
   * @param pageParams
   * @param filter
   */
  searchHtmlVersion(
    pageParams: IrisPageParams,
    filter: Partial<IrisHtmlVersion> & {
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
      createTimeBegin?: string
      createTimeEnd?: string
    },
  ): Promise<IrisPageResult<IrisHtmlVersion>>

  /**
   * 根据页面 id 和版本获取
   * @param pageId
   * @param version
   */
  getHtmlVersionByPageIdAndVersion(pageId: string, version: string): Promise<IrisHtmlVersion>

  /**
   * 根据页面 id 获取最新版本
   * @param pageId
   * @param params
   */
  getLatestHtmlVersion(pageId: string, params: Partial<IrisHtmlVersion>): Promise<IrisHtmlVersion>

  /**
   * 根据流程 id 获取
   * @param orderId
   */
  getHtmlVersionByOrderId(orderId: string): Promise<IrisHtmlVersion>

  /**
   * 返回版本对应的 DSL JSON
   * @param htmlVersion IrisHtmlVersion
   * @returns DSL JSON
   */
  getDSL(htmlVersion: IrisHtmlVersion): Promise<JSON>

  /**
   * 返回版本对应的 HTML 文本
   * @param htmlVersion IrisHtmlVersion
   * @returns HTML string
   */
  getHTML(htmlVersion: IrisHtmlVersion): Promise<string>

  /**
   * 创建页面版本
   * @param flow
   */
  createHtmlVersion(flow: IrisHtmlReleaseHistoryFlow): Promise<IrisHtmlVersion>

  /**
   * 上传 DSL
   * @param html
   * @param pageId
   * @param version
   * @param target
   */
  uploadDSL(html: string, pageId: string, version: string, target: IrisTargetEnvEnum): Promise<S3UploadResponse>

  /**
   * 上传 HTML 版本
   * @param html
   * @param pageId
   * @param version
   * @param target
   */
  uploadHTMLBackup(html: string, pageId: string, version: string, target: IrisTargetEnvEnum): Promise<S3UploadResponse>

  /**
   * 发布测试环境（主干 + 泳道）
   * @param html
   * @param pageId
   * @param target
   * @param swimlane
   * @returns
   */
  uploadHTMLS3(html: string, pageId: string, target: IrisTargetEnvEnum, swimlane?: string): Promise<S3UploadResponse>

  /**
   * 发布线上环境 HTML
   * @param html
   * @param pageId
   * @param strategyId 灰度策略 id
   * @returns
   */
  uploadHtmlWebStatic(html: string, pageId: string, strategyId?: string): Promise<void>

  /**
   * 获取页面版本 HTML 链接
   * @param input
   */
  getHtmlUrl(input: Partial<IrisHtmlVersion | IrisHtmlReleaseHistoryFlow>): Promise<string>

  /**
   * 根据页面 id 列表批量获取所有环境最新页面版本
   * @param pageIdList
   */
  getLatestVersionListByPageIdList(pageIdList: string[]): Promise<IrisHtmlVersion[]>
}
