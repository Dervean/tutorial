import moment from 'moment'
import { IAdministratorDAO } from 'iris/iris-base/dao/administrator-dao'
import { IrisAes256GcmEncryption } from 'iris/iris-lib/model/iris-aes256-gcm-encryption'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IrisAdministrator } from 'iris/iris-base/entities/iris-administrator'
import { IAdministratorService } from 'iris/iris-biz/service/administrator-service'
import { AdministratorDAO } from 'iris/iris-base/dao/impl/administrator-dao'

export class AdministratorService extends AbstractService implements IAdministratorService {
  protected dao: IAdministratorDAO<IrisAdministrator>

  constructor(dao?: AdministratorDAO) {
    super()
    this.dao = dao || new AdministratorDAO()
  }

  protected async encryptAdminToken(expiresTimestamp: number, userId: string) {
    const plaintext = `${expiresTimestamp}&${userId}`

    const adminToken = await IrisAes256GcmEncryption.encrypt(plaintext)
    return adminToken
  }

  protected async decryptAdminToken(encryptedAdminToken: string) {
    const adminToken = await IrisAes256GcmEncryption.decrypt(encryptedAdminToken)
    const [expiresTimestamp, decryptedUserId] = adminToken.split('&')

    return {
      expiresTimestamp: +expiresTimestamp,
      decryptedUserId: decryptedUserId,
    }
  }

  public async adminLoginAuthenticate() {
    const { userId } = this.irisEngine.user()
    const adminItem = await this.dao.getByUserId(userId)

    if (!adminItem) return null

    const expiresTime = moment().add(1, 'hours')
    const encryptedAdminToken = await this.encryptAdminToken(expiresTime.valueOf(), userId)
    return {
      token: encryptedAdminToken,
      expiresTime: expiresTime.utc(),
    }
  }

  public async getAdministrator(userId: string) {
    return this.dao.getByUserId(userId)
  }

  public async isAdministrator() {
    const { userId } = this.irisEngine.user()
    try {
      // const token = NestEventHelper.getContext()?.cookies?.get('admin_token')
      // if (!token) return false

      // const { expiresTimestamp, decryptedUserId } = await this.decryptAdminToken(token)
      // const current = moment()
      // const expires = moment(expiresTimestamp)

      // if (userId !== decryptedUserId) return false
      // if (expires.isBefore(current)) return false

      // return true

      const result = await this.dao.getByUserId(userId)
      return !!result
    } catch (error) {
      return false
    }
  }
}
