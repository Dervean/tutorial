import assert from 'assert'
import { IBaAuthService } from 'iris/iris-biz/service/ba-auth-service'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IrisBaAuth } from 'iris/iris-base/entities/iris-ba-auth'
import { IBaAuthDAO } from 'iris/iris-base/dao/ba-auth-dao'
import { BaAuthDAO } from 'iris/iris-base/dao/impl/ba-auth-dao'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'
import { Context } from 'iris/iris-app/interface/context'
import { BAHelper } from 'iris/iris-lib/helper/ba-helper'
import { IrisBAUnauthorizedError } from 'iris/iris-lib/model/iris-error'

export class BaAuthService extends AbstractService implements IBaAuthService {
  protected dao: IBaAuthDAO<IrisBaAuth>

  constructor(dao?: BaAuthDAO) {
    super()
    this.dao = dao || new BaAuthDAO()
  }

  async getList() {
    return this.dao.getList()
  }

  async verify(ctx: Context) {
    const model = BAHelper.getAuthModel(ctx)
    const list = await this.getList()
    const clientId = BAHelper.verify(model, list)
    if (!clientId) {
      throw new IrisBAUnauthorizedError(`BA 认证失败`)
    }
    return list.find(item => item.clientId === clientId)
  }

  async createBaAuth(auth: Pick<IrisBaAuth, 'name' | 'description'>) {
    assert.ok(auth.name, `名称必填`)
    const target = new IrisBaAuth()
    target.name = auth.name
    target.description = auth.description
    target.clientId = StringHelper.generatePrimaryKeyUUID().slice(16)
    target.clientSecret = StringHelper.generatePrimaryKeyUUID()
    target.userId = this.engine.user().userId
    const { id } = await this.dao.insert(target)
    target.id = id
    return target
  }
}
