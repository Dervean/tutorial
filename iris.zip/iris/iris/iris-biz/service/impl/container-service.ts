import { IContainerDAO } from 'iris/iris-base/dao/container-dao'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'
import { IrisContainer } from 'iris/iris-base/entities/iris-container'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { ContainerDAO } from 'iris/iris-base/dao/impl/container-dao'
import { IContainerService } from 'iris/iris-biz/service/container-service'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'

export class ContainerService extends AbstractService implements IContainerService {
  protected dao: IContainerDAO<IrisContainer>

  constructor(dao?: ContainerDAO) {
    super()
    this.dao = dao || new ContainerDAO()
  }

  public async searchContainer(pageParams: IrisPageParams) {
    const { pageNum, pageSize } = pageParams
    const offset = IrisPageResult.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.dao.search(offset, limit, { status: IrisStatusEnum.Active })
    const page = new IrisPageResult<IrisContainer>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }

  public async getContainer(id: string) {
    return this.dao.getByPrimaryKey(id)
  }

  public async createContainer(container: IrisContainer) {
    const { userId } = this.irisEngine.user()
    container.createdBy = userId
    container.updatedBy = userId
    return this.dao.insert(container)
  }

  public async updateContainer(containerId: string, container: IrisContainer) {
    const { userId } = this.irisEngine.user()
    container.updatedBy = userId
    return this.dao.updateByPrimaryKey(containerId, container)
  }

  public async offlineContainer(containerId: string) {
    const { userId } = this.irisEngine.user()
    await this.dao.deleteByPrimaryKey(containerId, userId)
    return
  }

  public async getContainerList(filter: { name?: string; status?: IrisStatusEnum }) {
    return this.dao.getContainerList({ status: IrisStatusEnum.Active, ...filter })
  }
}
