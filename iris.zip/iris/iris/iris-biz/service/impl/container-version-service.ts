import semver from 'semver'
import { IContainerVersionDAO } from 'iris/iris-base/dao/container-version-dao'
import { IrisContainerVersion } from 'iris/iris-base/entities/iris-container-version'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IContainerVersionService } from 'iris/iris-biz/service/container-version-service'
import { ContainerVersionDAO } from 'iris/iris-base/dao/impl/container-version-dao'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'
import { IrisContainerVersionAlreadyExisted, IrisInvalidFormatParamError } from 'iris/iris-lib/model/iris-error'

export class ContainerVersionService extends AbstractService implements IContainerVersionService {
  protected dao: IContainerVersionDAO<IrisContainerVersion>

  constructor(dao?: ContainerVersionDAO) {
    super()
    this.dao = dao || new ContainerVersionDAO()
  }

  public async searchContainerVersion(
    pageParams: IrisPageParams,
    filter: { containerId?: string; engineVersionEnd?: string; engineVersionStart?: string; version?: string },
  ) {
    const offset = IrisPageResult.getOffsetByPageNum(pageParams.pageNum, pageParams.pageSize)
    const limit = pageParams.pageSize
    const { rows, totalCnt } = await this.dao.search(offset, limit, filter)
    const page = new IrisPageResult<IrisContainerVersion>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageParams.pageNum)
    page.setPageSize(pageParams.pageSize)
    return page
  }

  public async getContainerVersion(id: string) {
    return this.dao.getByPrimaryKey(id)
  }

  public async getByContainerIdAndVersion(containerId: string, version: string) {
    return this.dao.getByContainerIdAndVersion(containerId, version)
  }

  public async getLatestContainerVersion(containerId: string, filter: { engineVersionEnd?: string; engineVersionStart?: string; version?: string }) {
    return this.dao.getLatestVersionByContainerId(containerId, filter)
  }

  public async createContainerVersion(containerVersion: IrisContainerVersion) {
    const { version, containerId } = containerVersion
    if (!semver.valid(version)) {
      throw new IrisInvalidFormatParamError(`页面容器版本格式错误: version=${version}`)
    }
    const result = await this.getByContainerIdAndVersion(containerId, version)
    if (result) {
      throw new IrisContainerVersionAlreadyExisted(`页面容器版本已存在: version=${version}`)
    }
    const { userId } = this.irisEngine.user()
    containerVersion.createdBy = userId
    return this.dao.insert(containerVersion)
  }
}
