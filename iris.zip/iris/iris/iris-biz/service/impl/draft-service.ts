import { IDraftDAO } from 'iris/iris-base/dao/draft-dao'
import { DraftDAO } from 'iris/iris-base/dao/impl/draft-dao'
import { IrisDraft } from 'iris/iris-base/entities/iris-draft'
import { IrisHtmlVersion } from 'iris/iris-base/entities/iris-html-version'
import { IrisTargetEnvEnum } from 'iris/iris-base/enum/common'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IDraftService } from 'iris/iris-biz/service/draft-service'
import { CommonEnum } from 'iris/iris-base'
import { MSSClientService, CDNSourceEnum } from 'iris/iris-out/mss/mss-client-service'
import { IrisDraftAlreadyExistedError, IrisDraftNotFoundError } from 'iris/iris-lib/model/iris-error'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out'

export class DraftService extends AbstractService implements IDraftService {
  protected dao: IDraftDAO<IrisDraft>

  constructor(dao?: DraftDAO) {
    super()
    this.dao = dao || new DraftDAO()
  }

  private async createDraft(pageId: string) {
    const { userId } = this.irisEngine.user()
    const [_, page, htmlVersion, draftItem] = await Promise.all([
      this.irisEngine.pageMember().verifyPageVisitorPermission(pageId),
      this.irisEngine.page().getActivePage(pageId),
      this.irisEngine.htmlVersion().getLatestHtmlVersion(pageId, { target: IrisTargetEnvEnum.Production }),
      this.dao.getByPageIdAndUserId(pageId, userId),
    ])

    if (draftItem) {
      throw new IrisDraftAlreadyExistedError(`草稿已存在: pageId=${pageId}, userId=${userId}`)
    }
    /**
     * 有版本 从最新版本 checkout
     * 无版本 返回 null
     */
    let dsl: JSON = null
    if (htmlVersion) {
      try {
        const objPath = IrisHtmlVersion.genS3DslObjPath(IrisTargetEnvEnum.Production, page.projectId, page.pageId, htmlVersion.version)
        const assetBucket = await LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAssetsBucket)
        const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, assetBucket)
        dsl = await client.queryJson(objPath)
      } catch (error) {
        dsl = null
      }
    }

    const draft = new IrisDraft()
    draft.pageId = pageId
    draft.projectId = page.projectId
    draft.userId = userId
    draft.dsl = dsl
    draft.syncVersion = htmlVersion?.version || null
    return this.dao.insert(draft)
  }

  async getDraft(pageId: string) {
    const { userId } = this.irisEngine.user()
    const [_, draft] = await Promise.all([
      this.irisEngine.pageMember().verifyPageVisitorPermission(pageId),
      this.dao.getByPageIdAndUserId(pageId, userId),
    ])
    if (draft) {
      return draft
    }
    /** 没有草稿 尝试创建草稿 */
    const { id } = await this.createDraft(pageId)
    return this.dao.getByPrimaryKey(id)
  }

  async checkoutDraft(pageId: string) {
    const [draft, htmlVersion] = await Promise.all([
      this.getDraft(pageId),
      this.irisEngine.htmlVersion().getLatestHtmlVersion(pageId, { target: IrisTargetEnvEnum.Production }),
    ])

    const version = htmlVersion?.version || null
    if (draft.syncVersion === version) {
      return draft
    }

    const assetBucket = await LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAssetsBucket)
    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, assetBucket)

    const objPathSync = IrisHtmlVersion.genS3DslObjPath(IrisTargetEnvEnum.Production, draft.projectId, draft.pageId, draft.syncVersion)
    const objPathProd = IrisHtmlVersion.genS3DslObjPath(IrisTargetEnvEnum.Production, draft.projectId, draft.pageId, version)

    // prettier-ignore
    const [dslSync, dslProd] = await Promise.all([
      !!draft.syncVersion && client.query(objPathSync),
      client.queryJson(objPathProd),
    ])
    const dsl = JSON.stringify(draft.dsl)
    if (draft.dsl === null || dsl === dslSync) {
      const target = new IrisDraft()
      target.dsl = dslProd
      target.syncVersion = version
      await this.dao.updateByPrimaryKey(draft.id, target)
    }
    return this.getDraft(pageId)
  }

  async updateDraft(pageId: string, draft: IrisDraft, params: { sync?: string }) {
    const { userId } = this.irisEngine.user()
    const [_, _draft, htmlVersion] = await Promise.all([
      this.irisEngine.pageMember().verifyPageVisitorPermission(pageId),
      this.dao.getByPageIdAndUserId(pageId, userId),
      !!params.sync && this.irisEngine.htmlVersion().getHtmlVersionByPageIdAndVersion(pageId, params.sync),
    ])
    if (_draft === null) {
      throw new IrisDraftNotFoundError(`草稿不存在: pageId=${pageId}, user=${userId}`)
    }
    switch (htmlVersion?.target) {
      case CommonEnum.IrisTargetEnvEnum.Production:
        draft.syncVersion = htmlVersion.version
        break
      case CommonEnum.IrisTargetEnvEnum.Test:
        draft.syncVersionTest = htmlVersion.version
        draft.swimlane = htmlVersion.swimlane
        break
      case CommonEnum.IrisTargetEnvEnum.Test01:
        draft.syncVersionTest01 = htmlVersion.version
        break
      default:
        break
    }
    return this.dao.updateByPrimaryKey(_draft.id, draft)
  }

  async hasSyncProd(pageId: string) {
    const { userId } = this.irisEngine.user()
    const [draft, htmlVersion] = await Promise.all([
      this.dao.getByPageIdAndUserId(pageId, userId),
      this.irisEngine.htmlVersion().getLatestHtmlVersion(pageId, { target: CommonEnum.IrisTargetEnvEnum.Production }),
    ])
    if (draft === null) {
      return true
    }
    if (draft.dsl === null) {
      return htmlVersion === null
    }
    return htmlVersion === null || htmlVersion.version === draft.syncVersion
  }

  async hasSyncTest01(pageId: string) {
    const { userId } = this.irisEngine.user()
    const [draft, htmlVersion] = await Promise.all([
      this.dao.getByPageIdAndUserId(pageId, userId),
      this.irisEngine.htmlVersion().getLatestHtmlVersion(pageId, { target: CommonEnum.IrisTargetEnvEnum.Test01 }),
    ])
    if (draft === null) {
      return true
    }
    if (draft.dsl === null) {
      return htmlVersion === null
    }
    return htmlVersion === null || htmlVersion.version === draft.syncVersionTest01
  }

  async hasSyncTest(pageId: string) {
    const { userId } = this.irisEngine.user()
    const draft = await this.dao.getByPageIdAndUserId(pageId, userId)
    if (draft === null) {
      return true
    }
    if (draft.swimlane === null) {
      return true
    }
    const htmlVersion = await this.irisEngine
      .htmlVersion()
      .getLatestHtmlVersion(pageId, { target: CommonEnum.IrisTargetEnvEnum.Test, swimlane: draft.swimlane })
    if (draft.dsl === null) {
      return htmlVersion === null
    }
    return htmlVersion === null || htmlVersion.version === draft.syncVersionTest
  }

  async getDraftListByPageIds(pageIdList: string[]) {
    return this.getDraftList({ pageIdList })
  }

  async getDraftList(filter: { pageIdList?: string[] }) {
    const { userId } = this.irisEngine.user()
    return this.dao.getDraftListByUserId(userId, filter)
  }
}
