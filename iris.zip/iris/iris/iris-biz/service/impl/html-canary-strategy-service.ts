import assert from 'assert'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IHtmlCanaryStrategyDAO } from 'iris/iris-base/dao/html-canary-strategy-dao'
import { IrisHtmlCanaryStrategy } from 'iris/iris-base/entities/iris-html-canary-strategy'
import { IrisHtmlVersion } from 'iris/iris-base/entities/iris-html-version'
import { CanaryUserInputActionEnum, IrisCanaryStateDescEnum, IrisCanaryStateEnum } from 'iris/iris-base/enum/canary'
import { CanaryStrategyModel } from 'iris/iris-biz/model/canary-strategy-model'
import { HtmlCanaryStrategyDAO } from 'iris/iris-base/dao/impl/html-canary-strategy-dao'
import { IHtmlCanaryStrategyService } from 'iris/iris-biz/service/html-canary-strategy-service'
import { CanaryStrategyItem } from 'iris/iris-out/webstatic/webstatic-admin-service'
import { IrisWebStaticCanaryStrategyDeletedError } from 'iris/iris-lib/model/iris-error'
import { DateHelper } from 'iris/iris-lib/helper/date-helper'

export interface HtmlCanaryUserInput {
  action: CanaryUserInputActionEnum
  operator: string
}

export class HtmlCanaryStrategyService extends AbstractService implements IHtmlCanaryStrategyService {
  public static IRIS_CANARY_ARGS = 'iris-canary'

  protected dao: IHtmlCanaryStrategyDAO<IrisHtmlCanaryStrategy>

  constructor(dao?: HtmlCanaryStrategyDAO) {
    super()
    this.dao = dao || new HtmlCanaryStrategyDAO()
  }

  public async createStrategy(params: { orderId: string; canaryArgs: string; originArgs: string; canaryVersion: string }) {
    const { originArgs, canaryArgs, canaryVersion, orderId } = params
    const { userId, userName } = this.irisEngine.user()
    const order = await this.irisEngine.htmlReleaseHistoryFlow().getFlow(orderId)
    const page = await this.irisEngine.page().getActivePage(order.pageId)
    const objPath = await IrisHtmlVersion.genWebStaticHtmlObjPath(page.projectId, page.path)
    const startTime = this.irisEngine.webstaticAdmin().processDatetime()
    const endTime = this.irisEngine.webstaticAdmin().processDatetime(true)

    const strategyPercentage: CanaryStrategyItem[] = [
      {
        type: 'percentage',
        value: 0,
        relation: '=',
      },
      /**
       * @todo
       * 目前 oceanus 不支持设置 null 值，初步对齐排期 Y23Q1 解决
       * https://tt.sankuai.com/ticket/detail?id=73636839
       *  */
      // {
      //   type: 'custom',
      //   value: originArgs,
      //   grayKey: HtmlCanaryStrategyService.IRIS_CANARY_ARGS,
      //   relation: 'not in',
      //   grayPosition: 'args',
      // },
    ]
    const strategyArgs: CanaryStrategyItem[] = [
      {
        type: 'custom',
        value: canaryArgs,
        grayKey: HtmlCanaryStrategyService.IRIS_CANARY_ARGS,
        relation: 'in',
        grayPosition: 'args',
      },
    ]
    const strategyCookie: CanaryStrategyItem[] = [
      {
        type: 'custom',
        value: 'true',
        grayKey: canaryVersion,
        relation: 'in',
        grayPosition: 'cookie',
      },
    ]
    const { id } = await this.irisEngine.webstaticAdmin().createCanaryStrategy(userName, {
      name: '灰度',
      startTime,
      endTime,
      path: [`/${objPath}`],
      strategy: [strategyPercentage, strategyArgs, strategyCookie],
    })
    this.irisEngine.logger().logInfo(`创建灰度策略成功: strategyId=${id}`)

    const target = new IrisHtmlCanaryStrategy()
    target.id = id as string
    target.orderId = orderId
    target.pageId = page.pageId
    target.projectId = page.projectId
    target.canaryArgs = canaryArgs
    target.originArgs = originArgs
    target.version = canaryVersion
    target.state = IrisCanaryStateEnum.Pending
    target.stateDesc = IrisCanaryStateDescEnum.Pending
    target.createdBy = userId

    await this.dao.insert(target)

    return target
  }

  public async getStrategyByOrderId(orderId: string) {
    const strategy = await this.dao.getByOrderId(orderId)
    const { userId, userName } = this.irisEngine.user()
    if (strategy) {
      try {
        const target = await this.irisEngine.webstaticAdmin().getCanaryStrategy(userName, strategy.id)
        strategy.canaryStrategy = new CanaryStrategyModel(target)
      } catch (error) {
        if (error instanceof IrisWebStaticCanaryStrategyDeletedError) {
          strategy.state = IrisCanaryStateEnum.Deleted
          strategy.stateDesc = IrisCanaryStateDescEnum.Deleted
        } else {
          throw error
        }
      }
    }
    return strategy
  }

  public async getStrategy(strategyId: string) {
    const strategy = await this.dao.getByPrimaryKey(strategyId)
    const { userId, userName } = this.irisEngine.user()
    if (strategy) {
      try {
        const target = await this.irisEngine.webstaticAdmin().getCanaryStrategy(userName, strategyId)
        strategy.canaryStrategy = new CanaryStrategyModel(target)
      } catch (error) {
        if (error instanceof IrisWebStaticCanaryStrategyDeletedError) {
          strategy.state = IrisCanaryStateEnum.Deleted
          strategy.stateDesc = IrisCanaryStateDescEnum.Deleted
        } else {
          throw error
        }
      }
    }
    return strategy
  }

  public async onlineStrategy(strategyId: string) {
    const { userId, userName } = this.irisEngine.user()

    const strategy = await this.getStrategy(strategyId)
    await this.irisEngine.webstaticAdmin().updateCanaryStrategy(userName, strategyId, {
      path: strategy.canaryStrategy?.path,
      status: 'on',
    })
    this.irisEngine.logger().logInfo(`打开灰度策略成功: strategyId=${strategyId}`)

    const target = new IrisHtmlCanaryStrategy()
    target.state = IrisCanaryStateEnum.Online
    target.stateDesc = IrisCanaryStateDescEnum.Online
    target.updatedBy = userId
    target.onlineTime = DateHelper.getDate()

    await this.dao.updateByPrimaryKey(strategyId, target)
    return
  }

  public async offlineStrategy(strategyId: string) {
    const { userId, userName } = this.irisEngine.user()

    await this.irisEngine.webstaticAdmin().updateCanaryStrategy(userName, strategyId, {
      status: 'off',
    })
    this.irisEngine.logger().logInfo(`关闭灰度策略成功: strategyId=${strategyId}`)

    const target = new IrisHtmlCanaryStrategy()
    target.state = IrisCanaryStateEnum.Offline
    target.stateDesc = IrisCanaryStateDescEnum.Offline
    target.updatedBy = userId
    target.offlineTime = DateHelper.getDate()

    await this.dao.updateByPrimaryKey(strategyId, target)
    return
  }

  public async deleteStrategy(strategyId: string) {
    const { userId, userName } = this.irisEngine.user()

    await this.irisEngine.webstaticAdmin().deleteCanaryStrategy(userName, strategyId)
    this.irisEngine.logger().logInfo(`删除灰度策略成功: strategyId=${strategyId}`)

    const target = new IrisHtmlCanaryStrategy()
    target.state = IrisCanaryStateEnum.Deleted
    target.stateDesc = IrisCanaryStateDescEnum.Deleted
    target.updatedBy = userId
    await this.dao.updateByPrimaryKey(strategyId, target)

    return
  }

  public async adjustPercentage(strategyId: string, percentage: number) {
    const strategy = await this.getStrategy(strategyId)

    const { userId, userName } = this.irisEngine.user()
    assert.ok(!!strategy?.canaryStrategy?.id, `查询灰度策略失败: strategyId=${strategyId}`)
    assert.ok(!!strategy?.canaryStrategy?.strategyPercentage, `不存在百分比策略: strategyId=${strategyId}`)
    strategy.canaryStrategy.strategyPercentage.value = percentage

    await this.irisEngine.webstaticAdmin().updateCanaryStrategy(userName, strategyId, {
      strategy: strategy.canaryStrategy.strategy,
    })

    this.irisEngine.logger().logInfo(`修改灰度放量百分比成功`, { percentage, strategyId })

    const target = new IrisHtmlCanaryStrategy()
    target.state = IrisCanaryStateEnum.Modifying
    target.stateDesc = IrisCanaryStateDescEnum.Modifying
    target.updatedBy = userId
    await this.dao.updateByPrimaryKey(strategyId, target)

    return
  }

  async clearPageCanaryStrategy(pageId: string) {
    // prettier-ignore
    const { userId, userName } = this.irisEngine.user()
    const [page, response] = await Promise.all([
      this.irisEngine.page().getActivePage(pageId),
      this.irisEngine.webstaticAdmin().getCanaryStrategyList(userName),
    ])
    const { items = [] } = response || {}
    const path = IrisHtmlVersion.genWebStaticHtmlObjPath(page.projectId, page.path)
    /** @todo 此处会删除包含该 page 的所有策略，后续多页发布功能需要修改 */
    // prettier-ignore
    await Promise.all(
      items
        .filter(e => e.path?.includes(`/${path}`))
        .map(strategy => strategy.id && this.deleteStrategy(strategy.id)),
    )
    return
  }

  public async searchStrategyList(filter: { projectId?: string; states?: IrisCanaryStateEnum[] }) {
    const strategyList = await this.dao.getStrategyList(filter)
    return strategyList
  }
}
