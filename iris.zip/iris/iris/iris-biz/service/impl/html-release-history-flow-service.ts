import assert from 'assert'
import { IHtmlReleaseHistoryFlowDAO } from 'iris/iris-base/dao/html-release-history-flow-dao'
import { IrisHtmlReleaseHistoryFlow } from 'iris/iris-base/entities/iris-html-release-history-flow'
import { IrisHtmlVersion } from 'iris/iris-base/entities/iris-html-version'
import { IrisPage } from 'iris/iris-base/entities/iris-page'
import { IrisPublishTypeEnum, IrisTargetEnvEnum } from 'iris/iris-base/enum/common'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IrisFlowStateEnum } from 'iris/iris-base/enum/flow'
import { IHtmlReleaseHistoryFlowService } from 'iris/iris-biz/service/html-release-history-flow-service'
import { HtmlReleaseHistoryFlowDAO } from 'iris/iris-base/dao/impl/html-release-history-flow-dao'
import { HtmlCanaryUserInput } from 'iris/iris-biz/service/impl/html-canary-strategy-service'
import { CanaryUserInputActionEnum } from 'iris/iris-base/enum/canary'
import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowService } from 'iris/iris-flow/service/iris-flow-service'
import { MSSClientService, CDNSourceEnum } from 'iris/iris-out/mss/mss-client-service'
import { IrisPageParams, IrisPageResult } from 'iris/iris-lib'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out'
import { IrisBizException, IrisContainerVersionNotFoundError, IrisMissingParamError } from 'iris/iris-lib/model/iris-error'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'

export class HtmlReleaseHistoryFlowService extends AbstractService implements IHtmlReleaseHistoryFlowService {
  public static CANARY_USER_INPUT = 'html-canary-user-input'
  public static CANARY_TASK_TAG = 'html-canary-task-tag'

  protected dao: IHtmlReleaseHistoryFlowDAO<IrisHtmlReleaseHistoryFlow>

  constructor(dao?: HtmlReleaseHistoryFlowDAO) {
    super()
    this.dao = dao || new HtmlReleaseHistoryFlowDAO()
  }

  async searchFlow(
    pageParams: IrisPageParams,
    filter?: {
      pageId?: string
      projectId?: string
      state?: IrisFlowStateEnum
      createdBy?: string
      createTimeBegin?: string
      createTimeEnd?: string
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
      version?: string
      swimlane?: string
    },
  ) {
    const offset = IrisPageResult.getOffsetByPageNum(pageParams.pageNum, pageParams.pageSize)
    const limit = pageParams.pageSize
    const { rows, totalCnt } = await this.dao.search(offset, limit, filter)
    const page = new IrisPageResult<IrisHtmlReleaseHistoryFlow>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageParams.pageNum)
    page.setPageSize(pageParams.pageSize)
    return page
  }

  async getFlow(orderId: string) {
    return this.dao.getByPrimaryKey(orderId)
  }

  private async createHistoryFlow(order: IrisFlowOrder, page: IrisPage, flow: IrisHtmlReleaseHistoryFlow) {
    try {
      assert.ok(!!flow.target, `target is required`)
      assert.ok(!!flow.type, `type is required`)
      assert.ok(!!flow.version, `version is required`)
      assert.ok(!!flow.containerId, `containerId is required`)
      assert.ok(!!flow.containerVersion, `containerVersion is required`)
    } catch (error) {
      this.irisEngine.logger().logError(error)
      throw new IrisMissingParamError(`参数缺失: ${(error as Error).message}`)
    }

    const item = new IrisHtmlReleaseHistoryFlow()
    item.orderId = order.orderId
    item.processName = order.processName
    item.remark = order.remark
    item.state = order.state
    item.stateDesc = order.stateDesc
    item.pageId = page.pageId
    item.projectId = page.projectId
    item.target = flow.target
    item.type = flow.type
    item.version = flow.version
    item.createdBy = flow.createdBy
    item.swimlane = flow.swimlane
    item.containerId = flow.containerId
    item.containerVersion = flow.containerVersion
    return this.dao.insert(item)
  }

  async updateFlow(id: string, flow: IrisHtmlReleaseHistoryFlow) {
    return this.dao.updateByPrimaryKey(id, flow)
  }

  async createProdReleaseFlow(pageId: string, dsl: JSON, htmlTemplate: string, processName: string, remark?: string) {
    const { userId } = this.irisEngine.user()
    const [page, _] = await Promise.all([
      this.irisEngine.page().getActivePage(pageId),
      /** 校验人员权限 */
      this.irisEngine.pageMember().verifyPageEditorPermission(pageId),
    ])
    const { containerId } = await this.irisEngine.scene().getScene(page.sceneId)

    const containerVersionItem = await this.irisEngine
      .containerVersion()
      .getLatestContainerVersion(containerId, { engineVersionStart: page.engineVersion, engineVersionEnd: page.engineVersion })
    if (containerVersionItem === null) {
      throw new IrisContainerVersionNotFoundError(`找不到对应的页面容器版本: engineVersion=${page.engineVersion}, containerId=${containerId}`)
    }
    const containerVersion = containerVersionItem.version

    const target = IrisTargetEnvEnum.Production
    const type = IrisPublishTypeEnum.Publish
    const version = StringHelper.generateVersion()
    const swimlane: string = null
    const { filename, bucket } = await this.irisEngine.htmlVersion().uploadDSL(JSON.stringify(dsl), pageId, version, target)
    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, bucket)
    const dslURL = client.cdnUrl(filename)
    const html = await this.irisEngine.html().genHTML(dslURL, htmlTemplate)

    const variable: Record<string, unknown> = {}
    variable['pageId'] = pageId
    variable['html'] = html
    variable['target'] = target
    variable['type'] = type
    variable['version'] = version
    variable['containerId'] = containerId
    variable['containerVersion'] = containerVersion
    variable['swimlane'] = swimlane

    const order = await this.createIrisOrderByProcessName(processName, userId, variable, remark)

    const flow = new IrisHtmlReleaseHistoryFlow()
    flow.version = version
    flow.swimlane = swimlane
    flow.createdBy = userId
    flow.containerId = containerId
    flow.containerVersion = containerVersion
    flow.type = type
    flow.target = target

    await this.createHistoryFlow(order, page, flow)

    return order
  }

  async createTest01ReleaseFlow(pageId: string, dsl: JSON, htmlTemplate: string, processName: string, remark?: string) {
    const { userId } = this.irisEngine.user()
    await this.irisEngine.pageMember().verifyPageEditorPermission(pageId)
    const page = await this.irisEngine.page().getActivePage(pageId)
    const { containerId } = await this.irisEngine.scene().getScene(page.sceneId)

    const containerVersionItem = await this.irisEngine
      .containerVersion()
      .getLatestContainerVersion(containerId, { engineVersionStart: page.engineVersion, engineVersionEnd: page.engineVersion })
    if (containerVersionItem === null) {
      throw new IrisContainerVersionNotFoundError(`找不到对应的页面容器版本: engineVersion=${page.engineVersion}, containerId=${containerId}`)
    }
    const containerVersion = containerVersionItem.version
    const target = IrisTargetEnvEnum.Test01
    const type = IrisPublishTypeEnum.Publish
    const version = StringHelper.generateVersion()
    const swimlane: string = null
    const { filename, bucket } = await this.irisEngine.htmlVersion().uploadDSL(JSON.stringify(dsl), pageId, version, target)
    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, bucket)
    const dslURL = client.cdnUrl(filename)
    const html = await this.irisEngine.html().genHTML(dslURL, htmlTemplate)

    const variable: Record<string, unknown> = {}
    variable['pageId'] = pageId
    variable['html'] = html
    variable['target'] = target
    variable['type'] = type
    variable['containerId'] = containerId
    variable['version'] = version
    variable['containerVersion'] = containerVersion
    variable['swimlane'] = swimlane

    const order = await this.createIrisOrderByProcessName(processName, userId, variable, remark)

    const flow = new IrisHtmlReleaseHistoryFlow()
    flow.version = version
    flow.swimlane = swimlane
    flow.createdBy = userId
    flow.containerId = containerId
    flow.containerVersion = containerVersion
    flow.type = type
    flow.target = target

    await this.createHistoryFlow(order, page, flow)

    return order
  }

  async createTestReleaseFlow(pageId: string, dsl: JSON, htmlTemplate: string, processName: string, swimlane: string, remark?: string) {
    const { userId } = this.irisEngine.user()
    await this.irisEngine.pageMember().verifyPageEditorPermission(pageId)
    const page = await this.irisEngine.page().getActivePage(pageId)
    const { containerId } = await this.irisEngine.scene().getScene(page.sceneId)
    const containerVersionItem = await this.irisEngine
      .containerVersion()
      .getLatestContainerVersion(containerId, { engineVersionStart: page.engineVersion, engineVersionEnd: page.engineVersion })
    if (containerVersionItem === null) {
      throw new IrisContainerVersionNotFoundError(`找不到对应的页面容器版本: engineVersion=${page.engineVersion}, containerId=${containerId}`)
    }
    const containerVersion = containerVersionItem.version
    const target = IrisTargetEnvEnum.Test
    const type = IrisPublishTypeEnum.Publish
    const version = StringHelper.generateVersion()
    const { filename, bucket } = await this.irisEngine.htmlVersion().uploadDSL(JSON.stringify(dsl), pageId, version, target)

    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, bucket)
    const dslURL = client.cdnUrl(filename)
    const html = await this.irisEngine.html().genHTML(dslURL, htmlTemplate)

    const variable: Record<string, unknown> = {}
    variable['pageId'] = pageId
    variable['html'] = html
    variable['target'] = target
    variable['type'] = type
    variable['version'] = version
    variable['containerId'] = containerId
    variable['containerVersion'] = containerVersion
    variable['swimlane'] = swimlane

    const order = await this.createIrisOrderByProcessName(processName, userId, variable, remark)

    const flow = new IrisHtmlReleaseHistoryFlow()
    flow.version = version
    flow.swimlane = swimlane
    flow.createdBy = userId
    flow.containerId = containerId
    flow.containerVersion = containerVersion
    flow.type = type
    flow.target = target
    await this.createHistoryFlow(order, page, flow)

    return order
  }

  async createRollbackFlow(pageId: string, oldVersion: string, processName: string, remark: string) {
    const { userId } = this.irisEngine.user()
    const [page, htmlVersionItem, assetBucket, _] = await Promise.all([
      this.irisEngine.page().getActivePage(pageId),
      this.irisEngine.htmlVersion().getHtmlVersionByPageIdAndVersion(pageId, oldVersion),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAssetsBucket),
      /** 校验人员权限 */
      this.irisEngine.pageMember().verifyPageEditorPermission(pageId),
    ])
    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, assetBucket)

    const dslObjPath = IrisHtmlVersion.genS3DslObjPath(htmlVersionItem.target, htmlVersionItem.projectId, htmlVersionItem.pageId, oldVersion)
    const htmlObjPath = IrisHtmlVersion.genS3HtmlBackupObjPath(htmlVersionItem.target, htmlVersionItem.projectId, htmlVersionItem.pageId, oldVersion)
    // prettier-ignore
    const [dsl, html] = await Promise.all([
      client.query(dslObjPath),
      client.query(htmlObjPath),
    ])

    const type = IrisPublishTypeEnum.Rollback
    const newVersion = StringHelper.generateVersion()
    await this.irisEngine.htmlVersion().uploadDSL(dsl, pageId, newVersion, htmlVersionItem.target)

    const { swimlane, target, containerId, containerVersion } = htmlVersionItem

    const variable: Record<string, unknown> = {}
    variable['pageId'] = pageId
    variable['html'] = html
    variable['target'] = target
    variable['type'] = type
    variable['version'] = newVersion
    variable['containerId'] = containerId
    variable['containerVersion'] = containerVersion
    variable['swimlane'] = swimlane

    const order = await this.createIrisOrderByProcessName(processName, userId, variable, remark)

    const flow = new IrisHtmlReleaseHistoryFlow()
    flow.version = newVersion
    flow.swimlane = swimlane
    flow.createdBy = userId
    flow.containerId = containerId
    flow.containerVersion = containerVersion
    flow.type = type
    flow.target = target
    await this.createHistoryFlow(order, page, flow)

    return order
  }

  async createCanaryReleaseFlow(pageId: string, dsl: JSON, htmlTemplate: string, processName: string, remark?: string) {
    const { userId } = this.irisEngine.user()

    const pageParams = new IrisPageParams()
    pageParams.pageNum = 1
    pageParams.pageSize = 1
    const [page, _, [activeOrder]] = await Promise.all([
      this.irisEngine.page().getActivePage(pageId),
      /** 校验人员权限 */
      this.irisEngine.pageMember().verifyPageEditorPermission(pageId),
      /** 校验是否有进行中的发布任务 */
      this.searchFlow(pageParams, {
        pageId: pageId,
        targets: [IrisTargetEnvEnum.Production],
        state: IrisFlowStateEnum.Active,
      }).then(pageResult => pageResult.getList()),
    ])
    if (activeOrder) {
      throw new IrisBizException(`存在进行中的线上发布任务: pageId=${pageId}, orderId=${activeOrder.orderId}`)
    }
    const { containerId } = await this.irisEngine.scene().getScene(page.sceneId)

    const containerVersionItem = await this.irisEngine
      .containerVersion()
      .getLatestContainerVersion(containerId, { engineVersionStart: page.engineVersion, engineVersionEnd: page.engineVersion })
    if (containerVersionItem === null) {
      throw new IrisContainerVersionNotFoundError(`找不到对应的页面容器版本: engineVersion=${page.engineVersion}, containerId=${containerId}`)
    }
    /**
     * 暂只支持单个灰度
     * - 清空线上可能存在的灰度策略
     * */
    await this.irisEngine.htmlCanaryStrategy().clearPageCanaryStrategy(page.pageId)

    const containerVersion = containerVersionItem.version

    const target = IrisTargetEnvEnum.Production
    const type = IrisPublishTypeEnum.Canary
    const version = StringHelper.generateVersion()
    const swimlane: string = null
    const { filename, bucket } = await this.irisEngine.htmlVersion().uploadDSL(JSON.stringify(dsl), pageId, version, target)
    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, bucket)
    const dslURL = client.cdnUrl(filename)
    const html = await this.irisEngine.html().genHTML(dslURL, htmlTemplate)

    const variable: Record<string, unknown> = {}
    variable['pageId'] = pageId
    variable['html'] = html
    variable['target'] = target
    variable['type'] = type
    variable['version'] = version
    variable['containerId'] = containerId
    variable['containerVersion'] = containerVersion
    variable['swimlane'] = swimlane

    const order = await this.createIrisOrderByProcessName(processName, userId, variable, remark)

    const flow = new IrisHtmlReleaseHistoryFlow()
    flow.version = version
    flow.swimlane = swimlane
    flow.createdBy = userId
    flow.containerId = containerId
    flow.containerVersion = containerVersion
    flow.type = type
    flow.target = target

    await this.createHistoryFlow(order, page, flow)

    return order
  }

  async terminateFlow(orderId: string) {
    const order = await this.getFlow(orderId)
    assert.ok(order.state === IrisFlowStateEnum.Active || order.state === IrisFlowStateEnum.Pending, `流程已结束: orderId=${orderId}`)
    const orderUpdated = await this.terminateIrisFlow(orderId)
    // prettier-ignore
    await Promise.all([
      /** 删除灰度策略（如有） */
      order.type === IrisPublishTypeEnum.Canary && this.irisEngine.htmlCanaryStrategy().clearPageCanaryStrategy(order.pageId),
      /** 更新历史发布流程 */
      this.updateFlow(orderId, orderUpdated),
    ])
    return
  }

  async completeCanaryRelease(orderId: string) {
    const { userId } = this.irisEngine.user()
    const userInput: HtmlCanaryUserInput = {
      action: CanaryUserInputActionEnum.Online,
      operator: userId,
    }
    const variable: Record<string, unknown> = {}
    variable[HtmlReleaseHistoryFlowService.CANARY_USER_INPUT] = userInput
    const order = await this.triggerIrisTask(orderId, HtmlReleaseHistoryFlowService.CANARY_TASK_TAG, userId, variable)
    assert.ok(!!order, `不存在进行中的灰度发布任务: order=${orderId}`)
    return
  }

  async cancelCanaryRelease(orderId: string) {
    const { userId } = this.irisEngine.user()
    const userInput: HtmlCanaryUserInput = {
      action: CanaryUserInputActionEnum.Offline,
      operator: userId,
    }
    const variable: Record<string, unknown> = {}
    variable[HtmlReleaseHistoryFlowService.CANARY_USER_INPUT] = userInput
    const order = await this.triggerIrisTask(orderId, HtmlReleaseHistoryFlowService.CANARY_TASK_TAG, userId, variable)
    assert.ok(!!order, `不存在进行中的灰度发布任务: order=${orderId}`)
    return
  }

  /**
   * 过渡 后续删除
   * @param processName
   * @param userId
   * @param variable
   * @param remark
   * @returns
   */
  private async createIrisOrderByProcessName(processName: string, userId: string, variable: Record<string, unknown>, remark: string) {
    try {
      const process = await this.irisFlowEngine.process().getLatestVersionProcess(processName)
      if (process === null) {
        throw new Error()
      }
      return this.irisFlowEngine.startInstanceById(process.processId, userId, variable, remark)
    } catch (error) {
      const irisFlowService = new IrisFlowService()
      return irisFlowService.createOrderByProcessName(processName, userId, JSON.stringify(variable), remark)
    }
  }

  /**
   * 过渡 后续删除
   * @param orderId
   * @returns
   */
  private async terminateIrisFlow(orderId: string) {
    const newVal = new IrisHtmlReleaseHistoryFlow()
    try {
      const orderCur = await this.irisFlowEngine.order().getOrder(orderId)
      if (orderCur === null) {
        throw new Error()
      }
      if (orderCur.state === IrisFlowStateEnum.Active || orderCur.state === IrisFlowStateEnum.Pending) {
        await this.irisFlowEngine.order().terminate(orderId)
        const orderUpdated = await this.irisFlowEngine.order().getOrder(orderId)
        newVal.state = orderUpdated.state
        newVal.stateDesc = orderUpdated.stateDesc
      } else {
        newVal.state = orderCur.state
        newVal.stateDesc = orderCur.stateDesc
      }
    } catch (error) {
      const irisFlow = new IrisFlowService()
      const orderCur = await irisFlow.getOrder(orderId)
      if (orderCur.state === IrisFlowStateEnum.Active || orderCur.state === IrisFlowStateEnum.Pending) {
        await irisFlow.terminateOrder(orderId)
        const orderUpdated = await irisFlow.getOrder(orderId)
        newVal.state = orderUpdated.state
        newVal.stateDesc = orderUpdated.stateDesc
      } else {
        newVal.state = orderCur.state
        newVal.stateDesc = orderCur.stateDesc
      }
    }
    return newVal
  }

  /**
   * 过渡 后续删除
   * @param orderId
   * @param tag
   * @param userId
   * @param variable
   * @returns
   */
  private async triggerIrisTask(orderId: string, tag: string, userId: string, variable: Record<string, unknown>) {
    try {
      const order = await this.irisFlowEngine.order().getOrder(orderId)
      if (order === null) {
        throw new Error()
      }
      return this.irisFlowEngine.trigger(orderId, HtmlReleaseHistoryFlowService.CANARY_TASK_TAG, userId, variable)
    } catch (error) {
      const irisFlow = new IrisFlowService()
      return irisFlow.trigger(orderId, HtmlReleaseHistoryFlowService.CANARY_TASK_TAG, userId, JSON.stringify(variable))
    }
  }
}
