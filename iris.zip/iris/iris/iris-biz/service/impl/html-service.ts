import { parse } from 'node-html-parser'

import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IHtmlService } from 'iris/iris-biz/service/html-service'
import { IrisContainerVersionNotFoundError, IrisInvalidFormatParamError, IrisMissingParamError } from 'iris/iris-lib/model/iris-error'
import { FileHelper } from 'iris/iris-lib'

export class HtmlService extends AbstractService implements IHtmlService {
  public static PAGE_INFO_SCRIPT_ID = 'iris-page-info'

  constructor() {
    super()
  }

  async genReleasePreview(pageId: string, env: 'production' | 'test') {
    // prettier-ignore
    const [ draft, page ] = await Promise.all([
        this.irisEngine.draft().getDraft(pageId),
        this.irisEngine.page().getActivePage(pageId),
      ])
    const { containerId } = await this.irisEngine.scene().getScene(page.sceneId)

    const containerVersionItem = await this.irisEngine
      .containerVersion()
      .getLatestContainerVersion(containerId, { engineVersionStart: page.engineVersion, engineVersionEnd: page.engineVersion })
    if (containerVersionItem === null) {
      throw new IrisContainerVersionNotFoundError(`找不到对应的页面容器版本: engineVersion=${page.engineVersion}, containerId=${containerId}`)
    }
    const { source } = containerVersionItem
    const { config } = await this.irisEngine.project().getActiveProject(page.projectId)
    const pageInfo = {
      projectId: page.projectId,
      pageId,
      swimlane: draft.swimlane,
      dsl: '$DSL_URL', // DSL 占位
      env,
      ...config,
    }
    const htmlTemplate = await this.injectPageInfo(source, pageInfo)
    return {
      /** 注入系统配置等属性、但未设置 dslURL 的 html 模版 */
      htmlTemplate,
      /** 草稿对象，包括 dsl 等 */
      draft,
    }
  }

  async genHTML(dslURL: string, htmlTemplate: string) {
    const root = parse(htmlTemplate)
    const node = root.querySelector(`#${HtmlService.PAGE_INFO_SCRIPT_ID}`)
    if (!node) {
      this.irisEngine.logger().logError(`缺少 #${HtmlService.PAGE_INFO_SCRIPT_ID} 脚本`, { htmlTemplate })
      throw new IrisMissingParamError(`页面模板格式错误: 缺少 #${HtmlService.PAGE_INFO_SCRIPT_ID} 脚本`)
    }
    const raw = node.innerText
    const rawRemSpace = raw.replace(/\s*/g, '')
    const regx = /pageInfo=(.+)/g
    const regxRes = regx.exec(rawRemSpace)
    if (!regxRes || !regxRes[1]) {
      this.irisEngine.logger().logError('未找到 pageInfo', { htmlTemplate })
      throw new IrisMissingParamError(`页面模板格式错误: 未找到 pageInfo`)
    }
    try {
      const pageInfo = JSON.parse(regxRes[1])
      pageInfo['dsl'] = dslURL
      node.textContent = `
window.pageInfo = ${JSON.stringify(pageInfo, null, 2)}
`
    } catch (err) {
      this.irisEngine.logger().logError(err, { message: 'pageInfo 格式错误', htmlTemplate })
      throw new IrisInvalidFormatParamError(`页面模板格式错误: pageInfo 格式错误`)
    }
    return root.toString()
  }

  private async injectPageInfo(htmlURL: string, pageInfo: Record<string, any>) {
    const html = await FileHelper.fetch(htmlURL)
    const root = parse(html)
    const target = root.querySelector(`#${HtmlService.PAGE_INFO_SCRIPT_ID}`)
    if (!target) {
      this.irisEngine.logger().logError(`缺少 #${HtmlService.PAGE_INFO_SCRIPT_ID} 脚本`, { htmlURL })
      throw new IrisMissingParamError(`页面模板格式错误: 缺少 #${HtmlService.PAGE_INFO_SCRIPT_ID} 脚本`)
    }
    target.textContent = `
window.pageInfo = ${JSON.stringify(pageInfo, null, 2)}
`
    return root.toString()
  }
}
