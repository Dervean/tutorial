const AdmZip = require('adm-zip')
import assert from 'assert'
import md5 from 'md5'
import { IHtmlVersionDAO } from 'iris/iris-base/dao/html-version-dao'
import { IrisHtmlReleaseHistoryFlow } from 'iris/iris-base/entities/iris-html-release-history-flow'
import { IrisHtmlVersion } from 'iris/iris-base/entities/iris-html-version'
import { IrisTargetEnvEnum, IrisPublishTypeEnum } from 'iris/iris-base/enum/common'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IHtmlVersionService } from 'iris/iris-biz/service/html-version-service'
import { HtmlVersionDAO } from 'iris/iris-base/dao/impl/html-version-dao'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out'
import { IrisInvalidFormatParamError, IrisMissingParamError } from 'iris/iris-lib/model/iris-error'
import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'

import { MSSClientService, CDNSourceEnum } from 'iris/iris-out/mss/mss-client-service'

export class HtmlVersionService extends AbstractService implements IHtmlVersionService {
  protected dao: IHtmlVersionDAO<IrisHtmlVersion>

  constructor(dao?: HtmlVersionDAO) {
    super()
    this.dao = dao || new HtmlVersionDAO()
  }

  async searchHtmlVersion(
    pageParams: IrisPageParams,
    filter: {
      pageId?: string
      createdBy?: string
      targets?: IrisTargetEnvEnum[]
      types?: IrisPublishTypeEnum[]
      version?: string
      createTimeBegin?: string
      createTimeEnd?: string
      swimlane?: string
    },
  ) {
    const offset = IrisPageResult.getOffsetByPageNum(pageParams.pageNum, pageParams.pageSize)
    const limit = pageParams.pageSize
    const { rows, totalCnt } = await this.dao.search(offset, limit, filter)
    const page = new IrisPageResult<IrisHtmlVersion>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageParams.pageNum)
    page.setPageSize(pageParams.pageSize)
    return page
  }

  async getHtmlVersionByPageIdAndVersion(pageId: string, version: string): Promise<IrisHtmlVersion> {
    if (typeof version === 'string') {
      return this.dao.getByPageIdAndVersion(pageId, version)
    }
    throw new IrisInvalidFormatParamError(`页面版本格式错误: version=${version}`)
  }

  async getLatestHtmlVersion(
    pageId: string,
    filter: { target?: IrisTargetEnvEnum; swimlane?: string; createdBy?: string; type?: IrisPublishTypeEnum },
  ) {
    return this.dao.getLastestVersionByPageId(pageId, filter)
  }

  async getHtmlVersionByOrderId(orderId: string) {
    return this.dao.getByOrderId(orderId)
  }

  async getDSL(htmlVersion: IrisHtmlVersion) {
    try {
      assert.ok(!!htmlVersion.pageId, `pageId is required`)
      assert.ok(!!htmlVersion.target, `target is required`)
      assert.ok(!!htmlVersion.projectId, `projectId is required`)
      assert.ok(!!htmlVersion.version, `version is required`)
    } catch (error) {
      this.irisEngine.logger().logError(error)
      throw new IrisMissingParamError(`参数缺失: ${(error as Error).message}`)
    }
    const bucket = await LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAssetsBucket)
    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, bucket)
    const objPath = IrisHtmlVersion.genS3DslObjPath(htmlVersion.target, htmlVersion.projectId, htmlVersion.pageId, htmlVersion.version)
    return client.queryJson(objPath)
  }

  async getHTML(htmlVersion: IrisHtmlVersion) {
    try {
      assert.ok(!!htmlVersion.target, `target is required`)
      assert.ok(!!htmlVersion.projectId, `projectId is required`)
      assert.ok(!!htmlVersion.pageId, `pageId is required`)
      assert.ok(!!htmlVersion.version, `version is required`)
    } catch (error) {
      this.irisEngine.logger().logError(error)
      throw new IrisMissingParamError(`参数缺失: ${(error as Error).message}`)
    }
    const bucket = await LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAssetsBucket)
    const client = await MSSClientService.getInstance(CDNSourceEnum.BJ, bucket)
    const objPath = IrisHtmlVersion.genS3HtmlBackupObjPath(htmlVersion.target, htmlVersion.projectId, htmlVersion.pageId, htmlVersion.version)
    return client.query(objPath)
  }

  async createHtmlVersion(flow: IrisHtmlReleaseHistoryFlow) {
    const item = new IrisHtmlVersion()
    item.id = StringHelper.generatePrimaryKeyUUID()
    item.orderId = flow.orderId
    item.projectId = flow.projectId
    item.pageId = flow.pageId
    item.containerId = flow.containerId
    item.containerVersion = flow.containerVersion
    item.target = flow.target
    item.type = flow.type
    item.version = flow.version
    item.swimlane = flow.swimlane
    item.remark = flow.remark
    item.createdBy = flow.createdBy
    const dsl = await this.getDSL(item)
    item.md5 = md5(dsl)
    return this.dao.insert(item)
  }

  private async uploadS3Asset(source: CDNSourceEnum, bucket: string, objPath: string, content: string, contentType: string) {
    const client = await MSSClientService.getInstance(source, bucket)
    return client.upload(objPath, content, contentType)
  }

  async uploadDSL(dsl: string, pageId: string, version: string, target: IrisTargetEnvEnum) {
    const [page, assetBucket] = await Promise.all([
      this.irisEngine.page().getActivePage(pageId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAssetsBucket),
    ])
    const objPath = IrisHtmlVersion.genS3DslObjPath(target, page.projectId, pageId, version)
    await Promise.all([
      this.uploadS3Asset(CDNSourceEnum.BJ, assetBucket, objPath, dsl, 'application/json').then(({ objectUrl }) => {
        this.irisEngine.logger().logInfo(`北京线上环境发布成功: ${objectUrl}`)
        return
      }),
      this.uploadS3Asset(CDNSourceEnum.SH, assetBucket, objPath, dsl, 'application/json')
        .then(({ objectUrl }) => {
          this.irisEngine.logger().logInfo(`上海线上环境发布成功: ${objectUrl}`)
          return
        })
        .catch(e => {
          this.irisEngine.logger().logWarning(`上海线上环境发布失败: ${e.message}`, { objPath })
        }),
      ,
    ])
    return {
      bucket: assetBucket,
      filename: objPath,
    }
  }

  async uploadHTMLBackup(html: string, pageId: string, version: string, target: IrisTargetEnvEnum) {
    const [page, htmlBucket] = await Promise.all([
      this.irisEngine.page().getActivePage(pageId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSAssetsBucket),
    ])
    const objPath = IrisHtmlVersion.genS3HtmlBackupObjPath(target, page.projectId, pageId, version)
    await Promise.all([
      this.uploadS3Asset(CDNSourceEnum.BJ, htmlBucket, objPath, html, 'text/html; charset=UTF-8').then(({ objectUrl }) => {
        this.irisEngine.logger().logInfo(`北京线上环境发布成功: ${objectUrl}`)
        return
      }),
      this.uploadS3Asset(CDNSourceEnum.SH, htmlBucket, objPath, html, 'text/html; charset=UTF-8')
        .then(({ objectUrl }) => {
          this.irisEngine.logger().logInfo(`上海线上环境发布成功: ${objectUrl}`)
          return
        })
        .catch(e => {
          this.irisEngine.logger().logWarning(`上海线上环境发布失败: ${e.message}`, { objPath })
        }),
      ,
    ])
    return {
      bucket: htmlBucket,
      filename: objPath,
    }
  }

  async uploadHTMLS3(html: string, pageId: string, target: IrisTargetEnvEnum, swimlane?: string) {
    const [page, htmlBucket, htmlBucketTest] = await Promise.all([
      this.irisEngine.page().getActivePage(pageId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSHtmlBucket),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSHtmlBucketTest),
    ])
    const objPath = IrisHtmlVersion.genS3HtmlObjPath(target, page.projectId, page.path, swimlane)
    await Promise.all([
      this.uploadS3Asset(CDNSourceEnum.BJ, htmlBucket, objPath, html, 'text/html; charset=UTF-8').then(({ objectUrl }) => {
        this.irisEngine.logger().logInfo(`北京线上环境发布成功: ${objectUrl}`)
        return
      }),
      this.uploadS3Asset(CDNSourceEnum.SH, htmlBucket, objPath, html, 'text/html; charset=UTF-8')
        .then(({ objectUrl }) => {
          this.irisEngine.logger().logInfo(`上海线上环境发布成功: ${objectUrl}`)
          return
        })
        .catch(e => {
          this.irisEngine.logger().logWarning(`上海线上环境发布失败: ${e.message}`, { objPath })
        }),
      ,
      this.uploadS3Asset(CDNSourceEnum.BJ_TEST, htmlBucketTest, objPath, html, 'text/html; charset=UTF-8').then(({ objectUrl }) => {
        this.irisEngine.logger().logInfo(`测试环境发布成功: ${objectUrl}`)
        return
      }),
    ])
    return {
      bucket: htmlBucket,
      filename: objPath,
    }
  }

  async uploadHtmlWebStatic(html: string, pageId: string, strategyId?: string) {
    const page = await this.irisEngine.page().getActivePage(pageId)
    const objPath = IrisHtmlVersion.genWebStaticHtmlObjPath(page.projectId, page.path)

    const zip = new AdmZip()
    zip.addFile(objPath, Buffer.from(html))
    await this.irisEngine.webstatic().deploy(zip.toBuffer(), strategyId)
    return
  }

  async getHtmlUrl(input: Partial<IrisHtmlVersion | IrisHtmlReleaseHistoryFlow>) {
    const { projectId, target, pageId, swimlane } = input
    assert.ok(!!projectId, `参数缺失: 项目 ID`)
    assert.ok(!!target, `参数缺失: target`)
    assert.ok(!!pageId, `参数缺失: 页面 ID`)
    const page = await this.irisEngine.page().getPage(pageId)
    const [domain, webStaticDomain] = await Promise.all([
      LionClientService.fetchConfigValue(LionConfigKeyEnum.MSSDomain),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.WebstaticDomain),
    ])
    if (target === IrisTargetEnvEnum.Production) {
      const objPath = IrisHtmlVersion.genWebStaticHtmlObjPath(projectId, page.path)
      return `${webStaticDomain}/${objPath}`
    } else {
      const objPath = IrisHtmlVersion.genS3HtmlObjPath(target, projectId, page.path, swimlane)

      return `${domain}/${objPath}`
    }
  }

  async getLatestVersionListByPageIdList(pageIdList: string[]) {
    return this.dao.getLatestVersionListByPageIdList(pageIdList)
  }
}
