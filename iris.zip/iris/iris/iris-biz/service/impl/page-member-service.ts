import { IPageMemberDAO } from 'iris/iris-base/dao/page-member-dao'
import { IrisPageMember } from 'iris/iris-base/entities/iris-page-member'
import { PermissionBuilder, RoleTypeEnum } from 'iris/iris-biz/model/permission-builder'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IrisUserRole } from 'iris/iris-app/model/iris-user-role'
import { PageMemberDAO } from 'iris/iris-base/dao/impl/page-member-dao'
import { IPageMemberService } from 'iris/iris-biz/service/page-member-service'
import { IrisMemberNotFoundError, IrisNoPagePermissionError, IrisUserNotFoundError } from 'iris/iris-lib/model/iris-error'

export class PageMemberService extends AbstractService implements IPageMemberService {
  protected dao: IPageMemberDAO<IrisPageMember>

  constructor(dao?: PageMemberDAO) {
    super()
    this.dao = dao || new PageMemberDAO()
  }

  public async getMemberList(filter: { userId?: string; pageId?: string; permission?: number; projectId?: string }) {
    return this.dao.getMemberList(filter)
  }

  public async getRoleListByPageId(pageId: string) {
    const memberList = await this.dao.getMemberList({ pageId })
    const userIdList = memberList.map(e => e.userId)
    const orgInfoList = await this.irisEngine.org().queryByEmpIdList(userIdList)

    return memberList.map(e => {
      const { userId, permission } = e
      const role = new PermissionBuilder(permission).permission2role()
      const user = new IrisUserRole()
      try {
        const { name, mis } = orgInfoList.find(p => p.empId == userId)
        user.displayName = name
        user.userName = mis
        user.userId = userId
        user.role = role
        return user
      } catch (error) {
        this.irisEngine.logger().logError(`user not found: userId=${userId}`)
        user.displayName = null
        user.userName = null
        user.userId = userId
        user.role = role
        return user
      }
    })
  }

  public async insertOrUpdateMember(pageId: string, targetUserId: string, role: RoleTypeEnum) {
    const { projectId } = await this.irisEngine.page().getActivePage(pageId)
    await this.preCheckModifyPermission(pageId, targetUserId)

    const permission = new PermissionBuilder(role).getPermission()
    const member = await this.dao.getByPageIdAndUserId(pageId, targetUserId)

    if (member !== null) {
      const updated = new IrisPageMember()
      updated.permission = permission
      return this.dao.updateByPrimaryKey(member.id, updated)
    }

    const pageMemberItem = new IrisPageMember()
    pageMemberItem.pageId = pageId
    pageMemberItem.projectId = projectId
    pageMemberItem.userId = targetUserId
    pageMemberItem.permission = permission

    return this.dao.insert(pageMemberItem)
  }

  public async offlineMember(pageId: string, targetUserId: string) {
    await this.preCheckModifyPermission(pageId, targetUserId)
    const { userId } = this.irisEngine.user()
    // 查看是否已存在角色条目
    const memberItem = await this.dao.getByPageIdAndUserId(pageId, targetUserId)
    if (!memberItem) {
      throw new IrisMemberNotFoundError(`项目成员不存在: pageId=${pageId}, userId=${targetUserId}`)
    }
    await this.dao.deleteByPrimaryKey(memberItem.id, userId)
    return
  }

  public async verifyPageAdminPermission(pageId: string, userId?: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    const user = userId || operatorUserId
    const pb = await this.getUserPermission(pageId, user)
    const hasRight = pb.checkAdminPermission()
    if (!hasRight) {
      throw new IrisNoPagePermissionError(`页面管理员权限校验不通过: pageId=${pageId}, user=${user}`)
    }
  }

  public async verifyPageVisitorPermission(pageId: string, userId?: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    const user = userId || operatorUserId
    const pb = await this.getUserPermission(pageId, user)
    const hasRight = pb.checkVisitorPermission()
    if (!hasRight) {
      throw new IrisNoPagePermissionError(`页面访客权限校验不通过: pageId=${pageId}, user=${user}`)
    }
  }

  public async verifyPageEditorPermission(pageId: string, userId?: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    const user = userId || operatorUserId
    const pb = await this.getUserPermission(pageId, user)
    const hasRight = pb.checkEditorPermission()
    if (!hasRight) {
      throw new IrisNoPagePermissionError(`页面编辑权限校验不通过: pageId=${pageId}, user=${user}`)
    }
  }

  public async getUserPermission(pageId: string, user: string) {
    const isAdministrator = await this.irisEngine.admin().isAdministrator()
    if (isAdministrator) {
      const pb = new PermissionBuilder()
      pb.grantAdminPermission()
      return pb
    }
    const pageItem = await this.irisEngine.page().getActivePage(pageId)
    const [projectPermission, pageMemberItem] = await Promise.all([
      this.irisEngine.projectMember().getUserPermission(pageItem?.projectId, user),
      this.dao.getByPageIdAndUserId(pageId, user),
    ])
    const pb = new PermissionBuilder(pageMemberItem?.permission | projectPermission.getPermission())

    return pb
  }

  // 前置校验
  protected async preCheckModifyPermission(pageId: string, targetUserId: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    // prettier-ignore
    const [empInfo, _] = await Promise.all([
      this.irisEngine.org().queryByEmpId(targetUserId),
      this.verifyPageAdminPermission(pageId, operatorUserId),
    ])
    if (!empInfo) {
      throw new IrisUserNotFoundError(`找不到指定用户: userId=${targetUserId}`)
    }
  }
}
