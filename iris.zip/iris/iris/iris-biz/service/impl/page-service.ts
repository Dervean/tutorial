import assert from 'assert'
import { IPageDAO } from 'iris/iris-base/dao/page-dao'
import { IrisPage } from 'iris/iris-base/entities/iris-page'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IPageService } from 'iris/iris-biz/service/page-service'
import { PageDAO } from 'iris/iris-base/dao/impl/page-dao'
import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'
import { IrisPageAlreadyExistedError, IrisPageNotFoundError } from 'iris/iris-lib/model/iris-error'

export class PageService extends AbstractService implements IPageService {
  protected dao: IPageDAO<IrisPage>

  constructor(dao?: PageDAO) {
    super()
    this.dao = dao || new PageDAO()
  }

  async createPage(page: IrisPage) {
    const { userId } = this.irisEngine.user()

    /** 前置校验 */
    IrisPage.validatePageName(page.pageName)
    IrisPage.validatePath(page.path)
    IrisPage.validateEngineVersion(page.engineVersion)
    await this.irisEngine.projectMember().verifyProjectEditorPermission(page.projectId)
    const uniqueItem = await this.dao.getByProjectIdAndPath(page.projectId, page.path)
    if (uniqueItem) {
      throw new IrisPageAlreadyExistedError(`路径重复: projectId=${page.projectId}, path=${page.path}`)
    }

    const target = new IrisPage()
    target.projectId = page.projectId
    target.pageName = page.pageName
    target.path = page.path
    target.sceneId = page.sceneId
    /** 编辑器引擎版本为正整数枚举 */
    target.engineVersion = page.engineVersion
    target.createdBy = userId
    target.description = page.description
    return this.dao.insert(target)
  }

  async updatePage(pageId: string, page: IrisPage) {
    // prettier-ignore
    await Promise.all([
      this.getActivePage(pageId),
      this.irisEngine.pageMember().verifyPageEditorPermission(pageId),
    ])
    return this.dao.updateByPrimaryKey(pageId, page)
  }

  async offlinePage(pageId: string) {
    const { userId } = this.irisEngine.user()
    const page = await this.getActivePage(pageId)
    /** 管理员权限校验 */
    await this.irisEngine.projectMember().verifyProjectAdminPermission(page.projectId)

    await this.dao.deleteByPrimaryKey(pageId, userId)
    return
  }

  async searchPage(
    pageParams: IrisPageParams,
    filter: {
      keyword?: string
      projectId?: string
      sceneId?: string
    },
  ) {
    const { projectId, sceneId, keyword } = filter || {}
    assert.ok(!!projectId, `搜索页面项目 ID 必填`)
    /** 读权限校验 */
    await this.irisEngine.projectMember().verifyProjectVisitorPermission(projectId)
    let pagedResult: IrisPageResult<IrisPage>
    if (this.irisEngine.isIrisId(keyword as string) && projectId) {
      pagedResult = await this.search(pageParams, { projectId, fuzzyPageId: keyword, sceneId, status: IrisStatusEnum.Active })
    } else if (keyword && keyword.length && projectId) {
      pagedResult = await this.search(pageParams, { projectId, fuzzyPageName: keyword, sceneId, status: IrisStatusEnum.Active })
    } else if (projectId) {
      /** keyword 为空 */
      pagedResult = await this.search(pageParams, { projectId, sceneId, status: IrisStatusEnum.Active })
    } else {
      pagedResult = await this.search(pageParams, { status: IrisStatusEnum.Active })
    }
    return pagedResult as IrisPageResult<IrisPage>
  }

  async getPage(pageId: string) {
    return this.dao.getByPrimaryKey(pageId)
  }

  async getActivePage(pageId: string) {
    const page = await this.dao.getByPrimaryKey(pageId)
    if (page === null) {
      throw new IrisPageNotFoundError(`页面不存在: pageId=${pageId}`)
    }
    if (page && page.status === IrisStatusEnum.Inactive) {
      throw new IrisPageNotFoundError(`页面已下线: pageId=${pageId}`)
    }
    return page
  }

  async getPageList(projectId: string): Promise<IrisPage[]>
  async getPageList(pageIdList: string[]): Promise<IrisPage[]>
  async getPageList(param: string[] | string) {
    if (Array.isArray(param)) {
      return this.dao.getByPrimaryKeyList(param)
    }
    return this.dao.getPageList({ status: IrisStatusEnum.Active, projectIdList: [param] })
  }

  protected async search(
    pageParams: IrisPageParams,
    filter: {
      pageIdList?: string[]
      createdBy?: string
      projectId?: string
      sceneId?: string
      fuzzyPageName?: string
      fuzzyPageId?: string
      status?: IrisStatusEnum
    },
  ) {
    const offset = IrisPageResult.getOffsetByPageNum(pageParams.pageNum, pageParams.pageSize)
    const limit = pageParams.pageSize
    const { rows, totalCnt } = await this.dao.search(offset, limit, filter)

    const page = new IrisPageResult<IrisPage>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageParams.pageNum)
    page.setPageSize(pageParams.pageSize)
    return page
  }
}
