import { IProjectMemberDAO } from 'iris/iris-base/dao/project-member-dao'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { PermissionBuilder, RoleTypeEnum } from 'iris/iris-biz/model/permission-builder'
import { IrisProjectMember } from 'iris/iris-base/entities/iris-project-member'
import { IrisUserRole } from 'iris/iris-app/model/iris-user-role'
import { IProjectMemberService } from 'iris/iris-biz/service/project-member-service'
import { ProjectMemberDAO } from 'iris/iris-base/dao/impl/project-member-dao'
import { IrisBizException, IrisMemberNotFoundError, IrisNoProjectPermissionError, IrisUserNotFoundError } from 'iris/iris-lib/model/iris-error'
import { OrgEmpInfo } from 'iris/iris-out/org/org-employee-service'

export class ProjectMemberService extends AbstractService implements IProjectMemberService {
  protected dao: IProjectMemberDAO<IrisProjectMember>

  constructor(dao?: ProjectMemberDAO) {
    super()
    this.dao = dao || new ProjectMemberDAO()
  }

  public async getMemberList(filter: { userId?: string; permission?: number; projectId?: string }) {
    return this.dao.getMemberList(filter)
  }

  public async getRoleListByProjectId(projectId: string) {
    const memberList = await this.dao.getMemberList({ projectId })
    const userIdList = memberList.map(e => e.userId)
    const orgInfoList = await this.irisEngine.org().queryByEmpIdList(userIdList)

    return this.genUserRoleList(memberList, orgInfoList)
  }

  public async getAdminListByProjectId(projectId: string) {
    const permission = PermissionBuilder.role2permission(RoleTypeEnum.Admin)
    const memberList = await this.dao.getMemberList({ projectId, permission })
    const userIdList = memberList.map(e => e.userId)
    const orgInfoList = await this.irisEngine.org().queryByEmpIdList(userIdList)

    return this.genUserRoleList(memberList, orgInfoList)
  }

  public async insertOrUpdateMember(projectId: string, targetUserId: string, role: RoleTypeEnum) {
    await this.preCheckModifyPermission(projectId, targetUserId)
    const permission = new PermissionBuilder(role).getPermission()
    /** 查找是否有已存在角色条目 */
    const member = await this.dao.getByProjectIdAndUserId(projectId, targetUserId)
    if (member !== null) {
      const updated = new IrisProjectMember()
      updated.permission = permission
      return this.dao.updateByPrimaryKey(member.id, updated)
    }

    const memberItem = new IrisProjectMember()
    memberItem.projectId = projectId
    memberItem.userId = targetUserId
    memberItem.permission = permission
    return this.dao.insert(memberItem)
  }

  public async offlineMember(projectId: string, targetUserId: string) {
    await this.preCheckModifyPermission(projectId, targetUserId)
    const { userId } = this.irisEngine.user()

    /** 查找是否有已存在角色条目 */
    const memberItem = await this.dao.getByProjectIdAndUserId(projectId, targetUserId)
    if (!memberItem) {
      throw new IrisMemberNotFoundError(`项目成员不存在: projectId=${projectId}, targetUserId=${targetUserId}`)
    }

    await this.dao.deleteByPrimaryKey(memberItem.id, userId)
    return
  }

  public async verifyProjectAdminPermission(projectId: string, userId?: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    const user = userId || operatorUserId
    const pb = await this.getUserPermission(projectId, user)
    const hasRight = pb.checkAdminPermission()
    if (!hasRight) {
      throw new IrisNoProjectPermissionError(`项目管理员权限校验不通过: projectId=${projectId}, user=${user}`)
    }
  }

  public async verifyProjectVisitorPermission(projectId: string, userId?: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    const user = userId || operatorUserId
    const pb = await this.getUserPermission(projectId, user)
    const hasRight = pb.checkVisitorPermission()
    if (!hasRight) {
      throw new IrisNoProjectPermissionError(`项目访客权限校验不通过: projectId=${projectId}, user=${user}`)
    }
  }

  public async verifyProjectEditorPermission(projectId: string, userId?: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    const user = userId || operatorUserId
    const pb = await this.getUserPermission(projectId, user)
    const hasRight = pb.checkEditorPermission()
    if (!hasRight) {
      throw new IrisNoProjectPermissionError(`项目编辑权限校验不通过: projectId=${projectId}, user=${user}`)
    }
  }

  public async getUserPermission(projectId: string, userId: string) {
    const isAdministrator = await this.irisEngine.admin().isAdministrator()
    if (isAdministrator) {
      const pb = new PermissionBuilder()
      pb.grantAdminPermission()
      return pb
    }
    const [projectItem, memberItem] = await Promise.all([
      this.irisEngine.project().getActiveProject(projectId),
      this.dao.getByProjectIdAndUserId(projectId, userId),
    ])
    const { isPrivate } = projectItem
    const pb = new PermissionBuilder(memberItem?.permission)
    if (!isPrivate) {
      pb.grantViewPermission()
    }
    return pb
  }

  /**
   * 根据项目成员和 org 信息输出角色列表
   * @param memberList
   * @param orgEmpList
   * @returns
   */
  private genUserRoleList(memberList: IrisProjectMember[], orgEmpList: OrgEmpInfo[]) {
    return memberList.map(e => {
      const { userId, permission } = e
      const user = new IrisUserRole()
      const role = new PermissionBuilder(permission).permission2role()
      try {
        const { name, mis } = orgEmpList.find(p => p.empId == userId)
        user.displayName = name
        user.userName = mis
        user.userId = userId
        user.role = role
        return user
      } catch (error) {
        this.irisEngine.logger().logError(`user not found: userId=${userId}`)
        user.displayName = null
        user.userName = null
        user.userId = userId
        user.role = role
        return user
      }
    })
  }

  /**
   * 增删改权限时的前置校验
   * @param projectId
   * @param targetUserId 被修改人
   */
  private async preCheckModifyPermission(projectId: string, targetUserId: string) {
    const { userId: operatorUserId } = this.irisEngine.user()
    /** 前置校验 */
    const [empInfo, _] = await Promise.all([
      this.irisEngine.org().queryByEmpId(targetUserId),
      this.verifyProjectAdminPermission(projectId, operatorUserId),
    ])
    if (!empInfo) {
      throw new IrisUserNotFoundError(`找不到指定用户: userId=${targetUserId}`)
    }
    /** 不能修改自己的权限 */
    if (targetUserId === operatorUserId) {
      throw new IrisBizException(`无法编辑自己的权限: userId=${targetUserId}`)
    }
  }
}
