import assert from 'assert'
import { IProjectDAO } from 'iris/iris-base/dao/project-dao'
import { PermissionBuilder, RoleTypeEnum } from 'iris/iris-biz/model/permission-builder'
import { IrisProject } from 'iris/iris-base/entities/iris-project'
import { IrisProjectMember } from 'iris/iris-base/entities/iris-project-member'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { IProjectService } from 'iris/iris-biz/service/project-service'
import { ProjectDAO } from 'iris/iris-base/dao/impl/project-dao'
import { IrisNoProjectPermissionError, IrisProjectNotFoundError } from 'iris/iris-lib/model/iris-error'
import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

export class ProjectService extends AbstractService implements IProjectService {
  protected dao: IProjectDAO<IrisProject>

  constructor(dao?: ProjectDAO) {
    super()
    this.dao = dao || new ProjectDAO()
  }

  public searchProject(pageParams: IrisPageParams, filter: { keyword?: string; searchPublic?: boolean }) {
    const { keyword, searchPublic = false } = filter
    if (this.irisEngine.isIrisId(keyword as string)) {
      return this.search(pageParams, { searchPublic, fuzzyProjectId: keyword, status: IrisStatusEnum.Active })
    }
    /** projectName 不能只包含数字 */
    if (keyword && keyword.length) {
      return this.search(pageParams, { searchPublic, fuzzyProjectName: keyword, status: IrisStatusEnum.Active })
    }
    /** 查询参数为空 */
    return this.search(pageParams, { searchPublic, status: IrisStatusEnum.Active })
  }

  public async createProject(project: IrisProject, tagIdList?: string[]) {
    const { userId } = this.irisEngine.user()
    await this.irisEngine.org().queryByEmpId(userId)

    const target = new IrisProject()
    target.isPrivate = Number(project.isPrivate)
    target.description = project.description
    target.projectName = project.projectName
    target.icon = project.icon
    target.leader = userId
    target.createdBy = userId
    target.updatedBy = userId
    target.config = project.config
    /** 创建者拥有所有权限 */
    const permissionBuiler = new PermissionBuilder(RoleTypeEnum.Admin)
    const admin = new IrisProjectMember()
    admin.userId = userId
    admin.permission = permissionBuiler.getPermission()
    return this.dao.insert(target, admin, tagIdList)
  }

  public async updateProject(projectId: string, project: IrisProject) {
    const { userId } = this.irisEngine.user()
    project.updatedBy = userId
    await this.irisEngine.projectMember().verifyProjectEditorPermission(projectId, userId)
    if (project.leader || project.config) {
      await this.irisEngine.projectMember().verifyProjectAdminPermission(projectId, userId)
    }

    return this.dao.updateByPrimaryKey(projectId, project)
  }

  public async updateProjectConfig(projectId: string, config: JSON) {
    const { userId } = this.irisEngine.user()
    await this.irisEngine.projectMember().verifyProjectAdminPermission(projectId, userId)
    const project = new IrisProject()
    project.config = config
    project.updatedBy = userId
    return this.dao.updateByPrimaryKey(projectId, project)
  }

  public async offlineProject(projectId: string) {
    const { userId } = this.irisEngine.user()
    const project = await this.getActiveProject(projectId)
    try {
      assert.ok(project.leader === userId, `仅项目负责人可以删除项目`)
    } catch (error) {
      throw new IrisNoProjectPermissionError((error as Error).message)
    }
    await this.dao.deleteByPrimaryKey(projectId, userId)
    return
  }

  public async getProject(projectId: string) {
    return this.dao.getByPrimaryKey(projectId)
  }

  public async getActiveProject(projectId: string) {
    const project = await this.getProject(projectId)
    if (project === null) {
      throw new IrisProjectNotFoundError(`项目不存在: projectId=${projectId}`)
    }
    if (project.status === IrisStatusEnum.Inactive) {
      throw new IrisProjectNotFoundError(`项目已下线: projectId=${projectId}`)
    }
    return project
  }

  protected async search(
    pageParams: IrisPageParams,
    filter: {
      status?: IrisStatusEnum
      searchPublic?: boolean
      fuzzyProjectName?: string
      fuzzyProjectId?: string
    },
  ) {
    const { userId } = this.irisEngine.user()
    const isAdministrator = await this.irisEngine.admin().isAdministrator()
    const offset = IrisPageResult.getOffsetByPageNum(pageParams.pageNum, pageParams.pageSize)
    const limit = pageParams.pageSize
    const page = new IrisPageResult<IrisProject>()
    if (isAdministrator) {
      const { rows, totalCnt } = await this.dao.search(offset, limit, filter)
      page.setList(rows)
      page.setTotalCnt(totalCnt)
    } else {
      const memberList = await this.irisEngine.projectMember().getMemberList({ userId })
      const projectIdList = memberList.map(e => e.projectId)
      const { rows, totalCnt } = await this.dao.search(offset, limit, { projectIdList, ...filter })
      page.setList(rows)
      page.setTotalCnt(totalCnt)
    }
    page.setPageNum(pageParams.pageNum)
    page.setPageSize(pageParams.pageSize)
    return page
  }
}
