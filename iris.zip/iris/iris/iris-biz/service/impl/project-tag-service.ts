import { IProjectTagDAO } from 'iris/iris-base/dao/project-tag-dao'
import { IrisProjectTag } from 'iris/iris-base/entities/iris-project-tag'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { IProjectTagService } from 'iris/iris-biz/service/project-tag-service'
import { ProjectTagDAO } from 'iris/iris-base/dao/impl/project-tag-dao'

export class ProjectTagService extends AbstractService implements IProjectTagService {
  protected dao: IProjectTagDAO<IrisProjectTag>

  constructor(dao?: ProjectTagDAO) {
    super()
    this.dao = dao || new ProjectTagDAO()
  }

  async getProjectTagList(filter: IrisProjectTag) {
    return this.dao.getProjectTagList(filter)
  }

  async updateProjectTag(projectId: string, tagIdList: string[]) {
    const { userId } = this.irisEngine.user()
    const tags = tagIdList.map(val => {
      const tag = new IrisProjectTag()
      tag.tagId = val
      tag.projectId = projectId
      tag.createdBy = userId
      return tag
    })
    return this.dao.updateProjectTags(projectId, tags)
  }
}
