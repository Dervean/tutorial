import { ISceneDAO } from 'iris/iris-base/dao/scene-dao'
import { IrisScene } from 'iris/iris-base/entities/iris-scene'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { ISceneService } from 'iris/iris-biz/service/scene-service'
import { SceneDAO } from 'iris/iris-base/dao/impl/scene-dao'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'
import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

import { IrisSceneNotFoundError } from 'iris/iris-lib/model/iris-error'

export class SceneService extends AbstractService implements ISceneService {
  protected dao: ISceneDAO<IrisScene>

  constructor(dao?: SceneDAO) {
    super()
    this.dao = dao || new SceneDAO()
  }

  public async searchScene(pageParams: IrisPageParams) {
    const { pageNum, pageSize } = pageParams
    const offset = IrisPageResult.getOffsetByPageNum(pageNum, pageSize)
    const limit = pageSize

    const { rows, totalCnt } = await this.dao.search(offset, limit, { status: IrisStatusEnum.Active })
    const page = new IrisPageResult<IrisScene>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageNum)
    page.setPageSize(pageSize)
    return page
  }

  public async getScene(sceneId: string) {
    return this.dao.getByPrimaryKey(sceneId)
  }

  public async getActiveScene(sceneId: string) {
    const scene = await this.getScene(sceneId)
    if (scene === null) {
      throw new IrisSceneNotFoundError(`场景不存在: sceneId=${sceneId}`)
    }
    if (scene.status === IrisStatusEnum.Inactive) {
      throw new IrisSceneNotFoundError(`场景已下线: sceneId=${sceneId}`)
    }
    return scene
  }

  public async createScene(scene: IrisScene, tags?: string[]) {
    const { userId } = this.irisEngine.user()
    scene.createdBy = userId
    scene.updatedBy = userId
    await this.dao.insert(scene, tags)
    return
  }

  public async updateScene(sceneId: string, scene: IrisScene) {
    const { userId } = this.irisEngine.user()
    scene.updatedBy = userId
    return this.dao.updateByPrimaryKey(sceneId, scene)
  }

  public async offlineScene(sceneId: string) {
    const { userId } = this.irisEngine.user()
    await this.dao.deleteByPrimaryKey(sceneId, userId)
    return
  }

  public async getSceneList(filter: { name?: string; status?: IrisStatusEnum }) {
    return this.dao.getSceneList({ status: IrisStatusEnum.Active, ...filter })
  }

  public async getSceneListByTagIds(tagIdList: string[]) {
    const sceneIdList = await this.irisEngine.sceneTag().getSceneIdListByTagIdList(tagIdList)
    return this.dao.getByPrimaryKeyList(sceneIdList)
  }
}
