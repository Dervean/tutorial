import { ISceneTagDAO } from 'iris/iris-base/dao/scene-tag-dao'
import { IrisSceneTag } from 'iris/iris-base/entities/iris-scene-tag'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { ISceneTagService } from 'iris/iris-biz/service/scene-tag-service'
import { SceneTagDAO } from 'iris/iris-base/dao/impl/scene-tag-dao'

export class SceneTagService extends AbstractService implements ISceneTagService {
  protected dao: ISceneTagDAO<IrisSceneTag>

  constructor(dao?: SceneTagDAO) {
    super()
    this.dao = dao || new SceneTagDAO()
  }

  async getSceneTagList(filter: IrisSceneTag) {
    return this.dao.getSceneTagList(filter)
  }

  async updateSceneTag(sceneId: string, tagIdList: string[]) {
    const { userId } = this.irisEngine.user()
    const tags = tagIdList.map(val => {
      const tag = new IrisSceneTag()
      tag.tagId = val
      tag.sceneId = sceneId
      tag.createdBy = userId
      return tag
    })
    return this.dao.updateSceneTags(sceneId, tags)
  }

  async getSceneIdListByTagIdList(tagIdList: string[]) {
    return this.dao.getSceneIdListByTagIdList(tagIdList)
  }
}
