import { ITagDAO } from 'iris/iris-base/dao/tag-dao'
import { IrisTag } from 'iris/iris-base/entities/iris-tag'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { ITagService } from 'iris/iris-biz/service/tag-service'
import { TagDAO } from 'iris/iris-base/dao/impl/tag-dao'
import { IrisStatusEnum } from 'iris/iris-base/enum/common'

export class TagService extends AbstractService implements ITagService {
  protected dao: ITagDAO<IrisTag>

  constructor(dao?: TagDAO) {
    super()
    this.dao = dao || new TagDAO()
  }

  public async getTag(tagId: string) {
    return this.dao.getByPrimaryKey(tagId)
  }

  public async createTag(tag: IrisTag) {
    const { userId } = this.irisEngine.user()
    tag.createdBy = userId
    tag.updatedBy = userId
    return this.dao.insert(tag)
  }

  public async updateTag(tagId: string, tag: IrisTag) {
    const { userId } = this.irisEngine.user()
    tag.updatedBy = userId
    return this.dao.updateByPrimaryKey(tagId, tag)
  }

  public async offlineTag(tagId: string) {
    const { userId } = this.irisEngine.user()
    await this.dao.deleteByPrimaryKey(tagId, userId)
    return
  }

  async getTagList(filter: { source?: string; tagType?: string; id?: string; tagValue?: string; status?: IrisStatusEnum; tagIdList?: string[] }) {
    return this.dao.getTagList({ status: IrisStatusEnum.Active, ...filter })
  }
}
