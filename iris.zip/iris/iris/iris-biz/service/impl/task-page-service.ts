import { IrisTaskPage } from 'iris/iris-base/entities/iris-task-page'
import { ITaskPageDAO } from 'iris/iris-base/dao/task-page-dao'
import { TaskPageDAO } from 'iris/iris-base/dao/impl/task-page-dao'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { ITaskPageService } from 'iris/iris-biz/service/task-page-service'

export class TaskPageService extends AbstractService implements ITaskPageService {
  protected dao: ITaskPageDAO<IrisTaskPage>

  constructor(dao?: TaskPageDAO) {
    super()
    this.dao = dao || new TaskPageDAO()
  }

  async getTaskPageList(taskId: string) {
    const result = await this.dao.getTaskPageList(taskId)
    return result
  }

  async createTaskPage(taskPageList: IrisTaskPage[]) {
    await this.dao.insertMany(taskPageList)
  }
}
