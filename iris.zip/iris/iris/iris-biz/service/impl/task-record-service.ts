import { ITaskRecordService } from 'iris/iris-biz/service/task-record-service'
import { ITaskRecordDAO } from 'iris/iris-base/dao/task-record-dao'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'
import { TaskRecordDAO } from 'iris/iris-base/dao/impl/task-record-dao'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'

export class TaskRecordService extends AbstractService implements ITaskRecordService {
  protected dao: ITaskRecordDAO<IrisTaskRecord>

  constructor(dao?: TaskRecordDAO) {
    super()
    this.dao = dao || new TaskRecordDAO()
  }

  public async createTaskRecord(taskRecord: IrisTaskRecord) {
    return this.dao.insert(taskRecord)
  }

  public async updateTaskRecord(taskRecordId: string, taskRecord: IrisTaskRecord) {
    await this.dao.updateByPrimaryKey(taskRecordId, taskRecord)
    return
  }

  public async getTaskRecord(taskRecordId: string) {
    const result = await this.dao.getTaskRecord(taskRecordId)
    if (result?.workflowId) {
      const workflowUrl = this.irisEngine.fedo().getFedoRedirectUrl(result.workflowId)
      return { ...result, workflowUrl }
    }
    return result
  }

  public async getSuccessfulTaskRecordByTaskId(taskId: string) {
    return this.dao.getSuccessfulTaskRecordByTaskId(taskId)
  }
}
