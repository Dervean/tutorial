import moment from 'moment'
import assert from 'assert'
import { ITaskDAO } from 'iris/iris-base/dao/task-dao'
import { IrisTask } from 'iris/iris-base/entities/iris-task'
import { AbstractService } from 'iris/iris-biz/service/abstract-service'
import { ITaskService } from 'iris/iris-biz/service/task-service'
import { TaskDAO } from 'iris/iris-base/dao/impl/task-dao'
import { IrisTaskStatusEnum } from 'iris/iris-base/enum/task'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'
import { IrisHtmlVersion } from 'iris/iris-base'
import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

import { IrisBizException } from 'iris/iris-lib/model/iris-error'
import { DateHelper } from 'iris/iris-lib/helper/date-helper'

export class TaskService extends AbstractService implements ITaskService {
  protected dao: ITaskDAO<IrisTask>

  constructor(dao?: TaskDAO) {
    super()
    this.dao = dao || new TaskDAO()
  }

  public async getTask(taskId: string) {
    return this.dao.detail(taskId)
  }

  public async createTask(task: IrisTask, pageIdList: string[]) {
    const { userId } = this.irisEngine.user()
    task.createdBy = userId
    task.updatedBy = userId
    task.status = IrisTaskStatusEnum.Pending
    return this.dao.insert(task, pageIdList)
  }

  public async updateTask(taskId: string, task: IrisTask, pageIdList: string[]) {
    const { userId } = this.irisEngine.user()
    task.updatedBy = userId
    await this.dao.update(taskId, task, pageIdList)
    return
  }

  public async offlineTask(taskId: string) {
    const task = await this.getTask(taskId)
    assert.ok(task.status !== IrisTaskStatusEnum.Active, `任务删除失败：“进行中”的任务无法删除`)

    const { userId } = this.irisEngine.user()
    await this.dao.deleteByPrimaryKey(taskId, userId)
    return
  }

  public async searchTask(
    pageParams: IrisPageParams,
    filter: { projectId?: string; name?: string; statusList?: IrisTaskStatusEnum[]; hidePublic?: boolean; createdBy?: string },
  ) {
    const result: IrisPageResult<IrisTask> = await this.search(pageParams, filter)

    const onesItemIds = result
      .getList()
      .map(item => item.onesTaskId || item.onesRequirementId)
      .filter(Boolean)
    const onesItemInfoList = await this.irisEngine.ones().batchQuery(onesItemIds)

    const list = result.getList().map(item => {
      const data = item as Partial<IrisTask> & { workflowUrl?: string; onesItemUrl?: string; onesItemName?: string }

      // 有运行记录的任务，返回数据带上 workflowUrl
      if (data.taskRecordList?.length) {
        let currentTaskRecord = data.taskRecordList.find(record => record.status === IrisTaskStatusEnum.Active)
        // 有可能所有运行记录都失败，这时候取最新一条运行失败记录
        if (!currentTaskRecord) {
          const sortList = data.taskRecordList.sort((a, b) => {
            return moment(b.updateTime).diff(moment(a.updateTime))
          })
          currentTaskRecord = sortList[0]
        }
        const workflowUrl = currentTaskRecord?.workflowId ? this.irisEngine.fedo().getFedoRedirectUrl(currentTaskRecord?.workflowId) : undefined
        data.workflowUrl = workflowUrl
      }
      // 有关联ones信息的任务，返回数据带上 onesItemUrl
      if (data.onesProjectId) {
        if (data.onesTaskId) {
          data.onesItemUrl = this.irisEngine.ones().getOnesTaskUrl(data.onesProjectId, data.onesTaskId)
          data.onesItemName = onesItemInfoList.find(item => item.id === data.onesTaskId)?.name
        } else if (data.onesRequirementId) {
          data.onesItemUrl = this.irisEngine.ones().getOnesRequirementUrl(data.onesProjectId, data.onesRequirementId)
          data.onesItemName = onesItemInfoList.find(item => item.id === data.onesRequirementId)?.name
        }
      }
      return data
    })
    result.setList(list)
    return result
  }

  public async runTask(params: {
    taskId: string
    projectId: string
    pageVersionList: (Pick<IrisHtmlVersion, 'pageId' | 'target'> & { dsl: JSON; html: string })[]
    description?: string
    workflowSchedule?: Record<string, any>
    groupId?: string
    templateId?: string
    processName: string
  }) {
    const { taskId, groupId, templateId, workflowSchedule: schedule, description, pageVersionList = [], processName } = params

    // 检查任务状态
    const task = await this.irisEngine.task().getTask(taskId)
    assert.ok([IrisTaskStatusEnum.Pending, IrisTaskStatusEnum.Failed].includes(task.status), `任务运行失败：只有“待执行”或“已失败”的任务才可以运行`)

    // TODO: 因为发布和回滚不支持多页面批量操作，所以暂时只发布第一个页面，后续跟德运一起来优化
    const { pageId, dsl, html } = pageVersionList[0]

    // TODO: 把createCanaryReleaseFlow拆分成两个步，第一步只保存dsl信息，第二步创建灰度发布工作流，需要找德运来协助进行改造。
    // 第二步在FEDO工作流的灰度发布节点才调用，真正去创建灰度发布工作流
    // prettier-ignore
    const order = await this.irisEngine
      .htmlReleaseHistoryFlow()
      .createCanaryReleaseFlow(pageId, dsl, html, processName, description)

    // 创建任务运行记录
    const taskRecord = new IrisTaskRecord()
    taskRecord.taskId = taskId
    taskRecord.orderId = order.orderId
    taskRecord.description = description
    taskRecord.status = IrisTaskStatusEnum.Pending
    const result = await this.irisEngine.taskRecord().createTaskRecord(taskRecord)
    const taskRecordId = result.id

    // 启动 FEDO 工作流
    const projectId = task.projectId
    const groupMembers = await this.getGroupMembers(task)
    const { userName, displayName } = this.irisEngine.user()
    const { onesProjectId, onesRequirementId } = task
    let requirementName = '[没有关联Ones工作项]'
    if (onesProjectId && onesRequirementId) {
      const onesRequirementUrl = this.irisEngine.ones().getOnesRequirementUrl(onesProjectId, onesRequirementId)
      const onesRequirementData = await this.irisEngine.ones().queryOnesRequirementInfoById(onesProjectId, onesRequirementId)
      if (onesRequirementData?.requirementName) {
        requirementName = `[${onesRequirementData.requirementName}|${onesRequirementUrl}]`
      } else {
        requirementName = `[Ones需求|${onesRequirementUrl}]`
      }
    }

    const workflowSchedule = {
      ...schedule,
      pageIdList: pageVersionList.map(item => item.pageId),
      orderId: order.orderId,
      projectId,
      taskRecordId,
      CREAT_DX_GROUP_INFO_TITLE: `【${task.name}】上线周知群 ${moment().format('MM-DD')}`,
      CREAT_DX_GROUP_INFO_MEMBER: groupMembers.join(','),
      // FEDO 周知节点自定义模板需要的数据
      // TODO: 这部分先代码写死，现阶段还要频繁调整比较方便，后续要做成可配置
      notification: {
        system: '旅速搭',
        requirementName,
        workflowUrl: `https://lvsuda.sankuai.com/task/view?projectId=${projectId}&taskId=${taskId}&taskRecordId=${taskRecordId}`,
        userName: displayName,
        userMis: userName,
      },
    }

    // 优先取传参中的 templateId，没有的话取系统配置中的 templateId，最后兜底取 Lion 中配置的 templateId
    // const project = await this.irisEngine.project().getActiveProject(projectId)
    // const fedoTemplateId = (project.config as IProjcetConfig)?.fedo?.templateId

    try {
      const data = await this.irisEngine.fedo().startWorkflow({ groupId, templateId, workflowSchedule, taskId, taskRecordId })
      const { url, workflowId } = data

      const targetTask = new IrisTask()
      targetTask.status = IrisTaskStatusEnum.Active

      const targetTaskRecord = new IrisTaskRecord()
      targetTaskRecord.status = IrisTaskStatusEnum.Active
      targetTaskRecord.workflowId = workflowId

      this.irisEngine.logger().logInfo('运行任务', { groupId, templateId, workflowSchedule, taskId, taskRecordId })
      await this.dao.updateTaskAndTaskRecord(taskId, targetTask, taskRecordId, targetTaskRecord)
      this.irisEngine.logger().logInfo('运行任务成功', { groupId, templateId, workflowSchedule, taskId, taskRecordId })

      return { workflowId, taskRecordId: result.id, fedoUrl: url }
    } catch (err) {
      this.irisEngine.logger().logError(err, { message: '执行任务失败', params })
      // 工作流启动失败后，将任务运行记录状态改为“已失败”
      const newTaskRecord = new IrisTaskRecord()
      newTaskRecord.status = IrisTaskStatusEnum.Failed
      await this.irisEngine.taskRecord().updateTaskRecord(taskRecordId, newTaskRecord)
      throw err
    }
  }

  protected async search(
    pageParams: IrisPageParams,
    filter: { projectId?: string; name?: string; statusList?: IrisTaskStatusEnum[]; hidePublic?: boolean; userId?: string },
  ) {
    const offset = IrisPageResult.getOffsetByPageNum(pageParams.pageNum, pageParams.pageSize)
    const limit = pageParams.pageSize
    const { rows, totalCnt } = await this.dao.search(offset, limit, filter)

    const page = new IrisPageResult<IrisTask>()
    page.setList(rows)
    page.setTotalCnt(totalCnt)
    page.setPageNum(pageParams.pageNum)
    page.setPageSize(pageParams.pageSize)
    return page
  }

  public async completeTask(taskId: string, taskRecordId: string) {
    const targetTask = new IrisTask()
    targetTask.status = IrisTaskStatusEnum.Success

    const targetTaskRecord = new IrisTaskRecord()
    targetTaskRecord.status = IrisTaskStatusEnum.Success

    this.irisEngine.logger().logInfo('完成任务', { taskId, taskRecordId })
    await this.dao.updateTaskAndTaskRecord(taskId, targetTask, taskRecordId, targetTaskRecord)
    this.irisEngine.logger().logInfo('完成任务成功', { taskId, taskRecordId })
    return
  }

  public async terminateTask(taskId: string, taskRecordId: string) {
    const targetTask = new IrisTask()
    targetTask.status = IrisTaskStatusEnum.Failed

    const targetTaskRecord = new IrisTaskRecord()
    targetTaskRecord.status = IrisTaskStatusEnum.Failed

    this.irisEngine.logger().logInfo('终止任务', { taskId, taskRecordId })
    await this.dao.updateTaskAndTaskRecord(taskId, targetTask, taskRecordId, targetTaskRecord)
    this.irisEngine.logger().logInfo('终止任务成功', { taskId, taskRecordId })

    /** @todo 下线灰度流程 */
    const taskRecord = await this.irisEngine.taskRecord().getTaskRecord(taskRecordId)
    const orderId = taskRecord.orderId
    // TODO: createCanaryReleaseFlow拆分成两个步调用后，这里可能就无需手动下线灰度发布流程了
    await this.irisEngine.htmlReleaseHistoryFlow().cancelCanaryRelease(orderId)
    return
  }

  public async rollbackTask(taskId: string, remark: string, processName: string) {
    const taskRecord = await this.irisEngine.taskRecord().getSuccessfulTaskRecordByTaskId(taskId)
    if (!taskRecord) {
      throw new IrisBizException('回滚任务失败：只有已发布成功的任务才可以进行回滚操作')
    }

    const taskPageList = await this.irisEngine.taskPage().getTaskPageList(taskId)
    if (taskPageList?.length === 0) {
      throw new IrisBizException('回滚任务失败：请检查该任务关联的页面是否都已废弃')
    }

    const flow = await this.irisEngine.htmlReleaseHistoryFlow().getFlow(taskRecord.orderId)
    // TODO: 默认先取第一个页面进行回滚，等回滚服务支持多页面批量回滚后，再进行改造
    // prettier-ignore
    const flowOrder = await this.irisEngine
      .htmlReleaseHistoryFlow()
      .createRollbackFlow(taskPageList[0].pageId, flow.version, processName, remark)
    const newTaskRecord = new IrisTaskRecord()
    newTaskRecord.taskId = taskId
    newTaskRecord.orderId = flowOrder.orderId
    newTaskRecord.description = remark
    newTaskRecord.status = IrisTaskStatusEnum.Rollback
    newTaskRecord.id = await this.rollback(taskId, newTaskRecord)
    return newTaskRecord
  }

  /**
   * 回滚任务
   * @param taskId
   * @param taskRecord
   * @returns
   */
  protected async rollback(taskId: string, taskRecord: IrisTaskRecord) {
    const targetTask = new IrisTask()
    targetTask.status = IrisTaskStatusEnum.Rollback
    targetTask.updateTime = DateHelper.getDate()

    this.irisEngine.logger().logInfo('回滚任务', { taskId, taskRecord })
    const rollbackTaskRecord = await this.dao.updateTaskAndCreateTaskRecord(taskId, targetTask, taskRecord)
    this.irisEngine.logger().logInfo('回滚任务成功', { taskId, taskRecord })
    return rollbackTaskRecord.id
  }

  protected async getGroupMembers(task: IrisTask) {
    let groupMembers = []
    try {
      const memberSet = new Set([...(JSON.parse(task.pm) || []), ...(JSON.parse(task.qa) || []), ...(JSON.parse(task.rd) || [])])
      const { userName } = this.irisEngine.user()
      memberSet.add(userName)
      groupMembers = Array.from(memberSet)
    } catch (e) {
      this.irisEngine.logger().logError(e)
    }
    return groupMembers
  }
}
