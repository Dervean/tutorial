import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisPageMember } from 'iris/iris-base/entities/iris-page-member'
import { PermissionBuilder, RoleTypeEnum } from 'iris/iris-biz/model/permission-builder'
import { IrisUserRole } from 'iris/iris-app/model/iris-user-role'

export interface IPageMemberService extends IHasEngine, IHasFlowEngine {
  /**
   * 获取页面成员列表
   * @param filter
   */
  getMemberList(filter: Partial<IrisPageMember>): Promise<IrisPageMember[]>

  /**
   * 根据页面 id 获取成员角色列表
   * @param pageId
   */
  getRoleListByPageId(pageId: string): Promise<IrisUserRole[]>

  /**
   * 增、改页面成员
   */
  insertOrUpdateMember(pageId: string, targetUserId: string, role: RoleTypeEnum): Promise<void | IrisPageMember>

  /**
   * 删除页面成员
   * @param pageId
   * @param targetUserId
   */
  offlineMember(pageId: string, targetUserId: string): Promise<void>

  /**
   * 校验页面管理员权限
   * @param pageId
   * @param user
   */
  verifyPageAdminPermission(pageId: string, user?: string): Promise<void>

  /**
   * 校验页面访客权限
   * @param pageId
   * @param user
   */
  verifyPageVisitorPermission(pageId: string, user?: string): Promise<void>

  /**
   * 校验页面编辑权限
   * @param pageId
   * @param user
   */
  verifyPageEditorPermission(pageId: string, user?: string): Promise<void>

  /**
   * 根据页面 id 获取当前用户的权限
   * @param pageId
   * @param user
   */
  getUserPermission(pageId: string, user: string): Promise<PermissionBuilder>
}
