import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisPage } from 'iris/iris-base/entities/iris-page'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'

export interface IPageService extends IHasEngine, IHasFlowEngine {
  /**
   * 创建页面
   * @param page
   */
  createPage(page: IrisPage): Promise<IrisPage>

  /**
   * 更新页面基本信息
   * @param pageId
   * @param page
   */
  updatePage(pageId: string, page: IrisPage): Promise<void>

  /**
   * 下线页面
   * @param pageId
   */
  offlinePage(pageId: string): Promise<void>

  /**
   * 搜索页面列表，可以通过 keyword / projectId / pageGroupId / sceneId 搜索
   * @param params
   * @returns
   */
  searchPage(
    pageParams: IrisPageParams,
    filter: Partial<IrisPage> & {
      keyword?: string
    },
  ): Promise<IrisPageResult<IrisPage>>

  /**
   * 获取页面（包括已下线的）
   * @param pageId
   */
  getPage(pageId: string): Promise<IrisPage>

  /**
   * 获取在线页面
   * @param pageId
   */
  getActivePage(pageId: string): Promise<IrisPage>

  /**
   * 获取页面列表
   * @param projectId
   */
  getPageList(projectId: string): Promise<IrisPage[]>

  /**
   * 获取页面列表
   * @param pageIdList
   */
  getPageList(pageIdList: string[]): Promise<IrisPage[]>
}
