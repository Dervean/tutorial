import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { PermissionBuilder, RoleTypeEnum } from 'iris/iris-biz/model/permission-builder'
import { IrisProjectMember } from 'iris/iris-base/entities/iris-project-member'
import { IrisUserRole } from 'iris/iris-app/model/iris-user-role'

export interface IProjectMemberService extends IHasEngine, IHasFlowEngine {
  /**
   * 获取项目成员列表
   * @param filter 过滤参数
   */
  getMemberList(filter: Partial<IrisProjectMember>): Promise<IrisProjectMember[]>

  /**
   * 获取项目权限角色列表
   * @param projectId 项目 ID
   */
  getRoleListByProjectId(projectId: string): Promise<IrisUserRole[]>

  /**
   * 获取项目管理员角色列表
   * @param projectId
   */
  getAdminListByProjectId(projectId: string): Promise<IrisUserRole[]>

  /**
   * 1. 添加项目个人权限
   * 2. 编辑项目个人权限
   * @param projectId 项目 ID
   * @param targetUserId 被修改人
   * @param role RoleTypeEnum
   */
  insertOrUpdateMember(projectId: string, targetUserId: string, role: RoleTypeEnum): Promise<void | IrisProjectMember>

  /**
   * 删除个人项目权限
   * @param projectId 项目 ID
   * @param targetUserId 被修改人
   */
  offlineMember(projectId: string, targetUserId: string): Promise<void>

  /**
   * 校验 用户 拥有项目 管理员 权限
   * @param projectId
   * @param userId
   */
  verifyProjectAdminPermission(projectId: string, userId?: string): Promise<void>

  /**
   * 校验 用户 拥有项目 访客 权限
   * @param projectId
   * @param userId
   */
  verifyProjectVisitorPermission(projectId: string, userId?: string): Promise<void>

  /**
   * 校验 用户 拥有项目 编辑 权限
   * @param projectId
   * @param userId
   */
  verifyProjectEditorPermission(projectId: string, userId?: string): Promise<void>

  /**
   * 查询 用户 项目权限
   * @param projectId
   * @param userId
   * @returns
   */
  getUserPermission(projectId: string, userId: string): Promise<PermissionBuilder>
}
