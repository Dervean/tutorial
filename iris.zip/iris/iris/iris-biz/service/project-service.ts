import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'
import { IrisProject } from 'iris/iris-base/entities/iris-project'

export interface IProjectService extends IHasEngine, IHasFlowEngine {
  /**
   * 搜索项目列表
   * @param
   * keyword 模糊搜索关键词
   * pageParams 分页参数
   * searchPublic 结果中是否包含公开项目
   */
  searchProject(
    pageParams: IrisPageParams,
    filter: {
      keyword?: string
      searchPublic?: boolean
    },
  ): Promise<IrisPageResult<IrisProject>>

  /** 创建项目 */
  createProject(project: IrisProject, tagIdList?: string[]): Promise<IrisProject>

  /**
   * 更新项目基础信息
   * @param projectId 项目 ID
   * @param project
   */
  updateProject(projectId: string, project: IrisProject): Promise<void>

  /**
   * 更新项目配置
   * @param projectId 项目 ID
   * @param config 配置JSON
   */
  updateProjectConfig(projectId: string, config: JSON): Promise<void>

  /** 下线项目 */
  offlineProject(projectId: string): Promise<void>

  /**
   * 获取项目（包括已下线项目）
   * @param projectId 项目 ID
   */
  getProject(projectId: string): Promise<IrisProject>

  /**
   * 获取在线项目
   * @param projectId 项目 ID
   */
  getActiveProject(projectId: string): Promise<IrisProject>
}
