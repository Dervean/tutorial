import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisProjectTag } from 'iris/iris-base/entities/iris-project-tag'

export interface IProjectTagService extends IHasEngine, IHasFlowEngine {
  /**
   * 获取项目标签列表
   * @param filter
   */
  getProjectTagList(filter: Partial<IrisProjectTag>): Promise<IrisProjectTag[]>

  /**
   * 更新项目标签
   * @param projectId
   * @param tagIdList
   */
  updateProjectTag(projectId: string, tagIdList: string[]): Promise<void>
}
