import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'
import { IrisScene } from 'iris/iris-base/entities/iris-scene'

export interface ISceneService extends IHasEngine, IHasFlowEngine {
  /**
   * 搜索场景列表
   * @param pageParams 分页参数
   * @returns
   */
  searchScene(pageParams: IrisPageParams): Promise<IrisPageResult<IrisScene>>

  /**
   * 根据id查场景详情
   * @param sceneId
   */
  getScene(sceneId: string): Promise<IrisScene>

  /**
   * 根据id查询在线场景
   * @param sceneId
   */
  getActiveScene(sceneId: string): Promise<IrisScene>

  /**
   * 创建场景
   * @param scene
   */
  createScene(scene: IrisScene, tags?: string[]): Promise<void>

  /**
   * 编辑场景
   * @param sceneId
   * @param scene
   */
  updateScene(sceneId: string, scene: IrisScene): Promise<void>

  /**
   * 下线场景
   * @param sceneId
   */
  offlineScene(sceneId: string): Promise<void>

  /**
   * 获取场景列表
   * @param filter
   */
  getSceneList(filter: Partial<IrisScene>): Promise<IrisScene[]>

  /**
   * 获取已关联 tagIdList 的所有场景
   * @param tagIdList
   */
  getSceneListByTagIds(tagIdList: string[]): Promise<IrisScene[]>
}
