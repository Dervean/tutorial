import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisSceneTag } from 'iris/iris-base/entities/iris-scene-tag'

export interface ISceneTagService extends IHasEngine, IHasFlowEngine {
  /**
   * 获取场景标签列表
   * @param filter
   */
  getSceneTagList(filter: Partial<IrisSceneTag>): Promise<IrisSceneTag[]>

  /**
   * 获取已关联 tagIdList 的所有场景的场景 id
   * @param tagIdList
   */
  getSceneIdListByTagIdList(tagIdList: string[]): Promise<string[]>

  /**
   * 更新场景标签
   * @param projectId
   * @param tagIdList
   */
  updateSceneTag(projectId: string, tagIdList: string[]): Promise<void>
}
