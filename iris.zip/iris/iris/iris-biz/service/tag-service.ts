import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisTag } from 'iris/iris-base/entities/iris-tag'

export interface ITagService extends IHasEngine, IHasFlowEngine {
  /**
   * 获取标签列表
   * @param filter
   */
  getTagList(filter: Partial<IrisTag> & { tagIdsList?: string[] }): Promise<IrisTag[]>

  /**
   * 根据id查标签详情
   * @param tagId
   */
  getTag(tagId: string): Promise<IrisTag>

  /**
   * 创建标签
   * @param tag
   */
  createTag(tag: IrisTag): Promise<IrisTag>

  /**
   * 编辑标签
   * @param tagId
   * @param tag
   */
  updateTag(tagId: string, tag: IrisTag): Promise<void>

  /**
   * 下线标签
   * @param tagId
   */
  offlineTag(tagId: string): Promise<void>
}
