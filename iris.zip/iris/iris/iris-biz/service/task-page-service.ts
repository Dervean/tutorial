import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisTaskPage } from 'iris/iris-base/entities/iris-task-page'

export interface ITaskPageService extends IHasEngine, IHasFlowEngine {
  /**
   * 根据任务ID查询任务关联的页面
   * @param taskId
   */
  getTaskPageList(taskId: string): Promise<IrisTaskPage[]>

  /**
   * 创建任务关联页面
   * @param task
   */
  createTaskPage(taskPageList: IrisTaskPage[]): Promise<void>
}
