import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'

export interface ITaskRecordService extends IHasEngine, IHasFlowEngine {
  /**
   * 新增任务运行记录
   * @param taskRecord
   */
  createTaskRecord(taskRecord: IrisTaskRecord): Promise<IrisTaskRecord>

  /**
   * 更新任务记录信息
   * @param taskRecordId
   * @param taskRecord
   */
  updateTaskRecord(taskRecordId: string, taskRecord: IrisTaskRecord): Promise<void>

  /**
   * 根据id查任务运行记录详情
   * @param taskRecordId
   */
  getTaskRecord(taskRecordId: string): Promise<IrisTaskRecord>

  /**
   * 获取任务运行成功的记录
   * @param taskId
   */
  getSuccessfulTaskRecordByTaskId(taskId: string): Promise<IrisTaskRecord>
}
