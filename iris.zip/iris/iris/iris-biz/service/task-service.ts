import { IHasFlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IHasEngine } from 'iris/iris-biz/context/iris-engine'
import { IrisTask } from 'iris/iris-base/entities/iris-task'

import { IrisPageResult, IrisPageParams } from 'iris/iris-lib'
import { IrisTaskRecord } from 'iris/iris-base/entities/iris-task-record'
import { IrisHtmlVersion } from 'iris/iris-base/entities/iris-html-version'
import { IrisTaskStatusEnum } from 'iris/iris-base/enum/task'

export interface ITaskService extends IHasEngine, IHasFlowEngine {
  /**
   * 根据id查任务详情
   * @param taskId
   */
  getTask(taskId: string): Promise<IrisTask>

  /**
   * 创建任务
   * @param task
   * @param pageIdList
   */
  createTask(task: IrisTask, pageIdList: string[]): Promise<IrisTask>

  /**
   * 编辑任务
   * @param taskId
   * @param task
   * @param pageIdList
   */
  updateTask(taskId: string, task: IrisTask, pageIdList: string[]): Promise<void>

  /**
   * 搜索任务列表
   * @param pageParams
   * @param filter
   */
  searchTask(
    pageParams: IrisPageParams,
    filter: Partial<IrisTask> & { statusList?: IrisTaskStatusEnum[]; hidePublic?: boolean },
  ): Promise<IrisPageResult<IrisTask>>

  /**
   * 下线任务
   * @param taskId
   */
  offlineTask(taskId: string): Promise<void>

  /**
   * 运行任务
   * @param params
   */
  runTask(params: {
    taskId: string
    projectId: string
    processName: string
    pageVersionList: (Pick<IrisHtmlVersion, 'pageId' | 'target'> & { dsl: JSON; html: string })[]
    description?: string
    workflowSchedule?: Record<string, any>
    groupId?: string
    templateId?: string
  }): Promise<{ workflowId: string; taskRecordId: string; fedoUrl: string }>

  /**
   * 完成任务
   * @param taskId
   * @param taskRecordId
   */
  completeTask(taskId: string, taskRecordId: string): Promise<void>

  /**
   * 终止任务
   * @param taskId
   * @param taskRecordId
   */
  terminateTask(taskId: string, taskRecordId: string): Promise<void>

  /**
   * 回滚任务
   * @param taskId
   * @param taskRecord
   * @param processName 回滚流程名称
   */
  rollbackTask(taskId: string, remark: string, processName: string): Promise<IrisTaskRecord>
}
