import { FlowAccessLocalService } from 'iris/iris-flow/access/flow-access-local-service'
import { FlowConfiguration } from 'iris/iris-flow/context/flow-configuration'
import { FlowServiceContext } from 'iris/iris-flow/context/flow-service-context'
import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { StreamHelper } from 'iris/iris-lib/helper/stream-helper'

describe('iris-flow/__tests__/custom/class', () => {
  let processId: string
  let engine: FlowEngine

  beforeAll(async () => {
    await import('iris/iris-flow/__tests__/custom/model/test-flow-custom-class')
    await new FlowConfiguration().configure()
    engine = FlowServiceContext.engine

    const absPath = StreamHelper.absFilePath('iris-resource', 'flow', '__tests__', 'custom', 'class.xml')
    const process = await engine.process().deploy(StreamHelper.getStreamFromAbsFilePath(absPath))
    processId = process.processId
  })
  it('should', async () => {
    const args: Record<string, any> = {}
    args['msg'] = ['custom class test!!']
    const order = await engine.startInstanceById(processId, 'wangdeyun', args)
    const tasks = await engine.task().getActiveTasks({
      orderId: order.orderId,
    })
    // for (const task of tasks) {
    //   await engine.executeTask(task.taskId, '1')
    // }
  })

  afterAll(() => {
    FlowAccessLocalService.showCurrentDataStore()
  })
})
