import { FlowConfiguration } from 'iris/iris-flow/context/flow-configuration'
import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { FlowAccessLocalService } from 'iris/iris-flow/access/flow-access-local-service'
import { StreamHelper } from 'iris/iris-lib/helper/stream-helper'
import { FlowServiceContext } from 'iris/iris-flow/context/flow-service-context'

describe('iris-flow/__tests__/custom/handler', () => {
  let processId: string
  let engine: FlowEngine

  beforeAll(async () => {
    await import('iris/iris-flow/__tests__/custom/model/test-flow-custom-handler')

    await new FlowConfiguration().configure()
    engine = FlowServiceContext.engine
    const absPath = StreamHelper.absFilePath('iris-resource', 'flow', '__tests__', 'custom', 'handler.xml')
    const process = await engine.process().deploy(StreamHelper.getStreamFromAbsFilePath(absPath))
    processId = process.processId
  })
  it('should', async () => {
    const order = await engine.startInstanceById(processId)
    const tasks = await engine.task().getActiveTasks({
      orderId: order.orderId,
    })
    // for (const task of tasks) {
    //   await engine.executeTask(task.taskId)
    // }
  })

  afterAll(() => {
    FlowAccessLocalService.showCurrentDataStore()
  })
})
