import { IrisScopeEnum } from 'iris/iris-flow/enum/flow'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'

@ReflectHelper.collect(IrisScopeEnum.IrisFlow)
export class TestFlowCustomClass {
  async execute(msg: string) {
    const ret = `custom execute :>> ${msg}`
    return ret
  }
}
