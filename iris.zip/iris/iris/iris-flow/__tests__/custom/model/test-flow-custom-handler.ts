import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { IrisScopeEnum } from 'iris/iris-flow/enum/flow'
import { IFlowHandler } from 'iris/iris-flow/interface/flow-handler'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'

@ReflectHelper.collect(IrisScopeEnum.IrisFlow)
export class TestFlowCustomHandler implements IFlowHandler {
  async handle(execution: FlowExecution): Promise<void> {
    execution.engine.logger().logInfo('custom handler!!')
  }
}
