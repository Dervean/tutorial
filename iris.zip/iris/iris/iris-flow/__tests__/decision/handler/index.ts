import { FlowAccessLocalService } from 'iris/iris-flow/access/flow-access-local-service'
import { FlowConfiguration } from 'iris/iris-flow/context/flow-configuration'
import { FlowServiceContext } from 'iris/iris-flow/context/flow-service-context'
import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { StreamHelper } from 'iris/iris-lib/helper/stream-helper'

describe('iris-flow/__tests__/decision/handler', () => {
  let processId: string
  let engine: FlowEngine

  beforeAll(async () => {
    await import('iris/iris-flow/__tests__/decision/model/test-flow-decision-handler')
    await new FlowConfiguration().configure()
    engine = FlowServiceContext.engine
    const absPath = StreamHelper.absFilePath('iris-resource', 'flow', '__tests__', 'decision', 'handler.xml')
    const process = await engine.process().deploy(StreamHelper.getStreamFromAbsFilePath(absPath))
    processId = process.processId
  })
  it('should', async () => {
    const args: Record<string, any> = {}
    args['task1.operator'] = ['wangdeyun']
    args['task2.operator'] = ['wangdeyun']
    args['task3.operator'] = ['wangdeyun']
    args['target'] = 'toTask3'
    const order = await engine.startInstanceById(processId, 'wangdeyun', args)

    const tasks = await engine.task().getActiveTasks({
      orderId: order.orderId,
    })
    engine.logger().logInfo('iris-flow/__tests__/decision/handler', { tasks })
    // for (const task of tasks) {
    //   await engine.executeTask(task.taskId, '1')
    // }
  })

  afterAll(() => {
    FlowAccessLocalService.showCurrentDataStore()
  })
})
