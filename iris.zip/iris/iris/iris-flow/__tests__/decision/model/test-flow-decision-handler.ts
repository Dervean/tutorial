import { IrisLogLevelEnum } from 'iris/iris-base/enum/common'
import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { IrisScopeEnum } from 'iris/iris-flow/enum/flow'
import { IFlowDecisionHandler } from 'iris/iris-flow/interface/flow-decision-handler'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'

@ReflectHelper.collect(IrisScopeEnum.IrisFlow)
export class TestFlowDecisionHandler implements IFlowDecisionHandler {
  async decide(execution: FlowExecution) {
    return execution.variable['target']
  }

  async autoRun(execution: FlowExecution) {
    execution.engine.log().createLog(execution.task, IrisLogLevelEnum.Info, { message: 'TestFlowDecisionHandler.autoRun' })
    execution.engine.logger().logInfo('TestFlowDecisionHandler::autoRun', {
      execution,
    })
  }

  async end(execution: FlowExecution) {
    execution.engine.logger().logInfo('TestFlowDecisionHandler::end', {
      execution,
    })
  }
}
