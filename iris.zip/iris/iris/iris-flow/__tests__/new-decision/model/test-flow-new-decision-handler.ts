import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { IrisScopeEnum } from 'iris/iris-flow/enum/flow'
import { IFlowDecisionHandler } from 'iris/iris-flow/interface/flow-decision-handler'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'

@ReflectHelper.collect(IrisScopeEnum.IrisFlow)
export class TestFlowNewDecisionHandler implements IFlowDecisionHandler {
  async decide(execution: FlowExecution) {
    execution.engine.logger().logInfo('TestFlowNewDecisionHandler::decide', {
      execution,
      'execution.variable': execution.variable,
    })
    return execution.variable['target']
  }

  async waitRun1(execution: FlowExecution) {
    execution.engine.logger().logInfo('TestFlowNewDecisionHandler::waitRun1', {
      execution,
    })
  }

  async autoRun1(execution: FlowExecution) {
    execution.engine.logger().logInfo('TestFlowNewDecisionHandler::autoRun1', {
      execution,
    })
  }

  async autoRun2(execution: FlowExecution) {
    execution.engine.logger().logInfo('TestFlowNewDecisionHandler::autoRun2', {
      execution,
    })
  }

  async end(execution: FlowExecution) {
    execution.engine.logger().logInfo('TestFlowNewDecisionHandler::end', {
      execution,
    })
  }
}
