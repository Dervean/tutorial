import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'
import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export class FlowLogDAO extends AbstractDAO<IrisFlowLog> {
  constructor() {
    super()
    this.setRepository(IrisFlowLog)
    this.setPrimaryKey(IrisFlowLog.columns.id)
  }
}
