import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'
import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export class FlowOrderDAO extends AbstractDAO<IrisFlowOrder> {
  constructor() {
    super()
    this.setRepository(IrisFlowOrder)
    this.setPrimaryKey(IrisFlowOrder.columns.orderId)
  }

  public async getByPrimaryKey(orderId: string) {
    try {
      const repo = await this.getRepository()
      const data = await repo.findOne({
        relations: [this.columns.logs, `${this.columns.logs}.${IrisFlowLog.columns.order}`],
        where: { [IrisFlowLog.columns.orderId]: orderId },
      })
      return data || null
    } catch (error) {
      this.logger().logError(error, { orderId })
      throw error
    }
  }
}
