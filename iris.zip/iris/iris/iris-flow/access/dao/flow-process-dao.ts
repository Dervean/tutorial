import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { AbstractDAO } from 'iris/iris-base/dao/abstract-dao'

export class FlowProcessDAO extends AbstractDAO<IrisFlowProcess> {
  constructor() {
    super()
    this.setRepository(IrisFlowProcess)
    this.setPrimaryKey(IrisFlowProcess.columns.processId)
  }

  public async getLatestVersionByProcessName(processName: string) {
    try {
      const repo = await this.getRepository()

      const result = await repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.name} = :processName`, { processName })
        .orderBy(`${this.tableName}.${this.columns.version}`, `DESC`)
        .limit(1)
        .getOne()

      return result || null
    } catch (error) {
      this.logger().logError(error, { processName })
      throw error
    }
  }
}
