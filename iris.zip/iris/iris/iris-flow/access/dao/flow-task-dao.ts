import { AbstractDAO, IrisFlowLog, IrisFlowTask } from 'iris/iris-base'
import { StateEnum } from 'iris/iris-flow/enum/flow'
import { Brackets } from '@gfe/zebra-typeorm-client'

export class FlowTaskDAO extends AbstractDAO<IrisFlowTask> {
  constructor() {
    super()
    this.setRepository(IrisFlowTask)
    this.setPrimaryKey(IrisFlowTask.columns.taskId)
  }

  public async getByPrimaryKey(taskId: string) {
    try {
      const repo = await this.getRepository()
      const data = await repo.findOne({
        relations: [this.columns.logs, `${this.columns.logs}.${IrisFlowLog.columns.task}`],
        where: { [IrisFlowLog.columns.taskId]: taskId },
      })
      return data || null
    } catch (error) {
      this.logger().logError(error, { taskId })
      throw error
    }
  }

  public async getTaskList(
    orderId: string,
    filter: {
      states?: StateEnum[]
    },
  ) {
    try {
      const { states = [] } = filter
      const repo = await this.getRepository()

      // prettier-ignore
      const qb = repo
        .createQueryBuilder(this.tableName)
        .where(`${this.tableName}.${this.columns.orderId} = :orderId`, { orderId })

      if (states.length) {
        qb.andWhere(
          new Brackets(qb => {
            qb.where(`${this.tableName}.${this.columns.state} = ${states[0]}`)
            for (let i = 1; i < states.length; i++) {
              qb.orWhere(`${this.tableName}.${this.columns.state} = ${states[i]}`)
            }
          }),
        )
      }

      const result = await qb.getMany()

      return result
    } catch (error) {
      this.logger().logError(error, { orderId, filter })
      throw error
    }
  }
}
