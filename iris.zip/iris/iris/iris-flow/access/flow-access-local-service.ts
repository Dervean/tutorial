import { IFlowDBAccess } from 'iris/iris-flow/interface/flow-db-access'
import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'
import { StateEnum } from 'iris/iris-flow/enum/flow'
import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'

export class FlowAccessLocalService implements IFlowDBAccess {
  private static instance: FlowAccessLocalService = null

  static getInstance() {
    if (this.instance === null) {
      this.instance = new FlowAccessLocalService()
    }
    return this.instance
  }

  private static someProcess: Map<string, IrisFlowProcess> = new Map()
  private static someOrder: Map<string, IrisFlowOrder> = new Map()
  private static someTask: Map<string, IrisFlowTask> = new Map()
  private static someLog: Map<string, IrisFlowLog> = new Map()

  private static idxLog = 1

  private objectToArray(obj: Record<string, any>) {
    const res = []
    const keys = Object.keys(obj || {})
    for (const key of keys) {
      res.push([key, obj[key]])
    }
    return res
  }

  async getActiveTasks(filter: Partial<IrisFlowTask>) {
    const ret: IrisFlowTask[] = []
    for (const [id, task] of FlowAccessLocalService.someTask.entries()) {
      let ok = true
      for (const [k, v] of this.objectToArray(filter)) {
        // @ts-ignore
        if (task[k] !== v) {
          ok = false
          break
        }
      }
      if (task.state !== StateEnum.Active) {
        ok = false
      }
      if (ok) {
        ret.push(task)
      }
    }
    return ret
  }

  async saveTask(task: IrisFlowTask) {
    FlowAccessLocalService.someTask.set(task.taskId, task)
  }

  async getTask(taskId: string) {
    return FlowAccessLocalService.someTask.get(taskId)
  }

  async getTasks(orderId: string) {
    const ret: IrisFlowTask[] = []
    for (const [id, task] of FlowAccessLocalService.someTask.entries()) {
      if (task.orderId === orderId) {
        ret.push(task)
      }
    }
    return ret
  }

  async saveOrder(order: IrisFlowOrder) {
    FlowAccessLocalService.someOrder.set(order.orderId, order)
  }

  async saveLog(log: IrisFlowLog) {
    await FlowAccessLocalService.someLog.set(String(FlowAccessLocalService.idxLog++), log)
    return
  }

  async getOrder(orderId: string) {
    return FlowAccessLocalService.someOrder.get(orderId)
  }

  async getOrders(orderIds: string[]): Promise<IrisFlowOrder[]> {
    const ret: IrisFlowOrder[] = []
    for (const [id, order] of FlowAccessLocalService.someOrder.entries()) {
      if (orderIds.includes(id)) {
        ret.push(order)
      }
    }
    return ret
  }

  async saveProcess(process: IrisFlowProcess) {
    FlowAccessLocalService.someProcess.set(process.processId, process)
  }

  async getProcessById(id: string) {
    return FlowAccessLocalService.someProcess.get(id)
  }

  async getLatestVersionProcess(processName: string) {
    for (const [id, process] of FlowAccessLocalService.someProcess.entries()) {
      if (process.name === processName) {
        return process
      }
    }
    return null
  }

  async updateOrder(order: IrisFlowOrder) {
    FlowAccessLocalService.someOrder.set(order.orderId, order)
  }

  async updateTask(task: IrisFlowTask) {
    FlowAccessLocalService.someTask.set(task.taskId, task)
  }

  static showCurrentDataStore() {
    console.log('CurrentDataStore')
    console.log(FlowAccessLocalService.someOrder)
    console.log(FlowAccessLocalService.someProcess)
    console.log(FlowAccessLocalService.someTask)
    console.log(FlowAccessLocalService.someLog)
  }
}
