import { IFlowDBAccess } from 'iris/iris-flow/interface/flow-db-access'
import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'
import { StateEnum } from 'iris/iris-flow/enum/flow'
import { FlowOrderDAO } from 'iris/iris-flow/access/dao/flow-order-dao'
import { FlowProcessDAO } from 'iris/iris-flow/access/dao/flow-process-dao'
import { FlowTaskDAO } from 'iris/iris-flow/access/dao/flow-task-dao'
import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'
import { FlowLogDAO } from 'iris/iris-flow/access/dao/flow-log-dao'

export class FlowAccessRemoteService implements IFlowDBAccess {
  private orderDao: FlowOrderDAO
  private processDao: FlowProcessDAO
  private taskDao: FlowTaskDAO
  private logDao: FlowLogDAO

  constructor(engine: FlowEngine) {
    this.orderDao = new FlowOrderDAO()
    this.orderDao.setLogger(engine.logger())
    this.processDao = new FlowProcessDAO()
    this.processDao.setLogger(engine.logger())
    this.taskDao = new FlowTaskDAO()
    this.taskDao.setLogger(engine.logger())
    this.logDao = new FlowLogDAO()
    this.logDao.setLogger(engine.logger())
  }

  // @todo
  async getActiveTasks(filter: Partial<IrisFlowTask>) {
    filter.state = StateEnum.Active
    return this.taskDao.getTaskList(filter.orderId, { states: [StateEnum.Active] })
  }

  async saveTask(task: IrisFlowTask) {
    await this.taskDao.insert(task)
    return
  }

  async getTask(id: string) {
    return this.taskDao.getByPrimaryKey(id)
  }

  async getTasks(orderId: string) {
    return this.taskDao.getTaskList(orderId, {})
  }

  async saveOrder(order: IrisFlowOrder) {
    await this.orderDao.insert(order)
    return
  }

  async saveLog(log: IrisFlowLog) {
    await this.logDao.insert(log)
    return
  }

  async getOrder(id: string) {
    return this.orderDao.getByPrimaryKey(id)
  }

  async getOrders(orderIds: string[]): Promise<IrisFlowOrder[]> {
    return this.orderDao.getByPrimaryKeyList(orderIds)
  }

  async saveProcess(process: IrisFlowProcess) {
    await this.processDao.insert(process)
    return
  }

  async getProcessById(id: string) {
    return this.processDao.getByPrimaryKey(id)
  }

  async getLatestVersionProcess(processName: string) {
    const item = await this.processDao.getLatestVersionByProcessName(processName)
    return item
  }

  async updateOrder(order: IrisFlowOrder) {
    const { orderId, createTime, updateTime, ...param } = order
    return this.orderDao.updateByPrimaryKey(orderId, param)
  }

  async updateTask(task: IrisFlowTask) {
    const { taskId, createTime, updateTime, ...param } = task
    return this.taskDao.updateByPrimaryKey(taskId, param)
  }
}
