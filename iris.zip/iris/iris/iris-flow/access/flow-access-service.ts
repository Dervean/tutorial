import { IFlowDBAccess } from 'iris/iris-flow/interface/flow-db-access'
import { FlowAccessLocalService } from 'iris/iris-flow/access/flow-access-local-service'
import { FlowAccessRemoteService } from 'iris/iris-flow/access/flow-access-remote-service'
import { FlowEngine } from 'iris/iris-flow//core/flow-engine'

export abstract class FlowAccessService {
  private _access: IFlowDBAccess = null
  private _engine: FlowEngine = null

  constructor(engine: FlowEngine) {
    this._engine = engine
    switch (process.env.IRIS_RUNTIME_ENV) {
      case 'jest':
        engine.logger().logInfo('use mock access service ...')
        this._access = FlowAccessLocalService.getInstance()
        break
      default:
        this._access = new FlowAccessRemoteService(engine)
        break
    }
  }

  protected access() {
    return this._access
  }

  protected get engine() {
    return this._engine
  }
}
