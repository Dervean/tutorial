import { StreamHelper } from 'iris/iris-lib/helper/stream-helper'
import { FlowServiceContext } from 'iris/iris-flow/context/flow-service-context'
import { XMLHelper, JSItemType } from 'iris/iris-lib/helper/xml-helper'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'

export class FlowConfiguration {
  private static CONFIG_ROOT = 'iris-resource/flow'
  private static BASE_CONFIG_FILE = 'base.config.xml'
  private static EXT_CONFIG_FILE = 'ext.config.xml'

  public static PROCESS_CONFIG = new Map<string, Record<string, string>>()

  public async configure() {
    await Promise.all([this.parseBase(), this.parseExt()])
    return
  }

  private async parseBase() {
    const filepath = StreamHelper.absFilePath(FlowConfiguration.CONFIG_ROOT, FlowConfiguration.BASE_CONFIG_FILE)
    const buffer = StreamHelper.getStreamFromAbsFilePath(filepath)
    const data = await XMLHelper.getFromBuffer(buffer)
    const { $, _, ...children } = data.config
    for (const name of Object.keys(children)) {
      const values = children[name] as JSItemType[]
      switch (name) {
        case 'parser':
          for (const val of values) {
            await import(StreamHelper.absFilePath(val.$.class))
            ReflectHelper.classMap.set(val.$.name, ReflectHelper.classMap.get(val.$.clazz))
          }
          break
        default:
          break
      }
    }
    for (const [name, val] of ReflectHelper.classMap.entries()) {
      FlowServiceContext.put(name, val)
    }
  }

  private async parseExt() {
    const filepath = StreamHelper.absFilePath(FlowConfiguration.CONFIG_ROOT, FlowConfiguration.EXT_CONFIG_FILE)
    const buffer = StreamHelper.getStreamFromAbsFilePath(filepath)
    const data = await XMLHelper.getFromBuffer(buffer)

    const { $, _, ...children } = data.config
    for (const name of Object.keys(children)) {
      const values = children[name] as JSItemType[]
      switch (name) {
        case 'process':
          for (const val of values) {
            await this.parseProcess(val)
          }
          break
        default:
          break
      }
    }
  }

  private async parseProcess(process: JSItemType) {
    const { $, _, ...children } = process
    const { name, ...attrs } = $

    FlowServiceContext.EXT_PROCESS_CONFIGURATION.set(name, { ...attrs })
    for (const t of Object.keys(children)) {
      const values = children[t] as JSItemType[]
      switch (t) {
        case 'custom-handler':
        case 'decision-handler':
          for (const val of values) {
            await import(StreamHelper.absFilePath(val.$.class))
          }
          break
        default:
          break
      }
    }
  }
}
