import assert from 'assert'

import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { FlowContext } from 'iris/iris-flow/context/flow-context'

export class FlowServiceContext {
  private static _context: FlowContext = null
  private static _engine: FlowEngine = null

  public static EXT_PROCESS_CONFIGURATION = new Map<string, Record<string, string>>()

  public static get context(): FlowContext {
    if (this._context === null) {
      this._context = new FlowContext()
    }
    return this._context
  }

  public static set context(value: FlowContext) {
    if (value) {
      this._context = value
    }
  }

  public static get engine(): FlowEngine {
    if (this._engine === null) {
      this._engine = new FlowEngine()
    }
    return this._engine
  }

  public static find<T extends new (...args: any[]) => any>(clz: T): T {
    assert.ok(!!this.context, 'context not ready')
    return this.context.find(clz)
  }

  public static findList<T extends new (...args: any[]) => any>(clz: T): T[] {
    assert.ok(!!this.context, 'context not ready')
    return this.context.findList(clz)
  }

  public static put(name: string, clz: new (...args: any[]) => any) {
    assert.ok(!!this.context, 'context not ready')
    return this.context.put(name, clz)
  }
}
