import assert from 'assert'
import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { FlowOrderService } from 'iris/iris-flow/core/flow-order-service'
import { FlowProcessService } from 'iris/iris-flow/core/flow-process-service'
import { FlowTaskService } from 'iris/iris-flow/core/flow-task-service'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'
import { StateEnum } from 'iris/iris-flow/enum/flow'
import { Context } from 'iris/iris-app/interface/context'
import { IrisUserInfo } from 'iris/iris-app/model/iris-user-info'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'
import { FlowLogService } from 'iris/iris-flow/core/flow-log-service'

export interface IHasFlowEngine {
  setFlowEngine(engine: FlowEngine): void

  get irisFlowEngine(): FlowEngine
}

export class FlowEngine {
  public static AUTO = 'system'

  protected _context: Context = null
  protected _user: IrisUserInfo = null
  protected _logger: IrisLogger = null

  private flowProcessService: FlowProcessService = null
  private flowOrderService: FlowOrderService = null
  private flowTaskService: FlowTaskService = null
  private flowLogService: FlowLogService = null

  constructor(context?: Context, user?: IrisUserInfo) {
    this._context = context
    this._user = user
    // @todo transaction interceptor
    // @todo cache
  }

  public logger() {
    if (this._logger === null) {
      const logger = new IrisLogger()
      this.setLogger(logger)
    }
    return this._logger
  }

  public setLogger(logger: IrisLogger) {
    if (logger) {
      this._logger = logger
      this._logger.setUser(this._user)
    }
  }

  /**
   * 返回请求上下文
   * @returns
   */
  public context() {
    return this._context
  }

  /**
   * ==================
   * 业务服务
   * ==================
   */
  public process() {
    if (this.flowProcessService === null) {
      this.flowProcessService = new FlowProcessService(this)
    }
    return this.flowProcessService
  }

  public order() {
    if (this.flowOrderService === null) {
      this.flowOrderService = new FlowOrderService(this)
    }
    return this.flowOrderService
  }

  public task() {
    if (this.flowTaskService === null) {
      this.flowTaskService = new FlowTaskService(this)
    }
    return this.flowTaskService
  }

  public log() {
    if (this.flowLogService === null) {
      this.flowLogService = new FlowLogService(this)
    }
    return this.flowLogService
  }

  public async startInstanceById(processId: string, operator?: string, args?: Record<string, any>, remark?: string) {
    if (!args) {
      args = {}
    }
    const process = await this.process().getProcessById(processId)
    return this.startProcess(process, operator, args, remark)
  }

  public async trigger(orderId: string, tag: string, operator?: string, args?: Record<string, any>) {
    // todo 应当能继续执行流程 不需要每次都 trigger

    // - 获取 trigger 的 task
    const filter = new IrisFlowTask()
    filter.tag = tag
    filter.orderId = orderId
    /** @todo subprocess trigger */
    const tasks = await this.task().getActiveTasks(filter)
    this.logger().logInfo(`trigger`, { orderId, tag, operator, getActiveTasks: tasks.map(t => `${t.taskId}__${t.name}`) })

    if (tasks.length === 0) {
      return null
    }

    // - 获取 order
    if (!args) {
      args = {}
    }
    const order = await this.order().getOrder(orderId)
    const process = await this.process().getProcessById(order.processId)

    // - 校验 order 的状态
    try {
      assert.ok(!!order, `流程不存在: orderId=${orderId}`)
      assert.ok(order.state === StateEnum.Active, `流程已结束: stateDesc=${order.stateDesc}`)
    } catch (error) {
      this.logger().logError(error, { orderId, stateDesc: order.stateDesc })
      throw error
    }

    // - 校验 task 的状态
    const target = tasks[0]

    if (target.state !== StateEnum.Active) {
      return null
    }

    /** 合并变量 */
    const variable = order.variable
    if (variable) {
      Object.keys(variable).forEach(e => {
        if (args[e] === undefined) {
          args[e] = variable[e]
        }
      })
    }

    /** 注入 tag */
    const execution = new FlowExecution(this, process, order, args, tag)
    execution.operator = operator
    execution.task = target
    execution.state = StateEnum.Active

    if (process.model) {
      const nm = process.model.getNode(execution.task.name)
      this.logger().logInfo(`trigger node: name=${nm.name}, order=${order.orderId}, task=${target.taskId}`)

      await nm.execute(execution)
    }

    return order
  }

  // public async executeTask(taskId: string, operator?: string, args?: Record<string, any>): Promise<IrisFlowTask[]> {
  //   const execution = await this.executeT(taskId, operator, args)
  //   if (!execution) return []

  //   const model = execution.process.model

  //   execution.engine.logger().logInfo(`start process model execution...`, { name: model.name })

  //   if (model) {
  //     const nm = model.getNode(execution.task.name)
  //     await nm.execute(execution)
  //   }
  //   return execution.tasks
  // }

  private async startProcess(process: IrisFlowProcess, operator?: string, args?: Record<string, any>, remark?: string) {
    const execution = await this.executeP(process, operator, args, null, null, remark)
    if (process.model) {
      const start = process.model.getStart()
      assert.ok(!!start, `empty start node: process=${process.name}`)
      start.execute(execution)
    }
    return execution.order
  }

  private async executeP(
    process: IrisFlowProcess,
    operator: string,
    args: Record<string, any>,
    parentId: string,
    parentNodeName: string,
    remark: string,
  ) {
    const order = await this.order().createOrder(process, operator, args, parentId, parentNodeName, remark)
    const current = new FlowExecution(this, process, order, args)
    current.operator = operator
    current.state = StateEnum.Active

    return current
  }

  // private async executeT(taskId: string, operator?: string, args?: Record<string, any>): Promise<FlowExecution> {
  //   if (!args) args = {}
  //   const task = await this.task().complete(taskId, operator, args)

  //   execution.engine.logger().logInfo(`task is completed`, { taskId: task.taskId })

  //   const order = await this.query().getOrder(task.orderId)

  //   assert.ok(!!order, `流程实例已完成或不存在: orderId=${order.orderId}`)

  //   order.updatedBy = operator
  //   await this.order().updateOrder(order)

  //   // @todo 协办任务

  //   const variable = order.variable
  //   if (variable) {
  //     Object.keys(variable).forEach(e => {
  //       if (args[e] === undefined) {
  //         args[e] = variable[e]
  //       }
  //     })
  //   }
  //   const process = await this.process().getProcessById(order.processId)
  //   const execution = new FlowExecution(this, process, order, args)
  //   execution.operator = operator
  //   execution.task = task
  //   execution.state = StateEnum.Active
  //   return execution
  // }
}
