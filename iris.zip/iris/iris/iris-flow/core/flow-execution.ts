import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'
import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { StateEnum } from 'iris/iris-flow/enum/flow'

export class FlowExecution {
  public operator: string
  public task: IrisFlowTask = null
  public state: StateEnum = null
  // public suspend: boolean

  private _tag: string = null
  private _engine: FlowEngine = null
  private _process: IrisFlowProcess = null
  private _order: IrisFlowOrder = null
  private _variable: Record<string, any> = null
  private _tasks: IrisFlowTask[] = []

  public get tag() {
    return this._tag
  }
  public get tasks(): IrisFlowTask[] {
    return this._tasks
  }
  public get engine(): FlowEngine {
    return this._engine
  }
  public get process(): IrisFlowProcess {
    return this._process
  }
  public get order() {
    return this._order
  }
  public get variable() {
    return this._variable
  }

  constructor(engine: FlowEngine, process: IrisFlowProcess, order: IrisFlowOrder, variable: Record<string, any>, tag?: string) {
    if (!process || !order || !engine) {
      throw new Error(`failed to construct FlowExecution: process=${process}, engine=${engine}, order=${order}`)
    }
    this._engine = engine
    this._process = process
    this._order = order
    this._variable = variable
    this._tag = tag
    // this.suspend = false
  }

  public isTerminated() {
    return this.state === StateEnum.Canceled
  }

  public isFailed() {
    return this.state === StateEnum.Failed
  }

  public addTasks(tasks: IrisFlowTask[]) {
    this._tasks.push(...tasks)
  }

  public addTask(task: IrisFlowTask) {
    this._tasks.push(task)
  }

  public toJSON() {
    return {
      process: this.process,
      order: this.order,
      task: this.task,
      operator: this.operator,
      tag: this.tag,
      variable: this.variable,
    }
  }
}
