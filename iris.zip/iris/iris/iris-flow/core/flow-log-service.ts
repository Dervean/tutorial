import { FlowAccessService } from 'iris/iris-flow/access/flow-access-service'
import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'
import { IrisFlowOrder, IrisFlowTask } from 'iris/iris-base'
import { IrisLogLevelEnum } from 'iris/iris-base/enum/common'
import { StringHelper } from 'iris/iris-lib'

export class FlowLogService extends FlowAccessService {
  async createLog(task: IrisFlowTask, level: IrisLogLevelEnum, content: Record<string, any>): Promise<void>
  async createLog(order: IrisFlowOrder, level: IrisLogLevelEnum, content: Record<string, any>): Promise<void>
  async createLog(entity: IrisFlowOrder | IrisFlowTask, level: IrisLogLevelEnum, content: Record<string, any>) {
    const log = new IrisFlowLog()
    log.id = StringHelper.generatePrimaryKeyUUID()
    log.orderId = entity.orderId
    if (entity instanceof IrisFlowTask) {
      log.taskId = entity.taskId
    }
    log.level = level
    log.content = content

    await this.saveLog(log)
    return
  }

  private async saveLog(log: IrisFlowLog) {
    return this.access().saveLog(log)
  }
}
