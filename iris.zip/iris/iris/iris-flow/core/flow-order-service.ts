import { FlowAccessService } from 'iris/iris-flow/access/flow-access-service'
import { StateDescEnum, StateEnum } from 'iris/iris-flow/enum/flow'
import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'

export class FlowOrderService extends FlowAccessService {
  public static ATTR_CREATOR_REMARK = 'remark'

  public async createOrder(
    process: IrisFlowProcess,
    operator: string,
    args: Record<string, any>,
    parentId?: string,
    parentNodeName?: string,
    remark?: string,
  ) {
    const order = new IrisFlowOrder()
    order.orderId = StringHelper.generatePrimaryKeyUUID()
    order.parentId = parentId || null
    order.parentNodeName = parentNodeName || null
    order.createdBy = operator
    order.remark = remark
    order.processId = process.processId
    order.processName = process.name
    /** @todo 过期时间？ */
    order.variable = args
    order.state = StateEnum.Active
    order.stateDesc = StateDescEnum.Active

    await this.saveOrder(order)

    return order
  }

  public async terminate(orderId: string, operator?: string) {
    const order = await this.getOrder(orderId)
    if (order === null) {
      throw new Error(`流程不存在: orderId=${orderId}`)
    }
    if (order.state !== StateEnum.Active) {
      throw new Error(`流程已结束: orderId=${orderId}, state=${order.state}`)
    }

    const tasks = await this.engine.task().getActiveTasks({ orderId })
    const terminateTasks: Promise<void>[] = []
    for (const task of tasks) {
      const t = this.engine.task().terminate(task.taskId, operator)
      terminateTasks.push(t)
    }
    await Promise.all(terminateTasks)

    order.state = StateEnum.Canceled
    order.stateDesc = StateDescEnum.Canceled
    return this.updateOrder(order)
  }

  public async complete(orderId: string) {
    const order = await this.getOrder(orderId)
    order.state = StateEnum.Success
    order.stateDesc = StateDescEnum.Success
    return this.updateOrder(order)
  }

  public async destroy(orderId: string) {
    const order = await this.getOrder(orderId)
    order.state = StateEnum.Failed
    order.stateDesc = StateDescEnum.Failed
    return this.updateOrder(order)
  }

  public async saveOrder(order: IrisFlowOrder) {
    return this.access().saveOrder(order)
  }

  public async getOrder(orderId: string) {
    return this.access().getOrder(orderId)
  }

  public async getOrders(orderIds: string[]) {
    const ids = orderIds.filter(e => !!e)
    return this.access().getOrders(ids)
  }

  public async updateOrder(order: IrisFlowOrder) {
    return this.access().updateOrder(order)
  }
}
