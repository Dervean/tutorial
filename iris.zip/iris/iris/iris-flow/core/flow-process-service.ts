import assert from 'assert'

import { FlowAccessService } from 'iris/iris-flow/access/flow-access-service'
import { FlowModelParser } from 'iris/iris-flow/parser/flow-model-parser'
import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'

export class FlowProcessService extends FlowAccessService {
  public async deploy(input: Buffer, creator?: string) {
    assert.ok(!!input)
    const model = await FlowModelParser.parse(input)
    const entity = new IrisFlowProcess()
    const latestVersionProcess = await this.getLatestVersionProcess(model.name)
    const latestVersion = latestVersionProcess?.version || 0
    entity.processId = StringHelper.generatePrimaryKeyUUID()
    entity.version = latestVersion + 1
    entity.model = model
    entity.createdBy = creator
    entity.name = model.name
    entity.content = input
    entity.displayName = model.displayName
    await this.saveProcess(entity)
    return entity
  }

  public async saveProcess(process: IrisFlowProcess) {
    return this.access().saveProcess(process)
  }

  public async getProcessById(processId: string) {
    const process = await this.access().getProcessById(processId)
    return this.setProcessModel(process)
  }

  public async getLatestVersionProcess(processName: string) {
    const process = await this.access().getLatestVersionProcess(processName)
    return this.setProcessModel(process)
  }

  private async setProcessModel(process: IrisFlowProcess) {
    if (!process) return process
    if (process.model) return process
    const modelInput = process.content
    const model = await FlowModelParser.parse(modelInput)
    process.model = model
    return process
  }
}
