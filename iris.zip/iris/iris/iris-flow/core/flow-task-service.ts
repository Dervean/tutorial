import assert from 'assert'

import { FlowAccessService } from 'iris/iris-flow/access/flow-access-service'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'
import { PerformTypeEnum, StateDescEnum, StateEnum } from 'iris/iris-flow/enum/flow'
import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { FlowTaskModel } from 'iris/iris-flow/model/node/flow-task-model'
import { FlowTaskArrangement } from 'iris/iris-flow/factory/flow-task-arrangement'
import { StringHelper } from 'iris/iris-lib/helper/string-helper'

export class FlowTaskService extends FlowAccessService {
  public static START = 'start'

  public async complete(taskId: string, operator: string, args?: Record<string, any>) {
    const task = await this.getTask(taskId)
    assert.ok(!!task, `指定任务不存在: taskId=${taskId}`)
    // tostring override
    task.variable = args

    if (!this.isAllowed(task, operator)) {
      throw new Error(`无执行任务权限: operator=${operator}, taskId=${taskId}`)
    }

    // @todo 历史任务
    task.state = StateEnum.Success
    task.stateDesc = StateDescEnum.Success
    task.operator = operator

    return this.updateTask(task)
  }

  public async terminate(taskId: string, operator: string) {
    const task = await this.getTask(taskId)
    if (task === null) {
      throw new Error(`指定任务不存在: taskId=${taskId}`)
    }
    if (task.state !== StateEnum.Active) {
      throw new Error(`指定任务已结束: taskId=${taskId}, state=${task.state}`)
    }

    task.state = StateEnum.Canceled
    task.stateDesc = StateDescEnum.Canceled
    task.operator = operator

    return this.updateTask(task)
  }

  public async destroy(taskId: string, operator: string) {
    const task = await this.getTask(taskId)
    if (task === null) {
      throw new Error(`指定任务不存在: taskId=${taskId}`)
    }
    if (task.state !== StateEnum.Active) {
      throw new Error(`指定任务已结束: taskId=${taskId}, state=${task.state}`)
    }

    task.state = StateEnum.Failed
    task.stateDesc = StateDescEnum.Failed
    task.operator = operator

    return this.updateTask(task)
  }

  public isAllowed(task: IrisFlowTask, operator: string) {
    if (!operator) return false
    if (operator === FlowEngine.AUTO) {
      return true
    }
    if (task.operator) {
      return task.operator === operator
    }
    const actors = task.actors
    if (!actors || !actors.length) return true
    return actors.includes(operator)
  }

  public async createTask(tm: FlowTaskModel, execution: FlowExecution) {
    const tasks = [] as IrisFlowTask[]
    const args = execution.variable || {}
    // @todo 提醒时间
    // @todo 确定参与者 ?
    const task = new IrisFlowTask()
    task.orderId = execution.order.orderId
    task.name = tm.name
    task.tag = tm.tag
    task.displayName = tm.displayName
    // @todo 主办协办
    task.parentTaskId = execution.task?.taskId || FlowTaskService.START
    task.model = tm
    task.state = StateEnum.Active
    task.stateDesc = StateDescEnum.Active
    // @todo 过期时间
    // @tod deep JSON.stringify ?
    task.variable = args
    if (tm.performType === PerformTypeEnum.Any) {
      const t = await this.saveTask(task, execution.variable[tm.assignee])
      tasks.push(t)
    } else if (tm.performType === PerformTypeEnum.All) {
      // todo
    }
    return tasks
  }

  private async saveTask(task: IrisFlowTask, actors: string[]) {
    task.taskId = StringHelper.generatePrimaryKeyUUID()
    // @todo confirm any?
    task.performType = PerformTypeEnum.Any
    task.actors = Array.isArray(actors) ? [...actors] : null
    await this.access().saveTask(task)
    // actors 不需要单独建表
    return task
  }

  public async getTask(taskId: string) {
    return this.access().getTask(taskId)
  }

  public async getTasks(orderId: string) {
    return this.access().getTasks(orderId)
  }

  public async getSortedTasks(orderId: string) {
    const arrange = new FlowTaskArrangement(this.engine, orderId)
    return arrange.getSortedTasksWithPending()
  }

  public async getActiveTasks(filter: Partial<IrisFlowTask>) {
    return this.access().getActiveTasks(filter)
  }

  public async updateTask(task: IrisFlowTask) {
    return this.access().updateTask(task)
  }
}
