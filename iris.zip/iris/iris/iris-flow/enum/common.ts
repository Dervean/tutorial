export enum IrisStatusEnum {
  Active = 1,
  Inactive = -1,
}
