export enum IrisScopeEnum {
  IrisFlow = 'iris.flow',
}

export enum StateEnum {
  Pending = 1,
  Active = 2,
  Success = 3,
  Failed = 4,
  Canceled = 5,
}

export enum StateDescEnum {
  Pending = '待执行',
  Active = '进行中',
  Success = '已完成',
  Failed = '已失败',
  Canceled = '已撤销',
}

export enum PerformTypeEnum {
  Any = 'ANY',
  All = 'ALL',
}
