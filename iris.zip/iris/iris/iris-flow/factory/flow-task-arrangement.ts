import { StringHelper } from 'iris/iris-lib/helper/string-helper'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'
import { StateEnum, StateDescEnum } from 'iris/iris-flow/enum/flow'
import { FlowProcessModel } from 'iris/iris-flow/model/flow-process-model'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowTaskModel } from 'iris/iris-flow/model/node/flow-task-model'
import { FlowTaskService } from 'iris/iris-flow/core/flow-task-service'
import { FlowEngine } from 'iris/iris-flow//core/flow-engine'

class Node {
  node: FlowTaskModel
  parent: IrisFlowTask
}

export class FlowTaskArrangement {
  private orderId: string = null
  private engine: FlowEngine = null

  constructor(engine: FlowEngine, orderId: string) {
    this.orderId = orderId
    this.engine = engine
  }

  public async getSortedTasks() {
    const tasks = await this.engine.task().getTasks(this.orderId)
    if (!tasks || tasks.length === 0) {
      return null
    }
    const sortedTasks: IrisFlowTask[] = []
    for (const task of tasks) {
      const parent = tasks.find(t => t.taskId === task.parentTaskId)
      if (parent === undefined) {
        sortedTasks.push(task)
        break
      }
    }
    while (true) {
      const parent = sortedTasks[sortedTasks.length - 1]
      const child = tasks.find(t => t.parentTaskId === parent.taskId)
      if (!child) break
      sortedTasks.push(child)
    }
    return sortedTasks
  }

  public async getSortedTasksWithPending() {
    // prettier-ignore
    const [sortedTasks, order] = await Promise.all([
      this.getSortedTasks(),
      this.engine.order().getOrder(this.orderId),
    ])
    if (sortedTasks === null) {
      return null
    }
    if (sortedTasks.length === 0) {
      return []
    }
    const process = await this.engine.process().getProcessById(order.processId)
    const task = sortedTasks[sortedTasks.length - 1]
    const shadows = await this.tasksWithPending(process.model, order.orderId, task)
    return [...sortedTasks, ...shadows]
  }

  private tasksWithPending(processModel: FlowProcessModel, orderId: string, task: IrisFlowTask) {
    if (!processModel || !task) return []

    const tasks: IrisFlowTask[] = []
    const root = processModel.getNode(task.name)
    const queue: Node[] = []
    queue.push(...this.nextCandidates(root, task))

    while (queue.length) {
      const cur = queue.shift()
      const target = this.createGhostTask(cur.node, orderId, cur.parent)
      tasks.push(target)
      queue.push(...this.nextCandidates(cur.node, target))
    }

    return tasks
  }

  private createGhostTask(taskModel: FlowTaskModel, orderId: string, parentTask?: IrisFlowTask) {
    const task = new IrisFlowTask()
    task.taskId = StringHelper.generatePrimaryKeyUUID()
    task.state = StateEnum.Pending
    task.stateDesc = StateDescEnum.Pending
    task.name = taskModel.name
    task.displayName = taskModel.displayName
    task.performType = taskModel.performType
    task.orderId = orderId
    task.actors = null
    task.operator = null
    task.createTime = null
    task.updateTime = null
    task.parentTaskId = parentTask?.taskId || FlowTaskService.START
    return task
  }

  private nextCandidates(node: FlowNodeModel, task: IrisFlowTask) {
    const o = [node.outgoingTransitions]
    const candidates: Node[] = []
    while (o.length) {
      const outputs = o.shift()
      for (const output of outputs) {
        const t = output.target
        if (t instanceof FlowTaskModel) {
          const target = new Node()
          target.node = t
          target.parent = task
          candidates.push(target)
        } else {
          o.push(t.outgoingTransitions)
        }
      }
    }
    return candidates
  }
}
