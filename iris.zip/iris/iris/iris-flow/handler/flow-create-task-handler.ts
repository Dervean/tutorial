import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { IFlowHandler } from 'iris/iris-flow/interface/flow-handler'
import { FlowTaskModel } from 'iris/iris-flow/model/node/flow-task-model'

export class FlowCreateTaskHandler implements IFlowHandler {
  private model: FlowTaskModel = null

  constructor(tm: FlowTaskModel) {
    this.model = tm
  }

  public async handle(execution: FlowExecution) {
    const tasks = await execution.engine.task().createTask(this.model, execution)
    execution.addTasks(tasks)
    // @todo 拦截器
  }
}
