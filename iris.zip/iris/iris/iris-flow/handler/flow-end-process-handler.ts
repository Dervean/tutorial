import { FlowEngine } from 'iris/iris-flow/core/flow-engine'
import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { IFlowHandler } from 'iris/iris-flow/interface/flow-handler'
import { StateEnum } from 'iris/iris-flow/enum/flow'

export class FlowEndProcessHandler implements IFlowHandler {
  public async handle(execution: FlowExecution) {
    const state = execution.state
    switch (state) {
      case StateEnum.Failed:
        await this.destroy(execution)
        break
      case StateEnum.Canceled:
        await this.terminate(execution)
        break
      default:
        await this.complete(execution)
        break
    }
    // @todo 父流程
  }

  private async complete(execution: FlowExecution) {
    const engine = execution.engine
    const order = execution.order
    const tasks = await execution.engine.task().getActiveTasks({ orderId: order.orderId })
    // @todo 主办任务?
    for (const task of tasks) {
      await engine.task().complete(task.taskId, FlowEngine.AUTO)
    }
    await engine.order().complete(order.orderId)
  }

  private async destroy(execution: FlowExecution) {
    const engine = execution.engine
    const order = execution.order
    const tasks = await execution.engine.task().getActiveTasks({ orderId: order.orderId })
    // @todo 主办任务?
    for (const task of tasks) {
      await engine.task().destroy(task.taskId, FlowEngine.AUTO)
    }
    await engine.order().destroy(order.orderId)
  }

  private async terminate(execution: FlowExecution) {
    const engine = execution.engine
    const order = execution.order
    const tasks = await execution.engine.task().getActiveTasks({ orderId: order.orderId })
    // @todo 主办任务?
    for (const task of tasks) {
      await engine.task().terminate(task.taskId, FlowEngine.AUTO)
    }
    await engine.order().terminate(order.orderId)
  }
}
