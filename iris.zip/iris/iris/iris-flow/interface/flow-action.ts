import { FlowExecution } from 'iris/iris-flow/core/flow-execution'

export interface IFlowAction {
  execute(execution: FlowExecution): Promise<void>
}
