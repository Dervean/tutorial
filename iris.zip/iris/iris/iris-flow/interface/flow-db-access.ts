import { IrisFlowLog } from 'iris/iris-base/entities/iris-flow-log'
import { IrisFlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'

export interface IFlowDBAccess {
  getTask(taskId: string): Promise<IrisFlowTask>
  getTasks(orderId: string): Promise<IrisFlowTask[]>
  getActiveTasks(filter: Partial<IrisFlowTask>): Promise<IrisFlowTask[]>
  getOrder(orderId: string): Promise<IrisFlowOrder>
  getOrders(orderIds: string[]): Promise<IrisFlowOrder[]>
  getProcessById(id: string): Promise<IrisFlowProcess>
  getLatestVersionProcess(processName: string): Promise<IrisFlowProcess>

  saveProcess(process: IrisFlowProcess): Promise<void>
  saveOrder(order: IrisFlowOrder): Promise<void>
  saveTask(task: IrisFlowTask): Promise<void>
  saveLog(log: IrisFlowLog): Promise<void>

  updateTask(task: IrisFlowTask): Promise<void>
  updateOrder(order: IrisFlowOrder): Promise<void>
}
