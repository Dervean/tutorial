import { FlowExecution } from 'iris/iris-flow/core/flow-execution'

export interface IFlowDecisionHandler {
  decide(execution: FlowExecution): Promise<string>
}
