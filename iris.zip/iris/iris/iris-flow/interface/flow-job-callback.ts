import { IrisFlowTask } from 'iris/iris-base/entities/iris-flow-task'

export interface IFlowJobCallback {
  callback(taskId: string, newTasks: IrisFlowTask[]): Promise<void>
}
