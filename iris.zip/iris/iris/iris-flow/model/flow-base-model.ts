import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { IFlowHandler } from 'iris/iris-flow/interface/flow-handler'

export class FlowBaseModel {
  protected _name: string
  public displayName?: string

  public get name(): string {
    return this._name
  }
  public set name(value: string) {
    this._name = value
  }

  protected async fire(handler: IFlowHandler, execution: FlowExecution) {
    return handler.handle(execution)
  }
}
