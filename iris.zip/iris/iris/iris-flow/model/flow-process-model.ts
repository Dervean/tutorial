import { FlowBaseModel } from 'iris/iris-flow/model/flow-base-model'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowStartModel } from 'iris/iris-flow/model/node/flow-start-model'

export class FlowProcessModel extends FlowBaseModel {
  public nodes: FlowNodeModel[] = []

  getStart() {
    for (const node of this.nodes) {
      if (node instanceof FlowStartModel) {
        return node
      }
    }
    return null
  }

  getNode(nodeName: string) {
    for (const node of this.nodes) {
      if (node.name === nodeName) {
        return node
      }
    }
    return null
  }
}
