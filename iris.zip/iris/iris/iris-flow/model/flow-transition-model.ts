import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { FlowCreateTaskHandler } from 'iris/iris-flow/handler/flow-create-task-handler'
import { IFlowAction } from 'iris/iris-flow/interface/flow-action'
import { FlowBaseModel } from 'iris/iris-flow/model/flow-base-model'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowTaskModel } from 'iris/iris-flow/model/node/flow-task-model'

export class FlowTransitionModel extends FlowBaseModel implements IFlowAction {
  public source: FlowNodeModel
  public target: FlowNodeModel
  public to: string

  public isEnabled = false

  public async execute(execution: FlowExecution) {
    if (!this.isEnabled) return
    // @todo subprocess
    if (this.target instanceof FlowTaskModel) {
      const taskHandler = new FlowCreateTaskHandler(this.target)
      await this.fire(taskHandler, execution)
      /** 注意 */
      const tasks = await execution.engine.task().getActiveTasks({ orderId: execution.order.orderId })
      execution.engine.logger().logInfo(`execute transition`, {
        order: execution.order.orderId,
        getActiveTasks: tasks.map(e => `${e.taskId}__${e.name}`),
      })

      for (let i = 0; i < tasks.length; i++) {
        await execution.engine.trigger(execution.order.orderId, null, execution.operator, execution.variable)
      }
    } else {
      return this.target.execute(execution)
    }
  }
}
