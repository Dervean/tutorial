import { VarTypeEnum } from 'iris/iris-flow/model/node/action/enum'

export class FlowVarNode {
  public name: string
  public desplayName: string
  public contextVarName: string
  public defaultValue: string
  public inOutType: VarTypeEnum
}
