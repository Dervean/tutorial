import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { ActionTypeEnum, VarTypeEnum } from 'iris/iris-flow/model/node/action/enum'
import { FlowVarNode } from 'iris/iris-flow/model/flow-var-node'

export abstract class AbstractActionModel {
  protected _vars: FlowVarNode[] = []
  public get vars() {
    return this._vars
  }
  public addVar(value: FlowVarNode) {
    this._vars.push(value)
  }

  public abstract exec(execution: FlowExecution): Promise<void>

  public abstract getType(): ActionTypeEnum

  public setReturn(executionArgs: Record<string, any>, value: any) {
    for (let i = 0; i < this.vars.length; i++) {
      const v = this.vars[i]
      if (v.inOutType === VarTypeEnum.RETURN) {
        executionArgs[v.contextVarName] = value
        return
      }
    }
  }

  public getReturn(executionArgs: Record<string, any>) {
    for (let i = 0; i < this.vars.length; i++) {
      const v = this.vars[i]
      if (v.inOutType === VarTypeEnum.RETURN) {
        return executionArgs[v.contextVarName]
      }
    }
  }
}
