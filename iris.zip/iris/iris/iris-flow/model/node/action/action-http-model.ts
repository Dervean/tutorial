import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import * as HTTP from 'iris/iris-lib/constants/http'
import { AbstractActionModel } from 'iris/iris-flow/model/node/action/abstract-action-model'
import { ActionTypeEnum } from 'iris/iris-flow/model/node/action/enum'

export interface ActionHttpResponse {
  status: number
  data: unknown
  message?: string
}

export class ActionHttpModel extends AbstractActionModel {
  public host: string = null
  public port: number = null
  public path: string = null
  public method: HTTP.MethodEnum = HTTP.MethodEnum.POST

  // private payload(executionArgs: Record<string, any>) {
  //   const ret: Map<string, any> = new Map()
  //   for (let i = 0; i < this.vars.length; i++) {
  //     const v = this.vars[i]
  //     if (v.inOutType === VarTypeEnum.PARAM) {
  //       ret.set(v.contextVarName, executionArgs[v.contextVarName])
  //     }
  //   }
  //   return ret
  // }

  public async exec(execution: FlowExecution): Promise<void> {
    throw new Error(`HTTP 方法未实现: orderId=${execution.order.orderId}`)

    // const authorization: AuthorizationModel = {
    //   hostname: this.host,
    //   port: +this.port,
    //   path: this.path,
    //   method: this.method,
    //   headers: {},
    // }
    // const payload = this.payload(execution.args)

    // const res: ActionHttpResponse = await this.request(authorization, JSON.stringify(payload))
    // const { status, message, data } = res || {}
    // if (status === 0) {
    //   this.setReturn(execution.args, data)
    //   return
    // }
    // throw new Error(`执行回调失败: ${message}`)
  }

  // /** @todo 这个放在哪，要不要拆分 */
  // private request(options: RequestOptions, payload = ''): Promise<ActionHttpResponse> {
  //   const isGetMethod = options.method === HTTP.MethodEnum.GET
  //   const isHttps = options.port === HTTP.ProtocalEnum.HTTPS
  //   const request = isHttps ? requestHttps : requestHttp
  //   return new Promise((resolve, reject) => {
  //     const opt = {
  //       ...options,
  //       headers: {
  //         ...(!isGetMethod ? { [HTTP.HeaderEnum.CONTENT_LENGTH]: Buffer.byteLength(payload) } : {}),
  //         ...(options.headers || {}),
  //       },
  //     }
  //     const req = request(opt, res => {
  //       res.setEncoding('utf-8')
  //       const buffer: any[] = []
  //       res.on('data', chunk => buffer.push(Buffer.from(chunk)))
  //       res.on('end', () => {
  //         const data = Buffer.concat(buffer).toString()
  //         try {
  //           const parsedData: ActionHttpResponse = JSON.parse(data)
  //           resolve(parsedData)
  //         } catch (e) {
  //           execution.engine.logger().logError(`some error occurred during data transforming`, { data })
  //           reject(e)
  //         }
  //       })
  //     })
  //     req.on('error', e => {
  //       execution.engine.logger().logError('request failed', e)
  //     })
  //     if (!isGetMethod) {
  //       req.write(payload)
  //     }
  //     req.end()
  //   })
  // }

  public getType(): ActionTypeEnum {
    return ActionTypeEnum.HTTP
  }
}
