import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'
import { AbstractActionModel } from 'iris/iris-flow/model/node/action/abstract-action-model'
import { ActionTypeEnum, VarTypeEnum } from 'iris/iris-flow/model/node/action/enum'

export class ActionNodeModel extends AbstractActionModel {
  public clazz: string
  public methodName: string

  private invokeObject: Object

  public getArgs(executionArgs: Record<string, any>) {
    const ret: any[] = []
    for (let i = 0; i < this.vars.length; i++) {
      const v = this.vars[i]
      if (v.inOutType === VarTypeEnum.PARAM) {
        ret.push(executionArgs[v.contextVarName])
      }
    }
    return ret
  }

  public async exec(execution: FlowExecution) {
    execution.engine.logger().logInfo(`执行自定义对象实例`, { clazz: this.clazz, methodName: this.methodName })
    if (!this.invokeObject) {
      this.invokeObject = ReflectHelper.newInstance(this.clazz)
    }
    if (!this.invokeObject) {
      throw new Error(`自定义模型对象实例化失败: clazz=${this.clazz}`)
    }
    const ret = await ReflectHelper.invoke(this.invokeObject, this.methodName, [execution])

    this.setReturn(execution.variable, ret)
    return
  }

  public getType(): ActionTypeEnum {
    return ActionTypeEnum.NODE
  }
}
