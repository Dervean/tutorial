export class ActionThriftDefinitionNode {
  public name: string = null
  public link: string = null
}
