const request = require('request')
const requireFromString = require('require-from-string')
import { ThriftPool } from '@mtfe/thrift'
import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { AbstractActionModel } from 'iris/iris-flow/model/node/action/abstract-action-model'
import { ActionTypeEnum, VarTypeEnum } from 'iris/iris-flow/model/node/action/enum'
import { ActionThriftDefinitionNode } from 'iris/iris-flow/model/node/action/action-thrift-definition-node'
import { ActionThriftServiceNode } from 'iris/iris-flow/model/node/action/action-thrift-serivce-node'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'
import { ConfigHelper } from 'iris/iris-lib/helper/config-helper'
import { IrisThriftError } from 'iris/iris-lib/model/iris-error'

export class ActionThriftModel extends AbstractActionModel {
  private _timeout: number = 3000
  private _retry: number = 0
  private _serviceName: string = null
  private _methodName: string = null
  private _remoteAppKey: string = null
  private _definition: ActionThriftDefinitionNode = null
  private _serviceList: ActionThriftServiceNode[] = []

  public get timeout(): number {
    return this._timeout
  }

  public set timeout(value: number) {
    if (Number.isInteger(value) && value > 0) {
      this._timeout = value
    }
  }

  public get retry(): number {
    return this._retry
  }

  public set retry(value: number) {
    if (Number.isInteger(value) && value > 0) {
      this._retry = value
    }
  }

  public get serviceName(): string {
    return this._serviceName
  }

  public set serviceName(value: string) {
    this._serviceName = value
  }

  public get methodName(): string {
    return this._methodName
  }

  public set methodName(value: string) {
    this._methodName = value
  }

  public get remoteAppKey(): string {
    return this._remoteAppKey
  }

  public set remoteAppKey(value: string) {
    this._remoteAppKey = value
  }

  public set definition(value: ActionThriftDefinitionNode) {
    this._definition = value
  }

  public get serviceList(): ActionThriftServiceNode[] {
    return this._serviceList
  }

  public addService(value: ActionThriftServiceNode) {
    this._serviceList.push(value)
  }

  private get client() {
    const serviceList = this.serviceList
    return new ThriftPool({
      localAppKey: ConfigHelper.getAppKey(),
      remoteAppKey: this.remoteAppKey,
      serviceName: this.serviceName,
      unified: true,
      enableAuth: true,
      ...(!!serviceList.length ? { serviceList } : {}),
    })
  }

  public getArgs(execution: FlowExecution) {
    const executionArgs = execution.variable
    const ret: any[] = []
    for (let i = 0; i < this.vars.length; i++) {
      const v = this.vars[i]
      if (v.inOutType !== VarTypeEnum.PARAM) {
        continue
      }
      switch (v.contextVarName) {
        case FlowNodeParser.ATTR_FLOW_CONTEXT:
          ret.push(JSON.parse(JSON.stringify(execution)))
          break
        case '':
          ret.push(v.defaultValue)
          break
        default:
          ret.push(executionArgs[v.contextVarName])
          break
      }
    }
    return ret
  }

  public async exec(execution: FlowExecution) {
    const codeStr = await this.request(this._definition.link)
    const func = requireFromString(codeStr)
    const args = this.getArgs(execution)

    const ctx = {
      remoteAppKey: this.remoteAppKey,
      methodName: this.methodName,
      serviceName: this.serviceName,
      serviceList: this.serviceList,
      timeout: this.timeout,
      retry: this.retry,
      taskName: execution.task.name,
    }

    execution.engine.logger().logInfo('RPC调用', ctx)

    /** @todo 沙箱 */
    return this.client
      .exec(
        func,
        {
          methodName: this.methodName,
          timeout: this.timeout,
          retry: this.retry,
        },
        ...args,
      )
      .then(ret => {
        this.setReturn(execution.variable, ret)
        return
      })
      .catch(e => {
        execution.engine.logger().logError(e)
        execution.engine.logger().logError('RPC调用失败', ctx)
        throw new IrisThriftError()
      })
  }

  private request(link: string) {
    return new Promise((resolve, reject) => {
      /** @todo 替换 */
      request(link, (error: Error, response: any, body: any) => {
        if (error) {
          reject(error)
        }
        if (response.statusCode != 200) {
          reject(`请求 IDL 文件失败: statusCode=${response.statusCode}, link=${link}`)
        }
        resolve(body)
      })
    })
  }

  public getType(): ActionTypeEnum {
    return ActionTypeEnum.THRIFT
  }
}
