export class ActionThriftServiceNode {
  private _ip: string
  private _port: number

  public get ip(): string {
    return this._ip
  }
  public set ip(value: string) {
    this._ip = value
  }
  public get port(): number {
    return this._port
  }
  public set port(value: number) {
    if (!Number.isInteger(+value)) {
      throw new Error(`RPC 配置端口格式错误: port=${value}`)
    }
    this._port = +value
  }
}
