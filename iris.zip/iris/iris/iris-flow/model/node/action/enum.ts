export enum ActionTypeEnum {
  HTTP = 'http',
  HTTPS = 'https',
  NODE = 'node',
  THRIFT = 'thrift',
}

export enum VarTypeEnum {
  PARAM = 'param',
  RETURN = 'return',
}
