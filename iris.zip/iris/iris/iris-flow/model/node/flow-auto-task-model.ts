import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { PerformTypeEnum, StateEnum } from 'iris/iris-flow/enum/flow'
import { FlowTaskModel } from 'iris/iris-flow/model/node/flow-task-model'
import { FlowServiceContext } from 'iris/iris-flow'

export class FlowAutoTaskModel extends FlowTaskModel {
  public async exec(execution: FlowExecution) {
    if (this.performType === PerformTypeEnum.Any) {
      /** 执行外部任务 */
      try {
        await this.action.exec(execution)
      } catch (error) {
        execution.engine.logger().logError(error, {
          message: `任务失败`,
          taskId: execution.task.taskId,
          taskName: execution.task.name,
          operator: execution.operator,
        })
        /** @todo 不是所有任务失败都自毁 */
        await execution.engine.task().destroy(execution.task.taskId, execution.operator)
        execution.state = StateEnum.Failed
        execution.engine.logger().logInfo(`自毁任务成功，准备结束流程`, { taskId: execution.task.taskId })
        return this.terminate(execution)
      }
      /** 检测任务是否被外部更新 */
      const task = await execution.engine.task().getTask(execution.task.taskId)
      if (task.state === StateEnum.Failed || task.state === StateEnum.Canceled) {
        execution.state = task.state
        return this.terminate(execution)
      }
      /** @todo 加在这里? */
      await execution.engine.task().complete(execution.task.taskId, execution.operator, execution.variable)
      return this.runOutTransition(execution)
    }
    {
      // @todo all
    }
  }
}
