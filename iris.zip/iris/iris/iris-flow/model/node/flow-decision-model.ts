import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { StateEnum } from 'iris/iris-flow/enum/flow'
import { FlowServiceContext } from 'iris/iris-flow/context/flow-service-context'

export class FlowDecisionModel extends FlowNodeModel {
  public async exec(execution: FlowExecution) {
    try {
      await this.action.exec(execution)
      const next = this.action.getReturn(execution.variable)
      execution.engine.logger().logInfo(`决策结果: next=${next}`)

      let isFound = false
      for (const tm of this.outgoingTransitions) {
        if (tm.name === next) {
          tm.isEnabled = true
          await tm.execute(execution)
          isFound = true
        }
      }
      if (!isFound) {
        throw new Error(`无法确定下一步决策节点`)
      }
    } catch (error) {
      execution.engine.logger().logError(error, { mesasge: `决策失败`, order: execution.order })

      /** @todo 记录 sys_log */
      execution.state = StateEnum.Failed
    }
  }

  // // public expr: string
  // public scope: string
  // public handleClass: string
  // private decision: IFlowDecisionHandler
  // // private expression: Expression

  // public async exec(execution: FlowExecution) {
  //   // @todo
  //   // expr 先不做
  //   if (!this.decision) {
  //     this.decision = ReflectHelper.newInstance(this.handleClass)
  //   }
  //   if (!this.decision) {
  //     throw new Error(`自定义决策对象实例化失败: scope=${this.scope}, handleClass=${this.handleClass}`)
  //   }
  //   const next = await this.decision.decide(execution)
  //   execution.engine.logger().logInfo(`decision result: next=${next}`)

  //   let isFound = false
  //   for (const tm of this.outgoingTransitions) {
  //     if (tm.name === next) {
  //       tm.isEnabled = true
  //       await tm.execute(execution)
  //       isFound = true
  //     }
  //   }
  //   if (!isFound) {
  //     throw new Error(`decision 节点无法确定下一步执行节点: orderId=${execution.order.orderId}`)
  //   }
  // }
}
