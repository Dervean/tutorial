import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { FlowEndProcessHandler } from 'iris/iris-flow/handler/flow-end-process-handler'
import { FlowTransitionModel } from 'iris/iris-flow/model/flow-transition-model'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'

export class FlowEndModel extends FlowNodeModel {
  public get name(): string {
    return FlowNodeParser.ATTR_END_NAME
  }

  public set name(value: string) {
    this._name = FlowNodeParser.ATTR_END_NAME
  }

  public get outgoingTransitions() {
    return [] as FlowTransitionModel[]
  }

  public async exec(execution: FlowExecution) {
    await this.fire(new FlowEndProcessHandler(), execution)
    /** 回调通知调用方流程结束 不等待 不卡错 */
    try {
      this.action?.exec(execution)
    } catch (error) {
      execution.engine.logger().logError(error)
    }
    return this.runOutTransition(execution)
  }
}
