import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { IFlowAction } from 'iris/iris-flow/interface/flow-action'
import { FlowBaseModel } from 'iris/iris-flow/model/flow-base-model'
import { FlowTransitionModel } from 'iris/iris-flow/model/flow-transition-model'
import { AbstractActionModel } from 'iris/iris-flow/model/node/action/abstract-action-model'

export abstract class FlowNodeModel extends FlowBaseModel implements IFlowAction {
  private _tag: string = null
  public get tag(): string {
    return this._tag
  }
  public set tag(value: string) {
    this._tag = value
  }

  private _incomingTransitions: FlowTransitionModel[] = []
  public get incomingTransitions(): FlowTransitionModel[] {
    return this._incomingTransitions
  }
  public addIncomingTransition(value: FlowTransitionModel) {
    this._incomingTransitions.push(value)
  }

  private _outgoingTransitions: FlowTransitionModel[] = []
  public get outgoingTransitions(): FlowTransitionModel[] {
    return this._outgoingTransitions
  }
  public addOutgoingTransition(value: FlowTransitionModel) {
    this._outgoingTransitions.push(value)
  }

  private _incomingNodes: FlowNodeModel[] = []
  public get incomingNodes(): FlowNodeModel[] {
    return this._incomingNodes
  }
  public addIncomingNode(value: FlowNodeModel) {
    this._incomingNodes.push(value)
  }

  private _outgoingNodes: FlowNodeModel[] = []
  public get outgoingNodes(): FlowNodeModel[] {
    return this._outgoingNodes
  }
  public addOutgoingNode(value: FlowNodeModel) {
    this.outgoingNodes.push(value)
  }

  private _action: AbstractActionModel = null
  public get action(): AbstractActionModel {
    return this._action
  }
  public set action(value: AbstractActionModel) {
    this._action = value
  }

  protected abstract exec(execution: FlowExecution): Promise<void>

  public async execute(execution: FlowExecution) {
    // @todo 拦截器？
    return this.exec(execution)
  }

  protected async runOutTransition(execution: FlowExecution) {
    for (const tm of this.outgoingTransitions) {
      tm.isEnabled = true
      await tm.execute(execution)
    }
  }
}
