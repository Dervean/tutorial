import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { FlowTransitionModel } from 'iris/iris-flow/model/flow-transition-model'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'

export class FlowStartModel extends FlowNodeModel {
  public get name(): string {
    return FlowNodeParser.ATTR_START_NAME
  }

  public set name(value: string) {
    this._name = FlowNodeParser.ATTR_START_NAME
  }

  public get incomingTransitions() {
    return [] as FlowTransitionModel[]
  }

  public async exec(execution: FlowExecution) {
    return this.runOutTransition(execution)
  }
}
