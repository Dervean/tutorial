import { FlowExecution } from 'iris/iris-flow/core/flow-execution'
import { PerformTypeEnum } from 'iris/iris-flow/enum/flow'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'

export abstract class FlowTaskModel extends FlowNodeModel {
  public performType: PerformTypeEnum = PerformTypeEnum.Any
  public shadow: 'Y' | 'N' = 'N'
  public assignee: string // not user name

  public abstract exec(execution: FlowExecution): Promise<void>

  /** 任务失败/取消 跳至终止节点 */
  protected async terminate(execution: FlowExecution) {
    const nm = execution.process.model.getNode(FlowNodeParser.ATTR_END_NAME)
    execution.engine.logger().logInfo('开始执行终止节点', {
      name: nm.name,
      displayName: nm.displayName,
    })
    return nm.execute(execution)
  }
}
