import assert from 'assert'
import { FlowServiceContext } from 'iris/iris-flow/context/flow-service-context'
import { FlowProcessModel } from 'iris/iris-flow/model/flow-process-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'
import { XMLHelper, JSItemType } from 'iris/iris-lib/helper/xml-helper'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'

export class FlowModelParser {
  public static async parse(buffer: Buffer) {
    const data = await XMLHelper.getFromBuffer(buffer)
    assert.ok(!!data, `empty xml input`)

    const pm = new FlowProcessModel()
    const attrs = data.process.$

    pm.displayName = attrs[FlowNodeParser.ATTR_DISPLAYNAME] || null
    pm.name = attrs[FlowNodeParser.ATTR_NAME]

    const { $, _, ...children } = data.process

    Object.keys(children).forEach(name => {
      const valueList = children[name] as JSItemType[]
      valueList.forEach(value => {
        const nm = this.parseNode(name, value)
        pm.nodes.push(nm)
      })
    })

    for (const node of pm.nodes) {
      for (const transition of node.outgoingTransitions) {
        const to = transition.to
        for (const nodeTo of pm.nodes) {
          if (to === nodeTo.name) {
            nodeTo.addIncomingTransition(transition)
            transition.target = nodeTo
          }
        }
      }
    }
    return pm
  }

  private static parseNode(name: string, value: JSItemType) {
    try {
      // @todo type declr
      const parser = FlowServiceContext.context.findByName(name, FlowNodeParser) as any
      parser.parse(value)
      return parser.model
    } catch (e) {
      new IrisLogger().logError(e, { mesage: `parse failed`, name, value })
      throw e
    }
  }
}
