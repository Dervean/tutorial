import { FlowTransitionModel } from 'iris/iris-flow/model/flow-transition-model'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { ActionTypeEnum, VarTypeEnum } from 'iris/iris-flow/model/node/action/enum'
import { ActionHttpModel } from 'iris/iris-flow/model/node/action/action-http-model'
import { AbstractActionModel } from 'iris/iris-flow/model/node/action/abstract-action-model'
import { FlowVarNode } from 'iris/iris-flow/model/flow-var-node'
import { ActionThriftDefinitionNode } from 'iris/iris-flow/model/node/action/action-thrift-definition-node'
import { ActionNodeModel } from 'iris/iris-flow/model/node/action/action-node-model'
import { ActionThriftModel } from 'iris/iris-flow/model/node/action/action-thrift-model'
import { ActionThriftServiceNode } from 'iris/iris-flow/model/node/action/action-thrift-serivce-node'
import { JSItemType } from 'iris/iris-lib/helper/xml-helper'
import { MethodEnum } from 'iris/iris-lib/constants/http'

export abstract class FlowNodeParser {
  public static ATTR_START_NAME = 'IRIS_FLOW_START'
  public static ATTR_END_NAME = 'IRIS_FLOW_END'
  public static ATTR_FLOW_CONTEXT = 'IRIS_FLOW_CONTEXT'

  public static ATTR_NAME = 'name'
  public static ATTR_DISPLAYNAME = 'displayName'
  // public static ATTR_INSTANCEURL = 'instanceUrl'
  // public static ATTR_INSTANCENOCLASS = 'instanceNoClass'
  // public static ATTR_EXPR = 'expr'
  public static ATTR_HANDLECLASS = 'handleClass'
  // public static ATTR_FORM = 'form'
  // public static ATTR_FIELD = 'field'
  // public static ATTR_VALUE = 'value'
  // public static ATTR_ATTR = 'attr'
  // public static ATTR_TYPE = 'type'
  public static ATTR_ASSIGNEE = 'assignee'
  // public static ATTR_ASSIGNEE_HANDLER = 'assignmentHandler'
  public static ATTR_PERFORMTYPE = 'performType'
  // public static ATTR_TASKTYPE = 'taskType'
  public static ATTR_TO = 'to'
  // public static ATTR_PROCESSNAME = 'processName'
  // public static ATTR_VERSION = 'version'
  // public static ATTR_EXPIRETIME = 'expireTime'
  public static ATTR_AUTOEXECUTE = 'autoExecute'
  public static ATTR_SHADOW = 'shadow'
  public static ATTR_CALLBACK = 'callback'
  // public static ATTR_REMINDERTIME = 'reminderTime'
  // public static ATTR_REMINDERREPEAT = 'reminderRepeat'
  public static ATTR_CLAZZ = 'clazz'
  public static ATTR_SCOPE = 'scope'
  public static ATTR_METHODNAME = 'methodName'
  public static ATTR_ARGS = 'args'
  public static ATTR_VAR = 'var'
  public static ATTR_TAG = 'tag'
  // public static ATTR_LAYOUT = 'layout'
  // public static ATTR_G = 'g'
  // public static ATTR_OFFSET = 'offset'
  // public static ATTR_PREINTERCEPTORS = 'preInterceptors'
  // public static ATTR_POSTINTERCEPTORS = 'postInterceptors'

  private _model: FlowNodeModel

  protected get model(): FlowNodeModel {
    return this._model
  }

  protected abstract newModel(): FlowNodeModel

  protected abstract parseNode(model: FlowNodeModel, element: JSItemType): void

  public parse(element: JSItemType) {
    this._model = this.newModel()

    const attrs = element.$
    this._model.displayName = attrs[FlowNodeParser.ATTR_DISPLAYNAME] || null
    this._model.name = attrs[FlowNodeParser.ATTR_NAME]

    /** parse transitions */
    const transitions = (element.transition || []) as JSItemType[]
    for (const t of transitions) {
      const transition = new FlowTransitionModel()
      const tAttrs = t.$
      transition.displayName = tAttrs[FlowNodeParser.ATTR_DISPLAYNAME] || null
      transition.name = tAttrs[FlowNodeParser.ATTR_NAME]
      transition.to = tAttrs[FlowNodeParser.ATTR_TO]
      // source
      // expr
      this._model.addOutgoingTransition(transition)
    }
    /** parse action */
    const actions = (element.action || []) as JSItemType[]
    if (actions.length) {
      const action = actions[0]
      const tAttrs = action.$
      const type = tAttrs.type as ActionTypeEnum
      switch (type) {
        case ActionTypeEnum.HTTP:
          throw new Error(`暂不支持 http 节点`)
          this._model.action = this.parseActionHttp(action, 80)
          break
        case ActionTypeEnum.HTTPS:
          throw new Error(`暂不支持 https 节点`)
          this._model.action = this.parseActionHttp(action, 443)
          break
        case ActionTypeEnum.NODE:
          this._model.action = this.parseActionNode(action)
          break
        case ActionTypeEnum.THRIFT:
          this._model.action = this.parseActionThrift(action)
          break
        default:
          throw new Error(`未知行为节点类型: type=${type}, action=${JSON.stringify(action)}`)
      }
    }
    this.parseNode(this._model, element)
  }

  public parseActionHttp(action: JSItemType, port: number) {
    const attrs = action.$
    const vars = (action.var || []) as JSItemType[]
    const node = new ActionHttpModel()
    node.host = attrs.host as string
    node.method = attrs.method as MethodEnum
    node.port = port
    node.path = attrs.path as string
    this.parseVars(node, vars)

    return node
  }

  public parseActionNode(action: JSItemType) {
    const attrs = action.$
    const vars = (action.var || []) as JSItemType[]
    const node = new ActionNodeModel()
    node.clazz = attrs.clazz as string
    node.methodName = (attrs.methodName || 'handle') as string
    this.parseVars(node, vars)
    return node
  }

  public parseActionThrift(action: JSItemType) {
    const attrs = action.$
    const vars = (action.var || []) as JSItemType[]
    const definitionNodes = (action.definition || []) as JSItemType[]
    const serviceNodes = (action.service || []) as JSItemType[]
    const { remoteAppKey, timeout, methodName, serviceName, retry } = attrs
    const node = new ActionThriftModel()
    node.remoteAppKey = remoteAppKey as string
    node.methodName = methodName as string
    node.timeout = +timeout
    node.serviceName = serviceName as string
    node.retry = +retry

    if (definitionNodes.length === 0) {
      throw new Error(`IDL 定义缺失: methodName=${methodName}`)
    }
    const definition = new ActionThriftDefinitionNode()
    const defNode = definitionNodes[0]
    const defNodeLink = (defNode.link || []) as unknown[]
    definition.name = defNode.$.name
    definition.link = defNodeLink[0] as string
    node.definition = definition

    for (let i = 0; i < serviceNodes.length; i++) {
      const serviceNode = serviceNodes[i]
      const thriftService = new ActionThriftServiceNode()
      thriftService.ip = (serviceNode.ip as any)[0]
      thriftService.port = (serviceNode.port as any)[0]
      node.addService(thriftService)
    }

    this.parseVars(node, vars)

    return node
  }

  public parseVars(actionNode: AbstractActionModel, vars: JSItemType[]) {
    for (const v of vars) {
      const varNode = new FlowVarNode()
      const attrs = v.$

      varNode.inOutType = attrs.inOutType as VarTypeEnum
      varNode.contextVarName = attrs.contextVarName || ''
      varNode.desplayName = attrs.desplayName || ''
      varNode.name = attrs.name || ''
      varNode.defaultValue = attrs.defaultValue || ''
      actionNode.addVar(varNode)
    }
  }
}
