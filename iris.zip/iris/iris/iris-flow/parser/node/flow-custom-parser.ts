import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'
import { JSItemType } from 'iris/iris-lib/helper/xml-helper'
import { FlowCustomModel } from 'iris/iris-flow/model/node/flow-custom-model'

@ReflectHelper.collect()
export class FlowCustomParser extends FlowNodeParser {
  protected parseNode(model: FlowNodeModel, element: JSItemType): void {
    const node = model as FlowCustomModel
    const attrs = element.$
    node.clazz = attrs[FlowNodeParser.ATTR_CLAZZ]
    node.scope = attrs[FlowNodeParser.ATTR_SCOPE] || ''
    node.args = attrs[FlowNodeParser.ATTR_ARGS]
    node.methodName = attrs[FlowNodeParser.ATTR_METHODNAME]
    node.var = attrs[FlowNodeParser.ATTR_VAR]
  }

  protected newModel() {
    return new FlowCustomModel()
  }
}
