import { FlowDecisionModel } from 'iris/iris-flow/model/node/flow-decision-model'
import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'
import { JSItemType } from 'iris/iris-lib/helper/xml-helper'

@ReflectHelper.collect()
export class FlowDecisionParser extends FlowNodeParser {
  protected parseNode(model: FlowNodeModel, element: JSItemType): void {
    // const task = model as FlowDecisionModel
    // const attrs = element.$
    // task.expr = attrs[FlowNodeParser.ATTR_EXPR]
    // task.scope = attrs[FlowNodeParser.ATTR_SCOPE] || ''
    // task.handleClass = attrs[FlowNodeParser.ATTR_HANDLECLASS]
  }

  protected newModel() {
    return new FlowDecisionModel()
  }
}
