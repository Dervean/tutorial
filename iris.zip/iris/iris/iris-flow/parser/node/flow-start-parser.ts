import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowStartModel } from 'iris/iris-flow/model/node/flow-start-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'
import { JSItemType } from 'iris/iris-lib/helper/xml-helper'

@ReflectHelper.collect()
export class FlowStartParser extends FlowNodeParser {
  protected parseNode(model: FlowNodeModel, element: JSItemType): void {}

  protected newModel() {
    return new FlowStartModel()
  }
}
