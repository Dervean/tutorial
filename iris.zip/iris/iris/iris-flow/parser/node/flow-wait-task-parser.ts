import { FlowNodeModel } from 'iris/iris-flow/model/node/flow-node-model'
import { FlowNodeParser } from 'iris/iris-flow/parser/flow-node-parser'
import { ReflectHelper } from 'iris/iris-lib/helper/reflect-helper'
import { JSItemType } from 'iris/iris-lib/helper/xml-helper'
import { PerformTypeEnum } from 'iris/iris-flow/enum/flow'
import { FlowWaitTaskModel } from 'iris/iris-flow/model/node/flow-wait-task-model'

@ReflectHelper.collect()
export class FlowWaitTaskParser extends FlowNodeParser {
  protected parseNode(model: FlowNodeModel, element: JSItemType): void {
    const task = model as FlowWaitTaskModel

    const attrs = element.$
    if (attrs[FlowNodeParser.ATTR_PERFORMTYPE]) {
      task.performType = attrs[FlowNodeParser.ATTR_PERFORMTYPE] as PerformTypeEnum
    }
    if (attrs[FlowNodeParser.ATTR_SHADOW]) {
      task.shadow = attrs[FlowNodeParser.ATTR_SHADOW] as 'Y' | 'N'
    }
    if (attrs[FlowNodeParser.ATTR_TAG]) {
      task.tag = attrs[FlowNodeParser.ATTR_TAG]
    }
    task.assignee = attrs[FlowNodeParser.ATTR_ASSIGNEE]
    // taskType
    // assignment handler
  }

  protected newModel() {
    return new FlowWaitTaskModel()
  }
}
