import { ThriftPool } from '@mtfe/thrift'
import { IrisFlowOrder as FlowOrder } from 'iris/iris-base/entities/iris-flow-order'
import { IrisFlowProcess as FlowProcess } from 'iris/iris-base/entities/iris-flow-process'
import { IrisFlowTask as FlowTask } from 'iris/iris-base/entities/iris-flow-task'
import { IrisFlowStateDescEnum, IrisFlowStateEnum } from 'iris/iris-base/enum/flow'
import { ConfigHelper } from 'iris/iris-lib/helper/config-helper'
import { IrisFlowError } from 'iris/iris-lib/model/iris-error'

// @ts-ignore
const IrisFlow = require('../../iris-resource/thrift/iris-flow/target/IrisFlow.js')

enum IrisThriftApiEnum {
  deployProcess = 'deployProcess',
  getProcessById = 'getProcessById',
  getLatestVersionProcess = 'getLatestVersionProcess',
  createOrderByProcessName = 'createOrderByProcessName',
  createOrderByProcessId = 'createOrderByProcessId',
  getOrder = 'getOrder',
  trigger = 'trigger',
  terminateOrder = 'terminateOrder',
  getActiveTasks = 'getActiveTasks',
  getTasks = 'getTasks',
  destroyTask = 'destroyTask',
  terminateTask = 'terminateTask',
}

class IrisFlowThriftResponse<T> {
  code: number
  message: string
  data: T
}

class IrisFlowTask {
  taskId: string
  name: string
  orderId: string
  state: IrisFlowStateEnum
  stateDesc: string
  displayName: string
  performType: string
  parentTaskId: string
  operator: string
  actors: string[]
  logs: any[]
  createTime: Date
  updateTime: Date

  constructor(model: IrisFlowTask) {
    if (model) {
      this.taskId = model.taskId
      this.name = model.name
      this.orderId = model.orderId
      this.state = model.state
      this.stateDesc = model.stateDesc
      this.displayName = model.displayName
      this.performType = model.performType
      this.parentTaskId = model.parentTaskId
      this.operator = model.operator
      this.actors = model.actors
      this.logs = model.logs
      this.createTime = model.createTime
      this.updateTime = model.updateTime
    }
  }
}

class IrisFlowOrder {
  orderId: string
  processId: string
  processName: string
  state: IrisFlowStateEnum
  stateDesc: IrisFlowStateDescEnum
  createdBy: string
  remark: string
  parentId: string
  parentNodeName: string
  createTime: Date
  updatedBy: string
  updateTime: Date
  logs: any[]

  private _variable: string

  public get variable(): Record<string, any> {
    if (typeof this._variable === 'string') {
      return JSON.parse(this._variable)
    }
    return this._variable
  }

  public set variable(value: Record<string, any>) {
    if (typeof value === 'string') {
      this._variable = value
    } else {
      this._variable = JSON.stringify(value)
    }
  }

  constructor(model: IrisFlowOrder) {
    if (model) {
      this.orderId = model.orderId
      this.processId = model.processId
      this.processName = model.processName
      this.variable = model.variable
      this.state = model.state
      this.stateDesc = model.stateDesc
      this.createdBy = model.createdBy
      this.remark = model.remark
      this.parentId = model.parentId
      this.parentNodeName = model.parentNodeName
      this.createTime = model.createTime
      this.updatedBy = model.updatedBy
      this.updateTime = model.updateTime
      this.logs = model.logs
    }
  }
}

class IrisFlowProcess {
  processId: string
  name: string
  displayName: string
  version: string
  createdBy: string
  updatedBy: string
  createTime: Date
  updateTime: Date

  constructor(model: IrisFlowProcess) {
    if (model) {
      this.processId = model.processId
      this.name = model.name
      this.displayName = model.displayName
      this.version = model.version
      this.createdBy = model.createdBy
      this.updatedBy = model.updatedBy
      this.createTime = model.createTime
      this.updateTime = model.updateTime
    }
  }
}

export class IrisFlowExecution {
  operator: string
  tag: string
  task: IrisFlowTask
  order: IrisFlowOrder
  process: IrisFlowProcess
  private _variable: string

  public get variable(): Record<string, any> {
    if (typeof this._variable === 'string') {
      return JSON.parse(this._variable)
    }
    return this._variable
  }

  public set variable(value: Record<string, any>) {
    if (typeof value === 'string') {
      this._variable = value
    } else {
      this._variable = JSON.stringify(value)
    }
  }

  constructor(model: IrisFlowExecution) {
    if (model) {
      this.operator = model.operator
      this.tag = model.tag
      this.variable = model.variable
      this.order = new IrisFlowOrder(model.order)
      this.task = new IrisFlowTask(model.task)
      this.process = new IrisFlowProcess(model.process)
    }
  }
}

export class IrisFlowService {
  private static SERVER_APP_KEY = 'com.sankuai.iris.flow'
  private static SERVICE_NAME = 'com.sankuai.iris.flow.thrift.api'

  private timeout = 5000

  constructor(params?: { timeout?: number }) {
    const { timeout } = params || {}
    this.timeout = this.timeout || timeout
  }

  private get client(): any {
    return new ThriftPool({
      localAppKey: ConfigHelper.getAppKey(),
      remoteAppKey: IrisFlowService.SERVER_APP_KEY,
      serviceName: IrisFlowService.SERVICE_NAME,
      unified: true,
      enableAuth: true,
    })
  }

  /**
   * 部署流程
   * @param model 流程定义 XML
   * @param creator 创建人
   * @returns
   */
  async deployProcess(model: Buffer, creator: string): Promise<FlowProcess> {
    const methodName = IrisThriftApiEnum.deployProcess
    const response: IrisFlowThriftResponse<FlowProcess> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      model,
      creator,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`部署流程定义失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 获取流程
   * @param processId 流程 ID
   * @returns
   */
  async getProcessById(processId: string): Promise<FlowProcess> {
    const methodName = IrisThriftApiEnum.getProcessById
    const response: IrisFlowThriftResponse<FlowProcess> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      processId,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`获取流程定义失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 获取最新版本流程
   * @param processName
   * @returns
   */
  async getLatestVersionProcess(processName: string): Promise<FlowProcess> {
    const methodName = IrisThriftApiEnum.getLatestVersionProcess
    const response: IrisFlowThriftResponse<FlowProcess> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      processName,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`获取最新版本流程定义失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 根据流程名称创建流程实例
   * @param processName 流程名称
   * @param operator 操作人
   * @param variable 流程实例变量
   * @param remark 备注
   * @returns
   */
  async createOrderByProcessName(processName: string, operator: string, variable: string, remark?: string): Promise<FlowOrder> {
    const methodName = IrisThriftApiEnum.createOrderByProcessName
    const response: IrisFlowThriftResponse<FlowOrder> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      processName,
      operator,
      variable,
      remark,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`创建流程实例失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 根据流程 ID 创建流程实例
   * @param processId 流程 ID
   * @param operator 操作人
   * @param variable 流程实例变量
   * @param remark 备注
   * @returns
   */
  async createOrderByProcessId(processId: string, operator: string, variable: string, remark?: string): Promise<FlowOrder> {
    const methodName = IrisThriftApiEnum.createOrderByProcessId
    const response: IrisFlowThriftResponse<FlowOrder> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      processId,
      operator,
      variable,
      remark,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`创建流程实例失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 获取流程实例
   * @param orderId 流程实例 ID
   * @returns
   */
  async getOrder(orderId: string): Promise<FlowOrder> {
    const methodName = IrisThriftApiEnum.getOrder
    const response: IrisFlowThriftResponse<FlowOrder> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      orderId,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`获取流程实例失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 触发任务
   * @param orderId 流程实例 ID
   * @param tag 任务标签
   * @param operator 操作人
   * @param variable 流程变量
   * @returns
   */
  async trigger(orderId: string, tag: string, operator: string, variable: string): Promise<FlowOrder> {
    const methodName = IrisThriftApiEnum.trigger
    const response: IrisFlowThriftResponse<FlowOrder> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      orderId,
      tag,
      operator,
      variable,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`触发流程实例失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 终止流程实例
   * @param orderId 流程实例 ID
   * @returns
   */
  async terminateOrder(orderId: string) {
    const methodName = IrisThriftApiEnum.terminateOrder
    await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      orderId,
    )
    return
  }

  /**
   * 获取活跃中的任务列表
   * @param filter 过滤参数
   * @returns
   */
  async getActiveTasks(filter: Pick<FlowTask, 'orderId'>): Promise<FlowTask[]> {
    const methodName = IrisThriftApiEnum.getActiveTasks
    const response: IrisFlowThriftResponse<FlowTask[]> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      filter,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`获取流程任务失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 获取流程任务列表
   * @param orderId 流程实例 ID
   * @returns
   */
  async getTasks(orderId: string): Promise<FlowTask[]> {
    const methodName = IrisThriftApiEnum.getTasks
    const response: IrisFlowThriftResponse<FlowTask[]> = await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      orderId,
    )
    if (response.code !== 0) {
      throw new IrisFlowError(`获取流程任务失败: message=${response.message}`)
    }
    return response.data
  }

  /**
   * 销毁任务，将任务状态置为已失败
   * @param taskId 任务 ID
   * @param operator 操作人
   * @returns
   */
  async destroyTask(taskId: string, operator: string) {
    const methodName = IrisThriftApiEnum.destroyTask
    await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      taskId,
      operator,
    )
    return
  }

  /**
   * 终止任务，将任务状态置为已取消
   * @param taskId 任务 ID
   * @param operator 操作人
   * @returns
   */
  async terminateTask(taskId: string, operator: string) {
    const methodName = IrisThriftApiEnum.terminateTask
    await this.client.exec(
      IrisFlow,
      {
        methodName,
        timeout: this.timeout,
      },
      taskId,
      operator,
    )
    return
  }
}
