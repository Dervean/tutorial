export const enum MethodEnum {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
  PATCH = 'PATCH',
}

export const enum HeaderEnum {
  ACESS_CONTROL_ALLOW_CREDENTIALS = 'Access-Control-Allow-Credentials',
  ACESS_CONTROL_ALLOW_ORIGIN = 'Access-Control-Allow-Origin',
  ACESS_CONTROL_ALLOW_HEADERS = 'Access-Control-Allow-Headers',
  ACESS_CONTROL_ALLOW_METHODS = 'Access-Control-Allow-Methods',
  AUTHORIZATION = 'Authorization',
  CONTENT_TYPE = 'Content-Type',
  CONTENT_LENGTH = 'Content-Length',
  CONTENT_MD5 = 'Content-MD5',
  CACHE_CONTROL = 'Cache-Control',
  DATE = 'Date',
  X_DATE = 'X-Date',
  PRESIGNED_EXPIRES = 'presigned-expires',
  HOST = 'Host',
  USER_AGENT = 'User-Agent',
  /** cookie */
  Set_Cookie = 'Set-Cookie',

  /** org */
  ORG_DATA_SCOPE = 'data-scope',

  /** webstatic */
  WEBSTATIC_ENV = 'X-WebStatic-Env',
  WEBSTATIC_OPERATOR = 'X-WebStatic-Operator',
}

export const enum ProtocalEnum {
  HTTPS = 443,
  HTTP = 80,
}
