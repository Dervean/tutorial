export const enum IrisResponseStatusEnum {
  /** 保留 0 */
  Normal = 0,

  /** ************************ */
  /** 入参异常 */
  BadRequestInvalidFormatParam = 6000, // 参数格式错误
  BadRequestMissingParam = 6001, // 参数缺失

  /** ************************ */
  /** 拒绝处理 - 权限 */
  ForbiddenNoProjectPermission = 7000, // 项目权限校验失败
  ForbiddenNoPagePermission = 7005, // 页面权限校验失败
  /** 拒绝处理 - 重复 */
  ForbiddenDraftAlreadyExisted = 7101, // 草稿已存在
  ForbiddenContainerAlreadyExisted = 7102, // 页面容器已存在
  ForbiddenContainerVersionAlreadyExisted = 7103, // 页面容器版本重复
  ForbiddenSceneAlreadyExisted = 7104, // 场景重复
  ForbiddenPageAlreadyExisted = 7105, // 页面（路径）已存在
  /** 拒绝处理 - 业务异常 - 通用 */
  ForbiddenBizException = 7999, // 通用业务逻辑异常

  /** ************************ */
  /** 资源不存在 */
  NotFoundUserNotFound = 8000, // 用户不存在
  NotFoundProjectNotFound = 8001, // 项目不存在 或 已删除
  NotFoundMemberNotFound = 8002, // 项目成员不存在 或 已删除
  NotFoundPageNotFound = 8004, // 页面不存在 或 已删除
  NotFoundDraftNotFound = 8006, // 草稿不存在
  NotFoundSceneNotFound = 8007, // 场景不存在 或 已删除
  NotFoundWebStaticCanaryStrategyDeleted = 8008, // 灰度策略已删除
  NotFoundContainerNotFound = 8009, // 容器不存在 或 已删除
  NotFoundContainerVersionNotFound = 8010, // 容器版本不存在 或 已删除

  /** ************************ */
  /** 服务异常 */
  ServerErrorUnkownError = 50000, // 未知错误
  ServerErrorSSOUnauthorized = 50001, // SSO 认证异常
  ServerErrorZebraError = 50002, // 数据修改失败
  ServerErrorS3Error = 50003, // S3 操作失败
  ServerErrorORGError = 50004, // ORG 操作失败
  ServerErrorKMSError = 50005, // KMS 查询失败
  ServerErrorLionError = 50006, // Lion 查询失败
  ServerErrorHttpRequestError = 50007, // http 请求失败
  ServerErrorBAUnauthorized = 50008, // BA 认证异常
  ServerErrorUnauthorized = 50009, // 认证异常(SSO/BA/...)
  ServerErrorIrisFlowError = 50010, // Iris Flow 请求错误
  ServerErrorFedoError = 50011, // FEDO 请求错误
  ServerErrorThriftError = 50012, // thrift 执行错误

  /** ************************ */
  /** runtime error */
  RuntimeErrorClassNotFoundError = 90001, // 类不存在
  RuntimeErrorReflectError = 90002, // 反射错误
}
