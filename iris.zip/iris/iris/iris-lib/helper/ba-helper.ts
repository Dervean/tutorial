import { RequestOptions } from 'https'
import { CryptoHelper } from 'iris/iris-lib/helper/crypto-helper'
import { DateHelper } from 'iris/iris-lib/helper/date-helper'
import * as HTTP from 'iris/iris-lib/constants/http'
import { Context } from 'iris/iris-app/interface/context'

interface BaAuth {
  clientId: string
  clientSecret: string
}

export class BAHelper {
  public static getAuthModel(ctx: Context) {
    const model: RequestOptions & { api?: string } = {
      api: ctx.request.url,
      method: ctx.request.method,
      headers: {
        [HTTP.HeaderEnum.AUTHORIZATION]: ctx.headers['authorization'],
        [HTTP.HeaderEnum.DATE]: ctx.headers['date'],
      },
    }
    return model
  }

  public static verify(model: RequestOptions, authList: BaAuth[]) {
    if (!authList || !authList.length || !model || !model.headers) {
      return null
    }
    const date = model.headers[HTTP.HeaderEnum.DATE]
    const authorization = model.headers[HTTP.HeaderEnum.AUTHORIZATION]
    if (!authorization) {
      return null
    }
    for (let i = 0; i < authList.length; i++) {
      const auth = authList[i]
      const { Authorization } = this.create(model, auth, date as string)
      if (Authorization === authorization) {
        return auth.clientId
      }
    }
    return null
  }

  public static create(model: RequestOptions & { api?: string }, auth: BaAuth, dateParam: string | number | Date = null) {
    const { api, method } = model
    const { clientId, clientSecret } = auth
    let dateInput = null
    let date = DateHelper.getDate()
    try {
      dateInput = dateParam && DateHelper.getDate(dateParam)
    } catch (err) {}
    if (dateInput && this.check(date, dateInput)) {
      date = dateInput
    }
    const datestr = DateHelper.rfc822(date)
    const str2sign = `${method} ${api}\n${datestr}`
    const signature = CryptoHelper.hmac(clientSecret, str2sign, 'base64', 'sha1')
    return {
      [HTTP.HeaderEnum.DATE]: datestr,
      [HTTP.HeaderEnum.AUTHORIZATION]: `MWS ${clientId}:${signature}`,
    }
  }

  private static check(d1: Date, d2: Date, error = 20 * 1000) {
    const m1 = d1.getMilliseconds()
    const m2 = d2.getMilliseconds()
    return Math.abs(m1 - m2) <= error
  }
}
