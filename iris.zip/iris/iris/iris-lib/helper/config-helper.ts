import assert from 'assert'

type IrisRuntimeEnvType = 'test' | 'prod' | 'dev'

export class ConfigHelper {
  private static APP_KEY: string = null
  private static RUNTIME_ENV: IrisRuntimeEnvType = null

  public static setAppKey(appKey: string) {
    ConfigHelper.APP_KEY = appKey
  }

  public static getAppKey() {
    return ConfigHelper.APP_KEY
  }

  public static setRuntimeEnv(env: IrisRuntimeEnvType) {
    assert.ok(['test', 'prod', 'dev'].includes(env), `IrisRuntimeEnv 取值必须是 prod, test 或者 dev`)
    ConfigHelper.RUNTIME_ENV = env
  }

  public static getRuntimeEnv() {
    return ConfigHelper.RUNTIME_ENV
  }
}
