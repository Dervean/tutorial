import http from 'http'
import https from 'https'
import { IrisHttpRequestError, IrisInvalidFormatParamError } from 'iris/iris-lib/model/iris-error'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'

export class FileHelper {
  public static fetch(url: string): Promise<string> {
    const _url = new URL(url)
    const protocol = _url.protocol.replace(/\W/, '')

    switch (protocol) {
      case 'http':
        return this.fetchHttp(url)
      case 'https':
        return this.fetchHttps(url)
      default:
        throw new IrisInvalidFormatParamError(`链接格式不正确: url=${url}`)
    }
  }

  private static fetchHttps(url: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const req = https.get(url, res => {
        const buffer: Buffer[] = []
        res.setEncoding('utf-8')
        res.on('data', chunk => buffer.push(Buffer.from(chunk)))
        res.on('end', () => {
          const data = Buffer.concat(buffer).toString()
          resolve(data)
        })
      })
      req.on('error', e => {
        new IrisLogger().logError(e)
        throw new IrisHttpRequestError(e.message)
      })
      req.end()
    })
  }

  private static fetchHttp(url: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const req = http.get(url, res => {
        const buffer: Buffer[] = []
        res.setEncoding('utf-8')
        res.on('data', chunk => buffer.push(Buffer.from(chunk)))
        res.on('end', () => {
          const data = Buffer.concat(buffer).toString()
          resolve(data)
        })
      })
      req.on('error', e => {
        new IrisLogger().logError(e)
        throw new IrisHttpRequestError(e.message)
      })
      req.end()
    })
  }
}
