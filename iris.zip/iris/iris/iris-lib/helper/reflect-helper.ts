import 'reflect-metadata'

import { IrisLogger } from 'iris/iris-lib/model/iris-logger'
import { IrisReflectError, IrisClassNotFoundError } from 'iris/iris-lib/model/iris-error'

export class ReflectHelper {
  public static classMap: Map<string, new (...args: any[]) => any> = new Map()

  public static collect(scope?: string) {
    return function (clz: new (...args: any[]) => any) {
      const name = scope ? `${scope}.${clz.name}` : clz.name
      if (ReflectHelper.classMap.get(name)) {
        new IrisLogger().logWarning(`duplicated class anotation: name=${name}`)
      }
      ReflectHelper.classMap.set(name, clz)
    }
  }

  public static newInstance(clzName: string) {
    try {
      const clz = ReflectHelper.classMap.get(clzName)
      if (!clz) {
        throw new IrisClassNotFoundError(`实例化目标类不存在: clz=${clz}, classMap=${ReflectHelper.classMap}`)
      }
      return new clz()
    } catch (e) {
      new IrisLogger().logError(e, { message: '实例化失败', clzName })
      throw new IrisReflectError()
    }
  }

  public static invoke(instance: Object, fnName: string, args: any[]) {
    try {
      const fn = Reflect.get(instance, fnName)
      return fn(...args)
    } catch (e) {
      new IrisLogger().logError(e, { message: '方法调用失败', instance: instance.constructor, fnName, args })
      throw new IrisReflectError()
    }
  }
}
