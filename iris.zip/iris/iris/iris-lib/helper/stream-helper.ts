import fs from 'fs'
import path from 'path'

export class StreamHelper {
  public static absFilePath(...paths: string[]) {
    const root = path.resolve(__dirname, '..', '..')
    return path.posix.join(root, ...paths)
  }

  public static getStreamFromAbsFilePath(filepath: string) {
    return fs.readFileSync(filepath)
  }

  /**
   * 获取目录下所有文件列表
   * @param dir 绝对路径
   */
  public static walk(dir: string) {
    const listRet: string[] = []
    function traverse(dir: string) {
      const arr = fs.readdirSync(dir)
      arr.forEach(item => {
        const fullpath = path.join(dir, item)
        const stats = fs.statSync(fullpath)
        if (stats.isDirectory()) {
          traverse(fullpath)
        } else {
          listRet.push(fullpath)
        }
      })
    }
    const stats = fs.statSync(dir)
    if (stats.isDirectory()) {
      traverse(dir)
    } else {
      // 不是目录文件
      listRet.push(dir)
    }
    return listRet
  }
}
