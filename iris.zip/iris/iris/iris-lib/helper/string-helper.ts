import { v4 as uuid } from 'uuid'
import { IrisInvalidFormatParamError } from 'iris/iris-lib/model/iris-error'

type JoinMode = 'kehab' | 'snake'
export class StringHelper {
  public static REGEX_HREF_Param = /{{([\w]+)}}/g

  public static isString(t: any) {
    return typeof t === 'string'
  }

  public static generatePrimaryKeyUUID() {
    return uuid().replace(/-/g, '')
  }

  public static generateVersion() {
    return uuid().replace(/-/g, '')
  }

  public static generateUUID() {
    return uuid()
  }

  public static parseHref(href: string, params: Map<string, any>) {
    while (true) {
      const res = this.REGEX_HREF_Param.exec(href)
      if (res === null) {
        break
      }
      const param = res[1]
      const value = params.get(param)
      href = href.replace(res[0], value)
    }
    return href
  }

  public static transformFromCamelCase(str: string, target: JoinMode) {
    const joinletter = StringHelper.joinLetter(target)
    return str
      .split('')
      .map((letter, idx) => (letter.toUpperCase() === letter ? `${idx !== 0 ? joinletter : ''}${letter.toLowerCase()}` : letter))
      .join('')
  }

  public static transformToCamelCase(str: string, source: JoinMode) {
    const joinletter = StringHelper.joinLetter(source)
    return str
      .split(joinletter)
      .map((word, idx) => (idx ? StringHelper.captitalize(word) : word))
      .join('')
  }

  private static joinLetter(mode: JoinMode) {
    let joinletter: string
    switch (mode) {
      case 'kehab':
        joinletter = '-'
        break
      case 'snake':
        joinletter = '_'
        break
      default:
        throw new IrisInvalidFormatParamError(`undefine String Join Mode`)
    }
    return joinletter
  }

  private static captitalize(str: string) {
    return `${str.charAt(0).toUpperCase()}${str.slice(1)}`
  }
}
