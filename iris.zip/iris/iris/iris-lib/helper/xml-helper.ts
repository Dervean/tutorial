import * as xml2js from 'xml2js'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'

/**
 * @todo
 */
export type JSItemType = {
  [key: string]: JSItemType[] | Record<string, string> | string
  $?: Record<string, string>
  _?: string
}

export type JSType = {
  [key: string]: JSItemType
}

export class XMLHelper {
  public static async getFromBuffer(buffer: Buffer): Promise<JSType> {
    try {
      const parser = new xml2js.Parser()
      const ret = await parser.parseStringPromise(buffer)
      return ret
    } catch (e) {
      new IrisLogger().logError(e, { message: `xml build failed, please check xml format` })
      throw e
    }
  }
}
