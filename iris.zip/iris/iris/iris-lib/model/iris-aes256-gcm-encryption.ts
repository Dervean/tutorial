import * as crypto from 'crypto'
import { KMSConfigKeyEnum, KMSSecretManageService } from 'iris/iris-out/kms/kms-secret-manage-service'
import { IrisKMSError } from 'iris/iris-lib/model/iris-error'

export class IrisAes256GcmEncryption {
  private static async seed() {
    const [strIV, strKey] = await Promise.all([
      KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.EncryptionIrisAesIv),
      KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.EncryptionIrisAesKey),
    ])
    if (!strIV) {
      throw new IrisKMSError('encryption seed(iv) not ready')
    }
    if (!strKey) {
      throw new IrisKMSError('encryption seed(key) not ready')
    }
    return {
      strIV,
      strKey,
    }
  }

  static async encrypt(plaintext: string) {
    const { strIV, strKey } = await this.seed()

    const key = Buffer.from(strKey)
    const iv = Buffer.from(strIV)
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv)
    const enc1 = cipher.update(plaintext, 'utf8')
    const enc2 = cipher.final()
    // prettier-ignore
    const encrypted = Buffer
      .concat([enc1, enc2, iv, cipher.getAuthTag()])
      .toString('base64')
      .replace(/\//g, '-')
    return encrypted
  }

  static async decrypt(ciphertext: string) {
    const { strIV, strKey } = await this.seed()

    const key = strKey
    const buffer = Buffer.from(ciphertext.replace(/\-/g, '/'), 'base64')
    const enc = buffer.slice(0, buffer.length - 28)
    const iv = buffer.slice(buffer.length - 28, buffer.length - 16)
    const tag = buffer.slice(buffer.length - 16)

    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv)
    decipher.setAuthTag(tag)
    const s1 = decipher.update(enc, null, 'utf8')
    const s2 = decipher.final('utf8')
    return [s1, s2].join('')
  }
}
