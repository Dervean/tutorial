import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'

export abstract class AbstractIrisError extends Error {
  public code: IrisResponseStatusEnum
  constructor(msg?: string) {
    super(msg)
    Object.setPrototypeOf(this, AbstractIrisError.prototype)
  }
}
