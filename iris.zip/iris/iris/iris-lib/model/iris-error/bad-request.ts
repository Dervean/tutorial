import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'

export class IrisInvalidFormatParamError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.BadRequestInvalidFormatParam
    Object.setPrototypeOf(this, IrisInvalidFormatParamError.prototype)
  }
}

export class IrisMissingParamError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.BadRequestMissingParam
    Object.setPrototypeOf(this, IrisMissingParamError.prototype)
  }
}
