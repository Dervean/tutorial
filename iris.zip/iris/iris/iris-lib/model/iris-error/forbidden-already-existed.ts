import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'

export class IrisDraftAlreadyExistedError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenDraftAlreadyExisted
    Object.setPrototypeOf(this, IrisDraftAlreadyExistedError.prototype)
  }
}

export class IrisPageAlreadyExistedError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenPageAlreadyExisted
    Object.setPrototypeOf(this, IrisPageAlreadyExistedError.prototype)
  }
}

export class IrisContainerAlreadyExistedError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenContainerAlreadyExisted
    Object.setPrototypeOf(this, IrisContainerAlreadyExistedError.prototype)
  }
}

export class IrisSceneAlreadyExisted extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenSceneAlreadyExisted
    Object.setPrototypeOf(this, IrisSceneAlreadyExisted.prototype)
  }
}

export class IrisContainerVersionAlreadyExisted extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenContainerVersionAlreadyExisted
    Object.setPrototypeOf(this, IrisContainerVersionAlreadyExisted.prototype)
  }
}
