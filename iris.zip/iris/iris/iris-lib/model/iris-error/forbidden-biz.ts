import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'

export class IrisBizException extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenBizException
    Object.setPrototypeOf(this, IrisBizException.prototype)
  }
}
