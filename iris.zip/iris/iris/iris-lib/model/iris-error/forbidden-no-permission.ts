import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'

export class IrisNoPagePermissionError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenNoPagePermission
    Object.setPrototypeOf(this, IrisNoPagePermissionError.prototype)
  }
}

export class IrisNoProjectPermissionError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ForbiddenNoProjectPermission
    Object.setPrototypeOf(this, IrisNoProjectPermissionError.prototype)
  }
}
