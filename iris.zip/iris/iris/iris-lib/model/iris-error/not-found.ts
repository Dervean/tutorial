import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'

export class IrisDraftNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundDraftNotFound
    Object.setPrototypeOf(this, IrisDraftNotFoundError.prototype)
  }
}

export class IrisMemberNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundMemberNotFound
    Object.setPrototypeOf(this, IrisMemberNotFoundError.prototype)
  }
}

export class IrisPageNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundPageNotFound
    Object.setPrototypeOf(this, IrisPageNotFoundError.prototype)
  }
}

export class IrisProjectNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundProjectNotFound
    Object.setPrototypeOf(this, IrisProjectNotFoundError.prototype)
  }
}

export class IrisSceneNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundSceneNotFound
    Object.setPrototypeOf(this, IrisSceneNotFoundError.prototype)
  }
}

export class IrisContainerNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundContainerNotFound
    Object.setPrototypeOf(this, IrisContainerNotFoundError.prototype)
  }
}

export class IrisContainerVersionNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundContainerVersionNotFound
    Object.setPrototypeOf(this, IrisContainerVersionNotFoundError.prototype)
  }
}

export class IrisUserNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundUserNotFound
    Object.setPrototypeOf(this, IrisUserNotFoundError.prototype)
  }
}

export class IrisWebStaticCanaryStrategyDeletedError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.NotFoundWebStaticCanaryStrategyDeleted
    Object.setPrototypeOf(this, IrisWebStaticCanaryStrategyDeletedError.prototype)
  }
}
