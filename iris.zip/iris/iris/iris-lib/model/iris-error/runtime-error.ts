import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'

export class IrisClassNotFoundError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.RuntimeErrorClassNotFoundError
    Object.setPrototypeOf(this, IrisClassNotFoundError.prototype)
  }
}

export class IrisReflectError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.RuntimeErrorReflectError
    Object.setPrototypeOf(this, IrisReflectError.prototype)
  }
}
