import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'

export class IrisBAUnauthorizedError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorBAUnauthorized
    Object.setPrototypeOf(this, IrisBAUnauthorizedError.prototype)
  }
}

export class IrisHttpRequestError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorHttpRequestError
    Object.setPrototypeOf(this, IrisHttpRequestError.prototype)
  }
}

export class IrisKMSError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorKMSError
    Object.setPrototypeOf(this, IrisKMSError.prototype)
  }
}

export class IrisLionError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorLionError
    Object.setPrototypeOf(this, IrisLionError.prototype)
  }
}

export class IrisORGError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorORGError
    Object.setPrototypeOf(this, IrisORGError.prototype)
  }
}

export class IrisS3Error extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorS3Error
    Object.setPrototypeOf(this, IrisS3Error.prototype)
  }
}

export class IrisSSOUnauthorizedError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorSSOUnauthorized
    Object.setPrototypeOf(this, IrisSSOUnauthorizedError.prototype)
  }
}

export class IrisUnauthorizedError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorUnauthorized
    Object.setPrototypeOf(this, IrisUnauthorizedError.prototype)
  }
}

export class IrisZebraError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorZebraError
    Object.setPrototypeOf(this, IrisZebraError.prototype)
  }
}

export class IrisFedoError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorFedoError
    Object.setPrototypeOf(this, IrisFedoError.prototype)
  }
}

export class IrisFlowError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorIrisFlowError
    Object.setPrototypeOf(this, IrisFlowError.prototype)
  }
}

export class IrisThriftError extends AbstractIrisError {
  constructor(msg?: string) {
    super(msg)
    this.code = IrisResponseStatusEnum.ServerErrorThriftError
    Object.setPrototypeOf(this, IrisThriftError.prototype)
  }
}
