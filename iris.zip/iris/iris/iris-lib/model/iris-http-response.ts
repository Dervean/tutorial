import { AbstractIrisError } from 'iris/iris-lib/model/iris-error'
import { IrisResponseStatusEnum } from 'iris/iris-lib/constants/response'
import * as HTTP from 'iris/iris-lib/constants/http'
import { Context } from 'iris/iris-app/interface/context'

export class IrisHttpResponse {
  public static NormalMsg = 'success'
  private status: number
  private message: string
  private data: Record<string, any> | boolean | number | string
  private headers: Map<HTTP.HeaderEnum, any>

  constructor()
  constructor(data: Record<string, any> | boolean | number | string)
  constructor(error: Error)
  constructor(param?: Record<string, any> | boolean | number | string | Error) {
    if (param instanceof Error) {
      this.status = IrisResponseStatusEnum.ServerErrorUnkownError
      if (param instanceof AbstractIrisError) {
        this.status = param.code
      }
      this.message = param.message || null
      this.data = null
    } else {
      this.status = IrisResponseStatusEnum.Normal
      this.message = IrisHttpResponse.NormalMsg
      this.data = param || null
    }
    const DefaultHeaders = new Map<HTTP.HeaderEnum, any>()
    DefaultHeaders.set(HTTP.HeaderEnum.ACESS_CONTROL_ALLOW_HEADERS, 'Content-Type')
    DefaultHeaders.set(HTTP.HeaderEnum.CONTENT_TYPE, 'application/json;charset=utf-8')
    this.headers = DefaultHeaders
  }

  public setMessage(message: string): void {
    this.message = message
  }

  public setData(data: Record<string, any>): void {
    this.data = data
  }

  public setHeader(header: HTTP.HeaderEnum, value: any) {
    this.headers.set(header, value)
  }

  private buildHeaders(ctx: Context) {
    for (const [key, val] of this.headers.entries()) {
      ctx.set(key, val)
    }
  }

  private buildBody(ctx: Context) {
    ctx.body = {
      status: this.status,
      message: this.message,
      data: JSON.parse(JSON.stringify(this.data)),
    }
  }

  public build(ctx: Context) {
    this.buildHeaders(ctx)
    this.buildBody(ctx)
    return ctx
  }
}
