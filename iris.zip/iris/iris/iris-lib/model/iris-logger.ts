import chalk from 'chalk'
import { IrisUserInfo } from 'iris/iris-app'

interface ILogger {
  info(message: any, ...args: any[]): void
  warn(message: any, ...args: any[]): void
  error(message: any, ...args: any[]): void
  debug(message: any, ...args: any[]): void
}

class ConsoleLogger implements ILogger {
  info(message: any, ...args: any[]): void {
    console.log(message)
  }
  warn(message: any, ...args: any[]): void {
    console.warn(message)
  }
  error(message: any, ...args: any[]): void {
    console.error(message)
  }
  debug(message: any, ...args: any[]): void {
    console.debug(message)
  }
}

export class IrisLogger {
  private _logger: ILogger = null
  private _name = 'iris'
  private _user: IrisUserInfo = null

  private get logger(): ILogger {
    if (this._logger) {
      return this._logger
    }
    return new ConsoleLogger()
  }

  public setLogger(logger: ILogger) {
    if (logger) {
      this._logger = logger
    }
  }

  public setName(name: string) {
    if (name) {
      this._name = name
    }
  }

  public setUser(userInfo: IrisUserInfo) {
    if (userInfo) {
      this._user = userInfo
    }
  }

  public logInfo(message: string, data?: Record<string, any> | null): void {
    const msg = this.buildMessage(message, data)
    return this.logger.info(`${chalk.green('[INFO]')}${msg}`)
  }

  public logWarning(message: string, data?: Record<string, any> | null): void {
    const msg = this.buildMessage(message, data)
    return this.logger.warn(`${chalk.yellow('[WARN]')}${msg}`)
  }

  public logError(payload: string | Error | unknown, data?: Record<string, any> | null): void {
    let msg: string
    if (payload instanceof Error) {
      msg = `${this.buildMessage(payload.message, data)}\n${payload.stack}`
    } else if (typeof payload === 'string') {
      msg = this.buildMessage(payload, data)
    } else {
      msg = JSON.stringify(payload)
    }
    return this.logger.error(`${chalk.red('[ERROR]')}${msg}`)
  }

  public logDebug(message: string, data?: Record<string, any> | null): void {
    const msg = this.buildMessage(message, data)
    return this.logger.debug(`${chalk.green('[DEBUG]')}${msg}`)
  }

  private buildMessage(message: string, data: Record<string, any> | null = null) {
    const keys = Object.keys(data || {})
    const opt = keys.map(k => `${k}=${JSON.stringify(data?.[k])}`)
    const optstr = data && typeof data === 'object' && Object.keys(data).length > 0 ? `${opt.join(', ')}` : ''
    const userName = this._user?.userName
    const ret = []
    ret.push(`[${this._name}]`)
    userName && ret.push(`[${userName}]`)
    ret.push(` `)
    ret.push(optstr ? `${message}: ${optstr}` : `${message}`)
    return ret.join('')
  }
}
