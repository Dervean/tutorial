export class IrisPageParams {
  private _pageNum: number = 1
  private _pageSize: number = 20

  public get pageNum(): number {
    return this._pageNum
  }

  public set pageNum(value: number) {
    if (Number.isInteger(value)) {
      this._pageNum = value
    }
  }

  public get pageSize(): number {
    return this._pageSize
  }

  public set pageSize(value: number) {
    if (Number.isInteger(value)) {
      this._pageSize = value
    }
  }
}
