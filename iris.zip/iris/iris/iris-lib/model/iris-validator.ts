import assert from 'assert'
import { RoleTypeEnum } from 'iris/iris-biz/model/permission-builder'
import { DateHelper } from 'iris/iris-lib/helper/date-helper'
import { EnumHelper } from 'iris/iris-lib/helper/enum-helper'
import { JsonHelper } from 'iris/iris-lib/helper/json-helper'
import { IrisInvalidFormatParamError, IrisMissingParamError } from 'iris/iris-lib/model/iris-error'

export class IrisValidator {
  /**
   * ------------------------------------------------------------------------------------
   * Primetive Checker
   * ------------------------------------------------------------------------------------
   */
  /**
   * 布尔值校验 并返回 input 对应的 布尔值
   *
   * return true
   *  - number(1)
   *  - boolean(true)
   *  - string('true')
   *
   * return false
   *  - number(0)
   *  - boolean(false)
   *  - string('false')
   *
   * return undefined
   *  - undefined
   * @param flag
   * @returns
   */
  static validateBoolean(flag: boolean | number | string | undefined) {
    const BOOLEAN_FLAGS: unknown[] = [1, 0, true, false, 'true', 'false', undefined]
    try {
      assert(BOOLEAN_FLAGS.includes(flag), `参数格式错误: ${flag}`)
      if (flag === undefined) {
        return undefined
      }
      return Boolean(JSON.parse(flag as any))
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateString(param: string) {
    try {
      assert.ok(typeof param === 'string', `参数格式错误`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateJson(param: JSON) {
    try {
      assert.ok(JsonHelper.isJson(param), `参数格式错误: ${param}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateDate(param: Date) {
    try {
      return DateHelper.getDate(param)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateEnum<T>(value: T, targetEnum: { [key: string]: T }) {
    try {
      assert.ok(EnumHelper.isEnumMember(value, targetEnum), `参数错误: ${value}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * Iris Type Checker
   * ------------------------------------------------------------------------------------
   */
  static validateIrisId(id: string) {
    try {
      if (typeof id === 'string') {
        assert.ok(!!id.length, `参数错误: id=${id}`)
      }
      assert.ok(Number.isInteger(+id), `参数错误: id=${id}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateIrisIdList(idList: string[]) {
    try {
      assert.ok(Array.isArray(idList), `参数错误`)
      for (const id of idList) {
        this.validateIrisId(id)
      }
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateIrisUuid(id: string) {
    try {
      assert.ok(id !== undefined, `参数缺失`)
    } catch (error) {
      throw new IrisMissingParamError((error as Error).message)
    }
    try {
      assert.ok(typeof id === 'string', `参数格式错误`)
      assert.ok(id.length === 32, `参数格式错误`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  /**
   * ------------------------------------------------------------------------------------
   * User Checker
   * ------------------------------------------------------------------------------------
   */
  static validateUserId(userId: string) {
    try {
      assert.ok(/^\d+$/.test(`${userId}`), `参数格式错误: userId=${userId}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateUserIdList(userIdList: string[]) {
    try {
      assert.ok(Array.isArray(userIdList), `参数错误: ${userIdList}`)
      for (const userId of userIdList) {
        this.validateUserId(userId)
      }
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  static validateRoleType(role: RoleTypeEnum) {
    try {
      assert.ok(EnumHelper.isEnumMember(role, RoleTypeEnum), `参数错误: ${role}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }
}
