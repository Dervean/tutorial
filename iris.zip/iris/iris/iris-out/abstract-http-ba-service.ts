import { RequestOptions } from 'https'
import * as HTTP from 'iris/iris-lib/constants/http'
import { KMSSecretManageService, KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'
import { AbstractHttpService } from 'iris/iris-out/abstract-http-service'
import { BAHelper } from 'iris/iris-lib/helper/ba-helper'

export abstract class AbstractHttpBAService extends AbstractHttpService {
  protected ACCESS_KEY: KMSConfigKeyEnum
  protected SECRET_KEY: KMSConfigKeyEnum
  protected HOSTNAME: LionConfigKeyEnum
  protected HOSTPORT: LionConfigKeyEnum

  protected async auth(model: RequestOptions) {
    const [clientId, clientSecret, hostname, port] = await Promise.all([
      KMSSecretManageService.fetchConfigValue(this.ACCESS_KEY),
      KMSSecretManageService.fetchConfigValue(this.SECRET_KEY),
      LionClientService.fetchConfigValue(this.HOSTNAME),
      LionClientService.fetchConfigValue(this.HOSTPORT).then(port => +port),
    ])
    const { Authorization, Date } = BAHelper.create(model, { clientId, clientSecret })
    model.hostname = hostname as string
    model.port = port
    model.headers[HTTP.HeaderEnum.DATE] = Date
    model.headers[HTTP.HeaderEnum.AUTHORIZATION] = Authorization
    return model
  }
}
