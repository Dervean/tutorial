import { request as requestHttp } from 'http'
import { request as requestHttps, RequestOptions } from 'https'
import { IrisLogger } from 'iris/iris-lib'
import * as HTTP from 'iris/iris-lib/constants/http'
import { IrisHttpRequestError } from 'iris/iris-lib/model/iris-error'

export abstract class AbstractHttpService {
  protected logger = new IrisLogger()

  protected async request<T>(options: RequestOptions, payload?: string | ArrayBuffer): Promise<T> {
    const isHttps = options.port == HTTP.ProtocalEnum.HTTPS
    const request = isHttps ? requestHttps : requestHttp
    switch (options.method) {
      case HTTP.MethodEnum.GET:
      case HTTP.MethodEnum.DELETE:
        return this.get(request, options)
      case HTTP.MethodEnum.POST:
      case HTTP.MethodEnum.PUT:
      case HTTP.MethodEnum.PATCH:
        return this.post(request, options, payload)
      default:
        this.logger.logError('error in http request options', { options, payload })
        throw new IrisHttpRequestError('HTTP 请求参数错误')
    }
  }

  private get<T>(request: typeof requestHttp, options: RequestOptions): Promise<T> {
    return new Promise((resolve, reject) => {
      const req = request(options, res => {
        res.setEncoding('utf-8')
        const buffer: any[] = []
        res.on('data', chunk => buffer.push(Buffer.from(chunk)))
        res.on('end', () => {
          const data = Buffer.concat(buffer).toString()
          try {
            const parsedData = JSON.parse(data)
            if (res.statusCode !== 200) {
              reject(parsedData)
            } else {
              resolve(parsedData)
            }
          } catch (e) {
            this.logger.logError(e, { message: `some error occurred during data transforming`, data })
            reject(data)
          }
        })
      })
      req.on('error', e => {
        this.logger.logError(e)
      })
      req.end()
    })
  }

  private post<T>(request: typeof requestHttp, options: RequestOptions, payload: string | ArrayBuffer): Promise<T> {
    return new Promise((resolve, reject) => {
      const opt = {
        ...options,
        headers: {
          [HTTP.HeaderEnum.CONTENT_LENGTH]: Buffer.byteLength(payload),
          ...(options.headers || {}),
        },
      }
      const req = request(opt, res => {
        res.setEncoding('utf-8')
        const buffer: any[] = []
        res.on('data', chunk => buffer.push(Buffer.from(chunk)))
        res.on('end', () => {
          const data = Buffer.concat(buffer).toString()
          try {
            const parsedData = JSON.parse(data)
            if (res.statusCode !== 200) {
              reject(parsedData)
            } else {
              resolve(parsedData)
            }
          } catch (e) {
            this.logger.logError(e, { message: `some error occurred during data transforming`, data })
            reject(data)
          }
        })
      })
      req.on('error', e => {
        this.logger.logError(e)
        throw e
      })
      req.write(payload)
      req.end()
    })
  }
}
