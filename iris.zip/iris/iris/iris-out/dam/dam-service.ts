import { RequestOptions } from 'https'
import * as HTTP from 'iris/iris-lib/constants/http'
import { IrisHttpRequestError } from 'iris/iris-lib/model/iris-error'
import { AbstractHttpBAService } from 'iris/iris-out/abstract-http-ba-service'
import { KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'

interface DamSubAppModel {
  id?: number
  applicationName?: string
  client?: string
  owner?: string
  tag?: string
  source?: string
  systemPlatform?: string
  projectId?: string
  raptorKey?: string
}

interface DamHttpResponse<T> {
  code?: number
  data: T
  message: string
}

export class DamService extends AbstractHttpBAService {
  constructor() {
    super()
    this.ACCESS_KEY = KMSConfigKeyEnum.DamClientId
    this.SECRET_KEY = KMSConfigKeyEnum.DamClientSecret
    this.HOSTNAME = LionConfigKeyEnum.DamHostName
    this.HOSTPORT = LionConfigKeyEnum.DamHostPort
  }

  private async requestDam<T>(options: RequestOptions, payload = '') {
    const authApiInfo = await this.auth(options)
    return this.request<DamHttpResponse<T>>(authApiInfo, payload).then(res => {
      if (!res || res?.code) {
        this.logger.logError(`DAM 请求失败: message=${res?.message}, code=${res?.code}`)
        throw new IrisHttpRequestError(`DAM 请求失败: message=${res?.message}`)
      }
      return res.data
    })
  }

  /**
   * 创建子应用
   * @returns
   */
  async createSubApp(payload: DamSubAppModel) {
    try {
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/v2/subApplications/modify`,
        path: `/api/v2/subApplications/modify`,
        method: HTTP.MethodEnum.POST,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      const ret = await this.requestDam<{ id: number }>(apiInfo, JSON.stringify(payload))
      return ret
    } catch (error) {
      this.logger.logError(error, { message: 'create dam sub app failed', payload })
      throw error
    }
  }

  /**
   * 更新子应用
   * @returns
   */
  async updateSubApp(id: string, payload: DamSubAppModel) {
    try {
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/v2/subApplications/modify`,
        path: `/api/v2/subApplications/modify`,
        method: HTTP.MethodEnum.POST,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      const ret = await this.requestDam<null>(apiInfo, JSON.stringify({ ...payload, id }))
      return ret
    } catch (error) {
      this.logger.logError(error, { message: 'update dam sub app failed', payload })
      throw error
    }
  }
}
