import { RequestOptions } from 'https'
import * as HTTP from 'iris/iris-lib/constants/http'
import { KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { AbstractHttpBAService } from 'iris/iris-out/abstract-http-ba-service'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'
import { IrisFedoError } from 'iris/iris-lib/model/iris-error'

interface FedoHttpResponse<T> {
  status: number
  code?: number
  name?: string
  data: T
  message: string
}

interface FedoTemplate {
  id: string
  name: string
  desc: string
  groupId: string
  workflowStage: string
  techStack: string
  imageUrl: string
  deleted: boolean
  isPublic: boolean
  version: number
}

enum HookTriggerType {
  complete = 'complete', // 流水线执行完成时触发
  terminated = 'terminated', // 流水线终止时触发
  beforeNodeExecution = 'beforeNodeExecution', // 节点执行前
  afterNodeExecution = 'afterNodeExecution', // 节点执行后
  beforeJobExecution = 'beforeJobExecution', // Job执行前
  afterJobExecution = 'afterJobExecution', // Job执行后
  beforeStageExecution = 'beforeStageExecution', // Stage执行前
  afterStageExecution = 'afterStageExecution', // Stage执行后
  onNodeFailed = 'onNodeFailed', // 节点执行失败时触发
}

export class FedoService extends AbstractHttpBAService {
  private GROUP_ID: LionConfigKeyEnum
  private TEMPLATE_ID: LionConfigKeyEnum
  private FEDO_HOOKS_COMPLETE_URL: LionConfigKeyEnum
  private FEDO_HOOKS_TERMINATE_URL: LionConfigKeyEnum

  constructor() {
    super()
    this.ACCESS_KEY = KMSConfigKeyEnum.FedoClientId
    this.SECRET_KEY = KMSConfigKeyEnum.FedoClientSecret
    this.HOSTNAME = LionConfigKeyEnum.FedoHostName
    this.HOSTPORT = LionConfigKeyEnum.FedoHostPort
    this.GROUP_ID = LionConfigKeyEnum.FedoGroupId
    this.TEMPLATE_ID = LionConfigKeyEnum.FedoTemplateId
    this.FEDO_HOOKS_COMPLETE_URL = LionConfigKeyEnum.FedoHooksCompleteUrl
    this.FEDO_HOOKS_TERMINATE_URL = LionConfigKeyEnum.FedoHooksTerminateUrl
  }

  private async requestFedo<T>(options: RequestOptions, payload: string) {
    const authApiInfo = await this.auth(options)
    return this.request<FedoHttpResponse<T>>(authApiInfo, payload)
  }

  getFedoRedirectUrl(workflowId: string) {
    // FEDO 团队反馈该地址已有多个外部团队在使用，不可能发生变动，所以这里直接写死。
    // display=embedded是FEDO提供的内嵌展示模式参数，增加该参数后顶部和左侧的菜单栏会自动隐藏
    return `https://fedo.sankuai.com/workflow/redirect/${workflowId}?display=embedded`
  }

  /**
   * 创建 FEDO 工作流失败
   * @param params
   * @returns
   */
  async startWorkflow({
    taskId,
    taskRecordId,
    workflowSchedule,
    groupId,
    templateId,
  }: {
    taskId: string
    taskRecordId: string
    workflowSchedule: Record<string, any>
    groupId?: string
    templateId?: string
  }) {
    type ResponseData = {
      sprintId: string
      taskId: string
      workflowId: string
    }

    const [fedoGroupId, fedoTemplateId, fedoHooksCompleteUrl, fedoHooksTerminateUrl] = await Promise.all([
      LionClientService.fetchConfigValue(this.GROUP_ID),
      LionClientService.fetchConfigValue(this.TEMPLATE_ID),
      LionClientService.fetchConfigValue(this.FEDO_HOOKS_COMPLETE_URL),
      LionClientService.fetchConfigValue(this.FEDO_HOOKS_TERMINATE_URL),
    ])

    try {
      const payload = {
        groupId: groupId || fedoGroupId,
        templateId: templateId || fedoTemplateId,
        hooks: [
          { hookUrl: `${fedoHooksCompleteUrl}?taskId=${taskId}&taskRecordId=${taskRecordId}`, hookTriggerType: HookTriggerType.complete },
          { hookUrl: `${fedoHooksTerminateUrl}?taskId=${taskId}&taskRecordId=${taskRecordId}`, hookTriggerType: HookTriggerType.terminated },
        ],
        workflowSchedule,
      }
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/open-api/quickSetupWorkflow`,
        path: `/open-api/quickSetupWorkflow`,
        method: HTTP.MethodEnum.POST,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }

      this.logger.logInfo(`startWorkflow payload: ${JSON.stringify(payload)}`)
      const result = await this.requestFedo<ResponseData>(apiInfo, JSON.stringify(payload))
      const workflowId = result?.data?.workflowId
      if (!workflowId) {
        this.logger.logError(`创建 FEDO 工作流失败`, { result })
        throw new IrisFedoError('创建 FEDO 工作流失败, /open-api/quickSetupWorkflow 接口没有正确返回 workflowId')
      }
      return { ...result.data, url: this.getFedoRedirectUrl(workflowId) }
    } catch (error) {
      this.logger.logError(error, { message: `创建 FEDO 工作流失败`, workflowSchedule })
      throw error
    }
  }

  /**
   * 批量添加 FEDO 研发组成员。
   * 作用：旅速搭新建或变更项目组成员时，将成员信息同步到 FEDO 研发组，避免没有 FEDO 研发组权限而导致无法使用发布流程。
   * @param params
   * @returns
   */
  async batchAddMembers({ groupId, misIds, roleId = 1 }: { groupId?: string; misIds?: string[]; roleId?: string | number }) {
    try {
      const fedoGroupId = await LionClientService.fetchConfigValue(this.GROUP_ID)
      const payload = { groupId: groupId || fedoGroupId, misIds, roleId }
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/open-api/auth/group/single`,
        path: `/open-api/auth/group/single`,
        method: HTTP.MethodEnum.POST,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      this.logger.logInfo(`batchAddMembers payload: ${JSON.stringify(payload)}`)
      const result = await this.requestFedo<any>(apiInfo, JSON.stringify(payload))
      if (result.status === 0) {
        this.logger.logInfo(`批量添加 FEDO 研发组成员成功，result: ${JSON.stringify(result)}`)
      } else {
        this.logger.logError(`批量添加 FEDO 研发组成员失败，result: ${JSON.stringify(result)}`)
      }
      return result.data
    } catch (error) {
      this.logger.logError(error, { message: `批量添加 FEDO 研发组成员失败`, misIds, groupId })
      throw error
    }
  }

  /**
   * 获取 FEDO 研发组下的所有工作流模板。
   * @param params
   * @returns
   */
  async getTemplateList({ groupId }: { groupId?: string }) {
    try {
      const fedoGroupId = await LionClientService.fetchConfigValue(this.GROUP_ID)
      const payload = { groupId: groupId || fedoGroupId }
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/open-api/template/list`,
        path: `/open-api/template/list`,
        method: HTTP.MethodEnum.POST,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      this.logger.logInfo(`getTemplateList payload: ${JSON.stringify(payload)}`)
      const result = await this.requestFedo<any>(apiInfo, JSON.stringify(payload))
      if (result.status !== 0) {
        this.logger.logError(`获取研发组下的所有工作流模板失败，result: ${JSON.stringify(result)}`)
        return []
      }
      this.logger.logInfo(`获取研发组下的所有工作流模板成功， result: ${JSON.stringify(result)}`)
      const templateList = (result.data?.list || []) as FedoTemplate[]
      return templateList
        .filter(item => item.deleted === false)
        .map(item => ({
          id: item.id,
          name: item.name,
          desc: item.desc,
          groupId: item.groupId,
          workflowStage: item.workflowStage,
          techStack: item.techStack,
          imageUrl: item.imageUrl,
          isPublic: item.isPublic,
          version: item.version,
        }))
    } catch (error) {
      this.logger.logError(error, { message: `获取研发组下的所有工作流模板失败`, groupId })
      throw error
    }
  }

  /**
   * 终止 FEDO 工作流
   * @param params
   * @returns
   */
  async abortWorkflow({ groupId, workflowId }: { groupId?: string; workflowId: string }) {
    try {
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/open-api/workflow/${workflowId}/abort`,
        path: `/open-api/workflow/${workflowId}/abort`,
        method: HTTP.MethodEnum.PUT,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      this.logger.logInfo(`abortWorkflow workflowId: ${workflowId}`)
      const result = await this.requestFedo<any>(apiInfo, '')
      if (result.status === 0) {
        this.logger.logInfo(`终止 FEDO 工作流成功， result: ${JSON.stringify(result)}`)
      } else {
        this.logger.logError(`终止 FEDO 工作流失败，result: ${JSON.stringify(result)}`)
      }
      return result.data
    } catch (error) {
      this.logger.logError(error, { message: `终止 FEDO 工作流失败`, workflowId, groupId })
      throw error
    }
  }
}
