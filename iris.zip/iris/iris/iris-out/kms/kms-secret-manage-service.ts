import assert from 'assert'
// @ts-ignore
import { getKeyByName } from '@dp/node-kms'
import { IrisKMSError } from 'iris/iris-lib/model/iris-error'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'
import { ConfigHelper } from 'iris/iris-lib/helper/config-helper'

export enum KMSConfigKeyEnum {
  /** WebStatic */
  WebStaticCliToken = 'webstatic_cli_token',
  WebStaticAdminToken = 'webstatic_admin_token',

  /** MSS */
  MssServiceAccessKey = 's3plus_service_access_key',
  MssSerivceSecretKey = 's3plus_service_secret_key',
  MssServiceAccessKeyTest = 'oss_ak_test',
  MssSerivceSecretKeyTest = 'oss_sk_test',

  /** SSO */
  SsoClientId = 'sso_client_id',
  SsoClientSecret = 'sso_client_secret',

  /** ORG */
  OrgClientId = 'org_client',
  OrgClientSecret = 'org_secret',

  /** Encryption */
  EncryptionIrisAesIv = 'encryption_iris_aes_iv',
  EncryptionIrisAesKey = 'encryption_iris_aes_key',

  /** RDS */
  RdsConnType = 'rds_conn_type',
  RdsRouteType = 'rds_route_type',
  RdsJdbcRef = 'rds_jdbcref',

  /** TAM */
  TamClientId = 'tam_client_id',
  TamClientSecret = 'tam_client_secret',

  /** DAM */
  DamClientId = 'dam_client_id',
  DamClientSecret = 'dam_client_secret',

  /** PU */
  PUProjectId = 'pu_project_id',

  /** FEDO */
  FedoClientId = 'fedo_client_id',
  FedoClientSecret = 'fedo_client_secret',

  /** ONES */
  OnesToken = 'ones_token',
}

export interface KMSConfigValueType {
  /** WebStatic */
  [KMSConfigKeyEnum.WebStaticCliToken]: string
  [KMSConfigKeyEnum.WebStaticAdminToken]: string

  /** MSS */
  [KMSConfigKeyEnum.MssServiceAccessKey]: string
  [KMSConfigKeyEnum.MssSerivceSecretKey]: string
  [KMSConfigKeyEnum.MssServiceAccessKeyTest]: string
  [KMSConfigKeyEnum.MssSerivceSecretKeyTest]: string

  /** SSO */
  [KMSConfigKeyEnum.SsoClientId]: string
  [KMSConfigKeyEnum.SsoClientSecret]: string

  /** ORG */
  [KMSConfigKeyEnum.OrgClientId]: string
  [KMSConfigKeyEnum.OrgClientSecret]: string

  /** Encryption */
  [KMSConfigKeyEnum.EncryptionIrisAesIv]: string
  [KMSConfigKeyEnum.EncryptionIrisAesKey]: string

  /** RDS */
  [KMSConfigKeyEnum.RdsConnType]: 'mysql' | 'mariadb'
  [KMSConfigKeyEnum.RdsRouteType]: 'master-only' | 'master-slave' | 'slave-only'
  [KMSConfigKeyEnum.RdsJdbcRef]: string

  /** TAM */
  [KMSConfigKeyEnum.TamClientId]: string
  [KMSConfigKeyEnum.TamClientSecret]: string

  /** DAM */
  [KMSConfigKeyEnum.DamClientId]: string
  [KMSConfigKeyEnum.DamClientSecret]: string

  [KMSConfigKeyEnum.PUProjectId]: string

  /** FEDO */
  [KMSConfigKeyEnum.FedoClientId]: string
  [KMSConfigKeyEnum.FedoClientSecret]: string

  /** ONES */
  [KMSConfigKeyEnum.OnesToken]: string
}

type ValueOf<T, Key extends keyof T> = T[Key]

export class KMSSecretManageService {
  static log = true
  static logger = new IrisLogger()

  static async fetchConfigValue<Key extends KMSConfigKeyEnum>(key: Key) {
    const appKey = ConfigHelper.getAppKey()
    try {
      const value = await getKeyByName(appKey, key)
      assert.ok(!!value.length, `获取 KMS 失败: key=${key}, value=${value}`)
      if (KMSSecretManageService.log) {
        KMSSecretManageService.logger.logInfo(`fetch successfully: ${key}=${value}`)
      }
      return value as ValueOf<KMSConfigValueType, Key>
    } catch (error) {
      KMSSecretManageService.logger.logError(error, { message: `fetch kms failed: key=${key}, appKey=${appKey}` })
      throw new IrisKMSError((error as Error).message)
    }
  }
}
