const lion = require('@dp/lion-client')

import { IrisLionError } from 'iris/iris-lib/model/iris-error'
import { IrisLogger, ConfigHelper } from 'iris/iris-lib'

export enum LionConfigKeyEnum {
  /** MSS */
  MSSAssetsBucket = 'mss_assets_bucket',
  MSSHtmlBucket = 'mss_html_bucket',
  MSSEndPointBJ = 'mss_endpoint_bj',
  MSSEndPointSH = 'mss_endpoint_sh',
  MSSCDNEndPointBJ = 'mss_cdn_endpoint_bj',
  MSSCDNEndPointSH = 'mss_cdn_endpoint_sh',

  /** MSS Test */
  MSSHtmlBucketTest = 'mss_html_bucket_test',
  MSSEndPointBJTest = 'mss_endpoint_bj_test',
  MSSCDNEndPointBJTest = 'mss_cdn_endpoint_bj_test',

  /** Domain */
  MSSDomain = 'mss_domain',
  WebstaticDomain = 'webstatic_domain',
  AssetsDomain = 'assets_domain',

  /** ORG */
  OrgHostName = 'org_hostname',
  OrgHostPort = 'org_hostport',

  /** RDS */
  RdsLogOptions = 'rds_log_options',

  /** TAM */
  TamHostName = 'tam_hostname',
  TamHostPort = 'tam_hostport',

  /** DAM */
  DamHostName = 'dam_hostname',
  DamHostPort = 'dam_hostport',

  /** omp pu */
  PUHostName = 'pu_hostname',
  PUHostPort = 'pu_hostport',
  PUHostNameTest = 'pu_hostname_test',
  PUHostPortTest = 'pu_hostport_test',
  PUSource = 'pu_source',

  /** WebStatic Admin */
  WebStaticAdminHostName = 'webstatic_admin_hostname',
  WebStaticAdminHostPort = 'webstatic_admin_hostport',
  WebStaticAdminV2HostName = 'webstatic_admin_v2_hostname',
  WebStaticAdminV2HostPort = 'webstatic_admin_v2_hostport',

  /** FEDO */
  FedoHostName = 'fedo_hostname',
  FedoHostPort = 'fedo_hostport',
  FedoGroupId = 'fedo_group_id',
  FedoTemplateId = 'fedo_template_id',
  FedoHooksCompleteUrl = 'fedo_hooks_complete_url',
  FedoHooksTerminateUrl = 'fedo_hooks_terminate_url',

  /** ONES */
  OnesHostName = 'ones_hostname',
  OnesHostPort = 'ones_hostport',

  /** 页面鉴权 */
  UACDomain = 'uac_domain',
  UACDomainTest = 'uac_domain_test',
  DtauthDomain = 'dtauth_domain',
  DtauthDomainTest = 'dtauth_domain_test',
  AuthDomainTest = 'auth_domain_test',
  AuthDomain = 'auth_domain',
  GatewayGroupId = 'gateway_group_id',
  GatewayProjectId = 'gateway_project_id',
  RegisterGatewayPath = 'register_gateway_path',
  RegisterGatewayHostPort = 'register_gateway_hostport',
  RegisterGatewayHostName = 'register_gateway_hostname',
  RegisterGatewayHostPortTest = 'register_gateway_hostport_test',
  RegisterGatewayHostNameTest = 'register_gateway_hostname_test',
}

export interface LionConfigValueType {
  /** MSS */
  [LionConfigKeyEnum.MSSAssetsBucket]: string
  [LionConfigKeyEnum.MSSHtmlBucket]: string
  [LionConfigKeyEnum.MSSEndPointBJ]: string
  [LionConfigKeyEnum.MSSEndPointSH]: string
  [LionConfigKeyEnum.MSSCDNEndPointBJ]: string
  [LionConfigKeyEnum.MSSCDNEndPointSH]: string

  /** MSS Test */
  [LionConfigKeyEnum.MSSHtmlBucketTest]: string
  [LionConfigKeyEnum.MSSEndPointBJTest]: string
  [LionConfigKeyEnum.MSSCDNEndPointBJTest]: string

  /** Domain */
  [LionConfigKeyEnum.MSSDomain]: string
  [LionConfigKeyEnum.WebstaticDomain]: string
  [LionConfigKeyEnum.AssetsDomain]: string

  /** ORG */
  [LionConfigKeyEnum.OrgHostName]: string
  [LionConfigKeyEnum.OrgHostPort]: string

  /** RDS */
  [LionConfigKeyEnum.RdsLogOptions]: string[]

  /** TAM */
  [LionConfigKeyEnum.TamHostName]: string
  [LionConfigKeyEnum.TamHostPort]: string

  /** WebStatic Admin */
  [LionConfigKeyEnum.WebStaticAdminHostName]: string
  [LionConfigKeyEnum.WebStaticAdminHostPort]: string
  [LionConfigKeyEnum.WebStaticAdminV2HostName]: string
  [LionConfigKeyEnum.WebStaticAdminV2HostPort]: string

  /** DAM */
  [LionConfigKeyEnum.DamHostName]: string
  [LionConfigKeyEnum.DamHostPort]: string

  /** omp pu */
  [LionConfigKeyEnum.PUHostName]: string
  [LionConfigKeyEnum.PUHostPort]: string
  [LionConfigKeyEnum.PUHostNameTest]: string
  [LionConfigKeyEnum.PUHostPortTest]: string
  [LionConfigKeyEnum.PUSource]: string

  /** FEDO */
  [LionConfigKeyEnum.FedoHostName]: string
  [LionConfigKeyEnum.FedoHostPort]: string
  [LionConfigKeyEnum.FedoGroupId]: string
  [LionConfigKeyEnum.FedoTemplateId]: string
  [LionConfigKeyEnum.FedoHooksCompleteUrl]: string
  [LionConfigKeyEnum.FedoHooksTerminateUrl]: string

  /** Ones */
  [LionConfigKeyEnum.OnesHostName]: string
  [LionConfigKeyEnum.OnesHostPort]: string

  /** 页面鉴权 */
  [LionConfigKeyEnum.UACDomain]: string
  [LionConfigKeyEnum.UACDomainTest]: string
  [LionConfigKeyEnum.DtauthDomain]: string
  [LionConfigKeyEnum.DtauthDomainTest]: string
  [LionConfigKeyEnum.AuthDomainTest]: string
  [LionConfigKeyEnum.AuthDomain]: string
  [LionConfigKeyEnum.GatewayGroupId]: string
  [LionConfigKeyEnum.GatewayProjectId]: string
  [LionConfigKeyEnum.RegisterGatewayPath]: string
  [LionConfigKeyEnum.RegisterGatewayHostPort]: string
  [LionConfigKeyEnum.RegisterGatewayHostName]: string
  [LionConfigKeyEnum.RegisterGatewayHostPortTest]: string
  [LionConfigKeyEnum.RegisterGatewayHostNameTest]: string
}

type ValueOf<T, Key extends keyof T> = T[Key]

export class LionClientService {
  static log = true
  static logger = new IrisLogger()

  static async fetchConfigValue<Key extends LionConfigKeyEnum>(key: Key) {
    const lionConfigJson = [LionConfigKeyEnum.RdsLogOptions]
    try {
      let value = await lion.getProperty(`${ConfigHelper.getAppKey()}.${key}`, '')
      if (LionClientService.log) {
        this.logger.logInfo(`fetch successfully: ${key}=${value}`)
      }
      if (lionConfigJson.includes(key) && typeof value === 'string') {
        value = JSON.parse(value)
      }
      return value as ValueOf<LionConfigValueType, Key>
    } catch (error) {
      this.logger.logError(error, { message: `fetch ${key} failed` })
      throw new IrisLionError('获取 Lion 配置失败')
    }
  }
}
