import assert from 'assert'
const mss = require('mos-mss')
import { RequestOptions } from 'https'
import { IrisInvalidFormatParamError, IrisKMSError, IrisLionError, IrisS3Error } from 'iris/iris-lib/model/iris-error'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'
import { KMSSecretManageService, KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'

export enum CDNSourceEnum {
  SH = 'SH',
  BJ = 'BJ',
  BJ_TEST = 'BJ_TEST',
}

export type S3UploadResponse = {
  filename: string
  bucket: string
  objectUrl?: string
  cdnObjectUrl?: string
}

interface MSSResponse {
  code: number
  data: {
    content: string
  }
  error: Buffer
}

interface MSSClient {
  putObject: (filename: string, buffer: Buffer, options?: RequestOptions) => Promise<MSSResponse>
  getBuffer: (filename: string) => Promise<MSSResponse>
  copyObject: (source: string, target: string) => Promise<MSSResponse>
  listObject: (options?: RequestOptions) => Promise<MSSResponse>
  deleteObject: (key: string, options?: RequestOptions) => Promise<MSSResponse>
}

export class MSSClientService {
  public endpoint: string
  public cdnEndpoint: string
  public bucket: string
  private client: MSSClient
  private logger = new IrisLogger()

  private static async configuration(source: CDNSourceEnum) {
    let endpoint: LionConfigKeyEnum
    let cdnEndpoint: LionConfigKeyEnum
    let ak: KMSConfigKeyEnum
    let sk: KMSConfigKeyEnum
    switch (source) {
      case CDNSourceEnum.BJ:
        endpoint = LionConfigKeyEnum.MSSEndPointBJ
        cdnEndpoint = LionConfigKeyEnum.MSSCDNEndPointBJ
        ak = KMSConfigKeyEnum.MssServiceAccessKey
        sk = KMSConfigKeyEnum.MssSerivceSecretKey
        break
      case CDNSourceEnum.SH:
        endpoint = LionConfigKeyEnum.MSSEndPointSH
        cdnEndpoint = LionConfigKeyEnum.MSSCDNEndPointSH
        ak = KMSConfigKeyEnum.MssServiceAccessKey
        sk = KMSConfigKeyEnum.MssSerivceSecretKey
        break
      case CDNSourceEnum.BJ_TEST:
        endpoint = LionConfigKeyEnum.MSSEndPointBJTest
        cdnEndpoint = LionConfigKeyEnum.MSSCDNEndPointBJTest
        ak = KMSConfigKeyEnum.MssServiceAccessKeyTest
        sk = KMSConfigKeyEnum.MssSerivceSecretKeyTest
        break
      default:
        throw new IrisS3Error(`未知集群: endpoint=${endpoint}`)
    }

    return Promise.all([
      KMSSecretManageService.fetchConfigValue(ak).catch(err => {
        throw new IrisKMSError(err.message)
      }),
      KMSSecretManageService.fetchConfigValue(sk).catch(err => {
        throw new IrisKMSError(err.message)
      }),
      LionClientService.fetchConfigValue(endpoint).catch(err => {
        throw new IrisLionError(err.message)
      }),
      LionClientService.fetchConfigValue(cdnEndpoint).catch(err => {
        throw new IrisLionError(err.message)
      }),
    ])
  }

  public static async getInstance(source: CDNSourceEnum, bucket: string) {
    const [accessKeyId, accessKeySecret, endpoint, cdnEndpoint] = await this.configuration(source)
    return new MSSClientService({ endpoint, cdnEndpoint, accessKeyId, accessKeySecret, bucket })
  }

  constructor(params: { accessKeyId: string; accessKeySecret: string; endpoint: string; cdnEndpoint: string; bucket: string }) {
    const { endpoint, cdnEndpoint, accessKeyId, accessKeySecret, bucket } = params
    this.endpoint = endpoint
    this.cdnEndpoint = cdnEndpoint
    this.bucket = bucket
    this.client = new mss({ accessKeyId, accessKeySecret, bucket, endpoint })
  }

  /**
   * 返回 cdn 链接
   * @param key 文件名/文件路径
   * @returns
   */
  public cdnUrl(key: string) {
    return `https://${this.cdnEndpoint}/${this.bucket}/${key}`
  }

  /**
   * 返回对象链接
   * @param key 文件名
   * @returns
   */
  public objectUrl(key: string) {
    return `https://${this.endpoint}/${this.bucket}/${key}`
  }

  private validateFilename(filename: string) {
    try {
      assert.ok(!!filename, `S3 文件名不能为空: filename=${filename}`)
      assert.ok(!filename.startsWith('/'), `S3 文件名不能以 '/' 开头, filename=${filename}`)
    } catch (error) {
      throw new IrisInvalidFormatParamError((error as Error).message)
    }
  }

  /**
   * 上传
   * @param filename e.g. test.json, schema/test.json
   * @param content string
   * @param contentType e.g. text/html
   * @returns
   */
  async upload(filename: string, content: string, contentType: string): Promise<S3UploadResponse> {
    this.validateFilename(filename)

    const buffer = Buffer.from(content)
    const headers = { 'Content-Type': contentType }

    const result = await this.client.putObject(filename, buffer, { headers })

    if (!result) {
      this.logger.logError(`S3 上传文件失败: filename=${filename}`)
      throw new IrisS3Error(`S3 上传文件失败: filename=${filename}`)
    }
    if (result.code !== 200) {
      this.logger.logError(`S3 上传文件失败: filename=${filename}`, { code: result?.code, error: result?.error?.toString('base64') })
      throw new IrisS3Error(`上传文件失败: filename=${filename}, code=${result?.code}, error=${result?.error?.toString('base64')}`)
    }
    return {
      filename,
      bucket: this.bucket,
      objectUrl: this.objectUrl(filename),
      cdnObjectUrl: this.cdnUrl(filename),
    }
  }

  /**
   * 下载
   * @param filename e.g. test.json, schema/test.json
   * @returns
   */
  async query(filename: string): Promise<string> {
    this.validateFilename(filename)

    const result = await this.client.getBuffer(filename)

    if (!result) {
      this.logger.logError(`S3 获取失败: filename=${filename}`)
      throw new IrisS3Error(`S3 请求文件失败: filename=${filename}`)
    }
    if (result.code !== 200) {
      this.logger.logError(`S3 获取失败: filename=${filename}`, { code: result?.code, error: result?.error?.toString('base64') })
      throw new IrisS3Error(`错误: filename=${filename}, code=${result?.code}, error=${result?.error?.toString('base64')}`)
    }

    return result.data.content
  }

  async queryJson(filename: string) {
    this.validateFilename(filename)

    const content = await this.query(filename)
    return JSON.parse(content)
  }

  /**
   * 拷贝
   * @param source e.g. test.json, schema/test.json
   * @param target e.g. test.json, schema/test.json
   */
  async copy(source: string, target: string) {
    this.validateFilename(source)
    this.validateFilename(target)

    const sourceEsp = this.escapedS3Filename(source)
    const targetEsp = this.escapedS3Filename(target)
    const sourcePath = `/${this.bucket}/${sourceEsp}`
    const targetPath = `/${this.bucket}/${targetEsp}`

    const result = await this.client.copyObject(sourcePath, targetPath)

    if (!result) {
      throw new IrisS3Error(`S3 拷贝文件失败: source=${source}, target=${target}`)
    }
    if (result.code !== 200) {
      this.logger.logError(`S3 拷贝文件失败`, { code: result?.code, error: result?.error?.toString('base64') })
      throw new IrisS3Error(`错误: source=${source}, target=${target}, code=${result?.code}, error=${result?.error?.toString('base64')}`)
    }
  }

  private escapedS3Filename(filename: string) {
    return filename.replace(/\+/g, '%2B')
  }
}
