import { RequestOptions } from 'https'
import * as HTTP from 'iris/iris-lib/constants/http'
import { KMSSecretManageService, KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { AbstractHttpBAService } from 'iris/iris-out/abstract-http-ba-service'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'

interface OnesHttpResponse<T> {
  code: number
  message: string
  data: T
}

enum OnesTypeEnum {
  REQUIREMENT = 'REQUIREMENT', // ones 需求
  DEVTASK = 'DEVTASK', // ones 任务
}

export interface OnesItem {
  id: string
  name: string
  type: OnesTypeEnum
  requirementId: string
  projectId: string
}

export interface OnesRequirementItem {
  requirementId: string
  requirementName: string
  requirementState: string
}

interface OnesResponseItem {
  name: { value: string }
  id: { value: string }
  type: OnesTypeEnum
  projectId: { id: string; value: string }
  state: { name: string; category: string; value: string }
  parent?: OnesResponseItem
}

interface SearchParams {
  keyword: string
  userName: string
  onlyAssignToMe?: string
}

function mapping(item: OnesResponseItem) {
  if (item.type === OnesTypeEnum.DEVTASK) {
    return {
      id: item.id.value,
      name: item.name.value,
      type: OnesTypeEnum.DEVTASK,
      requirementId: item.parent?.id?.value,
      projectId: item.projectId.id,
    } as OnesItem
  } else if (item.type === OnesTypeEnum.REQUIREMENT) {
    return {
      id: item.id.value,
      name: item.name.value,
      type: OnesTypeEnum.REQUIREMENT,
      requirementId: item.id.value,
      projectId: item.projectId.id,
    } as OnesItem
  }
  return null
}

export class OnesService extends AbstractHttpBAService {
  private ONES_TOKEN: KMSConfigKeyEnum

  constructor() {
    super()
    this.ONES_TOKEN = KMSConfigKeyEnum.OnesToken
    this.HOSTNAME = LionConfigKeyEnum.OnesHostName
    this.HOSTPORT = LionConfigKeyEnum.OnesHostPort
  }

  private async requestOnes<T>(options: RequestOptions, payload: string) {
    // prettier-ignore
    const [hostname, port] = await Promise.all([
      LionClientService.fetchConfigValue(this.HOSTNAME),
      LionClientService.fetchConfigValue(this.HOSTPORT).then(port => +port),
    ])
    return this.request<OnesHttpResponse<T>>({ ...options, hostname: hostname as string, port }, payload)
  }

  /**
   * 根据 Ones 需求/任务的 ID 或名称，查询对应的详细信息
   * @param params
   * @returns
   */
  async searchByIdOrName(params: SearchParams): Promise<OnesItem[]> {
    type ResponseData = {
      cn: number
      items: OnesResponseItem[]
    }
    const { keyword, userName, onlyAssignToMe = 0 } = params
    if (!keyword) {
      return []
    }

    const Authorization = await KMSSecretManageService.fetchConfigValue(this.ONES_TOKEN)

    try {
      const queryParams = [
        { key: 'type', value: `${OnesTypeEnum.REQUIREMENT},${OnesTypeEnum.DEVTASK}` }, // 查询需求和任务
        { key: 'includeFatherChain', value: true }, // 查询结果需要带上任务上级需求的信息
        { key: 'cn', value: '1' },
        { key: 'sn', value: '10' }, // 默认只返回前10条记录
      ]
      // queryDSL 详细配置详见接口文档：https://km.sankuai.com/page/791591504
      const payload = {
        query: [] as Record<string, unknown>[],
        displayFieldList: ['id', 'type', 'projectId', 'name', 'state', 'parent'],
      }

      if (Number(onlyAssignToMe) === 1) {
        // 只查询指派人为本人的数据
        payload.query.push({
          field: 'assigned',
          value: userName,
          type: 'TERM',
        })
      }

      // 如果 keyword 是纯数字，当成id去精准匹配查询；如果不是纯数字，则当成 name 去模糊匹配查询
      if (/^\d+$/.test(keyword)) {
        payload.query.push({
          field: 'id',
          value: String(keyword),
          type: 'TERM',
        })
      } else {
        // 咨询过 Ones 团队，现在 searchV2 接口的 Query DSL 不支持 name 字段模糊匹配，只有把 name 参数放到 query 中才能支持模糊匹配
        queryParams.push({ key: 'name', value: encodeURIComponent(keyword) })
      }
      const queryStr = queryParams.map(item => `${item.key}=${item.value}`).join('&')
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/1.0/ones/issues/searchV2`,
        path: `/api/1.0/ones/issues/searchV2?${queryStr}`,
        method: HTTP.MethodEnum.POST,
        headers: {
          Authorization,
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }

      this.logger.logInfo(`searchByIdOrName queryStr: ${queryStr}`)
      this.logger.logInfo(`searchByIdOrName payload: ${JSON.stringify(payload)}`)
      const responseData = await this.requestOnes<ResponseData>(apiInfo, JSON.stringify(payload))
      const result = responseData?.data?.items.map(mapping) || []
      return result
    } catch (error) {
      this.logger.logError(error, { message: `查询 Ones 需求/任务失败`, keyword, userName })
      throw error
    }
  }

  /**
   * 根据 Ones 需求/任务ID，批量查询对应的详细信息
   * @param onesItemIds
   * @returns
   */
  async batchQuery(onesItemIds: string[]): Promise<OnesItem[]> {
    type ResponseData = {
      cn: number
      items: OnesResponseItem[]
    }
    if (!Array.isArray(onesItemIds) || onesItemIds.length === 0) {
      return []
    }

    const Authorization = await KMSSecretManageService.fetchConfigValue(this.ONES_TOKEN)

    try {
      const queryParams = [
        { key: 'type', value: `${OnesTypeEnum.REQUIREMENT},${OnesTypeEnum.DEVTASK}` }, // 查询需求和任务
        { key: 'includeFatherChain', value: true },
        { key: 'cn', value: '1' },
        { key: 'sn', value: onesItemIds.length },
      ]
      // queryDSL 详细配置详见接口文档：https://km.sankuai.com/page/791591504
      const payload = {
        query: [
          {
            field: 'id',
            valueList: onesItemIds,
            type: 'TERMS',
          },
        ],
        displayFieldList: ['id', 'type', 'projectId', 'name', 'state'],
      }

      const queryStr = queryParams.map(item => `${item.key}=${item.value}`).join('&')
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/1.0/ones/issues/searchV2`,
        path: `/api/1.0/ones/issues/searchV2?${queryStr}`,
        method: HTTP.MethodEnum.POST,
        headers: {
          Authorization,
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }

      this.logger.logInfo(`batchQuery queryStr: ${queryStr}`)
      this.logger.logInfo(`batchQuery payload: ${JSON.stringify(payload)}`)
      const responseData = await this.requestOnes<ResponseData>(apiInfo, JSON.stringify(payload))
      const result = responseData?.data?.items.map(mapping) || []
      return result
    } catch (error) {
      this.logger.logError(error, { message: `批量查询 Ones 需求/任务失败`, onesItemIds })
      throw error
    }
  }

  /**
   * 根据 Ones 需求ID，查询对应的需求信息
   * @param projectId
   * @param requirementId
   * @returns
   */
  async queryOnesRequirementInfoById(projectId: string, requirementId: string): Promise<OnesRequirementItem> {
    type ResponseData = {
      cn: number
      items: OnesResponseItem[]
    }

    const Authorization = await KMSSecretManageService.fetchConfigValue(this.ONES_TOKEN)

    try {
      const queryParams = [
        { key: 'type', value: OnesTypeEnum.REQUIREMENT }, // 只查询需求
        { key: 'includeFatherChain', value: false },
        { key: 'cn', value: '1' },
        { key: 'sn', value: '1' },
      ]
      // queryDSL 详细配置详见接口文档：https://km.sankuai.com/page/791591504
      const payload = {
        query: [
          {
            field: 'id',
            value: requirementId,
            type: 'TERM',
          },
        ],
        displayFieldList: ['id', 'type', 'projectId', 'name', 'state'],
      }

      const queryStr = queryParams.map(item => `${item.key}=${item.value}`).join('&')
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/1.0/ones/projects/${projectId}/issues/search`,
        path: `/api/1.0/ones/projects/${projectId}/issues/search?${queryStr}`,
        method: HTTP.MethodEnum.POST,
        headers: {
          Authorization,
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }

      this.logger.logInfo(`queryOnesRequirementInfoById queryStr: ${queryStr}`)
      this.logger.logInfo(`queryOnesRequirementInfoById payload: ${JSON.stringify(payload)}`)
      const responseData = await this.requestOnes<ResponseData>(apiInfo, JSON.stringify(payload))
      if (responseData?.data?.items?.length) {
        const matchItem = responseData.data.items[0]
        return {
          requirementId: matchItem.id.value,
          requirementName: matchItem.name.value,
          requirementState: matchItem.state.category,
        }
      }
      return null
    } catch (error) {
      this.logger.logError(error, { message: `查询 Ones 需求失败`, projectId, requirementId })
      throw error
    }
  }

  getOnesTaskUrl(onesProjectId: string, onesTaskId: string): string {
    return `https://ones.sankuai.com/ones/product/${onesProjectId}/workItem/task/detail/${onesTaskId}`
  }
  getOnesRequirementUrl(onesProjectId: string, onesRequirementId: string): string {
    return `https://ones.sankuai.com/ones/product/${onesProjectId}/workItem/requirement/detail/${onesRequirementId}`
  }
}
