import { RequestOptions } from 'https'
import * as HTTP from 'iris/iris-lib/constants/http'
import { KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { AbstractHttpBAService } from 'iris/iris-out/abstract-http-ba-service'
import { LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'
import { IrisHttpRequestError, IrisUserNotFoundError } from 'iris/iris-lib/model/iris-error'

export interface OrgEmpInfo {
  tenantId: number // 1
  source: string // MT
  empId: string
  mis: string
  name: string
}

interface OrgHttpResponse<T> {
  message: string
  data: T
}

export class ORGEmployeeService extends AbstractHttpBAService {
  constructor() {
    super()
    this.ACCESS_KEY = KMSConfigKeyEnum.OrgClientId
    this.SECRET_KEY = KMSConfigKeyEnum.OrgClientSecret
    this.HOSTNAME = LionConfigKeyEnum.OrgHostName
    this.HOSTPORT = LionConfigKeyEnum.OrgHostPort
  }

  private async requestOrg<T>(options: RequestOptions, payload?: string) {
    const authApiInfo = await this.auth(options)
    authApiInfo.headers[HTTP.HeaderEnum.ORG_DATA_SCOPE] = 'tenantId=1;sources=ALL'

    return this.request<OrgHttpResponse<T>>(authApiInfo, payload)
      .then(res => {
        if (!res || res.message) {
          throw new IrisHttpRequestError(`调用 org http 接口失败: message=${res.message}`)
        }
        return res.data
      })
      .catch(e => {
        this.logger.logError(e, { message: '调用 org http 接口失败', options, payload })
        throw new IrisHttpRequestError(`调用 org http 接口失败: path=${options.path}`)
      })
  }

  /**
   * 根据 id 查询单个员工
   * @param empId
   * @returns
   */
  async queryByEmpId(empId: string) {
    try {
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/org2/emps/${empId}`,
        path: `/api/org2/emps/${empId}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      const ret = await this.requestOrg<OrgEmpInfo>(apiInfo)
      return ret
    } catch (error) {
      this.logger.logError(error, { message: 'request org info failed', empId })
      throw error
    }
  }

  /**
   * 根据 id 批量查询员工
   * 上限 200
   * @param empIdList
   * @returns
   */
  async queryByEmpIdList(empIdList: string[]) {
    try {
      if (!empIdList || !empIdList.length) return []

      const empIds = empIdList.join(',')
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/org2/emps/_batch`,
        path: `/api/org2/emps/_batch?empIds=${empIds}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      const ret = await this.requestOrg<OrgEmpInfo[]>(apiInfo)
      return ret
    } catch (error) {
      this.logger.logError(error, { message: 'request org info failed', empIdList })
      throw error
    }
  }

  /**
   * 根据 mis 批量查询员工
   * 上限 200
   * @param empMisList
   * @returns
   */
  async queryByEmpMisList(empMisList: string[]) {
    try {
      if (!empMisList || !empMisList.length) return []

      const mises = empMisList.join(',')
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/org2/emps/_batch`,
        path: `/api/org2/emps/_batch?mises=${mises}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      const ret = await this.requestOrg<OrgEmpInfo[]>(apiInfo)
      return ret
    } catch (error) {
      this.logger.logError(error, { message: 'request org info failed', empMisList })
      throw error
    }
  }

  /**
   * 根据 mis 查询单个员工
   * @param mis
   * @returns
   */
  async queryByEmpMis(mis: string) {
    try {
      const res = await this.queryByEmpMisList([mis])
      if (!res || !res.length) {
        throw new IrisUserNotFoundError(`数据不存在: mis=${mis}`)
      }
      return res[0]
    } catch (error) {
      this.logger.logError(error, { message: 'request org info failed', mis })
      throw error
    }
  }

  /**
   * 根据 mis 关键字搜索员工
   * 全匹配
   * @param fuzzyMis
   * @returns
   */
  async searchByEmpMis(fuzzyMis: string) {
    type ResponseData = { count: number; items: OrgEmpInfo[] }

    try {
      if (!fuzzyMis) return []

      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/org2/emps`,
        path: `/api/org2/emps?keyword=${fuzzyMis}&searchFields=mis&matchType=1`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      const res = await this.requestOrg<ResponseData>(apiInfo)
      if (!res || !res.items) {
        return []
      }
      return res.items.map(e => ({ mis: e.mis, name: e.name, empId: e.empId })) as OrgEmpInfo[]
    } catch (error) {
      this.logger.logError(error, { message: 'request org info failed', fuzzyMis })
      throw error
    }
  }

  /**
   * 根据 name 关键字搜索员工
   * 全匹配
   * @param fuzzyName
   * @returns
   */
  async searchByEmpName(fuzzyName: string) {
    type ResponseData = { count: number; items: OrgEmpInfo[] }

    try {
      if (!fuzzyName) return []

      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/org2/emps`,
        path: encodeURI(`/api/org2/emps?keyword=${fuzzyName}&searchFields=name&matchType=1`),
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      const res = await this.requestOrg<ResponseData>(apiInfo)
      if (!res || !res.items) {
        return []
      }
      return res.items.map(e => ({ mis: e.mis, name: e.name, empId: e.empId })) as OrgEmpInfo[]
    } catch (error) {
      this.logger.logError(error, { message: 'request org info failed', fuzzyName })
      throw error
    }
  }

  /**
   * 根据 mis name 关键字搜索员工
   * 全匹配
   * @param keyword
   * @returns
   */
  async searchByEmpNameAndEmpMis(keyword: string) {
    type ResponseData = { count: number; items: OrgEmpInfo[] }

    try {
      if (!keyword) return []

      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/org2/emps`,
        path: encodeURI(`/api/org2/emps?keyword=${keyword}&searchFields=name,mis&matchType=1`),
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      const res = await this.requestOrg<ResponseData>(apiInfo)
      if (!res || !res.items) {
        return []
      }
      return res.items.map(e => ({ mis: e.mis, name: e.name })) as OrgEmpInfo[]
    } catch (error) {
      this.logger.logError(error, { message: 'request org info failed', keyword })
      throw error
    }
  }
}
