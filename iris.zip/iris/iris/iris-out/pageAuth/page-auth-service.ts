import * as HTTP from 'iris/iris-lib/constants/http'
import { AbstractHttpService } from 'iris/iris-out/abstract-http-service'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'

enum EnvEnum {
  Test = 'test',
  Prod = 'production',
}

export enum AuthTypeEnum {
  Uac = 'uac',
  Dt = 'dtauth',
}

type env = EnvEnum.Test | EnvEnum.Prod

type authType = AuthTypeEnum.Uac | AuthTypeEnum.Dt

interface RegisterHttpResponse {
  id: string
}

export class AuthService extends AbstractHttpService {
  private uacUrl = '/api/v2/sdk/auth/authResource'
  private dtauthUrl = '/auth/authPermission'
  private async configuration() {
    const [
      UACDomain,
      UACDomainTest,
      dtauthDomain,
      dtauthDomainTest,
      authDomainTest,
      authDomain,
      gatewayGroupId,
      gatewayProjectId,
      registerGatewayPath,
      registerGatewayHostPort,
      registerGatewayHostName,
      registerGatewayHostPortTest,
      registerGatewayHostNameTest,
    ] = await Promise.all([
      LionClientService.fetchConfigValue(LionConfigKeyEnum.UACDomain),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.UACDomainTest),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.DtauthDomain),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.DtauthDomainTest),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.AuthDomainTest),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.AuthDomain),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.GatewayGroupId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.GatewayProjectId),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.RegisterGatewayPath),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.RegisterGatewayHostPort),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.RegisterGatewayHostName),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.RegisterGatewayHostPortTest),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.RegisterGatewayHostNameTest),
    ])
    return {
      UACDomain,
      UACDomainTest,
      dtauthDomain,
      dtauthDomainTest,
      authDomainTest,
      authDomain,
      gatewayGroupId,
      gatewayProjectId,
      registerGatewayPath,
      registerGatewayHostPort,
      registerGatewayHostName,
      registerGatewayHostPortTest,
      registerGatewayHostNameTest,
    }
  }
  async editGatewayAPI(params: { id?: string; env: env; authType: authType; name: string; path: string; secret: string; appKey: string }) {
    try {
      const {
        UACDomain,
        UACDomainTest,
        dtauthDomain,
        dtauthDomainTest,
        authDomainTest,
        authDomain,
        gatewayGroupId,
        gatewayProjectId,
        registerGatewayPath,
        registerGatewayHostPort,
        registerGatewayHostName,
        registerGatewayHostPortTest,
        registerGatewayHostNameTest,
      } = await this.configuration()
      const { id, env, authType, name, path, secret, appKey } = params
      let authApiDomain, authApiUrl, authApiMethod
      if (authType === AuthTypeEnum.Uac) {
        authApiUrl = this.uacUrl
        authApiDomain = env === EnvEnum.Test ? UACDomainTest : UACDomain
        authApiMethod = '2'
      } else {
        authApiUrl = this.dtauthUrl
        authApiDomain = env === EnvEnum.Test ? dtauthDomainTest : dtauthDomain
        authApiMethod = '1'
      }
      const requestParams = {
        hostname: env === 'test' ? registerGatewayHostNameTest : registerGatewayHostName,
        port: env === 'test' ? registerGatewayHostPortTest : registerGatewayHostPort,
        path: registerGatewayPath,
        method: HTTP.MethodEnum.POST,
        headers: {
          'Content-Type': 'application/json',
        },
      }
      const requestBody = {
        apiInfo: {
          id: id || null,
          name: name,
          groupId: gatewayGroupId,
          httpRoute: {
            id: null as unknown,
            methods: [0, 1, 2, 3, 4, 5, 6],
            domains: [env === EnvEnum.Test ? authDomainTest : authDomain],
            path,
            timeout: '1000000',
          },
          services: {
            simpleInfo: {
              openParallel: false,
              openSerial: true,
              shuntInfo: null as unknown,
              pipelineServices: [
                {
                  preTasks: null as unknown,
                  serviceInfo: {
                    serviceType: 2,
                    serviceInfo: JSON.stringify({
                      taskReferenceName: 'invoke-http1',
                      type: 'invoke-http',
                      timeout: '10000',
                      taskType: 'invoke-http',
                      directForwarding: ['Cookie', 'Header', 'Params', 'PathParams', 'RequestBody', 'Result'],
                      url: authApiUrl,
                      domain: authApiDomain,
                      methodValue: authApiMethod,
                      appKey,
                      secret,
                      parameters: null,
                      openTransmit: false,
                      needOriginDomain: false,
                      octoAppkey: null,
                      remoteCallTaskPostFilterModel: null,
                    }),
                  },
                  postTasks: null as unknown,
                },
              ],
              openShunt: false,
              openShuntCopy: false,
            },
            workflowInfo: {
              workflow: '',
            },
          },
          response: {
            successTemplate: {
              template: {
                type: 3,
                expression: "function extract(extractor) {\n    var result = extractor.extract('$.endpoint.output');\n    return result\n}",
              },
              defaultValue: null as unknown,
            },
            errorTemplate: {
              template: {
                type: 2,
                expression: '{"status":"$.exception.code","message":"$.exception.message"}',
              },
              defaultValue: null as unknown,
            },
            mockTemplate: {
              template: {
                type: 0,
                expression: '',
              },
              defaultValue: '',
            },
            contentType: '',
            useGWCode: true,
          },
          logInfo: {
            open: true,
            openDebug: true,
          },
          apiTasks:
            '[{"taskReferenceName":"CORS","type":"access-control-allow-filter","taskOrderType":"pre","taskDefEnum":"CROSS_DOMAIN","order":100,"taskType":"access-control-allow-filter"}]',
          wrapper: {
            wrapper: '',
          },
          appKey: gatewayProjectId,
        },
      }
      const result = await this.request<RegisterHttpResponse>(requestParams, JSON.stringify(requestBody))
      this.logger.logInfo(`注册网关api res:`, result)
      if (!result.id) {
        this.logger.logError(`注册网关api失败`, { requestBody, result })
        throw Error('注册网关api失败')
      }
      return {
        id: result.id,
        url: `https://${env === EnvEnum.Test ? authDomainTest : authDomain}${path}`,
      }
    } catch (error) {
      this.logger.logError(error, { message: `注册网关api失败`, params })
      throw error
    }
  }
}
