import * as HTTP from 'iris/iris-lib/constants/http'
import { AbstractHttpService } from 'iris/iris-out/abstract-http-service'
import { RequestOptions } from 'https'
import { BAHelper } from 'iris/iris-lib/helper/ba-helper'

interface UACMenuHttpResponse {
  code: string
  data: {
    businessSysCode: string
    businessSysName: string
    menuFolderList: Array<{ nodeId: number; resId: number; nodeCode: string; nodeName: string }>
    folderCount: number
  }
  message: string
  error?: {
    message: string
    code: number
  }
}

export class UACService extends AbstractHttpService {
  protected ACCESS_KEY: string
  protected SECRET_KEY: string
  protected HOSTNAME: string
  protected HOSTPORT: number
  protected ENV: string
  constructor(params: { clientId: string; secret: string; hostName: string; hostPort: number }) {
    super()
    this.ACCESS_KEY = params.clientId
    this.SECRET_KEY = params.secret
    this.HOSTNAME = params.hostName
    this.HOSTPORT = params.hostPort
  }

  async getUserMenus(uid: string) {
    try {
      // const [hostName] = (await this.configuration()) as string[]
      const requestParams: RequestOptions & { api: string } = {
        hostname: this.HOSTNAME,
        port: this.HOSTPORT,
        api: `/api/v2/sdk/auth/getUserMenus`,
        path: `/api/v2/sdk/auth/getUserMenus?uid=${uid}&tenantId=1&operatorId=${uid}`,
        method: HTTP.MethodEnum.POST,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      const { Authorization, Date } = BAHelper.create(requestParams, { clientId: this.ACCESS_KEY, clientSecret: this.SECRET_KEY })
      requestParams.headers[HTTP.HeaderEnum.DATE] = Date
      requestParams.headers[HTTP.HeaderEnum.AUTHORIZATION] = Authorization
      const result = await this.request<UACMenuHttpResponse>(requestParams, JSON.stringify({ uid }))
      if (result.code !== 'SUCCESS_STATUS') {
        this.logger.logError(`查询uac用户的菜单树失败`, { uid, httpRequest: requestParams, message: result })
      }
      return result
    } catch (error) {
      this.logger.logError(error, { message: `查询uac用户的菜单树失败`, uid })
      throw error
    }
  }
}
