import { AbstractHttpService } from 'iris/iris-out/abstract-http-service'
import { KMSSecretManageService, KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'
import { IrisTargetEnvEnum } from 'iris/iris-base/enum/common'
import * as HTTP from 'iris/iris-lib/constants/http'

interface PUHttpResponse {
  code: number
  data: { id: string }
  error: {
    message: string
    code: number
  }
}

export enum PU_ENUM_ENV {
  Test = 'test',
  Prod = 'production',
}

export type PU_ENV = PU_ENUM_ENV.Test | PU_ENUM_ENV.Prod

interface PURequest {
  projectId: string
  businessId: string
  name: string
  path: string
  owner: string[]
  createUser: string
  opener: string
  source: string
  desc?: string
  help?: string
  bizOwner?: string[]
  route?: string
  attr?: Record<string, any>
  input?: string
  output?: string
  appId?: string
}

interface PUPathModel {
  prod: {
    create: string
    modify: string
  }
  dev: {
    create: string
    modify: string
  }
}

export class PUService extends AbstractHttpService {
  constructor() {
    super()
  }

  // 标准注册pu 自动拼接参数
  async standardRegsterPu(params: {
    createUser: string
    pageTypeName?: string
    path: PUPathModel
    projectName: string
    pageName: string
    pageDesc: string
    pageId: string
    target: IrisTargetEnvEnum
    owner: string[]
    prodPUProjectId?: string
    testPUProjectId?: string
    projectId?: string
    pageContent?: string
    attr?: any
  }) {
    const {
      createUser,
      prodPUProjectId,
      testPUProjectId,
      pageTypeName,
      pageName,
      projectName,
      path,
      pageDesc,
      owner,
      pageId,
      target,
      attr,
      pageContent,
    } = params
    const [PUSource, standardPUProjectId] = await Promise.all([
      LionClientService.fetchConfigValue(LionConfigKeyEnum.PUSource),
      KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.PUProjectId),
    ])
    let PUProjectId
    if (target === IrisTargetEnvEnum.Production) {
      PUProjectId = prodPUProjectId
    } else {
      PUProjectId = testPUProjectId
    }
    const requestBody = {
      projectId: standardPUProjectId,
      businessId: `${standardPUProjectId}${pageId}`,
      name: `${projectName}-${pageName}-${pageTypeName || '其他'}`,
      owner,
      createUser,
      source: PUSource,
      opener: 'IFrame',
      path: JSON.stringify(path),
      desc: pageDesc || '',
      appId: PUProjectId || null,
      attr: attr || null,
      pageContent,
    }
    this.logger.logInfo('pu requestBody', requestBody)

    return this.registerPU(requestBody, target === IrisTargetEnvEnum.Production ? PU_ENUM_ENV.Prod : PU_ENUM_ENV.Test)
  }

  /**
   * 查询资产包
   * @param params
   * @returns
   */
  async registerPU(params: PURequest, env: PU_ENV) {
    try {
      const [PUHostPort, PUHostName] = await Promise.all([
        LionClientService.fetchConfigValue(env === PU_ENUM_ENV.Prod ? LionConfigKeyEnum.PUHostPort : LionConfigKeyEnum.PUHostPortTest),
        LionClientService.fetchConfigValue(env === PU_ENUM_ENV.Prod ? LionConfigKeyEnum.PUHostName : LionConfigKeyEnum.PUHostNameTest),
      ])
      const requestParams = {
        hostname: PUHostName,
        port: PUHostPort,
        path: `/operation/sync/node`,
        method: HTTP.MethodEnum.POST,
        headers: {
          'Content-Type': 'application/json',
        },
      }
      const result = await this.request<PUHttpResponse>(requestParams, JSON.stringify(params))
      if (result.code !== 200) {
        this.logger.logError(`注册pu失败`, { params, httpRequest: requestParams, message: result.error.message })
      }
      return result
    } catch (error) {
      this.logger.logError(error, { message: `注册pu失败`, params })
      throw error
    }
  }
}
