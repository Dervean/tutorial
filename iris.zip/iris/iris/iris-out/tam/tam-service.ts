const querystring = require('querystring')
import { RequestOptions } from 'https'
import * as HTTP from 'iris/iris-lib/constants/http'
import { KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { AbstractHttpBAService } from 'iris/iris-out/abstract-http-ba-service'
import { LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'

interface TamHttpResponse<T> {
  code: number
  data: T
  pageInfo?: {
    currentPageNum: number
    pageSize: number
    totalCount: number
    totalPageCount: number
  }
}

export class TamService extends AbstractHttpBAService {
  constructor() {
    super()
    this.ACCESS_KEY = KMSConfigKeyEnum.TamClientId
    this.SECRET_KEY = KMSConfigKeyEnum.TamClientSecret
    this.HOSTNAME = LionConfigKeyEnum.TamHostName
    this.HOSTPORT = LionConfigKeyEnum.TamHostPort
  }

  private async requestTam<T>(options: RequestOptions, payload = '') {
    const authApiInfo = await this.auth(options)
    return this.request<TamHttpResponse<T>>(authApiInfo, payload)
  }

  /**
   * 查询资产包
   * @param params
   * @returns
   */
  async getPackages(params: {
    assetType: string
    withComponent?: number
    tag?: string
    pageSize?: number
    pageNum?: number
    env?: string
    all?: number
  }) {
    type ResponseData = {
      list: {
        sort: Record<string, unknown>
        packages: unknown[]
        components: unknown[]
        version: string
      }[]
    }

    try {
      const args = querystring.stringify(params)
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/api/tam/paas/getPackages`,
        path: `/api/tam/paas/getPackages?${args}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      const ret = await this.requestTam<ResponseData>(apiInfo)
      return ret
    } catch (error) {
      this.logger.logError(error, { message: `请求 TAM 资产包失败`, params })
      throw error
    }
  }
}
