import moment from 'moment'
import { RequestOptions } from 'https'
import { AbstractHttpService } from 'iris/iris-out/abstract-http-service'
import { LionClientService, LionConfigKeyEnum } from 'iris/iris-out/lion/lion-client-service'
import { KMSSecretManageService, KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'
import { ConfigHelper } from 'iris/iris-lib/helper/config-helper'
import { IrisHttpRequestError, IrisWebStaticCanaryStrategyDeletedError } from 'iris/iris-lib/model/iris-error'
import * as HTTP from 'iris/iris-lib/constants/http'

export interface CanaryStrategyCustomItem {
  type: 'custom'
  value: string
  grayKey: string
  relation: 'in' | 'not in'
  grayPosition: 'cookie' | 'args' | 'header'
}

export interface CanaryStrategyPercentageItem {
  type: 'percentage'
  relation: '='
  value: number
}

export type CanaryStrategyItem = CanaryStrategyCustomItem | CanaryStrategyPercentageItem

export interface WebStaticCanaryStrategyModel {
  id?: string
  appkey?: string
  startTime?: string
  endTime?: string
  mis?: string
  desc?: string
  /** 灰度策略匹配路径（列表） */
  path?: string[]
  /** 策略名 */
  name?: string
  status?: 'on' | 'off'
  env?: 'test' | 'prod'
  strategy?: CanaryStrategyItem[][]
}

const DATETIME_FORMAT = 'YYYY-MM-DD HH:mm'

/**
 * api doc: https://km.sankuai.com/page/1540008951
 */
export class WebStaticAdminService extends AbstractHttpService {
  constructor() {
    super()
  }

  private async requestCanary<T>(userName: string, options: RequestOptions, payload?: string) {
    const [$1, $2, token] = await Promise.all([
      LionClientService.fetchConfigValue(LionConfigKeyEnum.WebStaticAdminV2HostName).then(hostname => (options.hostname = hostname)),
      LionClientService.fetchConfigValue(LionConfigKeyEnum.WebStaticAdminV2HostPort).then(port => (options.port = +port)),
      KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.WebStaticAdminToken),
    ])
    const env = ConfigHelper.getRuntimeEnv()
    /** 设置鉴权 */
    options.headers[HTTP.HeaderEnum.AUTHORIZATION] = `token ${token}`
    options.headers[HTTP.HeaderEnum.WEBSTATIC_ENV] = env === 'prod' ? 'prod' : 'test'
    options.headers[HTTP.HeaderEnum.WEBSTATIC_OPERATOR] = userName
    return this.request<T>(options, payload).catch(e => {
      this.logger.logError(`调用 webstatic http 接口失败`, { options, payload, e })
      switch (e?.code) {
        // 策略已删除
        case 15999:
          throw new IrisWebStaticCanaryStrategyDeletedError(e?.message)
        // 策略不存在
        case 15006:
          throw new IrisWebStaticCanaryStrategyDeletedError(e?.message)
        default:
          throw new IrisHttpRequestError(`调用 webstatic http 接口失败: path=${options.path}`)
      }
    })
  }

  async createCanaryStrategy(userName: string, payload: WebStaticCanaryStrategyModel) {
    try {
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/v2/gray-strategies`,
        path: `/v2/gray-strategies`,
        method: HTTP.MethodEnum.POST,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      const params = {
        appkey: ConfigHelper.getAppKey(),
        mis: userName,
        ...payload,
      }
      this.logger.logInfo(`WebStaticAdminService::createCanaryStrategy`, params)
      const ret = await this.requestCanary<WebStaticCanaryStrategyModel>(userName, apiInfo, JSON.stringify(params))
      return ret
    } catch (error) {
      this.logger.logError(error, { message: `创建灰度策略失败`, payload })
      throw error
    }
  }

  async updateCanaryStrategy(userName: string, strategyId: string, payload: WebStaticCanaryStrategyModel) {
    try {
      const appkey = ConfigHelper.getAppKey()
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/v2/gray-strategies/${appkey}/${strategyId}`,
        path: `/v2/gray-strategies/${appkey}/${strategyId}`,
        method: HTTP.MethodEnum.PATCH,
        headers: {
          [HTTP.HeaderEnum.CONTENT_TYPE]: 'application/json',
        },
      }
      const params = {
        appkey,
        mis: userName,
        ...payload,
      }
      this.logger.logInfo(`WebStaticAdminService::updateCanaryStrategy`, { strategyId, payload })
      const ret = await this.requestCanary<WebStaticCanaryStrategyModel>(userName, apiInfo, JSON.stringify(params))
      return ret
    } catch (error) {
      this.logger.logError(error, { message: `更新灰度策略失败`, payload })
      throw error
    }
  }

  async deleteCanaryStrategy(userName: string, strategyId: string) {
    try {
      const appkey = ConfigHelper.getAppKey()
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/v2/gray-strategies/${appkey}/${strategyId}`,
        path: `/v2/gray-strategies/${appkey}/${strategyId}`,
        method: HTTP.MethodEnum.DELETE,
        headers: {},
      }
      this.logger.logInfo(`WebStaticAdminService::deleteCanaryStrategy`, { strategyId })
      const ret = await this.requestCanary<{ deleted: number }>(userName, apiInfo)
      return ret
    } catch (error) {
      this.logger.logError(error, { message: `删除灰度策略失败`, strategyId })
      throw error
    }
  }

  /**
   * 获取策略
   * @param userName
   * @param strategyId
   * @returns
   */
  async getCanaryStrategy(userName: string, strategyId: string) {
    try {
      const appkey = ConfigHelper.getAppKey()
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/v2/gray-strategies/${appkey}/${strategyId}`,
        path: `/v2/gray-strategies/${appkey}/${strategyId}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.logger.logInfo(`WebStaticAdminService::getCanaryStrategy`, { strategyId })
      const ret = await this.requestCanary<WebStaticCanaryStrategyModel>(userName, apiInfo)
      return ret
    } catch (error) {
      this.logger.logError(error, { message: `查询灰度策略失败`, strategyId })
      throw error
    }
  }

  /**
   * 获取策略列表
   * @param userName
   * @returns
   */
  async getCanaryStrategyList(userName: string) {
    try {
      const appkey = ConfigHelper.getAppKey()
      const apiInfo: RequestOptions & { api?: string } = {
        api: `/v2/gray-strategies/${appkey}`,
        path: `/v2/gray-strategies/${appkey}`,
        method: HTTP.MethodEnum.GET,
        headers: {},
      }
      this.logger.logInfo(`WebStaticAdminService::getCanaryStrategyList`)
      const ret = await this.requestCanary<{ total: number; items: WebStaticCanaryStrategyModel[] }>(userName, apiInfo)
      return ret
    } catch (error) {
      this.logger.logError(error, { message: `查询灰度策略列表失败` })
      throw error
    }
  }

  /**
   * 返回 webstatic 的日期格式字符串
   * 默认当下时间
   * @param forever 是否永久
   * @returns
   */
  public processDatetime(forever = false) {
    let target = moment()
    if (forever) {
      target = moment().year(2099)
    }
    return target.format(DATETIME_FORMAT)
  }
}
