import { KMSSecretManageService, KMSConfigKeyEnum } from 'iris/iris-out/kms/kms-secret-manage-service'

import { IrisKMSError } from 'iris/iris-lib/model/iris-error'
import { ConfigHelper } from 'iris/iris-lib/helper/config-helper'
import { IrisLogger } from 'iris/iris-lib/model/iris-logger'

const WebStatic = require('@bfe/webstatic')

interface WebStaticDeployResponse {
  eventUuid: string
  message: string
  session: string
}

export class WebStaticClientService {
  private async getToken() {
    const logger = new IrisLogger()
    return KMSSecretManageService.fetchConfigValue(KMSConfigKeyEnum.WebStaticCliToken).catch((error: any) => {
      logger.logError(error)
      throw new IrisKMSError(error.message)
    })
  }

  public async deploy(artifact: Buffer, strategyId?: string): Promise<WebStaticDeployResponse> {
    const token = await this.getToken()
    // const swimlane = process.env.NEST_SWIMLANE
    return WebStatic.deploy({
      appkey: ConfigHelper.getAppKey(),
      env: this.env(),
      token,
      artifact,
      ...(strategyId ? { gray: strategyId } : {}),
    })
  }

  private env() {
    const env = ConfigHelper.getRuntimeEnv()
    switch (env) {
      case 'dev':
      case 'test':
        return 'test'
      case 'prod':
        return 'prod'
    }
  }
}
