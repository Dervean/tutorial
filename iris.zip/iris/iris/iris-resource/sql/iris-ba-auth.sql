CREATE TABLE `iris_ba_auth` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `client_id` varchar(16) NOT NULL COMMENT '16-bit ba client id',
  `client_secret` varchar(32) NOT NULL COMMENT '32-bit ba client secret',
  `user_id` varchar(32) NOT NULL COMMENT '负责人',
  `name` varchar(64) NOT NULL COMMENT '名称',
  `description` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_id_secret`(`client_id`, `client_secret`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='BA 认证信息表';