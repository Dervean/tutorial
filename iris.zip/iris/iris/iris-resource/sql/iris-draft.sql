CREATE TABLE `iris_draft` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '草稿 id',
  `page_id` bigint(20) unsigned NOT NULL COMMENT '页面 id',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '项目 id',
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'org emp id',
  `dsl` json DEFAULT NULL COMMENT '草稿 JSON',
  `sync_version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '同步版本号',
  `sync_version_test` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '同步泳道版本号',
  `sync_version_test01` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '同步测试主干版本号',
  `swimlane` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '泳道号',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_page_user` (`page_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=659 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='草稿表'