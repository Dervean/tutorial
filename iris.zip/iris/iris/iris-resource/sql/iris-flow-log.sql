CREATE TABLE `iris_flow_log` (
  `id` varchar(32) NOT NULL COMMENT '流程任务 ID, 流程任务表主键',
  `order_id` varchar(32) NOT NULL COMMENT '流程实例 ID, 流程实例表主键',
  `task_id` varchar(32) DEFAULT NULL COMMENT '流程任务 ID, 流程任务表主键',
  `level` varchar(16) NOT NULL COMMENT '日志级别',
  `content` JSON COMMENT '日志内容',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='流程日志表'