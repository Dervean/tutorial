CREATE TABLE `iris_flow_process` (
  `process_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程定义 ID, 流程定义表主键',
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程定义名称',
  `display_name` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '流程定义显示名称',
  `version` int(10) unsigned NOT NULL COMMENT '版本',
  `content` blob COMMENT '流程定义 XML',
  `created_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`process_id`),
  UNIQUE KEY `uniq_name_key_version` (`name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='流程定义表'