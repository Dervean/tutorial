CREATE TABLE `iris_flow_task` (
  `task_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程任务 ID, 流程任务表主键',
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程任务名称',
  `display_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程任务显示名称',
  `state` tinyint(4) NOT NULL COMMENT '状态',
  `state_desc` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '状态描述',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程实例 ID, 流程实例表主键',
  `perform_type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '任务类型',
  `parent_task_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '父任务 ID',
  `operator` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '处理人',
  `tag` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tag',
  `actors` json DEFAULT NULL COMMENT '参与人',
  `variable` json DEFAULT NULL COMMENT '变量',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`task_id`),
  KEY `idx_state_order_id` (`state`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='流程任务表'