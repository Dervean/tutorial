CREATE TABLE `iris_html_canary_strategy` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '灰度策略 id',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程实例 ID, 流程实例表主键',
  `page_id` bigint(20) unsigned NOT NULL COMMENT '页面 id',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '项目 id',
  `canary_args` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '灰度参数',
  `origin_args` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主干参数',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '灰度版本',
  `state` tinyint(4) NOT NULL COMMENT '状态',
  `state_desc` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '状态描述',
  `online_time` datetime DEFAULT NULL COMMENT '上线时间',
  `offline_time` datetime DEFAULT NULL COMMENT '下线时间',
  `created_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_canary_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='页面灰度策略表';