CREATE TABLE `iris_html_version` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'id',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程实例 ID',
  `page_id` bigint(20) unsigned NOT NULL COMMENT '页面 id',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '项目 id',
  `target` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '发布环境',
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '发布类型',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号',
  `container_id` bigint(20) unsigned NOT NULL COMMENT '页面容器 ID',
  `container_version` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '页面容器版本号',
  `remark` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人备注',
  `created_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `swimlane` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'swimlane',
  `md5` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'md5',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_page_version` (`page_id`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='页面版本表';