CREATE TABLE `iris_page` (
  `page_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '页面ID',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '项目 id',
  `page_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '页面名称',
  `path` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '页面路径',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `description` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '页面描述',
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  `scene_id` bigint(20) unsigned NOT NULL COMMENT '场景 id',
  `engine_version` bigint(20) NOT NULL COMMENT '编辑器引擎版本',
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `uniq_proj_path` (`project_id`,`path`)
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='页面表'