CREATE TABLE `iris_project_member` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '项目 id',
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'org emp id',
  `permission` int(10) unsigned NOT NULL COMMENT '权限 32-bit integer',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_proj_user` (`project_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目成员信息表'