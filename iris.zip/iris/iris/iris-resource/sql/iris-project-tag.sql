CREATE TABLE `iris_project_tag` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '项目 ID',
  `tag_id` bigint(20) unsigned NOT NULL COMMENT '标签 ID',
  `created_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_tag` (`tag_id`,`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目标签关系表'