CREATE TABLE `iris_project` (
  `project_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `project_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '项目名称',
  `is_private` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否私有',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `description` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '项目描述',
  `icon` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'icon',
  `config` json DEFAULT NULL COMMENT '页面容器注入属性',
  `leader` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '项目负责人',
  `created_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作人',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2495 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目表'