CREATE TABLE `iris_tag` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '标签 ID',
  `parent_tag_id` bigint(20) unsigned DEFAULT NULL COMMENT '标签父级ID',
  `source` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签来源',
  `tag_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签类型',
  `tag_value` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签值',
  `tag_name` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签名称',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '标签状态 删除(-1) 生效(1)',
  `created_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '变更时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_tag` (`source`,`tag_type`,`tag_value`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='标签表'