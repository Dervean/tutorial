CREATE TABLE `iris_task_page` (
  `task_id` bigint(20) unsigned NOT NULL COMMENT '任务ID',
  `page_id` bigint(20) unsigned NOT NULL COMMENT '页面ID',
  PRIMARY KEY (`task_id`,`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务和页面关联表'