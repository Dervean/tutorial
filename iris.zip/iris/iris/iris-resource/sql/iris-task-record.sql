CREATE TABLE `iris_task_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '任务执行记录ID',
  `task_id` bigint(20) unsigned NOT NULL COMMENT '任务ID',
  `workflow_id` bigint(20) unsigned NOT NULL COMMENT '工作流ID',
  `order_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程实例ID',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '执行状态',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '上线描述',
  `error_msg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '错误原因',
  `created_by` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '创建人',
  `updated_by` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最近一次更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_task_workflow` (`task_id`,`workflow_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务执行记录表'