include "Model.thrift"

service IrisFlow {
  Model.ProcessDTO deployProcess(1:binary model, 2:string creator);
  
  Model.ProcessDTO getProcessById(1:string processId);

  Model.ProcessDTO getLatestVersionProcess(1:string processName);

  Model.OrderDTO createOrderByProcessName(1:string processName, 2:string operator, 3:string variable, 4:string remark);

  Model.OrderDTO createOrderByProcessId(1:string processId, 2:string operator, 3:string variable, 4:string remark);

  Model.OrderDTO getOrder(1:string orderId);
  
  Model.OrderDTO trigger(1:string orderId, 2:string tag, 3:string operator, 4:string variable);

  void terminateOrder(1:string orderId)

  Model.TaskListDTO getActiveTasks(1:Model.QueryFilterDTO filter);

  Model.TaskListDTO getTasks(1:string orderId);

  void destroyTask(1:string taskId, 2:string operator);

  void terminateTask(1:string taskId, 2:string operator);
}
