struct Log {
  1:optional string type,
  2:optional string content,
  3:optional string datetime,
}

struct FlowProcess {
  1:required string processId,
  2:required string name,

  3:optional string displayName,
  4:optional i64 version,
  5:optional string createdBy,
  6:optional string createTime,
  7:optional string updatedBy,
  8:optional string updateTime,
}

struct FlowOrder {
  1:required string orderId,
  2:required string processId,
  3:required string processName,

  4:optional i16 state,
  5:optional string stateDesc,
  6:optional string createdBy,
  7:optional string remark,
  8:optional string parentId,
  9:optional string parentNodeName,
  10:optional string variable,
  11:optional string createTime,
  12:optional string updatedBy,
  13:optional string updateTime,
  14:optional list<Log> logs,
}

struct FlowTask {
  1:required string taskId,
  2:required string name,
  3:required string orderId,

  4:optional i16 state,
  5:optional string stateDesc,
  6:optional string displayName,
  7:optional string performType,
  8:optional string parentTaskId,
  9:optional string operator,
  10:optional list<string> actors,
  12:optional string createTime,
  13:optional string updateTime,
  14:optional list<Log> logs,
}

struct ProcessDTO {
  1:required i16 code,
  2:optional string message,

  3:optional FlowProcess data,
}

struct OrderDTO {
  1:required i16 code,
  2:optional string message,

  3:optional FlowOrder data,
}

struct TaskListDTO {
  1:required i16 code,
  2:optional string message,

  3:optional list<FlowTask> data,
}

struct QueryFilterDTO {
  1:optional string orderId,
}

