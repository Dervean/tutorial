include "Model.thrift"

service Iris {
  void uploadBetaVersionHtml(1:Model.FlowExecution execution);
  void releaseBetaVersionHtml(1:Model.FlowExecution execution);

  void uploadProdVersionHtml(1:Model.FlowExecution execution);
  void releaseProdVersionHtml(1:Model.FlowExecution execution);
  
  void rollbackProdVersionHtml(1:Model.FlowExecution execution);

  void completeHtmlReleaseOrder(1:Model.FlowExecution execution);

  void handleIrisFlowRemoteCall(1:string handleClazz, 2:Model.FlowExecution execution);
}
