/**
 * 计算复利
 * @param year 第 x 年
 * @param delta 每年新增本金
 * @param ratio 每年盈利比例
 * @returns 第 x 年余额
 */
const compoundInterest = (year: number, delta = 15, ratio = 0.3): number => {
  if (year <= 0) {
    return 0
  }
  const last = compoundInterest(year - 1, delta, ratio)
  return (last + delta) * (1 + ratio)
}

console.log('ret :>> ', compoundInterest(5, 30))
