module.exports = {
  roots: ['<rootDir>/iris/'],
  testMatch: ['**/__tests__/**/index.ts'],
  globalSetup: '<rootDir>/jest/setup.ts',
  globalTeardown: '<rootDir>/jest/teardown.ts',
  moduleNameMapper: {
    '^iris/(.*)': '<rootDir>/iris/$1',
  },
  transform: {
    '^.+\\.ts$': 'ts-jest',
  },
  testTimeout: 15000,
  // collectCoverage: true,
  // collectCoverageFrom: [
  //   "**/*.ts",
  //   "!**/__tests__/*.ts"
  // ],
  // coverageReporters: ['html', 'text-summary'],
}
