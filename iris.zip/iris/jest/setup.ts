import { addAlias } from 'module-alias'
import { posix } from 'path'

module.exports = async () => {
  process.env.IRIS_RUNTIME_ENV = 'jest'
  await addAlias('iris', posix.join(__dirname, '..', 'iris'))
}
